#include <string>
#include <iostream>
#include <fstream>
#include "csvfile.h"
#include "CommonApi.h"



using namespace std;

#pragma once

namespace Components
{
	static CCriticalSection g_components_cs;
};


class CComponentsInfo
{
public:
	string manufacturer;
	string location;
	string gpn;
	string mpn;
	string serial_number;
	string batch_name;
	string date_code;
	string part_description;
	string part_type;
	string part_rerision;
	string quantity;
	string supplier;
};


class CComponents : public CCSvFile
{
private:
	CComponents() : CCSvFile("", "") {
	};

public:
	~CComponents() {
	};

	static CComponents* getInstance() {
		static auto_ptr<CComponents> pObj(new CComponents);
		return pObj.get();
	};

	void SetPathName(const char* name, const char* dir) {
		m_file_name = name;
		strcpy_s(m_rdlog_dir, dir);
		m_full_name = dir;
		m_full_name = m_full_name + "\\" + m_file_name + ".csv";
	}

	void WriteCComponents(CComponentsInfo& info, bool current_datatime = true) {
		char datetime[32];
		string data;
		string file;

		if (current_datatime == true) {
			GetDateTime(datetime, _countof(datetime));
			//info.data_time = datetime;
		}

		data = info.manufacturer + "," + info.location + "," + info.gpn + "," + info.mpn + ","
			+ info.serial_number + "," + info.batch_name + "," + info.date_code + "," + info.part_description + ","
			+ info.part_type + "," + info.part_rerision + "," + info.quantity + "," + info.supplier + "\n";

		if (!IsFileExist(m_full_name)) {
			WriteLog("MANUFACTURER,LOCATION,GPN,MPN,SERIAL_NUMBER,BATCH_CODE,DATE_CODE,PART_DESCRIPTION,PART_TYPE,PART_REVISION,QUANTITY,SUPPLIER\n");
		}
		WriteLog(data.c_str());
	}
};