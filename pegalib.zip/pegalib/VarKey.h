#pragma once


static const char SFIS_MO[] = { "SFIS_MO" };
static const char SFIS_SKU[] = { "SFIS_SKU" };
static const char SFIS_CONFIG[] = { "SFIS_CONFIG" };
static const char META_CONFIG[] = { "META_CONFIG" };
static const char WRITE_TO_CSV[] = { "Write2Csv" };
static const char LIMIT_BY_SKU[] = { "LimitBySku" };
static const char LAST_REC[] = { "LAST_REC" };
