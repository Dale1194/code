
#include "stdafx.h"
#include <string>
#include <iostream>
#include <fstream>


using namespace std;

#pragma once

class CFileStatusList
{
public:
	CFileStatusList(const char* path, const char* station_name, const char* dev_id) {
		SYSTEMTIME today;

		::GetLocalTime(&today);
		sprintf_s(m_file_name, "%s_%s_%.4d%.2d%.2d.filelist", station_name, dev_id, today.wYear, today.wMonth, today.wDay);
		sprintf_s(m_full_name, "%s\\%s", path, m_file_name);
	};

	~CFileStatusList() {
	};

	void AddContent(const char* content) {
		FILE* file;
		errno_t ret = fopen_s(&file, m_full_name, "a");
		if (ret == 0) {
			fputs(content, file);
			fputs("\n", file);
			fclose(file);
		}
		else {
			string s = string("failed to open file [") + m_full_name + "]";
			::OutputDebugStringA(s.c_str());
		}
	};

	void CopyTo(const char* path) {
		string target_path = string(path) + "\\" + m_file_name;
		
		if (::CopyFileA(m_full_name, target_path.c_str(), false) == FALSE)
		{
			string s = string("failed to copy file [") + target_path + "]";
			//::MessageBoxA(NULL, s.c_str(), "Warning!", MB_OK);
		}
	};


private:
	char	m_file_name[128];
	char	m_full_name[1024];
};