#include "StdAfx.h"
#include "Dut.h"
#include "Config.h"
#include "CommonApi.h"
#include "Iphlpapi.h"
#include "SFIS_Api.h"
#include <direct.h>
#include <regex>
#include "io.h"



extern HWND	g_uiwnd;

int CDut::cmd_als_test(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string append_name = PARAM_S("append_name");
	string adb_cmd = PARAM_S("adb_cmd");
	int times = PARAM_N("times");
	string data_name = PARAM_S("data_name");
	string adb_result;
	string reg_rule = "\\d{1,2}[.]\\d{1,6}";
	std::tr1::regex rx;
	smatch reg_result;
	string ls_value;
	vector<float> als_value;
	char new_item_name[64];
	char temp[64];

	rx.assign(reg_rule, regex_constants::icase);

	m_rdlog->WriteLogf(" adb_cmd:%s\n", adb_cmd.c_str());

	for (int n = 0; n < times; n++)
	{
		ret = adb_command(adb_cmd.c_str(), adb_result);
		m_rdlog->WriteLogf(" adb_result(%d):%s<:)\n", n, adb_result.c_str());

		if (ret == RET_SUCCESS)
		{
			if (regex_search(adb_result, reg_result, rx) == true)
			{
				ls_value = reg_result[0].str();
				als_value.push_back((float)atof(ls_value.c_str()));
			}
		}
	}

	for (unsigned int n = 0; n < als_value.size(); n++)
	{
		sprintf_s(new_item_name, "%s%sRAW_%d", item, append_name.c_str(), n);
		log_sfis_and_set_info_no_judge(new_item_name, CSfisCsv::Pass, als_value[n]);
	}

	ret = RET_SUCCESS;

	sprintf_s(new_item_name, "%s%sMAX", item, append_name.c_str());
	ret += log_sfis_and_set_info(new_item_name, *max_element(als_value.begin(), als_value.end()));

	sprintf_s(new_item_name, "%s%sMIN", item, append_name.c_str());
	ret += log_sfis_and_set_info(new_item_name, *min_element(als_value.begin(), als_value.end()));

	sprintf_s(new_item_name, "%s%sAVE", item, append_name.c_str());
	ret += log_sfis_and_set_info(new_item_name, calc_ave(als_value));

	sprintf_s(temp, "%1.4f", calc_ave(als_value));
	m_var[data_name] = temp;

	sprintf_s(new_item_name, "%s%sNOISE", item, append_name.c_str());
	ret += log_sfis_and_set_info(new_item_name, calc_noise(als_value));

	if (ret == RET_FAIL)
		m_exit_test = true;

	return ret;
}

