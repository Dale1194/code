/*******************************************************************************
 * Copyright Statement:
 * --------------------
 * BU3-SW Div.-ATS Dept.-Sec.1
 * PEGATRON CORPORATION (C) 2008-2010
 *
 ******************************************************************************/

/*******************************************************************************
 *==============================================================================
 * Filename:
 * ---------
 *  DOSCommand.h
 *
 * Project:
 * --------
 *  ALL
 *
 * Description:
 * ------------
 *  DOS Command Send/Receive
 *
 * Author:
 * -------
 *  Achigo_Liu@pegatroncorp.com	(#33959)
 *
 *	Rev	1.0.0	March	11	2010
 *==============================================================================
********************************************************************************/
#ifndef _DOSCOMMAND_SRC_H
#define _DOSCOMMAND_SRC_H

#include "windows.h"
#include "stdio.h"
#include "assert.h"
#include <string>
//#include "ReturnType.h"

using namespace std;

class CDOS
{
public:

	CDOS();
	virtual ~CDOS();

public:
	INT Send(CHAR *pcCommand, CHAR *pcMessage);
	int Send(const char* command, string& result, unsigned int timeout, unsigned int wait = 97, unsigned int timeout_noresponse = 10000);
	int Send(const char* command, string& result, const char* tmnl, unsigned int wait, unsigned int timeout);

public:
	// for Wifi resolve ip address
	INT InitConsole();
	INT TerminalCommand(CHAR *pcCommand, CHAR *pcMessage);
	INT TerminalFileUpload(CHAR *pcCommand, INT iTimeOut, INT* iExeTime, char *pFile);
	INT WifiMacFormat(CONST CHAR *pcInputWifiMac, CHAR *pcNewWifiMac);
	INT FindIPAddress(CHAR *pcCmdBuffer, CHAR *pcWifiMac, CHAR *pcIP);
	INT ResolveIP(CONST CHAR *pcMacAddress, CHAR *pcIP);\

	HANDLE	m_hThread;
	DWORD	m_dwThreadID;
	HANDLE	m_hInWriteData;
	HANDLE	m_hOutReadData;

	HANDLE	m_hInTerWrite;
	HANDLE	m_hOutTerRead;
	CHAR	m_szMessage[4096];
	BOOL	m_bEnableConsole;

	static DWORD WINAPI Thread_Console(LPVOID param);
};



#endif // End of _ADBCOMMAND_SRC_H
