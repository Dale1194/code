

#pragma once


class CMyEvent
{
private:
	HANDLE m_hEvent;
public:
	void Reset(){
		ResetEvent(m_hEvent);
	};
	void Set(){
		SetEvent(m_hEvent);
	};
	BOOL Unlook(DWORD dwTimeout = INFINITE){
		DWORD dwRet = WaitForSingleObject(m_hEvent, dwTimeout);
		if ( WAIT_TIMEOUT == dwRet )
			return TRUE;
		else
			return FALSE;
	};
	CMyEvent(){
		m_hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	};
	~CMyEvent(){
		CloseHandle(m_hEvent);
	};

};

