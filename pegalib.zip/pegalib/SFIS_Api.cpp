#include "stdafx.h"
#include "SFIS_Api.h"


CSFIS_Api::CSFIS_Api() :m_hDLL(NULL), m_err_code(NULL)
{
	::OutputDebugStringA("CSFIS_Api::CSFIS_Api()");
	LOAD_DLL();
	memset(&m_sfis_st, 0, sizeof(m_sfis_st));
}

CSFIS_Api::~CSFIS_Api() 
{
	if(m_hDLL)
	{
		::OutputDebugStringA("CSFIS_Api::~CSFIS_Api()");
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
	if (m_err_code)
	{
		delete m_err_code;
	}
}

INT CSFIS_Api::LOAD_DLL()
{
    INT	iStatus = ERROR_SUCCESS;

	//char curr_dir[MAX_PATH];
	char dll_file[MAX_PATH];
	string curr_dir;

	GetCurrentPath(curr_dir);
	//GetCurrentDirectory(_countof(curr_dir), curr_dir);
	sprintf_s(dll_file, "%s\\SFISWS.dll", curr_dir.c_str());

	m_hDLL = ::LoadLibraryA(dll_file);
	if(NULL == m_hDLL)
	{
		::MessageBoxA(NULL, "LoadLibrary SFISWS.dll Fail.", NULL, NULL);
		iStatus = ::GetLastError();
	}        
	else
    {	
        m_pfnSFIS_Connect		= (SFIS_CONNECT)::GetProcAddress(m_hDLL, "SFIS_Connect");
        m_pfnSFIS_Disconnect	= (SFIS_DISCONNECT)::GetProcAddress(m_hDLL, "SFIS_Disconnect");
        m_pfnSFIS_Login			= (SFIS_LOGIN)::GetProcAddress(m_hDLL, "SFIS_Login");
        m_pfnSFIS_CheckRoute	= (SFIS_CHECKROUTE)::GetProcAddress(m_hDLL, "SFIS_CheckRoute");
        m_pfnSFIS_TestResult	= (SFIS_TESTRESULT)::GetProcAddress(m_hDLL, "SFIS_TestResult");
        m_pfnSFIS_Repair		= (SFIS_REPAIR)::GetProcAddress(m_hDLL, "SFIS_Repair");
		m_pfnSFIS_GetVersion	= (SFIS_GETVERSION)::GetProcAddress(m_hDLL, "SFIS_GetVersion");
		m_pfnSFIS_GetI1394		= (SFIS_GETI1394)::GetProcAddress(m_hDLL, "SFIS_GetI1394");
		m_pfnSFIS_GetIMAC		= (SFIS_GETIMAC)::GetProcAddress(m_hDLL, "SFIS_GetIMAC");
		m_pfnSFIS_GenErrorCode	= (SFIS_GENERRORCODE)::GetProcAddress(m_hDLL,"SFIS_GenErrorCode");
		m_pfnSFIS_LoadKey		= (SFIS_LOADKEY)::GetProcAddress(m_hDLL,"SFIS_LoadKey");

        if( !m_pfnSFIS_Connect || !m_pfnSFIS_Disconnect || !m_pfnSFIS_Login ||
            !m_pfnSFIS_CheckRoute || !m_pfnSFIS_TestResult || !m_pfnSFIS_GetVersion || 
			!m_pfnSFIS_Repair || !m_pfnSFIS_GenErrorCode || !m_pfnSFIS_LoadKey ||
			!m_pfnSFIS_GetI1394 || !m_pfnSFIS_GetIMAC)
        {
			::FreeLibrary(m_hDLL);
			::MessageBoxA(NULL, "Load Function Point Fail.", NULL, NULL);
            iStatus = ::GetLastError(); 
        }
    }

    return iStatus;
}
INT CSFIS_Api::UNLOAD_DLL(VOID)
{
	if(m_hDLL)
	{
		::OutputDebugStringA("CSFIS_Api->UNLOAD_DLL()");
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
	return ERROR_SUCCESS;
}

void CSFIS_Api::output_debug(char *fmt, ...)
{
	char buffer[1024];
	va_list	list;

	va_start(list, fmt);
	vsprintf_s(buffer, _countof(buffer), fmt, list);
	va_end(list);
	::OutputDebugStringA(buffer);
}

int CSFIS_Api::Init(SFIS_INTERFACE& sfis_st)
{
	memcpy(&m_sfis_st, &sfis_st, sizeof(m_sfis_st));

	m_err_code = new CErrorCode(m_sfis_st.szErrorCodeFile);

	return ERROR_SUCCESS;
}

int CSFIS_Api::CheckConnection()
{
	INT iStatus = ERROR_SUCCESS;

	iStatus = m_pfnSFIS_Connect(m_sfis_st);
	DBGTRACE(("SFIS: %s", m_sfis_st.szMessage));

	return iStatus;
}

int CSFIS_Api::Login(const char* user_id)
{
	INT iStatus = ERROR_SUCCESS;

	m_sfis_st.szMessage[0] = 0;
	strcpy_s(m_sfis_st.szUserID, user_id);
	strcpy_s(m_sfis_st.szUserPassword, "1");
	strcpy_s(m_sfis_st.szLoginMode, SP_LOGIN);

	iStatus = m_pfnSFIS_Login(m_sfis_st);
	if(ERROR_SUCCESS != iStatus)
	{
		strcpy_s(m_sfis_st.szLoginMode, SP_LOGOUT);
		iStatus = m_pfnSFIS_Login(m_sfis_st);

		strcpy_s(m_sfis_st.szLoginMode, SP_LOGIN);
		iStatus = m_pfnSFIS_Login(m_sfis_st);
	}
	DBGTRACE(("SFIS: %s", m_sfis_st.szMessage));
	return iStatus;
}

int CSFIS_Api::Logout()
{
	INT iStatus = ERROR_SUCCESS;

	strcpy_s(m_sfis_st.szLoginMode, SP_LOGOUT);
	iStatus = m_pfnSFIS_Login(m_sfis_st);
	return iStatus;
}

int CSFIS_Api::GenerateErrorCode(const char* csv_file, string& error_code)
{
	INT	iStatus = ERROR_SUCCESS;

	m_sfis_st.szErrorCode[0] = 0x00;
	strcpy_s(m_sfis_st.szLogFile, csv_file);

	iStatus = m_pfnSFIS_GenErrorCode(m_sfis_st);
	if(ERROR_SUCCESS != iStatus)
	{
		return iStatus;
	}
	error_code = m_sfis_st.szErrorCode;
	return iStatus;
}

int CSFIS_Api::GenerateErrorCode(CSfisCsv* sfis_csv, string& err_code)
{
	string err_item = sfis_csv->GetFirstFailItem();
	string err_sfis_item = sfis_csv->GetFailSfisItem();

	strcpy_s(m_sfis_st.szLogStreamData, "\"TEST\",\"STATUS\",\"VALUE\",\"U_LIMIT\",\"L_LIMIT\"\n");

	if (sfis_csv->HaveHashtagSaveItem())
	{
		strcat_s(m_sfis_st.szLogStreamData, sfis_csv->GetHashtagSaveItem());
	}

	if (strlen(err_item.c_str()) == 0)
	{
		m_sfis_st.szErrorCode[0] = 0;
		m_sfis_st.szErrorItem[0] = 0;
	}
	else
	{
		m_err_code->GetErrorCode(err_item.c_str(), err_code);
		//err_code = "WIEOTR"; ///Hai add 22/07/29
		strcpy_s(m_sfis_st.szErrorCode, err_code.c_str());
		strcpy_s(m_sfis_st.szErrorItem, err_item.c_str());
		strcat_s(m_sfis_st.szLogStreamData, err_sfis_item.c_str());
	}
	//output_debug("\nm_sfis_st.szLogStreamData:\n%s", CSFIS_Api::getInstance()->m_sfis_st.szLogStreamData);  ///Hai add 22/07/30
	return 0;
}

void CSFIS_Api::ListItemsWithoutErrorCode(CSfisCsv* sfis_csv, string& items)
{
	const vector<string>* all_items = sfis_csv->GetAllItems();
	for each (string item in *all_items)
	{
		if (!m_err_code->IsErrorCodeExist(item.c_str()))
		{
			items = items + item + ";";
		}
	}
}

