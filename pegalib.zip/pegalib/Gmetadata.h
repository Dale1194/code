
#include <string>
#include <iostream>
#include <fstream>
#include "csvfile.h"




using namespace std;

#pragma once

class CGmetadata : public CCSvFile
{
public:
	CGmetadata(const char* name, const char* dir) : CCSvFile(name, dir) {
	};

	~CGmetadata() {
	};

	void WriteMetadata() {
		WriteLog("DUT_ID,TEST_NAME,TEST_DESCRIPTION,DEVICE_CONFIG,SPEC_VERSION,STATION_ID,LINE,LINE_ID,SOFTWARE_VERSION,FRAMEWORK_VERSION,TEST_VERSION,FIRMWARE_VERSION,MODE,STATUS,FAILURE_CODE,BUILD_PHASE,START_DATE_TIME,END_DATE_TIME\n");
		WriteLogf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", dut_id.c_str(), test_name.c_str(), test_description.c_str(), device_config.c_str(), spec_version.c_str(), station_id.c_str(), line.c_str(), line_id.c_str(), software_version.c_str(), framework_version.c_str(), test_version.c_str(), firmware_version.c_str(), mode.c_str(), status.c_str(), failure_code.c_str(), build_phase.c_str(), start_date_time.c_str(), end_date_time.c_str());
	}

public:
	string dut_id;
	string test_name;
	string test_description;
	string device_config;
	string spec_version;
	string station_id;
	string line;
	string line_id;
	string software_version;
	string framework_version;
	string test_version;
	string firmware_version;
	string mode;
	string status;
	string failure_code;
	string build_phase;
	string start_date_time;
	string end_date_time;
};