
#include <string>
#include <iostream>
#include <fstream>
#include "csvfile.h"
#include "CommonApi.h"



using namespace std;

#pragma once

namespace CheckPoint
{
	static CCriticalSection g_checkpoint_cs;
};


class CCheckPointInfo
{
public:
	string manufacturer;
	string location;
	string gpn;
	string mpn;
	string serial_number;
	string station_name;
	string station_id;
	string station_type;
	string line;
	string line_id;
	string op_id;
	string data_time;
	string build_phase;
	string status;
	string failure_code;
	string remarks;
};


class CCommonInfo
{
public:
	CCommonInfo() {};
	virtual ~CCommonInfo() {};

	void Add(const char* field_name, const char* field_val) {
		m_field.clear();
		m_field[field_name] = field_val;
		m_row.append(m_field);
	}

	void GetHeader(string& header) {
		header.clear();
		for (unsigned int n = 0; n < m_row.size(); n++) {
			if (n == 0)
				header = m_row[n].getMemberNames()[0];
			else
				header = header + "," + m_row[n].getMemberNames()[0];
		}
		header += "\n";
	}

	void GetRow(string& row) {
		row.clear();
		for (unsigned int n = 0; n < m_row.size(); n++) {
			if (n == 0)
				row = m_row[n][m_row[n].getMemberNames()[0]].asString();
			else
				row = row + m_row[n][m_row[n].getMemberNames()[0]].asString();
		}
		row += "\n";
	}

private:
	Json::Value m_field;
	Json::Value m_row;
};


class CGcheckpoint : public CCSvFile
{	
private:
	CGcheckpoint() : CCSvFile("", "") {
	};

public:
	~CGcheckpoint() {
	};

	static CGcheckpoint* getInstance() {
		static auto_ptr<CGcheckpoint> pObj(new CGcheckpoint);
		return pObj.get();
	};

	void SetPathName(const char* name, const char* dir) {
		m_file_name = name;
		strcpy_s(m_rdlog_dir, dir);
		m_full_name = dir;
		m_full_name = m_full_name + "\\" + m_file_name + ".csv";
	}
	
	void WriteCheckPoint(CCheckPointInfo& info, bool current_datatime = true) {
		char datetime[32];
		string data;

		if (current_datatime == true) {
			GetDateTime(datetime, _countof(datetime));
			info.data_time = datetime;
		}

		data = info.manufacturer + "," + info.location + "," + info.gpn + "," + info.mpn + "," + info.serial_number + "," + info.station_name + "," + info.station_id + "," + info.station_type + "," + info.line + "," + info.line_id + "," + info.op_id + "," + info.data_time + "," + info.build_phase + "," + info.status + "," + info.failure_code + "," + info.remarks + "\n";

		if (!IsFileExist(m_full_name)) {
			WriteLog("MANUFACTURER,LOCATION,GPN,MPN,SERIAL_NUMBER,STATION_NAME,STATION_ID,STATION_TYPE,LINE,LINE_ID,OPERATOR_ID,DATE_TIME,BUILD_PHASE,STATUS,FAILURE_CODE,REMARKS\n");
		}
		WriteLog(data.c_str());
	}

	void WriteCommonInfo(CCommonInfo& ci) {
		string data;
		
		if (!IsFileExist(m_full_name)) {
			ci.GetHeader(data);
			WriteLog(data.c_str());
		}
		ci.GetRow(data);
		WriteLog(data.c_str());
	}
};