
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include "CommonApi.h"
#include "Criteria.h"



using namespace std;

#pragma once

class CSfisCsv
{
public:
	enum Status {
		Pass = 0,
		Fail = 1,
	};
	
	CSfisCsv(const char* name, const char* dir) :m_full_name(""), m_fail_count(0), m_first_fail_item(""), m_fail_items("NULL"), m_fail_item_sfis_format(""), m_write_immediately(true), m_hashtag_save_item(""){
		m_file_name = name;
		strcpy_s(m_sfiscsv_dir, dir);
		m_full_name = dir;
		m_full_name = m_full_name + "\\" + m_file_name + ".csv";
		m_big_buffer[0] = 0;
		m_fail_items2.clear();
		WriteCsv("TEST", "STATUS", "VALUE", "U_LIMIT", "L_LIMIT");
		m_all_items.clear();
	};

	~CSfisCsv() {
	};

	void WriteCsv(const char* item, Status stat, const char* value, const char* u_limit, const char* l_limit) {
		int n = -1;
		int buf_cnt = 1024;
		char* buf = NULL;

		do
		{
			delete[] buf;
			buf_cnt *= 2;
			buf = new char[buf_cnt];
			n = _snprintf_s(buf, buf_cnt, _TRUNCATE, "\"%s\",%d,\"%s\",\"%s\",\"%s\"\n", item, stat, value, u_limit, l_limit);
		} while (n == -1);

		write_csv(buf);

		m_all_items.push_back(item);

		if (stat == CSfisCsv::Fail) {
			/// <summary>
			/// ////
			/// </summary>
			/// <param name="item"></param>
			/// <param name="stat"></param>
			/// <param name="value"></param>
			/// <param name="u_limit"></param>
			/// <param name="l_limit"></param>
			AddFailItem(item, buf);
		}
		m_hashtag_save_item += buf;
		/*if (strstr(item, "#SAVE:") != NULL) {
			m_hashtag_save_item += buf;
		}*/

		delete[] buf;
	};

	void WriteCsv(const char* item, const char* status, const char* value, const char* u_limit, const char* l_limit) {
		int n = -1;
		int buf_cnt = 1024;
		char* buf = NULL;

		do
		{
			delete[] buf;
			buf_cnt *= 2;
			buf = new char[buf_cnt];
			n = _snprintf_s(buf, buf_cnt, _TRUNCATE, "\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"\n", item, status, value, u_limit, l_limit);
		} while (n == -1);

		write_csv(buf);

		m_all_items.push_back(item);

		if (atoi(status) == 1) {
			AddFailItem(item, buf);
		}
		//m_hashtag_save_item += buf;
		if (strstr(item, "#SAVE:") != NULL) {
			m_hashtag_save_item += buf;
		}

		delete[] buf;
	};

	void WriteCsv(CCriteria::CriteriaField& sfiscsv) {
		WriteCsv(sfiscsv.item.c_str(), sfiscsv.status.c_str(), sfiscsv.value.c_str(), sfiscsv.ul.c_str(), sfiscsv.dl.c_str());
	};

	Status WriteCsv(const char* item, const char* value, const char* up_limit, const char* down_limit) {
		//char temp[64];
		//bool is_find_item = false;
		Status real_stat = CSfisCsv::Fail;
		//CCriteria::CriteriaField field;

		/*is_find_item = CCriteria::getInstance()->GetCriteriaByItem(item, field);
		if (is_find_item == false) {
			sprintf_s(temp, "Can not find item \"%s\" in the critria file!", item);
			::MessageBox(NULL, temp, "Warning", MB_OK);
		}*/
		
		/*if (is_find_item == true)
		{*/
			if (_stricmp(value, "fail") != 0) {
				if (_stricmp(up_limit, down_limit) == 0) {
					if (_stricmp(up_limit, "N/A") == 0) {
						real_stat = CSfisCsv::Pass;
					} else if (is_digits(up_limit)) {
						if ((atof(value) <= atof(up_limit)) && (atof(value) >= atof(down_limit))) {
							real_stat = CSfisCsv::Pass;
						}
					} else {
						std::vector<string>	values;
						StringToken(up_limit, values, "|");
						for (std::vector<string>::iterator it=values.begin(); it!=values.end(); ++it) {
							if (strcmp(value, it->c_str()) == 0) {
								real_stat = CSfisCsv::Pass;
								down_limit = value;
								up_limit = value;
								break;
							}
						}
					}
				} else {
					if (_stricmp(up_limit, "N/A") != 0 && _stricmp(down_limit, "N/A") != 0) {
						if ((atof(value)<=atof(up_limit)) && (atof(value)>=atof(down_limit))) {
							real_stat = CSfisCsv::Pass;
						}
					} else if (_stricmp(up_limit, "N/A") != 0) {
						if (atof(value)<=atof(up_limit)) {
							real_stat = CSfisCsv::Pass;
						}
					} else if (_stricmp(down_limit, "N/A") != 0) {
						if (atof(value)>=atof(down_limit)) {
							real_stat = CSfisCsv::Pass;
						}
					}
				}
			}
		/*} else {
			field.ul = "N/A";
			field.dl = "N/A";
		}*/
	
		WriteCsv(item, real_stat, value, up_limit, down_limit);
		
		return real_stat;
	};

	void WriteCsvSaveItem(const char* item, const char* value, bool write_really = true) {
		char buffer[1024];
		sprintf_s(buffer, "\"%s\",0,\"%s\",\"N/A\",\"N/A\"\n", item, value);
		if (write_really) {
			WriteCsv(buffer);
		}
		m_hashtag_save_item += buffer;
		/*if (strstr(item, "#SAVE:") != NULL) {
			m_hashtag_save_item += buffer;
		}*/
	}

	void WriteCsv(const char* data) {
		write_csv(data);
	};

	void AddFailItem(const char* item, const char* fail_sfis) {
		m_fail_count++;
		if (m_fail_count == 1) {
			m_first_fail_item = item;
			m_fail_item_sfis_format = fail_sfis;
			m_fail_items = item;
		} else {
			m_fail_items = m_fail_items + ";" + item;
		}
		m_fail_items2.push_back(item);
	};

	int GetFailCount() {
		return m_fail_count;
	};

	void GetFirstFailItem(string& item) {
		item = m_first_fail_item;
	};

	const char* GetFirstFailItem() {
		return m_first_fail_item.c_str();
	};

	const char* GetFailSfisItem() {
		return m_fail_item_sfis_format.c_str();
	};

	void GetFailItems(string& items) {
		items = m_fail_items;
	}

	void GetFailItems(vector<string>& items) {
		items = m_fail_items2;
	};

	bool HaveHashtagSaveItem() {
		return !m_hashtag_save_item.empty();
	}

	void GetHashtagSaveItem(string& save_item) {
		save_item = m_hashtag_save_item;
	}

	const char* GetHashtagSaveItem() {
		return m_hashtag_save_item.c_str();
	}

	void GetAllItems(vector<string>& items) {
		items = m_all_items;
	}

	const vector<string>* GetAllItems() {
		return &m_all_items;
	}

	const char* GetLastRecord() {
		return m_last_record.c_str();
	}

	//void WriteCsv2(const char *fmt, ...) {
	//	char buffer[1024];
	//	va_list	list;

	//	va_start(list, fmt);
	//	vsprintf_s(buffer, _countof(buffer), fmt, list);
	//	va_end(list);

	//	write_csv(buffer);
	//};

	void Rename(const char* name) {
		string file_name(m_sfiscsv_dir);

		file_name = file_name + "\\" + name + ".csv";
		if (rename(m_full_name.c_str(), file_name.c_str()) != 0) {
			errno_t err;
			_get_errno(&err);
			DBGTRACE(("failed to rename. [%s]", m_full_name.c_str()));
		} else {
			m_file_name = name;
			m_full_name = file_name;
		}
	}

	void GetCsvFullName(string& buf) {
		buf = m_full_name;
	}

	const char* GetCsvFullName() {
		return m_full_name.c_str();
	}

	void SetWriteImmediately(bool immediately) {
		m_write_immediately = immediately;
	}

private:
	void write_csv(const char* data) {
		HANDLE handle;
		DWORD dwBytesToWrite = (DWORD)strlen(data);
		DWORD dwBytesWritten = 0;
		char temp[64];

		m_last_record = data;

		handle = CreateFileA(m_full_name.c_str(), FILE_APPEND_DATA, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (handle == INVALID_HANDLE_VALUE) {
			::OutputDebugStringA("[fox] failed to open csv file");
			sprintf_s(temp, "err no:%d", ::GetLastError());
			::OutputDebugStringA(temp);
			::Sleep(5000);
			handle = CreateFileA(m_full_name.c_str(), FILE_APPEND_DATA, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		}
		if (handle != INVALID_HANDLE_VALUE) {
			SetFilePointer(handle, 0, NULL, FILE_END);
			WriteFile(handle, data, dwBytesToWrite, &dwBytesWritten, NULL);
			CloseHandle(handle);
		} else {
			::OutputDebugStringA("[fox] failed to open csv file(2)");
			sprintf_s(temp, "err no:%d", ::GetLastError());
			::OutputDebugStringA(temp);
		}

	}

	void write_csv2(const char* data) {
		FILE* file;
		char* p = NULL;

		if ((m_write_immediately == true) && (strlen(m_big_buffer) == 0))
		{
			p = (char*)data;
		}
		else
		{
			strcat_s(m_big_buffer, data);
			p = m_big_buffer;
		}

		if (m_write_immediately == true) {
			errno_t ret = fopen_s(&file, m_full_name.c_str(),"a");
			if (ret != 0) {
				::OutputDebugStringA("[fox] failed to open csv file");
				::Sleep(1500);
				ret = fopen_s(&file, m_full_name.c_str(), "a");
			}
			if (ret == 0) {
				fputs(p, file);
				fflush(file);
				if (fclose(file) != 0) {
					//::MessageBoxA(NULL, "failed to close file", "", 0);
					::OutputDebugStringA("[fox] failed to close csv file");
					fclose(file);
				}
				m_big_buffer[0] = 0;
			} else {
				DBGTRACE(("failed to open file [%s]", m_full_name.c_str()));
				//::MessageBoxA(NULL, m_full_name.c_str(), "failed to open csv file", 0);
				::OutputDebugStringA("[fox] failed to open csv file(2)");
			}
		}
	};

	bool is_digits(const std::string &str) {
		return str.find_first_not_of(".0123456789") == std::string::npos;
	};

public:
	string m_file_name;
	string m_full_name;
	int m_fail_count;
	string m_first_fail_item;
	string m_fail_items;
	vector<string> m_fail_items2;

private:
	char m_sfiscsv_dir[512];
	bool m_write_immediately;
	char m_big_buffer[32768];
	string m_fail_item_sfis_format;
	string m_hashtag_save_item;
	string m_last_record;
	vector<string> m_all_items;
};