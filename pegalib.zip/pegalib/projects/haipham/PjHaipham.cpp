#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "PjHaipham.h"
#include <regex>
#include <windows.system.h>

extern CDOS;

CPjHaipham::CPjHaipham(LPVOID ptr)
{
	m_main_dut = ptr;
	/// <summary>
	/// The test functions with PPS
	/// </summary>
	add_test_item("TEST_SET_VOLT_CURR_OUTPUT", &CPjHaipham::test_SET_VOLT_CURR_OUTPUT);
	add_test_item("TEST_MEAS_PPS_VOLT", &CPjHaipham::test_MEAS_PPS_VOLT);
	add_test_item("TEST_MEAS_PPS_CURR", &CPjHaipham::test_MEAS_PPS_CURR);
	add_test_item("TEST_PPS_OFF", &CPjHaipham::test_PPS_OFF);
	/// <summary>
	/// The test functions with DMM
	/// </summary>
	add_test_item("TEST_GET_VOLT", &CPjHaipham::test_GET_VOLT);
	add_test_item("TEST_GET_CURR", &CPjHaipham::test_GET_CURR);
	add_test_item("TEST_GET_OHM", &CPjHaipham::test_GET_OHM);
	add_test_item("TEST_GET_OHM_4W", &CPjHaipham::test_GET_OHM_4W);
	/// <summary>
	/// The Min, Max, Average and Stdevp function
	/// </summary>
	ReadData(data);
	add_test_item("TEST_PIR_MIN_VALUE", &CPjHaipham::test_PIR_MIN_VALUE);
	add_test_item("TEST_PIR_MAX_VALUE", &CPjHaipham::test_PIR_MAX_VALUE);
	add_test_item("TEST_PIR_AVERAGE_VALUE", &CPjHaipham::test_PIR_AVERAGE_VALUE);
	add_test_item("TEST_PIR_STDEVP_VALUE", &CPjHaipham::test_PIR_STDEVP_VALUE);
	/// <summary>
	/// The function tests the Regular Expression
	/// </summary>
	add_test_item("TEST_READ_REGEX", &CPjHaipham::test_read_data_from_regex);
}


CPjHaipham::~CPjHaipham()
{
}

bool CPjHaipham::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CPjHaipham::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CPjHaipham::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}
/// <summary>
/// The test functions with PPS
/// </summary>
int CPjHaipham::test_SET_VOLT_CURR_OUTPUT(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string Itemname = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	double Voltage = param["Voltage"].asDouble();
	double Current = param["Current"].asDouble();	
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		/*RDLOG->WriteLogf("PPS set Voltage: %f", Voltage);
		ret = MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_VOLTAGE_CH2(Voltage);
		RDLOG->WriteLogf("PPS set Current: %f", Current);
		ret += MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_CURRENT_CH2(Current);
		RDLOG->WriteLogf("PPS On");
		ret += MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_POWER_ON_CH2();*/
		RDLOG->WriteLogf("PPS set Voltage: %f", Voltage);
		ret = MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_VOLTAGE(Voltage);
		RDLOG->WriteLogf("PPS set Current: %f", Current);
		ret += MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_CURRENT(Current);
		RDLOG->WriteLogf("PPS On");
		ret += MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_POWER_ON();
	}
	if (ret == RET_SUCCESS)
	{
		MAINDUT->log_sfis_and_set_info_no_judge(Itemname.c_str(), CSfisCsv::Pass, "PASS");
	}
	else
		MAINDUT->log_sfis_and_set_info_no_judge(Itemname.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}
/// Agilent663x has not the get_voltage function
int CPjHaipham::test_MEAS_PPS_VOLT(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string Itemname = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	double Meas_Volt = 0;
	double pdVolt = 0;

	const char* GPIBnamestr = GPIBname.c_str();

	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		/*RDLOG->WriteLogf("PPS Meas Voltent");
		ret += MAINDUT->use_gpibdev(GPIBnamestr)->PPS_GET_VOLTAGE_CH2(&pdVolt);*/
		RDLOG->WriteLogf("PPS Meas Voltent");
		ret = MAINDUT->use_gpibdev(GPIBnamestr)->PPS_GET_VOLTAGE(&pdVolt);
		Meas_Volt = pdVolt;
	}
	MAINDUT->log_sfis_and_set_info(Itemname.c_str(), Meas_Volt);

	return ret;
}
int CPjHaipham::test_MEAS_PPS_CURR(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string Itemname = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	double Meas_Curr = 0;
	double pdCurr = 0;

	const char* GPIBnamestr = GPIBname.c_str();

	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		/*RDLOG->WriteLogf("PPS Meas Current");
		ret = MAINDUT->use_gpibdev(GPIBnamestr)->PPS_GET_CURRENT_CH2(&pdCurr);*/
		RDLOG->WriteLogf("PPS Meas Current");
		ret = MAINDUT->use_gpibdev(GPIBnamestr)->PPS_GET_CURRENT(&pdCurr);
		Meas_Curr = pdCurr;
	}
	MAINDUT->log_sfis_and_set_info(Itemname.c_str(), Meas_Curr);
	return ret;
}
int CPjHaipham::test_PPS_OFF(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string Itemname = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");

	const char* GPIBnamestr = GPIBname.c_str();

	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		/*RDLOG->WriteLogf("PPS Off");
		ret = MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_POWER_OFF_CH2();*/
		RDLOG->WriteLogf("PPS Off");
		ret = MAINDUT->use_gpibdev(GPIBnamestr)->PPS_SET_POWER_OFF();
	}

	if (ret == RET_SUCCESS)
		MAINDUT->log_sfis_and_set_info_no_judge(Itemname.c_str(), CSfisCsv::Pass, "PASS");
	else
		MAINDUT->log_sfis_and_set_info_no_judge(Itemname.c_str(), CSfisCsv::Fail, "FAIL");

	return ret;
}
/// <summary>
/// The test functions with DMM
/// </summary>
int CPjHaipham::test_GET_VOLT(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	int count_sample = 0;
	double pdDCVolt = 0;
	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		std::vector<double> sample_DC_volt;
		while (count_sample < count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_DC_VOLT,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			//Range, Resolution, IntegrationTime, CH Delay, Avg Count)
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_DC_VOLTAGE(channel, &pdDCVolt);
			count_sample++;
			RDLOG->WriteLogf(" Voltage Value[%d]: %f\n", count_sample, pdDCVolt);
			sample_DC_volt.push_back(pdDCVolt);
		}
		pdDCVolt = 0;
		for each (double var in sample_DC_volt)
		{
			pdDCVolt += var;
		}
		pdDCVolt /= (double)sample_DC_volt.size();
		volt = pdDCVolt;
		RDLOG->WriteLogf(" Voltage Average Value: %f\n", pdDCVolt);
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), pdDCVolt);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}
int CPjHaipham::test_GET_CURR(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	int count_sample = 0;
	double DC_current = 0;
	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		std::vector<double> sample_DC_curr;
		while (count_sample < count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_DC_CURR,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			//Range, Resolution, IntegrationTime, CH Delay, Avg Count)
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_DC_CURRENT(channel, &DC_current);
			count_sample++;
			RDLOG->WriteLogf(" Current Value[%d]: %f\n", count_sample, DC_current);
			sample_DC_curr.push_back(DC_current);
		}
		DC_current = 0;
		for each (double var in sample_DC_curr)
		{
			DC_current += var;
		}
		DC_current /= (double)sample_DC_curr.size();
		resistance = volt / DC_current;
		RDLOG->WriteLogf(" Current Average Value: %f\n", DC_current);
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), DC_current);
		MAINDUT->log_sfis_and_set_info_no_judge("CAL_RESISTOR_VALUE", CSfisCsv::Pass, resistance);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}
int CPjHaipham::test_GET_OHM(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	int count_sample = 0;
	double pdOHM = 0;
	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		std::vector<double> sample_OHM;
		while (count_sample < count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_OHM,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_RESISTANCE(channel, &pdOHM);
			count_sample++;
			RDLOG->WriteLogf(" Resistance Value[%d]: %f\n", count_sample, pdOHM);
			sample_OHM.push_back(pdOHM);
		}
		pdOHM = 0;
		for each (double var in sample_OHM)
		{
			pdOHM += var;
		}
		pdOHM /= (double)sample_OHM.size();
		RDLOG->WriteLogf(" Resistance Average Value: %f\n", pdOHM);
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, pdOHM);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}
int CPjHaipham::test_GET_OHM_4W(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	int count_sample = 0;
	double pdOHM = 0;

	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		std::vector<double> sample_OHM;
		while (count_sample < count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_OHM_4W,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_RESISTANCE_4W(channel, &pdOHM);
			count_sample++;
			RDLOG->WriteLogf(" Resistance Value[%d]: %f\n", count_sample, pdOHM);
			sample_OHM.push_back(pdOHM);
		}
		pdOHM = 0;
		for each (double var in sample_OHM)
		{
			pdOHM += var;
		}
		pdOHM /= (double)sample_OHM.size();
		RDLOG->WriteLogf(" Resistance Average Value: %f\n", pdOHM);
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, pdOHM);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}
/// <summary>
/// The Min, Max, Average and Stdevp function
/// </summary>
int CPjHaipham::test_PIR_MIN_VALUE(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();	
	for (size_t i = 0; i < SIZE_ARRAY; i++)
	{
		if (minValue > data[i])
		{
			minValue = data[i];
		}
	}
	char valueChar[32] = { 0 };
	sprintf_s(valueChar, "%.1f", minValue);
	if (strlen(valueChar) != 0)
	{
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), valueChar);
		ret = RET_SUCCESS;
	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	}
	RDLOG->WriteLogf(" Min Value: %s\n", valueChar);
	return ret;
}
int CPjHaipham::test_PIR_MAX_VALUE(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();

	for (size_t i = 0; i < SIZE_ARRAY; i++)
	{
		if (maxValue < data[i])
		{
			maxValue = data[i];
		}
	}
	char valueChar[32] = { 0 };
	sprintf_s(valueChar, "%.1f", maxValue);
	if (strlen(valueChar) != 0)
	{
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), valueChar);
		ret = RET_SUCCESS;
	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	}
	RDLOG->WriteLogf(" Max Value: %s\n", valueChar);
	return ret;
}
int CPjHaipham::test_PIR_AVERAGE_VALUE(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();

	for (size_t i = 0; i < SIZE_ARRAY; i++)
	{
		averageValue += data[i];
	}
	averageValue = averageValue / (double)SIZE_ARRAY;
	/*char valueChar[32] = { 0 };
	sprintf_s(valueChar, "%.1f", averageValue);*/
	if (averageValue != 0)
	{
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), averageValue);
		ret = RET_SUCCESS;
	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	}
	RDLOG->WriteLogf(" Average Value: %s\n", averageValue);
	return ret;
}
int CPjHaipham::test_PIR_STDEVP_VALUE(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();

	for (size_t i = 0; i < SIZE_ARRAY; i++)
	{
		stdevpValue += pow((data[i] - averageValue),2);
	}
	stdevpValue = stdevpValue / ((double)SIZE_ARRAY-1);
	stdevpValue = sqrt(stdevpValue);
	/*char valueChar[32] = { 0 };
	sprintf_s(valueChar, "%.1f", stdevpValue);*/
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, stdevpValue);
	RDLOG->WriteLogf("STDEV Value : %s\n", stdevpValue);
	return 0;
}
void CPjHaipham::ReadData(double* data)
{
	for (size_t i = 0; i < SIZE_ARRAY; i++)
	{
		data[i] = (rand() % 51) + 50;
	}
}
/// <summary>
/// The function tests the Regular Expression
/// </summary>
int CPjHaipham::test_read_data_from_regex(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string value = "PASS";
	string adb_result;

	string item_name = PARAM_S("item_name");
	Json::Value cmd_list = param["dut_cmd"];
	bool reg_enable = PARAM_B("reg_enable");
	int reg_catch = PARAM_N("reg_catch");
	string cmd_assgin = PARAM_S("cmd_assign");
	Json::Value reg_rule_list = param["reg_rule"];

	
	vector<string> cmd_assign_list, value_result;
	StringToken(cmd_assgin.c_str(), cmd_assign_list, ",", NONE);

	for (unsigned int i = 0; i < cmd_list.size(); i++)
	{
		for (unsigned int j = 0; j < cmd_assign_list.size(); j++)
		{
			static int hai = 0;
			if (i == stoi(cmd_assign_list[j]))
			{
				string Hai = MAINDUT->hai_cmd_by_regex(cmd_list[i].asString(), reg_enable, reg_rule_list[i].asString().c_str(), reg_catch);
				value_result.push_back(Hai);
			}
			else
			{
				MAINDUT->adb_command((cmd_list[i].asString()).c_str(), adb_result, 1000);
				RDLOG->WriteLogf(" result: %s", adb_result);
			}
		}
	}
	value = value_result[value_result.size() - 1];
	for (unsigned int n = 0; n < value_result.size(); n++)
	{
		if (value_result[n] == "FAIL")
		{
			value = "FAIL";
			break;
		}
	}
	ret = RET_SUCCESS;
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, value.c_str());
	return ret;
}