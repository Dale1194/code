#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"



using namespace std;

#define SIZE_ARRAY 100

class CPjHaipham :
	public CSubDut
{
public:
	CPjHaipham(LPVOID ptr);
	virtual ~CPjHaipham();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CPjHaipham::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);
	/// <summary>
	/// The test functions with PPS
	/// </summary>
	int CPjHaipham::test_SET_VOLT_CURR_OUTPUT(const char* item, const Json::Value& param);
	/// Agilent663x has not the get_voltage function
	int CPjHaipham::test_MEAS_PPS_VOLT(const char* item, const Json::Value& param);
	int CPjHaipham::test_MEAS_PPS_CURR(const char* item, const Json::Value& param);
	int CPjHaipham::test_PPS_OFF(const char* item, const Json::Value& param);
	/// <summary>
	/// The test functions with DMM
	/// </summary>
	int CPjHaipham::test_GET_VOLT(const char* item, const Json::Value& param);
	int CPjHaipham::test_GET_CURR(const char* item, const Json::Value& param);
	int CPjHaipham::test_GET_OHM(const char* item, const Json::Value& param);
	int CPjHaipham::test_GET_OHM_4W(const char* item, const Json::Value& param);
	/// <summary>
	/// The Min, Max, Average and Stdevp function
	/// </summary>
	int CPjHaipham::test_PIR_MIN_VALUE(const char* item, const Json::Value& param);
	int CPjHaipham::test_PIR_MAX_VALUE(const char* item, const Json::Value& param);
	int CPjHaipham::test_PIR_AVERAGE_VALUE(const char* item, const Json::Value& param);
	int CPjHaipham::test_PIR_STDEVP_VALUE(const char* item, const Json::Value& param);
	void CPjHaipham::ReadData(double* data);
	/// <summary>
	/// The function tests the Regular Expression
	/// </summary>
	int CPjHaipham::test_read_data_from_regex(const char* item, const Json::Value& param);
private:
	std::map<string, CPjHaipham::FN_CMD> m_command;

	enum func_ret
	{
		RET_SUCCESS = 0,
		RET_FAIL
	};
	
	double volt = 0;
	double resistance = 0;
	

	double data[SIZE_ARRAY];
	double minValue = 100;
	double maxValue = 0;
	double averageValue = 0;
	double stdevpValue = 0;
};

