#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "PjPavilion.h"



CPjPavilion::CPjPavilion(LPVOID ptr)
{
	m_main_dut = ptr;

	add_test_item("TEST_EDGE_DETECTION", &CPjPavilion::test_edge_detection);
	add_test_item("V_DET_TSTAT_Y_W_TO_HVAC_C", &CPjPavilion::test_V_DET_TSTAT_Y_W_TO_HVAC_C);
	add_test_item("I_DET_TSTAT_Y_W_TO_HVAC_C", &CPjPavilion::test_I_DET_TSTAT_Y_W_TO_HVAC_C);
	add_test_item("TEST_TRIAC_DET_EDGE_RISING", &CPjPavilion::test_TRIAC_DET_EDGE_RISING);
	add_test_item("TEST_TRIAC_EDGE_RISING_TIME", &CPjPavilion::test_TRIAC_EDGE_RISING_TIME);

	add_test_item("TEST_HELLO_WORLD_1", &CPjPavilion::test_HELLO_WOLRD);
}


CPjPavilion::~CPjPavilion()
{
}

bool CPjPavilion::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CPjPavilion::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CPjPavilion::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CPjPavilion::test_edge_detection(const char* item, const Json::Value& param)
{
	int ret = S_FALSE;
	float current_voltage = 8.0;
	double vol_a = MAINDUT->ParamDouble(param, "vol_a", 8.0);
	double vol_b = MAINDUT->ParamDouble(param, "vol_b", 12.0);
	const float increments_voltage = 0.125;
	char wcmd[64], tmnl[64];
	string new_item_1, new_item_2;
	string rdata = "";
	string nickname;
	string append_item;
	int delay = MAINDUT->ParamInt(param, "delay", 0);

	MAINDUT->ParamStr(param, "port_nickname", nickname, "JIG");
	MAINDUT->ParamStr(param, "append_item", append_item, "_X");

	m_source_voltage = 0.0;
	
	while (true)
	{
		vol_a += increments_voltage;

		sprintf_s(wcmd, "S_VAR_SOURCE_R_POS:%d", (int)(vol_a * 1000));
		sprintf_s(tmnl, "S_VAR_SOURCE_R_POS:%d_OK", (int)(vol_a * 1000));
		
		RDLOG->WriteLogf(" serial_cmd:%s\n", wcmd);
		ret = MAINDUT->use_comport(nickname.c_str())->WRString(wcmd, rdata, tmnl, 100, 1000);
		RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, rdata.c_str());

		if (ret == S_OK)
		{
			::Sleep(delay);

			strcpy_s(wcmd, "GET_DET_L_STATUS");
			strcpy_s(tmnl, "DET_L_");
			
			RDLOG->WriteLogf(" serial_cmd:%s\n", wcmd);
			ret = MAINDUT->use_comport(nickname.c_str())->WRString(wcmd, rdata, tmnl, 100, 1000);
			RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, rdata.c_str());
			
			if ((ret == S_OK) && (rdata.find("DET_L_LOW") != string::npos))
			{
				m_source_voltage = (float)vol_a;
				break;
			}
		}

		if (vol_a >= vol_b)
			break;
	}

	new_item_1 = "S_VAR_SOURCE_SWEEP" + append_item;
	new_item_2 = "D_DET_L_EDGE_DETECTION" + append_item;

	if (m_source_voltage != 0.0)
	{
		MAINDUT->log_sfis_and_set_info_no_judge(new_item_1.c_str(), CSfisCsv::Pass, vol_a);
		MAINDUT->log_sfis_and_set_info_no_judge(new_item_2.c_str(), CSfisCsv::Pass, "Falling Edge");
	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge(new_item_1.c_str(), CSfisCsv::Pass, vol_a);
		MAINDUT->log_sfis_and_set_info_no_judge(new_item_2.c_str(), CSfisCsv::Fail, "Fail");
	}

	return 0;
}

int CPjPavilion::test_V_DET_TSTAT_Y_W_TO_HVAC_C(const char* item, const Json::Value& param)
{
	MAINDUT->log_sfis_and_set_info(item, m_source_voltage);
	return 0;
}

int CPjPavilion::test_I_DET_TSTAT_Y_W_TO_HVAC_C(const char* item, const Json::Value& param)
{
	float vf = 0.625;
	float iDET = (m_source_voltage - (2 * vf)) / 25 * 1000;
	MAINDUT->log_sfis_and_set_info(item, iDET);
	return 0;
}

int CPjPavilion::test_TRIAC_DET_EDGE_RISING(const char* item, const Json::Value& param)
{
	int ret = S_FALSE;
	unsigned int timeout = MAINDUT->ParamInt(param, "timeout", 15000);
	string nickname;
	string rdata;
	string duration = "0";
	CCalcPeriod period;
	char temp[32] = { 0 };
	bool is_triac_det_hight = false;

	MAINDUT->ParamStr(param, "port_nickname", nickname, "JIG");

	period.GetTimeA();
	do
	{
		RDLOG->WriteLog(" serial_cmd:GET_TRIAC_DET_STATUS\n");
		ret = MAINDUT->use_comport(nickname.c_str())->WRString("GET_TRIAC_DET_STATUS", rdata, "TRIAC_DET_", 100, 1000);
		RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, rdata.c_str());

		if (ret == S_OK)
		{
			if (rdata.find("TRIAC_DET_HIGHT") != string::npos)
			{
				is_triac_det_hight = true;

				RDLOG->WriteLog(" serial_cmd:T_TRIAC_ON\n");
				ret = MAINDUT->use_comport(nickname.c_str())->WRString("T_TRIAC_ON", rdata, "T_TRIAC_ON:", 100, 1000);
				RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, rdata.c_str());

				if (ret == S_OK)
				{
					size_t pos = rdata.find(":");
					if (pos != string::npos)
					{
						duration = rdata.substr(pos + 1);
						double v = atof(duration.c_str());
						sprintf_s(temp, "%.1f", v/1000);
						MAINDUT->log_sfis_and_set_info("T_TRIAC_ON", temp);
					}
				}
				break;
			}
		}

		::Sleep(333);
		period.GetTimeB();
	} while (period.GetDiff() < timeout);

	if (is_triac_det_hight == true)
		MAINDUT->log_sfis_and_set_info_no_judge("D_TRIAC_DET_EDGE_RISING", CSfisCsv::Pass, "Rising Edge");
	else
		MAINDUT->log_sfis_and_set_info_no_judge("D_TRIAC_DET_EDGE_RISING", CSfisCsv::Fail, "FAIL");

	if (strlen(temp) != 0)
		MAINDUT->log_sfis_and_set_info("T_TRIAC_ON", temp);
	else
		MAINDUT->log_sfis_and_set_info_no_judge("T_TRIAC_ON", CSfisCsv::Fail, "FAIL");

	return 0;
}

int CPjPavilion::test_TRIAC_EDGE_RISING_TIME(const char* item, const Json::Value& param)
{
	int ret = S_FALSE;
	unsigned int timeout = MAINDUT->ParamInt(param, "timeout", 15000);
	string nickname;
	string rdata;
	string duration = "0";
	CCalcPeriod period;
	char rising_time[32];
	bool is_triac_det_hight = false;

	MAINDUT->ParamStr(param, "port_nickname", nickname, "JIG");

	period.GetTimeA();
	do
	{
		RDLOG->WriteLog(" serial_cmd:GET_TRIAC_DET_STATUS\n");
		ret = MAINDUT->use_comport(nickname.c_str())->WRString("GET_TRIAC_DET_STATUS", rdata, "TRIAC_DET_", 100, 1000);
		RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, rdata.c_str());

		if (ret == S_OK)
		{
			if (rdata.find("HIGH") != string::npos)
			{
				is_triac_det_hight = true;
				//break;
			}
		}

		::Sleep(950);
		period.GetTimeB();
	} while (period.GetDiff() < timeout);

	if (is_triac_det_hight)
		MAINDUT->log_sfis_and_set_info_no_judge("D_TRIAC_DET_EDGE_RISING", CSfisCsv::Pass, "Rising Edge");
	else
		MAINDUT->log_sfis_and_set_info_no_judge("D_TRIAC_DET_EDGE_RISING", CSfisCsv::Fail, "FAIL");

	RDLOG->WriteLog(" serial_cmd:GET_TIME\n");
	ret = MAINDUT->use_comport(nickname.c_str())->WRString("GET_TIME", rdata, "TIME:", 100, 1000);
	RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, rdata.c_str());

	strcpy_s(rising_time, "0");
	if (ret == S_OK)
	{
		size_t pos = rdata.find(":");
		if (pos != string::npos)
		{
			duration = rdata.substr(pos + 1);
			double v = atof(duration.c_str());
			sprintf_s(rising_time, "%.1f", v / 10);
		}
	}

	MAINDUT->log_sfis_and_set_info("T_TRIAC_ON", rising_time);

	return ret;
}




int CPjPavilion::test_HELLO_WOLRD(const char* item, const Json::Value& param)
{
	MAINDUT->log_sfis_and_set_info(item, "HAI 1 HELLO WORLD");
	return 0;
}





