#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CPjPavilion :
	public CSubDut
{
public:
	CPjPavilion(LPVOID ptr);
	virtual ~CPjPavilion();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CPjPavilion::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);
	
	int test_edge_detection(const char* item, const Json::Value& param);
	int test_V_DET_TSTAT_Y_W_TO_HVAC_C(const char* item, const Json::Value& param);
	int test_I_DET_TSTAT_Y_W_TO_HVAC_C(const char* item, const Json::Value& param);
	int test_TRIAC_DET_EDGE_RISING(const char* item, const Json::Value& param);
	int test_TRIAC_EDGE_RISING_TIME(const char* item, const Json::Value& param);

	int CPjPavilion::test_HELLO_WOLRD(const char* item, const Json::Value& param);

private:
	std::map<string, CPjPavilion::FN_CMD> m_command;

	float m_source_voltage;
};

