#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "Antenna.h"
#include ".\modules\tinyxml2\tinyxml2.h"

using namespace tinyxml2;



CAntenna::CAntenna(LPVOID ptr)
{
	 m_main_dut = ptr;

	 add_test_item("FATP_JUST_TEST", &CAntenna::fatp_just_test);
	 add_test_item("READ_XML_VALUE", &CAntenna::read_rf_value);
}


CAntenna::~CAntenna()
{
}

bool CAntenna::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CAntenna::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CAntenna::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CAntenna::fatp_just_test(const char* item, const Json::Value& param)
{
	::OutputDebugStringA("gucci_just_test");
	string itemname;
	MAINDUT->ParamStr(param, "item_name", itemname, "");
	//MAINDUT->use_gpibdev("INS1")->TURN_OFF_ROUTE()
	 
	return 0;
}

int CAntenna::read_rf_value(const char* item, const Json::Value& param)
{
	string itemname;
	string cate_string = "NULL";
	string file_name;//= "AUTO DETECT CHIP_RX_RTAP_5G_11ax_80p80.xml";
	CCriteria::CriteriaField criteria;
	int judge_stat;
	string backupvalue;
	
	char strtochar[64] = { 0x00 };
	Json::Value Pasar_HTML = param["Pasar_HTML"];
	MAINDUT->ParamStr(param, "HTML_FILE", file_name, "");
	MAINDUT->ParamStr(param, "ITEM_NAME", itemname, "");
	

	int found_position = Load_and_parser_html(cate_string, file_name, Pasar_HTML);
	if (found_position == -999) //NULL�䤣��r��
	{

	}
	else if (cate_string != "NULL") //�^��retry
	{
		do{
			backupvalue = cate_string;
			if (cate_string != "NULL")
			{
				judge_stat = CCriteria::getInstance()->GetCriteriaResult(itemname.c_str(), cate_string.c_str(), &criteria);
				if (judge_stat == 0)
				{
					backupvalue = cate_string;
					break;
				}
			}
			else
			{
				break;
			}
			cate_string = "NULL";
			found_position = Load_and_parser_html(cate_string, file_name, Pasar_HTML, found_position + 1);
			
		} while (found_position != -999 && cate_string.size() != 0);
		

	}

	MAINDUT->log_sfis_and_set_info(itemname.c_str(), atof(backupvalue.c_str()));
	return 0;
}
void CAntenna::Load_and_ParserXml()
{
	tinyxml2::XMLDocument docXml;
	DWORD	ta;
	DWORD	tb;
	ta = ::GetTickCount();
	XMLError errXml = docXml.LoadFile("UserDefine-69319BW30001C-2019_12_16_02_55_24_798--00_F.xml");
	if (XML_SUCCESS == errXml)
	{
		XMLElement* elmtRoot;
		XMLElement *second_element;
		XMLElement *third_element;
		XMLElement *fourth_element;
		XMLElement *fiveth_element;
		XMLElement *elmtAge;
		const char* pContent;
		const char* pContent1;
		elmtRoot = docXml.RootElement();
		


		//XMLElement *first_element = elmtRoot->FirstChildElement("source");
		for (int i = 0; i < 1000; i++)
		{
			second_element = elmtRoot->FirstChildElement("TestCollection");
			third_element = second_element->FirstChildElement("PassFail");
			fourth_element = third_element->FirstChildElement("DI");
			fiveth_element = fourth_element->FirstChildElement("N");
			elmtAge = fiveth_element->NextSiblingElement();
			pContent = elmtAge->GetText();
			pContent1 = fiveth_element->GetText();
		}
		tb = ::GetTickCount();
		int TT ;
		TT = tb - ta;
		return;
		/*XMLElement* elmtRoot = docXml.RootElement();
		XMLElement *elmtUser = elmtRoot->FirstChildElement("Panel");
		XMLElement *elmtName = elmtUser->FirstChildElement("UIData");
		XMLElement *elmtName1;
		const char* pContent;
		const char* pContent1;
		pContent = elmtName->Attribute("name");
		pContent1 = elmtName->Attribute("value");
		elmtName1 = elmtName->NextSiblingElement("UIData");
		do
		{			
			pContent = elmtName1->Attribute("name");
			pContent1 = elmtName1->Attribute("value");
			elmtName1 = elmtName1->NextSiblingElement("UIData");
		} while (elmtName1);
		
		if (elmtName1)
		{
			pContent = elmtName1->Attribute("name");
			printf("%s", pContent);
		}
		XMLElement *elmtAge = elmtName->NextSiblingElement();
		if (elmtAge)
		{
			const char* pContent = elmtAge->GetText();
			printf("%s", pContent);
		}*/
	}
	
}
int CAntenna::Load_and_parser_html(string &cutstring, string &filename, Json::Value Pasar_HTML, std::size_t found_position)
{
	string rawdata;
	unsigned int level_str=0;
	std::size_t backup_position = 0;
	bool bStatus = true;

	int cut_num = 0;

	ReadFileBin(filename, rawdata);
	int times = 0;

	do{
		if (times != 0)
			found_position = find_next_position(rawdata, Pasar_HTML[level_str].asString(), backup_position + 1);
		else
			found_position = find_next_position(rawdata, Pasar_HTML[level_str].asString(), found_position + 1);

		if (found_position == rawdata.npos )
		{
			if (level_str == 0 ) //�Ĥ@�h�䤣����w��r
				bStatus = false;
			level_str = 0;
		}
		else
		{
			
			level_str++;
			if (level_str == Pasar_HTML.size())
			{
				int i = Pasar_HTML[level_str - 2].asString().length();
				cutstring = rawdata.substr(cut_num + Pasar_HTML[level_str - 2].asString().length(), found_position - (backup_position + Pasar_HTML[level_str - 2].asString().length()));
				bStatus = false; //���r��
			}
			if (level_str == Pasar_HTML.size() - 1)
				cut_num = found_position;
			backup_position = found_position;
			times++;
		}
		//if (level_str + 1 == findstr.size())
		//	break;
		
	} while (bStatus);
	if (found_position == rawdata.npos)
	{
		return -999;
	}
	
	return found_position;
}



int CAntenna::find_next_position(string rawdata, string findstr,int start_position)
{
	std::size_t return_position = rawdata.find(findstr, start_position + 1);
	return return_position;

}




