#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class Person
{
public:
	string	m_sName;
	string	m_sNickName;
	int		m_nAge;
};

class CAntenna :
	public CSubDut
{
public:
	CAntenna(LPVOID ptr);
	virtual ~CAntenna();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CAntenna::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int fatp_just_test(const char* item, const Json::Value& param);
	void SaveXml(Person* person, string file);
	int read_rf_value(const char* item, const Json::Value& param);
	void Load_and_ParserXml();
	int Load_and_parser_html(string &cutstring, string &file_name, Json::Value Pasar_HTML, std::size_t found_position = 0);
	int find_next_position(string rawdata, string findstr, int start_position = 0);


private:
	std::map<string, CAntenna::FN_CMD> m_command;
};

