#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CQcFwdl :
	public CSubDut
{
public:
	CQcFwdl(LPVOID ptr);
	virtual ~CQcFwdl();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CQcFwdl::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int qfil_download(const char* item, const Json::Value& param);
	int qsahara_download(const char* item, const Json::Value& param);

private:
	std::map<string, CQcFwdl::FN_CMD> m_command;
};

