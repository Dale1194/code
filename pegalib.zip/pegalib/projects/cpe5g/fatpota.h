#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CFatpOta :
	public CSubDut
{
public:
	CFatpOta(LPVOID ptr);
	virtual ~CFatpOta();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CFatpOta::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int fatp_just_test(const char* item, const Json::Value& param);

private:
	std::map<string, CFatpOta::FN_CMD> m_command;
};

