#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "FatpOta.h"



CFatpOta::CFatpOta(LPVOID ptr)
{
	 m_main_dut = ptr;

	 add_test_item("FATP_JUST_TEST", &CFatpOta::fatp_just_test);
}


CFatpOta::~CFatpOta()
{
}

bool CFatpOta::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CFatpOta::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CFatpOta::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CFatpOta::fatp_just_test(const char* item, const Json::Value& param)
{
	::OutputDebugStringA("gucci_just_test");
	
	return 0;
}





