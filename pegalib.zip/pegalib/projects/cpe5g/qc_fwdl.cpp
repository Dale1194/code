#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include <regex>
#include "Dut.h"
#include "Qc_Fwdl.h"



CQcFwdl::CQcFwdl(LPVOID ptr)
{
	 m_main_dut = ptr;

	 add_test_item("QFIL_DOWNLOAD", &CQcFwdl::qfil_download);
	 add_test_item("QSAHARA_DOWNLOAD", &CQcFwdl::qsahara_download);
}


CQcFwdl::~CQcFwdl()
{
}

bool CQcFwdl::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CQcFwdl::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CQcFwdl::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CQcFwdl::qfil_download(const char* item, const Json::Value& param)
{
	int ret = S_FALSE;
	CDOS dos;
	string out_str;
	string result;
	string item_name = param["item_name"].asString();
	char cmd[1024];
	char _exe[] = "\"C:\\Program Files (x86)\\Qualcomm\\QPST\\bin\\Qfil.exe\"";
	char _mode[] = "-Mode=3 -downloadflat";
	char _comport[9] = "-COM=1";
	char _programmer[128] = "-Programmer=true;\".\\images\\sku\\prog_firehose_sdx55.mbn\"";
	char _devtype[] = "-deviceType=\"NAND\"";
	char _params[] = "-VALIDATIONMODE=0 -SWITCHTOFIREHOSETIMEOUT=50 -RESETTIMEOUT=500 -RESETDELAYTIME=5 -MaxPayloadSizeToTargetInBytes=true;49152";
	char _searchpath[256] = "-searchpath=\".\\images\\sku\"";
	char _rawprogram[128] = "-Rawprogram=\"rawprogram_nand_p4K_b256K.xml\"";
	char _patch[128] = "-Patch=\"patch_p4K_b256K.xml\"";
	char _logpath[] = "-logfilepath=\".\\log.txt\"";
	string _skupath;

	MAINDUT->ParamStr(param, "comport", out_str, "");
	sprintf_s(_comport, "-COM=%s", out_str.c_str());

	MAINDUT->ParamStr(param, "sku", _skupath, "");
	sprintf_s(_searchpath, "-searchpath=\".\\images\\%s\"", _skupath.c_str());

	MAINDUT->ParamStr(param, "programmer", out_str, "");
	sprintf_s(_programmer, "-Programmer=true;\".\\images\\%s\\%s\"", _skupath.c_str(), out_str.c_str());

	MAINDUT->ParamStr(param, "rawprogram", out_str, "");
	sprintf_s(_rawprogram, "-Rawprogram=\"%s\"", out_str.c_str());

	MAINDUT->ParamStr(param, "patch", out_str, "");
	sprintf_s(_patch, "-Patch=\"%s\"", out_str.c_str());

	sprintf_s(cmd, "%s %s %s %s %s %s %s %s %s %s", _exe, _mode, _comport, _programmer, _devtype, _params, _searchpath, _rawprogram, _patch, _logpath);
	RDLOG->WriteLogf(" QFIL download command:\n %s\n", cmd);

	ret = dos.Send(cmd, result, "Finish Download", 299, 180000);
	RDLOG->WriteLog(result.c_str());

	if (result.find("Download Succeed") != string::npos)
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, "PASS");
	else
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");

	return ret;
}

int CQcFwdl::qsahara_download(const char* item, const Json::Value& param)
{
	int ret = S_FALSE;
	CDOS dos;
	string out_str;
	string result;
	string item_name = param["item_name"].asString();
	char cmd[1024];
	char _exe[] = "\"C:\\Program Files (x86)\\Qualcomm\\QPST\\bin\\QSaharaServer.exe\"";
	char _portname[16];
	char _sku[32];
	char _images_param[512];

	MAINDUT->ParamStr(param, "port_name", out_str, "");
	sprintf_s(_portname, "-p \\\\.\\%s", out_str.c_str());

	MAINDUT->ParamStr(param, "sku", out_str, "");
	strcpy_s(_sku, out_str.c_str());

	MAINDUT->ParamStr(param, "images_param", out_str, "");
	strcpy_s(_images_param, out_str.c_str());

	std::regex rule("sku");
	string s = std::regex_replace(_images_param, rule, _sku);

	sprintf_s(cmd, "%s %s %s", _exe, _portname, s.c_str());
	RDLOG->WriteLogf(" QSahara download command:\n %s\n", cmd);

	ret = dos.Send(cmd, result, 20000, 5);
	RDLOG->WriteLog(result.c_str());

	if (result.find("Successfully uploaded all images") != string::npos && result.find("Sahara protocol completed") != string::npos)
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, "PASS");
	else
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");

	return ret;
}










