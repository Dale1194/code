#pragma once


using namespace std;

class COtherDut
{
public:
	COtherDut();
	virtual ~COtherDut();

	int AddSubDut(LPVOID ptr, const char* subdut_name);
	CSubDut* HaveTestItem(const char* item_name);
	int InitTest(const Json::Value& param);
	int PreEndTest(const Json::Value& param);
	int PostEndTest(const Json::Value& param);

private:
	typedef void(COtherDut::*CREATOR)(LPVOID ptr);
private:
	void create_subdut(LPVOID ptr, const char* subdut_name){ (this->*m_factory[subdut_name])(ptr); }


	// ***** ADD_SUB_DUT Step 2 *****
	// add function "add_pj_xxx" or "add_station_xxx"
	void create_pj_haipham(LPVOID ptr) { m_subduts.push_back(new CPjHaipham(ptr)); }
	void create_pj_susu(LPVOID ptr) { m_subduts.push_back(new CPjsusu(ptr)); }
	void create_pj_dale(LPVOID ptr) { m_subduts.push_back(new CPjDale(ptr)); }

private:
	std::map<string, CREATOR> m_factory;
	std::vector<CSubDut*> m_subduts;
};

