﻿#include "stdafx.h"
#include <string>
#include <ctime>
#include <vector>
#include <map>
#include "Dut.h"
#include "PjDale.h"
#include <regex>

extern CDOS;

CPjDale::CPjDale(LPVOID ptr)
{
	m_main_dut = ptr;

	// Write by Dale

	//ReadData(data);
	//Print_data(data);
	add_test_item("TEST_READ_DATA", &CPjDale::test_READ_DATA);
	//add_test_item("TEST_PRINT_DATA", &CPjDale::test_PRINT_DATA);
	add_test_item("TEST_PIR_MIN_VALUE", &CPjDale::test_PIR_MIN_VALUE);
	add_test_item("TEST_PIR_MAX_VALUE", &CPjDale::test_PIR_MAX_VALUE);
	add_test_item("TEST_PIR_AVERAGE_VALUE", &CPjDale::test_PIR_AVERAGE_VALUE);
	add_test_item("TEST_PIR_STD_VALUE", &CPjDale::test_PIR_STD_VALUE);
	//------------------------------------------
	add_test_item("TEST_GET_VOLT", &CPjDale::test_GET_VOLT);
	add_test_item("TEST_GET_CURR", &CPjDale::test_GET_VOLT);
	add_test_item("TEST_GET_OHM", &CPjDale::test_GET_OHM);
	add_test_item("TEST_GET_OHM_4W", &CPjDale::test_GET_OHM_4W);

}

CPjDale::~CPjDale()
{
}

bool CPjDale::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CPjDale::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;

	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);

	return ret;
}

int CPjDale::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

void CPjDale::ReadData(double* data)
{
	srand((unsigned)time(NULL));
	int i = 0;
	for (; i < ARRAY_SIZE;)
	{
		Valuerandom = (rand() % 100);
		if (Valuerandom > 20 && Valuerandom < 88)
		{
			data[i] = Valuerandom;
			i++;
		}
	}

	if (i == ARRAY_SIZE)
	{
		MAINDUT->log_sfis_and_set_info_no_judge("READ_DATA", CSfisCsv::Pass, "PASS");
	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge("READ_DATA", CSfisCsv::Fail, "FAIL");
	}

	RDLOG->WriteLogf("Array Value : [ ");

	for (size_t j = 0; j < ARRAY_SIZE; j++)
	{
		if (j == ARRAY_SIZE - 1)
		{
			RDLOG->WriteLogf("%.2f ]", data[j]);
		}
		else
		{
			RDLOG->WriteLogf("%.2f, ", data[j]);
		}
	}
	RDLOG->WriteLogf("\n");
}
//double Value = 0;
//int i = 0;
//srand((unsigned)time(NULL));
//while (i < ARRAY_SIZE)
//{
//	Value = (rand() % 100);
//	if (Value > 30 && Value < 50)
//	{
//		data[i] = Value;
//		i++;
//	}
//}
//	srand((unsigned)time(NULL));
//	for (int i = 0; i < ARRAY_SIZE;)
//	{
//		Valuerandom = (rand() % 100);
//		if (Valuerandom > 20 && Valuerandom < 88)
//		{
//			data[i] = Valuerandom;
//			i++;
//		}
//	}
//
//	RDLOG->WriteLogf("Array Value : [ ");
//	for (size_t i = 0; i < ARRAY_SIZE; i++)
//	{
//		if (i == ARRAY_SIZE - 1)
//		{
//			RDLOG->WriteLogf("%.2f ]", data[i]);
//		}
//		else
//		{
//			RDLOG->WriteLogf("%.2f, ", data[i]);
//		}
//
//	}
//	RDLOG->WriteLogf("\n");
//}
//void CPjDale::Print_data(double* data)
//{
//	RDLOG->WriteLogf("Array Value : [ ");
//	for (size_t i = 0; i < ARRAY_SIZE; i++)
//	{
//		if (i==ARRAY_SIZE-1)
//		{
//			RDLOG->WriteLogf("%.2f ]", data[i]);
//		}
//		else
//		{
//			RDLOG->WriteLogf("%.2f, ", data[i]);
//		}
//	
//	}
//	RDLOG->WriteLogf("\n");
//}
//int CPjDale::test_PRINT_DATA(const char*item, const Json::Value&param)
//{
//	Print_data(data);
//	return  RET_SUCCESS;
//}

int CPjDale::test_READ_DATA(const char*item, const Json::Value&param)
{
	ReadData(data);
	return RET_SUCCESS;
}

int CPjDale::test_PIR_MIN_VALUE(const char*item, const Json::Value&param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();

	for (size_t i = 0; i < ARRAY_SIZE; i++)
	{
		if (dMin>data[i])
		{
			dMin = data[i];
		}
	}
	if ((dMin) > 9999) // giá trị nhận về 9999 của 1 lần đo là 1 giá trị bất thường
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	}
	else
	{
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), dMin);
		ret = RET_SUCCESS;

	}
	RDLOG->WriteLogf("Min Value: %.1f\n", dMin);
	return ret;
}
int CPjDale::test_PIR_MAX_VALUE(const char* item, const Json::Value&param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();
	for (size_t i = 0; i < ARRAY_SIZE; i++)
	{
		if (dMax < data[i])
		{
			dMax = data[i];
		}
	}
	if ((dMax) > 9999) // giá trị nhận về 9999 của 1 lần đo là 1 giá trị bất thường
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	}
	else
	{
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), dMax);
		ret = RET_SUCCESS;

	}
	RDLOG->WriteLogf("Max Value: %.1f\n", dMax);
	return ret;
}
int CPjDale::test_PIR_AVERAGE_VALUE(const char* item, const Json::Value&param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();
	for (size_t i = 0; i < ARRAY_SIZE; i++)
	{
		dAverage += data[i];
	}
	dAverage = dAverage / (double)ARRAY_SIZE;

	if ((dAverage) > 0)
	{
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), dAverage);
		ret = RET_SUCCESS;
	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	}
	RDLOG->WriteLogf("AVERAGE VALUE: %.1f\n", dAverage);
	return ret;
}
int CPjDale::test_PIR_STD_VALUE(const char*item, const Json::Value&param)
{
	int ret = RET_FAIL;
	string item_name = param["item_name"].asString();

	for (size_t i = 0; i < ARRAY_SIZE; i++)
	{
		dStd += pow((data[i] - dAverage), 2);
	}

	dStd = dStd / ((double)ARRAY_SIZE - 1); // if Array_size > 1000 then use sStd = dStd/((double)ARRAY_SIZE -1);
	dStd = sqrt(dStd);

	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, dStd);
	RDLOG->WriteLogf("STD Value: %.2f\n", dStd);
	return 0;
}
int CPjDale::test_GET_VOLT(const char*item, const Json::Value&param)
{
	int ret = RET_FAIL;
	int count_sample = 0; //Đếm số lần lấy mẫu.
	double dDCVolt = 0;
	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL);
	{
		std::vector<double> array_DC_volt;
		while (count_sample<count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_AC_VOLT,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_DC_VOLTAGE(channel, &dDCVolt);
			count_sample++;
			RDLOG->WriteLogf("Voltage Value[%d] : %f\n", count_sample, dDCVolt);
			array_DC_volt.push_back(dDCVolt);
		}
		dDCVolt = 0;
		for each(double var in array_DC_volt)
		{
			dDCVolt += var;
		}
		dDCVolt /= (double)array_DC_volt.size();
		RDLOG->WriteLogf("Voltage Average Value : %f\n", dDCVolt);
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), dDCVolt);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}

int CPjDale::test_GET_CURR(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	int count_sample = 0;
	double DC_current = 0;
	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		std::vector<double> sample_DC_curr;
		while (count_sample < count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_DC_CURR,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			//Range, Resolution, IntegrationTime, CH Delay, Avg Count)
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_DC_CURRENT(channel, &DC_current);
			count_sample++;
			RDLOG->WriteLogf(" Current Value[%d]: %f\n", count_sample, DC_current);
			sample_DC_curr.push_back(DC_current);
		}
		DC_current = 0;
		for each (double var in sample_DC_curr)
		{
			DC_current += var;
		}
		DC_current /= (double)sample_DC_curr.size();
		resistance = volt / DC_current;
		RDLOG->WriteLogf(" Current Average Value: %f\n", DC_current);
		MAINDUT->log_sfis_and_set_info(item_name.c_str(), DC_current);
		MAINDUT->log_sfis_and_set_info_no_judge("CAL_RESISTOR_VALUE", CSfisCsv::Pass, resistance);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}
int CPjDale::test_GET_OHM(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	int count_sample = 0;
	double pdOHM = 0;
	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		std::vector<double> sample_OHM;
		while (count_sample < count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_OHM,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_RESISTANCE(channel, &pdOHM);
			count_sample++;
			RDLOG->WriteLogf(" Resistance Value[%d]: %f\n", count_sample, pdOHM);
			sample_OHM.push_back(pdOHM);
		}
		pdOHM = 0;
		for each (double var in sample_OHM)
		{
			pdOHM += var;
		}
		pdOHM /= (double)sample_OHM.size();
		RDLOG->WriteLogf(" Resistance Average Value: %f\n", pdOHM);
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, pdOHM);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}
int CPjDale::test_GET_OHM_4W(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	int count_sample = 0;
	double pdOHM = 0;

	string item_name = PARAM_S("item_name");
	string GPIBname = PARAM_S("GPIB_Name");
	int channel = PARAM_N("Channel");
	int count = PARAM_N("Count");
	const char* GPIBnamestr = GPIBname.c_str();
	if (MAINDUT->use_gpibdev(GPIBnamestr) != NULL)
	{
		std::vector<double> sample_OHM;
		while (count_sample < count)
		{
			MAINDUT->use_gpibdev(GPIBnamestr)->SET_DMM_MEAS_PARA(DMM_TYPE_OHM_4W,
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			MAINDUT->use_gpibdev(GPIBnamestr)->READ_RESISTANCE_4W(channel, &pdOHM);
			count_sample++;
			RDLOG->WriteLogf(" Resistance Value[%d]: %f\n", count_sample, pdOHM);
			sample_OHM.push_back(pdOHM);
		}
		pdOHM = 0;
		for each (double var in sample_OHM)
		{
			pdOHM += var;
		}
		pdOHM /= (double)sample_OHM.size();
		RDLOG->WriteLogf(" Resistance Average Value: %f\n", pdOHM);
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, pdOHM);
		return RET_SUCCESS;
	}
	MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");
	return ret;
}