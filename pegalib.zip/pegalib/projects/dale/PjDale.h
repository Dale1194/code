#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

#define ARRAY_SIZE 10

class CPjDale :
	public CSubDut
{
public:
	CPjDale(LPVOID ptr);
	virtual ~CPjDale();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CPjDale::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int CPjDale::test_PIR_MIN_VALUE(const char*item, const Json::Value&param);
	int CPjDale::test_PIR_MAX_VALUE(const char*item, const Json::Value&param);
	int CPjDale::test_PIR_AVERAGE_VALUE(const char*item, const Json::Value&param);
	int CPjDale::test_PIR_STD_VALUE(const char* item, const Json::Value&param);


	//int CPjDale::test_PRINT_DATA(const char*item, const Json::Value&param);
	int CPjDale::test_READ_DATA(const char*item, const Json::Value&param);
	//void CPjDale::Print_data(double*data);
	void CPjDale::ReadData(double* data);

	int CPjDale::test_GET_VOLT(const char* item, const Json::Value&param);
	int CPjDale::test_GET_CURR(const char*item, const Json::Value&param);
	int CPjDale::test_GET_OHM(const char*item, const Json::Value&param);
	int CPjDale::test_GET_OHM_4W(const char*item, const Json::Value&param);


private:
	std::map<string, CPjDale::FN_CMD> m_command;

	enum result_ret
	{
		RET_SUCCESS = 0,
		RET_FAIL
	};
	double volt = 0;
	double resistance = 0;

	double data[ARRAY_SIZE];
	double dMin = 1000;
	double dMax = 0;
	double dAverage = 0;
	double dStd = 0;
	double Valuerandom = 0;
};