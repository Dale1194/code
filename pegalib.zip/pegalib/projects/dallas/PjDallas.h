#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CPjDallas :
	public CSubDut
{
public:
	CPjDallas(LPVOID ptr);
	virtual ~CPjDallas();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CPjDallas::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int CPjDallas::test_CMD_ROOT(const char* item, const Json::Value& param);
	int CPjDallas::test_SET_ISN(const char* item, const Json::Value& param);


private:
	std::map<string, CPjDallas::FN_CMD> m_command;

	float m_source_voltage;
};

