#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "PjDallas.h"
#include <regex>

extern CDOS;

CPjDallas::CPjDallas(LPVOID ptr)
{
	m_main_dut = ptr;

	add_test_item("CMD_ROOT", &CPjDallas::test_CMD_ROOT);
	add_test_item("SET_MLB_ISN", &CPjDallas::test_SET_ISN);

}


CPjDallas::~CPjDallas()
{
}

bool CPjDallas::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CPjDallas::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CPjDallas::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CPjDallas::test_CMD_ROOT(const char* item, const Json::Value& param)
{

	string adb_result;
	string cmd_adb = "root ";

	MAINDUT->adb_command(cmd_adb.c_str(), adb_result, 1000);
	RDLOG->WriteLogf(" result:%s\n", adb_result.c_str());

	//RDLOG->WriteLogf(" min result:%s\n", adb_result.c_str());
	return 0;
}

int CPjDallas::test_SET_ISN(const char* item, const Json::Value& param)
{
	string get_isn;
	string adb_result;
	get_isn = MAINDUT->m_isn_ui;
	string cmd_adb = "shell ats system -setmlbsn " + get_isn;

	if (!get_isn.empty())
	{
		MAINDUT->adb_command(cmd_adb.c_str(), adb_result, 1000);
		MAINDUT->log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, "PASS");
		RDLOG->WriteLogf(" result:%s\n", adb_result.c_str());

	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, "FAIL");
	}
	return 0;
}

