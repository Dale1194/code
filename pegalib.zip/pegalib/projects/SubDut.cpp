#include "stdafx.h"
#include <string>
#include "Dut.h"
#include "SubDut.h"


CSubDut::CSubDut()
{
}


CSubDut::~CSubDut()
{
}

