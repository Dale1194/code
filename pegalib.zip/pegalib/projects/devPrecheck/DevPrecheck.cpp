#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "DevPrecheck.h"
#include "Config.h"



CDevPrecheck::CDevPrecheck(LPVOID ptr)
{
	 m_main_dut = ptr;

	 add_test_item("TEST_HELLO_PEGA", &CDevPrecheck::cmd_hello_pega);
	 const Json::Value param;
	 InitTest(param);

}


CDevPrecheck::~CDevPrecheck()
{
}

bool CDevPrecheck::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CDevPrecheck::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CDevPrecheck::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CDevPrecheck::cmd_hello_pega(const char* item, const Json::Value& param)
{
	::OutputDebugStringA("hello pega");
	MAINDUT->log_sfis_and_set_info_no_judge("Hello_Pega", CSfisCsv::Pass, "PASS");
	RDLOG->WriteLog(" CDevPrecheck::cmd_hello_pega()\n");
	
	return 0;
}

int CDevPrecheck::InitTest(const Json::Value& param)
{
	int ret = S_OK;
	::OutputDebugStringA("CDevPrecheck::InitTest()");

	if (check_if_comport_open() == S_FALSE)
		ret = S_FALSE;

	if (check_if_gpib_connect() == S_FALSE)
		ret = S_FALSE;

	if (ret == S_FALSE)
	{
		MAINDUT->log_sfis_and_set_info_no_judge("TEST_INIT", CSfisCsv::Fail, "FAIL");
		MAINDUT->m_exit_test_and_no_sfis = true;
	}
	
	return ret;
}

int CDevPrecheck::check_if_comport_open()
{
	Json::Value ports;
	string port_name;
	int fail_code = S_OK;

	CConfig::getInstance()->GetPorts("INS34970", ports);

	for (unsigned int i = 0; i < ports.size(); i++)
	{
		if (ports[i]["Enable"].asBool() == true)
		{
			if (ports[i].isMember("Name"))
			{
				port_name = ports[i]["Name"].asString();
				if (MAINDUT->use_comport(port_name.c_str()) != NULL)
				{
					fail_code |= MAINDUT->use_comport(port_name.c_str())->Open();
					if (fail_code != S_OK)
					{
						RDLOG->WriteLogf(" Failed to open com port[%s]:%d\n", port_name.c_str(), fail_code);
						::MessageBoxA(g_uiwnd, "Failed to open com port", MAINDUT->m_id_name.c_str(), MB_OK + MB_ICONERROR);
					}
					MAINDUT->use_comport(port_name.c_str())->Close();
				}
				else
				{
					fail_code |= S_FALSE;
				}
			}
		}
	}

	return fail_code;
}

int CDevPrecheck::check_if_gpib_connect()
{
	Json::Value gpibs;
	string gpibinst_name;
	int fail_code = S_OK;

	CConfig::getInstance()->GetGPIBs(gpibs);

	for (unsigned int i = 0; i < gpibs.size(); i++)
	{
		if (gpibs[i]["Enable"].asBool() == true)
		{
			if (gpibs[i].isMember("Name"))
			{
				gpibinst_name = gpibs[i]["Name"].asString();
				if (MAINDUT->use_gpibdev(gpibinst_name.c_str()) == NULL)
				{
					fail_code |= S_FALSE;
				}
			}
		}
	}

	return fail_code;
}






