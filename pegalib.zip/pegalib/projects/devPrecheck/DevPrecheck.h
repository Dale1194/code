#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CDevPrecheck :
	public CSubDut
{
public:
	CDevPrecheck(LPVOID ptr);
	virtual ~CDevPrecheck();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);

	int InitTest(const Json::Value& param);

private:
	typedef int (CDevPrecheck::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int cmd_hello_pega(const char* item, const Json::Value& param);
	int check_if_comport_open();
	int check_if_gpib_connect();

private:
	std::map<string, CDevPrecheck::FN_CMD> m_command;
};

