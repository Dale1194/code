#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "SubDut.h"
#include "other_sub_dut.h"
#include "OtherDut.h"



COtherDut::COtherDut()
{
	// ***** ADD_SUB_DUT Step 3 *****
	// add mapping
	m_factory["HAIPHAM"] = &COtherDut::create_pj_haipham;
	m_factory["SUSU"] = &COtherDut::create_pj_susu;
	m_factory["DALE"] = &COtherDut::create_pj_dale;
}


COtherDut::~COtherDut()
{
	for (std::vector<CSubDut*>::iterator it = m_subduts.begin(); it != m_subduts.end(); ++it)
		delete (*it);
}

int COtherDut::AddSubDut(LPVOID ptr, const char* subdut_name)
{
	create_subdut(ptr, subdut_name);

	return 0;
}

CSubDut* COtherDut::HaveTestItem(const char* item_name)
{
	CSubDut* subdut = NULL;

	for (std::vector<CSubDut*>::iterator it = m_subduts.begin(); it != m_subduts.end(); ++it)
	{
		if ((*it)->FindTestItem(item_name))
		{
			subdut = (*it);
			break;
		}
	}

	return subdut;
}

int COtherDut::InitTest(const Json::Value& param)
{
	int ret = S_OK;

	for (std::vector<CSubDut*>::iterator it = m_subduts.begin(); it != m_subduts.end(); ++it)
		ret |= (*it)->InitTest(param);

	return ret;
}

int COtherDut::PreEndTest(const Json::Value& param)
{
	int ret = S_OK;

	for (std::vector<CSubDut*>::iterator it = m_subduts.begin(); it != m_subduts.end(); ++it)
		ret |= (*it)->PreEndTest(param);

	return ret;
}

int COtherDut::PostEndTest(const Json::Value& param)
{
	int ret = S_OK;

	for (std::vector<CSubDut*>::iterator it = m_subduts.begin(); it != m_subduts.end(); ++it)
		ret |= (*it)->PostEndTest(param);

	return ret;
}






