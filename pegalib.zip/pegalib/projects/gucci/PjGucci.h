#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CPjGucci :
	public CSubDut
{
public:
	CPjGucci(LPVOID ptr);
	virtual ~CPjGucci();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CPjGucci::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int gucci_just_test(const char* item, const Json::Value& param);

private:
	std::map<string, CPjGucci::FN_CMD> m_command;
};

