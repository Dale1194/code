#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "Config.h"
#include "modules\others\ToolVer.h"
#include "VarKey.h"
#include "Grds.h"



CGrds::CGrds(LPVOID ptr)
{
	m_main_dut = ptr;

	string gucci_temp = MAINDUT->m_temp_path + "\\gucci";
	m_guccizip = std::auto_ptr<CGucciZip>(new CGucciZip(MAINDUT->m_ui));
	m_guccizip->CreateSourceDir(gucci_temp.c_str());

	m_glog = new CGlog("logs", gucci_temp.c_str());
	m_gmetadata = new CGmetadata("metadata", gucci_temp.c_str());
	m_gmeasurement = new CGmeasurement("measurements", gucci_temp.c_str());
}


CGrds::~CGrds()
{
	delete m_glog;
	delete m_gmetadata;
	delete m_gmeasurement;
}

bool CGrds::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CGrds::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CGrds::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CGrds::InitTest(const Json::Value& param)
{
	char datetime[64];
	string test_desc = param["TestDesc"].asString();

	m_glog->WriteRow(CGlog::Info, CConfig::getInstance()->cfg_station_id.c_str());
	GetSystemDateTime(datetime, _countof(datetime));
	add_metadata(test_desc.c_str(), CToolVer::getInstance()->GetPegalibVer(), datetime);

	return 0;
}

int CGrds::PreEndTest(const Json::Value& param)
{
	return 0;
}

int CGrds::PostEndTest(const Json::Value& param)
{
	char datetime[64];
	GetSystemDateTime(datetime, _countof(datetime));
	finish_metadata(datetime);
	zip_and_backup();
	upload_specific_server();
	return 0;
}

void CGrds::add_metadata(const char* test_desc, const char* sw_ver, const char* start_datetime)
{
	unsigned int idx = CConfig::getInstance()->cfg_station_id.find("_");
	string line_type = CConfig::getInstance()->cfg_station_id.substr(0, idx);
	if (line_type == "MLB") line_type = "SMT";

	char sw_version[8];
	GetWinVer(sw_version, _countof(sw_version));

	m_gmetadata->test_name = CConfig::getInstance()->cfg_station_id;
	m_gmetadata->test_description = test_desc;
	m_gmetadata->spec_version = string(CCriteria::getInstance()->GetCriteriaFileName()).substr(0, string(CCriteria::getInstance()->GetCriteriaFileName()).find_last_of('.'));
	m_gmetadata->station_id = CConfig::getInstance()->cfg_device_id;
	m_gmetadata->line = line_type;
	m_gmetadata->line_id = CConfig::getInstance()->cfg_line_num;
	m_gmetadata->software_version = sw_version;
	m_gmetadata->framework_version = "";
	m_gmetadata->test_version = sw_ver;
	m_gmetadata->mode = MAINDUT->m_test_mode == OnLine ? "PRODUCTION" : "DEBUG";
	m_gmetadata->build_phase = CConfig::getInstance()->cfg_run_stage;
	m_gmetadata->start_date_time = start_datetime;
}

void CGrds::finish_metadata(const char* end_datetime)
{
	m_gmetadata->dut_id = MAINDUT->m_isn;
	MAINDUT->m_var["fw_version"] = "1.0";
	m_gmetadata->firmware_version = MAINDUT->m_var["fw_version"].asString();
	m_gmetadata->status = (MAINDUT->m_error_code.empty() ? "PASS" : "FAIL");
	m_gmetadata->failure_code = MAINDUT->m_error_code;
	m_gmetadata->end_date_time = end_datetime;
	/*if (m_test_mode == OnLine){
	m_gmetadata->device_config = sfis_get_device_config();
	}
	else{
	m_gmetadata->device_config = "";
	}*/
	//fox//m_gmetadata->device_config = (m_test_mode == OnLine ? sfis_get_device_config() : "OFFLINE_BY_PASS");
	m_gmetadata->device_config = MAINDUT->m_var[META_CONFIG].asString();

	m_gmetadata->WriteMetadata();
}

void CGrds::zip_and_backup()
{
	char date[64];
	SYSTEMTIME st;
	::GetLocalTime(&st);
	sprintf_s(date, "%.4d%.2d%.2d", st.wYear, st.wMonth, st.wDay);

	string passfail = (MAINDUT->m_error_code.empty() == true) ? "\\PASS\\" : "\\FAIL\\";

	char datetime[64];
	GetSystemDateTimeFormatB(datetime, _countof(datetime));

	string zip_name = MAINDUT->m_isn + "_" + CConfig::getInstance()->cfg_station_id + "_" + datetime + "_dutr.zip";
	string local_path = MAINDUT->m_local_path + passfail + date + "\\";
	string local_full_name = local_path + zip_name;
	int n = m_guccizip->StartZip(local_full_name.c_str());
	
	if (CConfig::getInstance()->cfg_server_log.enable_save == true)
	{
		string server_path = MAINDUT->m_server_path + passfail + date + "\\";
		string server_full_name = server_path + zip_name;
		::CopyFileA(local_full_name.c_str(), server_full_name.c_str(), true);
	}
}

void CGrds::upload_specific_server()
{

}



