#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"
#include "CommonApi.h"
#include "csvfile.h"
#include "Glog.h"
#include "Gmetadata.h"
#include "Gmeasurements.h"
#include "Gucci_zip.h"


using namespace std;

   /**
	* class CGrds : class of Result Data Specification for G
	* <SERIAL NUMBER>_<TEST NAME>_<TIMESTAMP>_dutr.zip
	*	> metadata.csv
	*	> logs.csv
	*	> measurements.csv
	*	> attachments (folder)
	*		@ N number of files
	*
	* References
	* RFC 4180 - Specification for csv files (All Column Headers must be present & ordered)
	* ISO 8601 - Standardization for date time formatting
	*/
class CGrds :
	public CSubDut
{
public:
	CGrds(LPVOID ptr);
	virtual ~CGrds();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);

	int InitTest(const Json::Value& param);
	int PreEndTest(const Json::Value& param);
	int PostEndTest(const Json::Value& param);
	

private:
	typedef int (CGrds::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	void add_metadata(const char* test_desc, const char* sw_ver, const char* start_datetime);
	void finish_metadata(const char* end_datetime);
	void zip_and_backup();
	void upload_specific_server();

private:
	std::map<string, CGrds::FN_CMD> m_command;


	CGlog*			m_glog;
	CGmetadata*		m_gmetadata;
	CGmeasurement*	m_gmeasurement;
	std::auto_ptr<CGucciZip> m_guccizip;
};

