#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "PjGucci.h"



CPjGucci::CPjGucci(LPVOID ptr)
{
	m_main_dut = ptr;

	add_test_item("GUCCI_JUST_TEST", &CPjGucci::gucci_just_test);
}


CPjGucci::~CPjGucci()
{
}

bool CPjGucci::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CPjGucci::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CPjGucci::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CPjGucci::gucci_just_test(const char* item, const Json::Value& param)
{
	::OutputDebugStringA("gucci_just_test");
	
	return 0;
}





