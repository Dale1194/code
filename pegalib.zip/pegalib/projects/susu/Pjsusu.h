#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CPjsusu :
	public CSubDut
{
public:
	CPjsusu(LPVOID ptr);
	virtual ~CPjsusu();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CPjsusu::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int CPjsusu::test_CMD_ROOT(const char* item, const Json::Value& param);
	int CPjsusu::test_SET_ISN(const char* item, const Json::Value& param);
	int CPjsusu::cmd_serial_command_susu(const char* item, const Json::Value& param);
	void show_pic_only(string pic_name, string pic_description);
	int CPjsusu::test_write_dut_info(const char* item, const Json::Value& param);
	int CPjsusu::test_get_sfis_info_all(const char* item, const Json::Value& param);
	int CPjsusu::cmd_detect_directly(const char* item, const Json::Value& param);


private:
	std::map<string, CPjsusu::FN_CMD> m_command;

	float m_source_voltage;
};



