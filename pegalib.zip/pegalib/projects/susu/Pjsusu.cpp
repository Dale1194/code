#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include "Pjsusu.h"
#include <regex>
#include "SFISLibApi.h"

extern CDOS;

CPjsusu::CPjsusu(LPVOID ptr)
{
	m_main_dut = ptr;

	add_test_item("CMD_ROOT", &CPjsusu::test_CMD_ROOT);
	add_test_item("SET_MLB_ISN", &CPjsusu::test_SET_ISN);
	add_test_item("TEST_SERIAL_COMMAND_SUSU", &CPjsusu::cmd_serial_command_susu);
	add_test_item("TEST_WRITE_DUT_INFO", &CPjsusu::test_write_dut_info);
	add_test_item("TEST_GET_SFIS_INFO_ALL", &CPjsusu::test_get_sfis_info_all);
	add_test_item("CMD_DETECT_DIRECTLY", &CPjsusu::cmd_detect_directly);
}


CPjsusu::~CPjsusu()
{
}

bool CPjsusu::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CPjsusu::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;
	
	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);
	
	return ret;
}

int CPjsusu::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CPjsusu::test_CMD_ROOT(const char* item, const Json::Value& param)
{

	string adb_result;
	string cmd_adb = "root ";

	MAINDUT->adb_command(cmd_adb.c_str(), adb_result, 1000);
	RDLOG->WriteLogf(" result:%s\n", adb_result.c_str());

	//RDLOG->WriteLogf(" min result:%s\n", adb_result.c_str());
	return 0;
}

int CPjsusu::test_SET_ISN(const char* item, const Json::Value& param)
{
	string get_isn;
	string adb_result;
	get_isn = MAINDUT->m_isn_ui;
	string cmd_adb = "shell ats system -setmlbsn " + get_isn;

	if (!get_isn.empty())
	{
		MAINDUT->adb_command(cmd_adb.c_str(), adb_result, 1000);
		MAINDUT->log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, "PASS");
		RDLOG->WriteLogf(" result:%s\n", adb_result.c_str());

	}
	else
	{
		MAINDUT->log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, "FAIL");
	}
	return 0;
}

int CPjsusu::cmd_serial_command_susu(const char* item, const Json::Value& param) {
	int ret = S_FALSE;
	bool is_port_open = false;
	string item_name;
	string port_nickname;
	int retry = MAINDUT->ParamInt(param, "retry", 0);
	int times = 0;
	string serial_cmd;
	string r_tmnl;
	unsigned int wr_wait;
	unsigned int r_timeout;
	string serial_result = "";
	string reg_result;
	string pic_name; //susu add
	string pic_description; //susu add
	bool is_pic_show = false; //susu add
	int test_result = S_FALSE;
	bool is_type_byte = false;

	MAINDUT->ParamStr(param, "item_name", item_name, "");
	MAINDUT->ParamStr(param, "port_nickname", port_nickname, "");
	MAINDUT->ParamStr(param, "w_cmd", serial_cmd, "");
	serial_cmd = serial_cmd + "\r";
	MAINDUT->ParamStr(param, "r_tmnl", r_tmnl, "");
	wr_wait = MAINDUT->ParamInt(param, "wr_wait", 10);
	r_timeout = MAINDUT->ParamInt(param, "r_timeout", 500);

	is_type_byte = MAINDUT->ParamBool(param, "is_type_byte", false);
	is_pic_show = MAINDUT->ParamBool(param, "is_pic_show", false);//susu add

	vector<char> serial_cmd_byte;
	char* charCMD_byte = nullptr;
	if (is_type_byte)
	{
		const char* v_default = "0x00";
		serial_cmd_byte = MAINDUT->ParamByte(param, "w_cmd", v_default);
		charCMD_byte = serial_cmd_byte.data();
	}

	do
	{
		auto initial_comport = MAINDUT->use_comport(port_nickname.c_str());
		if (initial_comport != NULL)
		{
			is_port_open = initial_comport->IsOpen();
			if (!is_port_open)
				ret = initial_comport->Open();

			RDLOG->WriteLogf(" serial_cmd(%d):%s\n", ret, serial_cmd.c_str());

			if (is_pic_show)
			{
				MAINDUT->ParamStr(param, "pic_name", pic_name, "");
				MAINDUT->ParamStr(param, "pic_description", pic_description, "");
				show_pic_only(pic_name, pic_description);
			}

			if (r_tmnl == "")
				if (!is_type_byte)
				{
					ret = initial_comport->WRString(serial_cmd.c_str(), serial_result, 200);
				}
				else
				{
					ret = initial_comport->WRString(charCMD_byte, serial_result, 200);
				}
			else
				if (!is_type_byte)
				{
					ret = initial_comport->WRString(serial_cmd.c_str(), serial_result, r_tmnl.c_str(), wr_wait, r_timeout);
				}
				else
				{
					ret = initial_comport->WRString(charCMD_byte, serial_result, r_tmnl.c_str(), wr_wait, r_timeout);
				}
			
			RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, serial_result.c_str());

			if (!is_port_open)
				initial_comport->Close();
		}

		if (ret == S_OK)
			if (param.isMember("reg_enable"))
				ret = MAINDUT->regular(serial_result, param, reg_result);

		times++;
		if (ret == S_OK)
			test_result = MAINDUT->log_sfis_and_set_info(item_name.c_str(), reg_result.c_str(), times > retry);
		else
			MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL", times > retry);

	} while (times <= retry && test_result==S_FALSE);

	if (is_pic_show)
	{
		MAINDUT->m_ui->PopupPicMsgFormClose();
	}
	return ret;
}

void CPjsusu::show_pic_only(string pic_name, string pic_description) {
	string path_pic;
	GetCurrentPath(path_pic);
	path_pic = path_pic + "\\" + pic_name;
	HANDLE event;
	event = CreateEvent(NULL, TRUE, FALSE, NULL);
	ResetEvent(event);
	MAINDUT->m_ui->PopupPicMsgForm(event, path_pic.c_str(), pic_description.c_str(), -1);
}

int CPjsusu::test_write_dut_info(const char* item, const Json::Value& param) {
	//Mandatory
	auto data = MAINDUT->m_var.toStyledString();
	int ret = S_FALSE;
	string serial_result = "";
	int times = 0;
	string item_name = param["item_name"].asString();
	string port_nickname;
	bool is_port_open = false;
	int test_result = S_FALSE;
	//Variables
	string wr_cmd;
	string data_name;
	string chk_cmd;
	string r_tmnl;
	string w_tmnl;
	unsigned int wr_wait = MAINDUT->ParamInt(param, "wr_wait", 10);
	unsigned int r_timeout = MAINDUT->ParamInt(param, "r_timeout", 500);
	MAINDUT->ParamStr(param, "chk_cmd", chk_cmd, "");
	MAINDUT->ParamStr(param, "r_tmnl", r_tmnl, "");

	Json::Value w_cmd = param["w_cmd"];
	unsigned int w_timeout = MAINDUT->ParamInt(w_cmd, "w_timeout", 500);
	MAINDUT->ParamStr(w_cmd, "wr_cmd", wr_cmd, "");
	MAINDUT->ParamStr(w_cmd, "w_tmnl", w_tmnl, "");
	MAINDUT->ParamStr(w_cmd, "data_name", data_name, "");
	MAINDUT->ParamStr(param, "port_nickname", port_nickname, "");
	string data_value = MAINDUT->m_var[data_name].asString();
	

	if (MAINDUT->use_comport(port_nickname.c_str()) != NULL)
	{
		is_port_open = MAINDUT->use_comport(port_nickname.c_str())->IsOpen();
		if (!is_port_open)
			ret = MAINDUT->use_comport(port_nickname.c_str())->Open();

		MAINDUT->m_rdlog->WriteLogf(" serial_cmd(%d):%s\n", ret, wr_cmd.c_str());

		//Wirte info
		string from = "%0";
		string to = data_value;
		size_t start_pos = wr_cmd.find(from);
		if (start_pos != std::string::npos) {
			wr_cmd.replace(start_pos, from.length(), to);
		}

		ret = MAINDUT->use_comport(port_nickname.c_str())->WRString(wr_cmd.c_str(), serial_result, 200);
		string confirm = "Y\n";
		ret = MAINDUT->use_comport(port_nickname.c_str())->WRString(confirm.c_str(), serial_result, w_tmnl.c_str(), 200, w_timeout);
		if (ret == S_OK)
		{
			//check result after write
			ret = MAINDUT->use_comport(port_nickname.c_str())->WRString(chk_cmd.c_str(), serial_result, w_tmnl.c_str(), 200, w_timeout);
			if (serial_result.find(data_value) == std::string::npos)
			{
				ret = S_FALSE;
			}
			RDLOG->WriteLogf(" serial_result(%d):%s<:)\n", ret, serial_result.c_str());
		}
		if (!is_port_open)
			MAINDUT->use_comport(port_nickname.c_str())->Close();
	}

	times++;
	if (ret == S_OK)
		test_result = MAINDUT->log_sfis_and_set_info(item_name.c_str(), data_value.c_str(), true);
	else
		MAINDUT->log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL", true);

	return ret;
}

int CPjsusu::test_get_sfis_info_all(const char* item, const Json::Value& param) {
	int ret = S_FALSE;
	ret = S_OK;
	string result;
	string myId = "V24002427";
	//CSFISLibApi::getInstance()->Init("V24002427");
	CSFISLibApi::getInstance()->Login("V24002427", result);
	//CSFISLibApi::getInstance()->GetDbInfo(result);
	string userId = CSFISLibApi::getInstance()->GetUserId();
	string userName = CSFISLibApi::getInstance()->GetUserName();
	return ret;
}

int CPjsusu::cmd_detect_directly(const char* item, const Json::Value& param) {
	return 0;
}



