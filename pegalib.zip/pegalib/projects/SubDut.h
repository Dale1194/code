#pragma once
#include "include/json/json.h"


#define MAINDUT	((CDut*)m_main_dut)
#define RDLOG	((*(CDut*)m_main_dut).m_rdlog)

using namespace std;

class CSubDut
{
public:
	CSubDut();
	virtual ~CSubDut();

	virtual bool FindTestItem(const char* item_name) = 0;
	virtual int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param) = 0;
	virtual int InitTest(const Json::Value& param) { return 0; }
	virtual int PreEndTest(const Json::Value& param) { return 0; }
	virtual int PostEndTest(const Json::Value& param) { return 0; }

protected:
	PVOID m_main_dut;
	


};

