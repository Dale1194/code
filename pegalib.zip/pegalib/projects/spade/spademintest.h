#pragma once
#include "..\SubDut.h"
#include "include/json/json.h"


using namespace std;

class CMinspadetest :
	public CSubDut
{
public:
	CMinspadetest(LPVOID ptr);
	virtual ~CMinspadetest();

	bool FindTestItem(const char* item_name);
	int RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param);



private:
	typedef int (CMinspadetest::*FN_CMD)(const char* item, const Json::Value& param);
	int add_test_item(const char* item_name, FN_CMD fn_cmd);

	int CMinspadetest::test_GET_SERIAL(const char* item, const Json::Value& param);
	int CMinspadetest::test_GET_VERSION(const char* item, const Json::Value& param);

	int CMinspadetest::test_ENTER_KL15(const char* item, const Json::Value& param);
	int CMinspadetest::test_EXIT_KL15(const char* item, const Json::Value& param);

	int CMinspadetest::test_PIR_MAX(const char* item, const Json::Value& param);
	int CMinspadetest::test_PIR_MIN(const char* item, const Json::Value& param);
	int CMinspadetest::test_PIR_AVG(const char* item, const Json::Value& param);
	int CMinspadetest::test_PIR_STDEV(const char* item, const Json::Value& param);


	int CMinspadetest::test_GET_VOL(const char* item, const Json::Value& param);
	int CMinspadetest::test_GET_CURR(const char* item, const Json::Value& param);
	int CMinspadetest::test_HELLO_WOLRD(const char* item, const Json::Value& param);

private:



	std::map<string, CMinspadetest::FN_CMD> m_command;



	string key_cmd, str_cmd, str_result;
	double  min, max;
	double avg, std_dev;
	boolean exit_kl15 = FALSE;


};

