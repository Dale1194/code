#include "stdafx.h"
#include <string>
#include <vector>
#include <map>
#include "Dut.h"
#include <cctype> 
#include <iostream>
#include <sstream> 
#include <numeric>
#include "spademintest.h"

CMinspadetest::CMinspadetest(LPVOID ptr)
{
	m_main_dut = ptr;
	//add_item_test
	add_test_item("GET_SERIAL", &CMinspadetest::test_GET_SERIAL);
	add_test_item("GET_VERSION", &CMinspadetest::test_GET_VERSION);

	add_test_item("TEST_ENTER_KL15", &CMinspadetest::test_ENTER_KL15);
	add_test_item("TEST_EXIT_KL15", &CMinspadetest::test_EXIT_KL15);

	add_test_item("TEST_PIR_MAX", &CMinspadetest::test_PIR_MAX);
	add_test_item("TEST_PIR_MIN", &CMinspadetest::test_PIR_MIN);
	add_test_item("TEST_PIR_AVG", &CMinspadetest::test_PIR_AVG);
	add_test_item("TEST_PIR_STDEV", &CMinspadetest::test_PIR_STDEV);

	add_test_item("TEST_GET_VOL", &CMinspadetest::test_GET_VOL);
	add_test_item("TEST_GET_CURR", &CMinspadetest::test_GET_CURR);





	add_test_item("TEST_HELLO_WORLD", &CMinspadetest::test_HELLO_WOLRD);
}

CMinspadetest::~CMinspadetest()
{
}

bool CMinspadetest::FindTestItem(const char* item_name)
{
	return (m_command.find(item_name) != m_command.end());
}

int CMinspadetest::RunScriptCommand(string& item_name, string& replaced_item_name, Json::Value& item_param)
{
	int ret = S_FALSE;

	ret = (this->*m_command[item_name])(replaced_item_name.c_str(), item_param);

	return ret;
}

int CMinspadetest::add_test_item(const char* item_name, FN_CMD fn_cmd)
{
	m_command[item_name] = fn_cmd;
	return 0;
}

int CMinspadetest::test_GET_VERSION(const char* item, const Json::Value& param)
{
	string key_name;
	char dut[] = { "DUT" };
	string str_result, str_improve;

	MAINDUT->ParamStr(param, "key_name", key_name, "");

	string str_cmd = key_name + "\r";

	if (MAINDUT->use_comport(dut) != NULL)
	{
		if (MAINDUT->use_comport(dut)->Open() == S_OK)
		{
			MAINDUT->use_comport(dut)->WRString("version\r", str_result, ">", 100, 500);
			RDLOG->WriteLogf(" result:%s\n", str_result.c_str());
		}
		MAINDUT->use_comport(dut)->Close();
	}
	// improve string no white blank
	for (size_t i = 0; i < str_result.size(); i++)
	{
		if ((str_result[i] != ' ') && (str_result[i] != '\t') && (str_result[i] != '\n') && (str_result[i] != '#'))
		{
			str_improve += str_result[i];
		}
	}
	// split \t, \r, :  
	//std::vector<string> string_vector;
	//char temp[256];
	//char* next_token = NULL;
	//char* token;
	//strcpy_s(temp, str_improve.c_str());
	//token = strtok_s(temp, "\t\r:", &next_token);
	//while (token != NULL)
	//{
	//	string_vector.push_back(token);
	//	token = strtok_s(NULL, "\t\r:", &next_token);
	//}
	//----Map each value index
	//std::map<std::string, std::string> map;
	//for (size_t k = 1; k < (string_vector.size()); k = k + 2)
	//{
	//	map[string_vector[k]] = string_vector[k + 1];
	//}
	MAINDUT->log_sfis_and_set_info(item, "PASS");
	return 0;
}

int CMinspadetest::test_GET_SERIAL(const char* item, const Json::Value& param)
{
	char dut[] = { "DUT" };
	string key_name1;
	MAINDUT->ParamStr(param, "key_name1", key_name1, "");
	string str_cmd = key_name1 + "\r";
	string str_result;
	if (MAINDUT->use_comport(dut) != NULL)
	{
		if (MAINDUT->use_comport(dut)->Open() == S_OK)
		{
			//to write command to USB Port --//
			MAINDUT->use_comport(dut)->WRString(str_cmd.c_str(), str_result, ">", 100, 500);
			RDLOG->WriteLogf(" result:%s\n", str_result.c_str());
		}
		MAINDUT->use_comport(dut)->Close();
	}
	// split \n, \r  from str_result
	std::vector<string> vector_result;
	char temp[256];
	char* next_token = NULL;
	char* token;
	strcpy_s(temp, str_result.c_str());
	token = strtok_s(temp, "\n\r>", &next_token);
	while (token != NULL)
	{
		vector_result.push_back(token);
		token = strtok_s(NULL, "\n\r>", &next_token);
	}
	MAINDUT->log_sfis_and_set_info(item, vector_result[1].c_str());
	return 0;
}

int CMinspadetest::test_ENTER_KL15(const char* item, const Json::Value& param)
{
	char dut[] = { "DUT" };
	// cmd HEX to exit terminal
	const char cmd[3] = { 0x03, 0x0d, 0x00 };
	string serial_string_exit, str_result;
	std::vector<string> vec_result;
	std::vector<string> samp_PIR_val;
	//std::vector<int> num_PIR_val;
	std::vector<double> num_PIR_val;
	int count_sample = 0;
	string str_check = "KL15 pass-through";
	string str_check_exit = "#";
	boolean	check_exit = FALSE;
	double variance = 0, sum;
	if (MAINDUT->use_comport(dut) != NULL)
	{
		if (MAINDUT->use_comport(dut)->Open() == S_OK)
		{
			MAINDUT->use_comport(dut)->WriteString("\r");
			MAINDUT->use_comport(dut)->WRString("diag-kl15-passthru\r", str_result, ">", 100, 500);
			RDLOG->WriteLogf(" RESULT:%s\n", str_result.c_str());
			// check string match or not to know KL15 pass or not
			size_t check_match = str_result.find(str_check);
			if (check_match != string::npos)
			{
				MAINDUT->log_sfis_and_set_info(item, "PASS");
				//MAINDUT->use_comport(dut)->WriteString("ip+\r");
				::Sleep(1000);
			}
			else MAINDUT->log_sfis_and_set_info(item, "FAIL");
			MAINDUT->use_comport(dut)->WriteString("\r");
			MAINDUT->use_comport(dut)->WriteString(cmd);
			MAINDUT->use_comport(dut)->ReadString(serial_string_exit);
			RDLOG->WriteLogf(serial_string_exit.c_str());
			if (serial_string_exit == "") // #\r\r\n#
			{
				exit_kl15 = TRUE;
			}
			else exit_kl15 = FALSE;
		}
		MAINDUT->use_comport(dut)->Close();
	}
	return 0;
}

int CMinspadetest::test_GET_VOL(const char* item, const Json::Value& param)
{
	char DMM_name[] = "INS34970";
	int count_sample = 0;
	int iCH = 103;
	double pdDCVolt = 0;
	std::vector<double> sample_DC_volt;
	if (MAINDUT->use_gpibdev(DMM_name) != NULL)
	{
		while (count_sample < 5)
		{
			MAINDUT->use_gpibdev(DMM_name)->SET_DMM_MEAS_PARA(DMM_TYPE_DC_VOLT, 
					"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
			       //Range, Resolution, IntegrationTime, CH Delay, Avg Count)
			MAINDUT->use_gpibdev(DMM_name)->READ_DC_VOLTAGE(iCH, &pdDCVolt);
			count_sample++;
			sample_DC_volt.push_back(pdDCVolt);
		}
		count_sample = 0;
		MAINDUT->log_sfis_and_set_info(item, pdDCVolt);
	}
	return 0;
}

int CMinspadetest::test_GET_CURR(const char* item, const Json::Value& param)
{
	char DMM_name[] = "INS34970";
	double DC_current = 0;
	int iCH_curr = 121; // only 21,22
	if (MAINDUT->use_gpibdev(DMM_name) != NULL)
	{
		MAINDUT->use_gpibdev(DMM_name)->SET_DMM_MEAS_PARA(DMM_TYPE_DC_CURR, 
				"AUTO", "6", "1", "NONE", "NONE", "OFF", 0.001, 1);
		MAINDUT->use_gpibdev(DMM_name)->READ_DC_CURRENT(121, &DC_current);
	}
	MAINDUT->use_gpibdev(DMM_name)->GPIB_WRITE("ROUT:SCAN (@103, 121)");
	MAINDUT->log_sfis_and_set_info(item, DC_current);
	//ROUT:SCAN(@103, 121)	
	return 0;
}

int CMinspadetest::test_EXIT_KL15(const char* item, const Json::Value& param)
{
	if (exit_kl15 == TRUE)
	{
		MAINDUT->log_sfis_and_set_info(item, "PASS");
	}
	else MAINDUT->log_sfis_and_set_info(item, "FAIL");
	return 0;
}

int CMinspadetest::test_PIR_MIN(const char* item, const Json::Value& param)
{
	MAINDUT->log_sfis_and_set_info(item, min);
	return 0;
}

int CMinspadetest::test_PIR_MAX(const char* item, const Json::Value& param)
{
	MAINDUT->log_sfis_and_set_info(item, max);
	return 0;
}

int CMinspadetest::test_PIR_AVG(const char* item, const Json::Value& param)
{
	MAINDUT->log_sfis_and_set_info(item, avg);
	return 0;
}

int CMinspadetest::test_PIR_STDEV(const char* item, const Json::Value& param)
{
	MAINDUT->log_sfis_and_set_info(item, std_dev);
	return 0;
}

int CMinspadetest::test_HELLO_WOLRD(const char* item, const Json::Value& param)
{
	MAINDUT->log_sfis_and_set_info(item, "HAI HELLO WORLD");
	return 0;
}


