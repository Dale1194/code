
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include "CommonApi.h"



using namespace std;

#pragma once

class CErrorCode
{
public:
	CErrorCode(const char* name) :m_file_name(name) {
		read_error_code_file(name, m_err_code_map);
	};

	~CErrorCode() {
	};

	int GetErrorCode(const char* name, string& err_item, string& err_code, string& sfis_err_data) {
		string				buffer;
		std::vector<string>	lines;
		std::vector<string>	fields;

		if (ReadFileBin(name, buffer) == false) {
			::MessageBoxA(NULL, "[error code] failed to read csv!", "Warning", MB_OK);
			return -1;
		}

		StringToken(buffer.c_str(), lines, "\r\n", REMOVE_EMPTY_ENTRIES);

		sfis_err_data = lines[0] + "\n";

		for (std::vector<string>::iterator it = lines.begin() + 1; it != lines.end(); ++it)
		{
			StringToken(it->c_str(), fields, ",\"", REMOVE_EMPTY_ENTRIES);

			if (fields.size() == 5) {
				if (fields[1] != "0") {
					sfis_err_data = sfis_err_data + *it + "\n";
					err_item = fields[0];
					if (m_err_code_map.find(fields[0]) != m_err_code_map.end())
						err_code = m_err_code_map[fields[0]];
					else
						err_code = "WIEOTR";
					break;
				}
			}
		}
		return 0;
	};

	void GetErrorCode(const char* test_item, string& err_code) {
		if (IsErrorCodeExist(test_item))
			err_code = m_err_code_map[test_item];
		else
			err_code = "WIEOTR";
	}

	bool IsErrorCodeExist(const char* test_item) {
		return (m_err_code_map.find(test_item) != m_err_code_map.end());
	}

private:
	int read_error_code_file(const char* name, std::map<string, string>& err_list) {
		string				buffer;
		std::vector<string>	lines;
		std::vector<string>	fields;
		
		if (ReadFileBin(name, buffer) == false)
			::MessageBoxA(NULL, "[error code] failed to read err_code_file!", "Warning", MB_OK);

		StringToken(buffer.c_str(), lines, "\r\n", REMOVE_EMPTY_ENTRIES);

		if (lines.size() == 0)
			::MessageBoxA(NULL, "[error code] data is wrong!", "Warning", MB_OK);

		for (std::vector<string>::iterator it = lines.begin(); it != lines.end(); ++it)
		{
			StringToken(it->c_str(), fields, " \t", REMOVE_EMPTY_ENTRIES);

			if (fields.size() == 2) {
				err_list[fields[0]] = fields[1];
			}
			else {
				::MessageBoxA(NULL, "[error code] format is wrong!", "Warning", MB_OK);
			}
		}
		return 0;
	};

private:
	string m_file_name;
	std::map<string, string> m_err_code_map;
};