#include "stdafx.h"
#include "Scenario.h"


CScenario::CScenario(const char* name) :m_filename(name)
{
}


CScenario::~CScenario()
{
}
