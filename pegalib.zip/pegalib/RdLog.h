
#include <string>
#include <iostream>
#include <fstream>
#include "CommonApi.h"
#include "modules\outputlog\OutputDebug.h"



using namespace std;

#pragma once

class CRdLog : public COutputDebug
{

#define InfoLevel "[INFO] "
#define DebugLevel "[DEBUG] "
#define WarningLevel "[WARNING] "
#define ErrorLevel "[ERROR] "
#define SystemLevel "[SYSTEM] "

public:
	CRdLog(const char* name, const char* extname, const char* dir):m_full_name("") {
		m_file_name = name;
		strcpy_s(m_rdlog_dir, dir);
		m_ext_name = extname;
		m_full_name = dir;
		m_full_name = m_full_name + "\\" + m_file_name + m_ext_name;
	};

	~CRdLog() {
	};

	void WriteLog2(const char* buffer) {
		FILE* file;

		errno_t ret = fopen_s(&file, m_full_name.c_str(),"a");
		if (ret != 0) {
			::Sleep(1000);
			ret = fopen_s(&file, m_full_name.c_str(), "a");
		}
		if (ret == 0) {
			fputs(buffer, file);
			fflush(file);
			fclose(file);
		} else {
			DBGTRACE(("failed to open file [%s]", m_full_name.c_str()));
		}
	};

	void WriteLogf2(const char *fmt, ...) {
		char buffer[4096];
		va_list	list;

		va_start(list, fmt);
		vsprintf_s(buffer, _countof(buffer), fmt, list);
		va_end(list);

		FILE* file;

		errno_t ret = fopen_s(&file, m_full_name.c_str(),"a");
		if (ret != 0) {
			::OutputDebugStringA("[fox] failed to open log file");
			::Sleep(1500);
			ret = fopen_s(&file, m_full_name.c_str(), "a");
		}
		if (ret == 0) {
			fputs(buffer, file);
			fflush(file);
			fclose(file);
		} else {
			DBGTRACE(("failed to open file [%s]", m_full_name.c_str()));
			//::MessageBoxA(NULL, m_full_name.c_str(), "failed to open log file", 0);
			::OutputDebugStringA("[fox] failed to open log file(2)");
		}
	};

	void WriteLog(const char* buffer) {
		HANDLE handle;
		DWORD dwBytesToWrite = (DWORD)strlen(buffer);
		DWORD dwBytesWritten = 0;
		char temp[64];

		handle = CreateFileA(m_full_name.c_str(), FILE_APPEND_DATA, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (handle == INVALID_HANDLE_VALUE) {
			::OutputDebugStringA("[fox] failed to open log file");
			sprintf_s(temp, "err no:%d", ::GetLastError());
			::OutputDebugStringA(temp);
			::Sleep(5000);
			handle = CreateFileA(m_full_name.c_str(), FILE_APPEND_DATA, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		}
		if (handle != INVALID_HANDLE_VALUE) {
			SetFilePointer(handle, 0, NULL, FILE_END);
			WriteFile(handle, buffer, dwBytesToWrite, &dwBytesWritten, NULL);
			CloseHandle(handle);
		}
		else {
			::OutputDebugStringA("[fox] failed to open log file(2)");
			sprintf_s(temp, "err no:%d", ::GetLastError());
			::OutputDebugStringA(temp);
		}
	}

	void WriteLogf(const char *fmt, ...) {
		int buf_cnt = 2048;
		char* buffer = NULL;
		va_list	list;
		int vsn = -1;
		va_start(list, fmt);

		do{
			delete[] buffer;
			buf_cnt *= 2;			
			buffer = new char[buf_cnt];
			vsn = vsnprintf_s(buffer, buf_cnt, _TRUNCATE, fmt, list);
			//dave lin
			//bug fix from (buf_cnt) to (buf_cnt-1)
		} while (vsn == -1);

		va_end(list);

		WriteLog(buffer);
		delete[] buffer;
	}

	void WriteLogfEX(const char* level, const char *fmt, ...)
	{
		int buf_cnt = 2048;
		int vsn = -1;
		char* buffer = NULL;
		int tag_size;
		va_list  list;
		va_start(list, fmt);

		do{
			delete[] buffer;
			buf_cnt = (buf_cnt * 2);
			buffer = new char[buf_cnt];

			tag_size = add_tag(buffer, buf_cnt, level);
			vsn = vsnprintf_s(buffer + tag_size, buf_cnt - tag_size - 1, _TRUNCATE, fmt, list);
		} while (vsn == -1);

		va_end(list);

		WriteLog(buffer);
		delete[] buffer;
	}

	void Rename(const char* name) {
		if (!file_exist(m_full_name))
			return;

		string file_name(m_rdlog_dir);

		file_name = file_name + "\\" + name + m_ext_name;
		if (rename(m_full_name.c_str(), file_name.c_str()) != 0) {
			errno_t err;
			_get_errno(&err);
			WriteLogf("failed to rename. errorno is %d", err);
			DBGTRACE(("failed to rename. [%s]", m_full_name.c_str()));
		} else {
			m_file_name = name;
			m_full_name = file_name;
		}
	}
	
	void Output(const char* str) {
		WriteLogfEX(DebugLevel, str);
	}

	void Output(const string& str) {
		WriteLogfEX(DebugLevel, str.c_str());
	}

private:
	bool file_exist(string& file_name) {
		ifstream infile(file_name.c_str(), ifstream::in);
		return infile.good();
	}

	int add_tag(char* buf, int buf_size, const char* level) {
		SYSTEMTIME tim;
		GetLocalTime(&tim);

		char levelnull[2] = { 0 };
		if (level == NULL)
			level = levelnull;

		sprintf_s(buf, buf_size, "[%.2d:%.2d:%.2d.%.3d]%s", tim.wHour, tim.wMinute, tim.wSecond, tim.wMilliseconds, level);

		return strlen(buf);
	}

public:
	string m_file_name;
	string m_ext_name;
	string m_full_name;

private:
	char m_rdlog_dir[512];
};