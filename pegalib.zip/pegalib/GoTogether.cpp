#include "stdafx.h"
#include "GoTogether.h"



CGoTogether::CGoTogether() : m_count(0)
{
}


CGoTogether::~CGoTogether()
{
	for (map<string, HANDLE>::iterator it = m_id_handles.begin(); it != m_id_handles.end(); it++)
		CloseHandle(it->second);
}


void CGoTogether::Add(const char* id)
{
	HANDLE handle = CreateEvent(NULL, TRUE, FALSE, NULL);
	ResetEvent(handle);
	m_id_handles[id] = handle;
}

void CGoTogether::Remove(const char* id)
{
	if (m_id_handles.find(id) != m_id_handles.end())
	{
		CloseHandle(m_id_handles[id]);
		m_id_handles.erase(id);
	}
}

auto_ptr<CTheNumber> CGoTogether::TakeNumber(const char* id, int expected_count)
{
	bool is_first = (m_count == 0);
	int count = expected_count == DEFAULT ? m_id_handles.size() : expected_count;
	m_count++;
	if (m_count == count)
	{
		m_count = 0;

		for (map<string, HANDLE>::iterator it = m_id_handles.begin(); it != m_id_handles.end(); it++)
			SetEvent(it->second);
	}

	return auto_ptr<CTheNumber>(new CTheNumber(m_id_handles[id], is_first));
}



