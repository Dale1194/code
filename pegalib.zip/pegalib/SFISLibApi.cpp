#include "stdafx.h"
#include "SFISLibApi.h"
#include "CommonApi.h"


using namespace std;

CSFISLibApi::CSFISLibApi() : m_handle(NULL), m_err_code(NULL)
{
	read_sfis_ini();
	load_dll();
	read_erro_code();
}


CSFISLibApi::~CSFISLibApi()
{
	if (m_handle == NULL)
	{
		FreeLibrary(m_handle);
		m_handle = NULL;
	}
	if (m_err_code)
	{ 
		delete m_err_code;
	}
}

int CSFISLibApi::read_sfis_ini()
{
	string ini_name;

	GetCurrentPath(ini_name);
	ini_name = ini_name + "\\sfis.ini";

	::GetPrivateProfileStringA("SFIS_SETTING", "SFIS_WEB_SERVICE_URL", "", m_sfis_web_vervice_url, sizeof(m_sfis_web_vervice_url), ini_name.c_str());
	::GetPrivateProfileStringA("SFIS_SETTING", "SFIS_TSP", "", m_sfis_tsp, sizeof(m_sfis_tsp), ini_name.c_str());
	::GetPrivateProfileStringA("SFIS_SETTING", "SFIS_DEVICE_ID", "", m_sfis_device_id, sizeof(m_sfis_device_id), ini_name.c_str());
	::GetPrivateProfileStringA("SFIS_SETTING", "SFIS_CHECKROUTE_TYPE", "1", m_sfis_checkroute_type, sizeof(m_sfis_checkroute_type), ini_name.c_str());
	::GetPrivateProfileStringA("SFIS_SETTING", "SFIS_TESTRESULT_TYPE", "1", m_sfis_testresult_type, sizeof(m_sfis_testresult_type), ini_name.c_str());
	::GetPrivateProfileStringA("SFIS_SETTING", "SFIS_AUTOREPAIR_TYPE", "1", m_sfis_autorepair_type, sizeof(m_sfis_autorepair_type), ini_name.c_str());

	return S_OK;
}

int CSFISLibApi::load_dll()
{
	string dll_name;
	      
	GetCurrentPath(dll_name);
	dll_name = dll_name + "\\sfislib.dll";

	m_handle = LoadLibraryA(dll_name.c_str());
	if (NULL == m_handle)
	{
		::MessageBox(NULL, L"Failed to load sfislib.dll.", L"Error", MB_OK);
		return S_FALSE;
	}
	m_create_sfis_test_service = (CREATE_SFISTESTSERVICE)GetProcAddress((HMODULE)m_handle, "CreateSfisTestService");
	if (NULL == m_create_sfis_test_service)
	{
		::MessageBox(NULL, L"Failed to GetProcAddress[CreateSfisTestService].", L"Error", MB_OK);
		return S_FALSE;
	}
	if (S_OK != m_create_sfis_test_service(m_sfis_web_vervice_url, m_sfis_service))
	{
		::MessageBox(NULL, L"Failed to create SFIS test service.", L"Error", MB_OK);
		return S_FALSE;
	}

	return S_OK;
}

int CSFISLibApi::read_erro_code()
{
	string file_name;

	GetCurrentPath(file_name);
	file_name = file_name + "\\ErrorCode.txt";
	m_err_code = new CErrorCode(file_name.c_str());

	return S_OK;
}

void CSFISLibApi::Init(const char* userid)
{
	m_user_id = userid;
}

int CSFISLibApi::GetDbInfo(string& result)
{
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->GetDatabaseInformation(m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '1')
		{
			std::vector<string> fields;
			GetSfisResult(fields);
			m_db_info = fields[1];
		}
		else
			ret = S_FALSE;
	}

	return ret;
}

int CSFISLibApi::Login(const char* user_id, string& result)
{
	int ret = S_FALSE;

	if (user_id != NULL)
		m_user_id = user_id;

	m_sfisws_result.clear();
	ret = m_sfis_service->Loginout(m_user_id.c_str(), m_sfis_device_id, m_sfis_tsp, SFISLOGIN, m_sfisws_result);

	if (ret == S_FALSE)
	{
		ret = m_sfis_service->Loginout(m_user_id.c_str(), m_sfis_device_id, m_sfis_tsp, SFISLOGOUT, m_sfisws_result);
		ret = m_sfis_service->Loginout(m_user_id.c_str(), m_sfis_device_id, m_sfis_tsp, SFISLOGIN, m_sfisws_result);
	}

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '1')
		{
			std::vector<string> fields;
			GetSfisResult(fields);
			m_user_name = fields[2];
		}
		else
			ret = S_FALSE;
	}

	return ret;
}


int CSFISLibApi::Login(string& result)
{
	return Login(NULL, result);
}

int CSFISLibApi::Logout()
{
	int ret = S_FALSE;
	m_sfisws_result.clear();
	ret = m_sfis_service->Loginout(m_user_id.c_str(), m_sfis_device_id, m_sfis_tsp, SFISLOGOUT, m_sfisws_result);
	return ret;
}

int CSFISLibApi::ChkRoute(const char* isn, string& result)
{
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->ChkRoute(isn, m_sfis_device_id, "", "", m_sfis_checkroute_type, m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '0')
			ret = S_FALSE;
	}

	return ret;
}

int CSFISLibApi::GetVersion(const char* isn, const char* ptype, const char* chkdata, const char* chkdata2, string& result)
{
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->GetVersion(isn, m_sfis_device_id, ptype, chkdata, chkdata2, m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '0')
			ret = S_FALSE;
	}

	return ret;
}

int CSFISLibApi::GetVersion(const char* isn, const char* deviceid, const char* ptype, const char* chkdata, const char* chkdata2, string& result)
{
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->GetVersion(isn, deviceid, ptype, chkdata, chkdata2, m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '0')
			ret = S_FALSE;
	}

	return ret;
}

int CSFISLibApi::GetIMac(const char* isn, const char* status, const char* num, std::string& result) {
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->GetIMac(m_sfis_device_id, isn, status, num, m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '0')
			ret = S_FALSE;
	}

	return ret;
}

int CSFISLibApi::Repair(const char* isn, string& result)
{
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->Repair(m_sfis_autorepair_type, isn, m_sfis_device_id, m_sfis_tsp, m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '0')
			ret = S_FALSE;
	}

	return ret;
}

int CSFISLibApi::Result(const char* isn, const char* errcode, const char* data, string& result)
{
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->Result(isn, errcode, m_sfis_device_id, m_sfis_tsp, data, m_sfis_testresult_type, m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '0')
			ret = S_FALSE;
	}

	return ret;
}

int CSFISLibApi::SsdInputdata(const char* data, const char* type, string& result)
{
	int ret = S_FALSE;

	m_sfisws_result.clear();
	ret = m_sfis_service->SsdInputdata(m_sfis_device_id, data, type, m_sfisws_result);

	if (ret == S_OK)
	{
		result = m_sfisws_result;

		if (m_sfisws_result[0] == '0')
			ret = S_FALSE;
	}

	return ret;
}

void CSFISLibApi::GetErrMsg(string& errmsg)
{
	if (m_sfisws_result.empty())
	{
		errmsg.reserve(512);
		m_sfis_service->GetErrorMsg(errmsg);
	}
	else
		errmsg = m_sfisws_result;
}

int CSFISLibApi::GenerateErrorCode(CSfisCsv* sfis_csv, string& err_code)
{
	string err_item = sfis_csv->GetFirstFailItem();
	string err_sfis_item = sfis_csv->GetFailSfisItem();

	m_sfis_stream_data = "\"TEST\",\"STATUS\",\"VALUE\",\"U_LIMIT\",\"L_LIMIT\"\n";

	if (sfis_csv->HaveHashtagSaveItem())
	{
		m_sfis_stream_data = m_sfis_stream_data + sfis_csv->GetHashtagSaveItem();
	}

	if (strlen(err_item.c_str()) == 0)
	{
		m_error_code = "";
	}
	else
	{
		m_err_code->GetErrorCode(err_item.c_str(), err_code);
		m_error_code = err_code;
		m_sfis_stream_data = m_sfis_stream_data + err_sfis_item;
	}

	return 0;
}

void CSFISLibApi::ListItemsWithoutErrorCode(CSfisCsv* sfis_csv, string& items)
{
	const vector<string>* all_items = sfis_csv->GetAllItems();
	for each (string item in *all_items)
	{
		if (!m_err_code->IsErrorCodeExist(item.c_str()))
		{
			items = items + item + ";";
		}
	}
}

const char* CSFISLibApi::GetSfisResult()
{
	return m_sfisws_result.c_str();
}

void CSFISLibApi::GetSfisResult(vector<string>& result)
{
	char delim[] = { 0x7f, 0x00 };
	StringToken(m_sfisws_result.c_str(), result, delim, REMOVE_EMPTY_ENTRIES);
}

const char* CSFISLibApi::GetUserId()
{
	return m_user_id.c_str();
}

const char* CSFISLibApi::GetDbInfo()
{
	return m_db_info.c_str();
}

const char* CSFISLibApi::GetUserName()
{
	return m_user_name.c_str();
}

const char* CSFISLibApi::GetStreamData()
{
	return m_sfis_stream_data.c_str();
}

