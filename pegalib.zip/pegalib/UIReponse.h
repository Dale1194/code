#include "SfisCsv.h"

#pragma once
class CUIReponse
{
public:
	CUIReponse(HWND hwnd, int id_no, const char* id_name);
	virtual ~CUIReponse();

	void EnableButton(bool b);
	void UpdateTimer(const char* data);
	void UpdateIsn(const char* data);
	void UpdateStatus(const char* data);
	void UpdateCount(const char* data);
	void UpdateProgress(int step = -1);
	void SetRangeProgress(int range);
	void SetMaxProgress();
	void SetTextProgress(const char* data);
	void SetInfo(const char* item, CSfisCsv::Status stat, const char* value, const char* uplimit, const char* downlimit);
	void PopupInputForm(HANDLE handle, const char* title1, const char* reg1, const char* title2, const char* reg2, const char* title3, const char* reg3);
	void ClearInfo();
	void ZipFile(HANDLE handle, const char* source_dir, const char* dest_zip_name);
	void PopupPicMsgForm(HANDLE handle, const char* pic, const char* desc, const int btn_num);
	void PopupPicMsgFormClose();

private:
	HWND m_hwnd;
	int m_id_no;
	string m_id_name;
};

