#include "StdAfx.h"
#include "Dut.h"
#include "Config.h"
#include "CommonApi.h"
#include "Iphlpapi.h"
#include "SFIS_Api.h"
#include <direct.h>
#include <regex>
#include "io.h"



extern HWND	g_uiwnd;



int CDut::cmd_read_qrcode(const char* item, const Json::Value& param)
{
	int ret = RET_SUCCESS;
	string adb_cmd = param["dut_cmd"].asString();
	string reg_rule = param["reg_rule"].asString();
	string adb_result;
	string value = "FAIL";
	std::tr1::regex	rx;
	smatch reg_result;

	m_rdlog->WriteLogf(" adb_cmd:%s\n", adb_cmd.c_str());
	ret = adb_command(adb_cmd.c_str(), adb_result);
	m_rdlog->WriteLogf(" adb_result:%s<:)\n", adb_result.c_str());

	if (ret == RET_SUCCESS)
	{
		rx.assign(reg_rule, regex_constants::icase);
		if (regex_search(adb_result, reg_result, rx) == true)
		{
			value = reg_result[0].str();
			m_var["qrcode"] = value;
			log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, value.c_str());
		}
		else
			ret = RET_FAIL;
	}

	if (ret == RET_FAIL)
		ret = log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, value.c_str());

	return ret;
}

int CDut::cmd_check_qrcode(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string adb_cmd = PARAM_S("dut_cmd");
	string reg_rule = PARAM_S("reg_rule");
	string data_name = PARAM_S("data_name");
	string adb_result;
	string catch_value = "FAIL";
	string input_value1, input_value2, input_value3;
	std::tr1::regex	rx;
	smatch reg_result;

	if (m_var.isMember(data_name))
	{
		m_rdlog->WriteLogf(" QR Code from scanner:%s\n", m_var[data_name].asString().c_str());

		m_rdlog->WriteLogf(" adb_cmd:%s\n", adb_cmd.c_str());
		ret = adb_command(adb_cmd.c_str(), adb_result);
		m_rdlog->WriteLogf(" adb_result:%s<:)\n", adb_result.c_str());
	}
	else
	{
		m_rdlog->WriteLogf(" data_name(%s) is not exist!\n", data_name.c_str());
	}

	if (ret == RET_SUCCESS)
	{
		rx.assign(reg_rule, regex_constants::icase);
		if (regex_search(adb_result, reg_result, rx) == true)
		{
			catch_value = reg_result[0].str();
		}
		
		if (catch_value == m_var[data_name].asString())
		{
			//m_var[data_name] = input_value1;
			ret = log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, catch_value.c_str());
		}
		else
			ret = RET_FAIL;
	}

	if (ret == RET_FAIL)
		ret = log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, catch_value.c_str());

	return ret;
}

int CDut::cmd_compare_with_sfis(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = PARAM_S("item_name");
	string data_name = PARAM_S("data_name");
	Json::Value params;
	string chk_type;
	string chk_data1, chk_data2;
	unsigned int idx;
	bool reg_enable;
	string reg_rule;
	int reg_catch = -1;
	vector<string> getver;
	std::tr1::regex	rx;
	smatch reg_result;
	string catch_value = "FAIL";

	m_rdlog->WriteLogf(" item_name:%s\n data_name:%s\n", item_name.c_str(), data_name.c_str());

	params = param["getver_1st"];
	chk_type = params["chk_type"].asString();
	chk_data1 = params["chk_data1"].asString();
	chk_data2 = params["chk_data2"].asString();
	idx = params["idx"].asUInt();

	ret = sfis_get_version(m_isn_fatp.c_str(), chk_type.c_str(), chk_data1.c_str(), chk_data2.c_str(), getver);

	if (ret == RET_SUCCESS)
	{
		if (idx < getver.size())
			catch_value = getver[idx];
		else
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (param.isMember("getver_2nd"))
		{
			params = param["getver_2nd"];
			chk_type = params["chk_type"].asString();
			chk_data1 = params["chk_data1"].asString();
			chk_data2 = params["chk_data2"].asString();
			idx = params["idx"].asUInt();

			ret = sfis_get_version(catch_value.c_str(), chk_type.c_str(), chk_data1.c_str(), chk_data2.c_str(), getver);
		}
	}

	if (ret == RET_SUCCESS)
	{
		if (idx < getver.size())
			catch_value = getver[idx];
		else
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (param.isMember("getver_3rd"))
		{
			params = param["getver_3rd"];
			chk_type = params["chk_type"].asString();
			chk_data1 = params["chk_data1"].asString();
			chk_data2 = params["chk_data2"].asString();
			idx = params["idx"].asUInt();

			ret = sfis_get_version(catch_value.c_str(), chk_type.c_str(), chk_data1.c_str(), chk_data2.c_str(), getver);
		}
	}

	if (ret == RET_SUCCESS)
	{
		if (idx < getver.size())
			catch_value = getver[idx];
		else
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (param.isMember("reg_enable"))
		{
			reg_enable = PARAM_B("reg_enable");
			reg_rule = PARAM_S("reg_rule");
			reg_catch = PARAM_N("reg_catch");

			rx.assign(reg_rule, regex_constants::icase);
			if (regex_search(getver[idx], reg_result, rx) == true)
			{
				catch_value = reg_result[reg_catch].str();
			}
			else
				ret = RET_FAIL;
		}
	}

	if (ret == RET_SUCCESS)
	{
		if (m_var[data_name].asString() == catch_value)
			log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, "PASS");
		else
			ret = RET_FAIL;
	}

	if (ret != RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_compare_wifi_mac(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string wifi_mac;
	vector<string> getver;

	ret = sfis_get_version(m_isn_mlb.c_str(), "ISN_BASEINFO", "MAC1", "", getver);
	
	if (ret == RET_SUCCESS)
	{
		wifi_mac = m_var["hwaddr0"].asString();

		size_t pos = wifi_mac.find(":");
		while (pos != string::npos)
		{
			wifi_mac.erase(pos, 1);
			pos = wifi_mac.find(":");
		}
	}

	if (ret == RET_SUCCESS)
	{
		if (getver.size() < 3)
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (wifi_mac == getver[2])
			log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, "PASS");
		else
			ret = RET_FAIL;
	}
	
	if (ret != RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_compare_15_4_mac(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string _15_4_mac;
	vector<string> getver;

	ret = sfis_get_version(m_isn_mlb.c_str(), "ISN_BASEINFO", "A13941", "", getver);

	if (ret == RET_SUCCESS)
	{
		_15_4_mac = m_var["hwaddr1"].asString();

		size_t pos = _15_4_mac.find(":");
		while (pos != string::npos)
		{
			_15_4_mac.erase(pos, 1);
			pos = _15_4_mac.find(":");
		}
	}

	if (ret == RET_SUCCESS)
	{
		if (getver.size() < 3)
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (_15_4_mac == getver[2])
			log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, "PASS");
		else
			ret = RET_FAIL;
	}

	if (ret != RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_check_sfis_info(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = PARAM_S("item_name");
	string data_name = PARAM_S("data_name");
	bool pass_fail_only = PARAM_B("pass_fail_only");
	Json::Value params;
	string chk_type;
	string chk_data1, chk_data2;
	unsigned int idx;
	bool reg_enable;
	string reg_rule;
	int reg_catch = -1;
	vector<string> getver;
	std::tr1::regex	rx;
	smatch reg_result;
	string catch_value = "FAIL";

	m_rdlog->WriteLogf(" item_name:%s\n data_name:%s\n", item_name.c_str(), data_name.c_str());

	params = param["getver_1st"];
	chk_type = params["chk_type"].asString();
	chk_data1 = params["chk_data1"].asString();
	chk_data2 = params["chk_data2"].asString();
	idx = params["idx"].asUInt();

	ret = sfis_get_version(m_isn.c_str(), chk_type.c_str(), chk_data1.c_str(), chk_data2.c_str(), getver);

	if (ret == RET_SUCCESS)
	{
		if (idx < getver.size())
			catch_value = getver[idx];
		else
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (param.isMember("getver_2nd"))
		{
			params = param["getver_2nd"];
			chk_type = params["chk_type"].asString();
			chk_data1 = params["chk_data1"].asString();
			chk_data2 = params["chk_data2"].asString();
			idx = params["idx"].asUInt();

			ret = sfis_get_version(catch_value.c_str(), chk_type.c_str(), chk_data1.c_str(), chk_data2.c_str(), getver);
		}
	}

	if (ret == RET_SUCCESS)
	{
		if (idx < getver.size())
			catch_value = getver[idx];
		else
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (param.isMember("getver_3rd"))
		{
			params = param["getver_3rd"];
			chk_type = params["chk_type"].asString();
			chk_data1 = params["chk_data1"].asString();
			chk_data2 = params["chk_data2"].asString();
			idx = params["idx"].asUInt();

			ret = sfis_get_version(catch_value.c_str(), chk_type.c_str(), chk_data1.c_str(), chk_data2.c_str(), getver);
		}
	}

	if (ret == RET_SUCCESS)
	{
		if (idx < getver.size())
			catch_value = getver[idx];
		else
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (param.isMember("reg_enable"))
		{
			reg_enable = PARAM_B("reg_enable");
			reg_rule = PARAM_S("reg_rule");
			reg_catch = PARAM_N("reg_catch");

			rx.assign(reg_rule, regex_constants::icase);
			if (regex_search(getver[idx], reg_result, rx) == true)
			{
				catch_value = reg_result[reg_catch].str();
			}
			else
				ret = RET_FAIL;
		}
	}

	if (ret == RET_SUCCESS)
	{
		m_var[data_name] = catch_value;
		log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, (pass_fail_only == true) ? "PASS" : catch_value.c_str());
	}

	if (ret != RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_swdl_exclude_90pn(const char* item, const Json::Value& param)
{
	m_var["exclude_90pn"] = PARAM_S("exclude_90pn");
	m_rdlog->WriteLogf(" exclude_90pn:%s\n", m_var["exclude_90pn"].asString().c_str());

	return 0;
}

int CDut::cmd_swdl_sec_exclude_90pn(const char* item, const Json::Value& param)
{
	m_var["dl_sec_exclude_90pn"] = PARAM_S("dl_sec_exclude_90pn");
	m_rdlog->WriteLogf(" dl_sec_exclude_90pn:%s\n", m_var["dl_sec_exclude_90pn"].asString().c_str());

	return 0;
}

int CDut::cmd_ready_for_flash(const char* item, const Json::Value& param)
{
	if (m_sfiscsv->GetFailCount() != 0)
	{
		m_exit_test = true;
		m_rdlog->WriteLog(" have failed items, do not flash!\n");
	}

	if (m_var.isMember("exclude_90pn") && m_var.isMember("90pn"))
		if (m_var["exclude_90pn"].asString().find(m_var["90pn"].asString()) != string::npos)
		{
			m_exit_test = true;
			m_rdlog->WriteLogf(" 90PN is %s, do not flash!\n", m_var["90pn"].asString().c_str());
		}

	return 0;
}

int CDut::cmd_get_info_file_plist(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	unsigned int timeout = param["timeout"].asUInt();
	char temp[128];
	string dos_result;
	bool is_first = true;
	vector<string> removable_drv;
	CCalcPeriod period;

	period.GetTimeA();
	do
	{
		EnumCdromDrive(removable_drv);

		for (string drv : removable_drv)
		{
			if (_access_s(drv.c_str(), 4) != 0)
			{
				m_rdlog->WriteLogf(" %s can not be access.\n", drv.c_str());
				continue;
			}

			sprintf_s(temp, "cmd.exe /c type %sSERIAL", drv.c_str());
			ret = m_dos.Send(temp, dos_result, 500);
			m_rdlog->WriteLogf(" file [SERIAL]:%s\n", dos_result.c_str());

			if (ret == RET_SUCCESS)
			{
				if ((!m_isn_fatp.empty()) && (dos_result.find(m_isn_fatp) != string::npos))
				{
					m_var["cdrom_drv"] = drv;
					break;
				}
				else
					ret = RET_FAIL;
			}
		}

		if (removable_drv.size() == 0)
		{
			if (is_first)
			{
				is_first = false;
				m_rdlog->WriteLog(" no removable_drv =>X\n");
			}
			else
				m_rdlog->WriteLog(" =>X\n");
		}

		if (m_var.isMember("cdrom_drv"))
			break;

		::Sleep(1000);
		period.GetTimeB();
	} while (period.GetDiff() < timeout);

	if (!m_var.isMember("cdrom_drv"))
		m_rdlog->WriteLog(" can not find any cdrom device\n");

	if (ret == RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, "PASS");
	else
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_check_info(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = PARAM_S("item_name");
	string file_name = PARAM_S("file_name");
	string data_name = PARAM_S("data_name");
	string dos_cmd;
	string dos_result;
	
	if (m_var.isMember("cdrom_drv"))
		ret = RET_SUCCESS;

	if (ret == RET_SUCCESS)
	{
		dos_cmd = "cmd.exe /c type " + m_var["cdrom_drv"].asString() + file_name;
		m_rdlog->WriteLogf(" dos_cmd:%s\n", dos_cmd.c_str());
		ret = m_dos.Send(dos_cmd.c_str(), dos_result, 500);
		m_rdlog->WriteLogf(" dos_result:%s\n", dos_result.c_str());
	}

	if (ret == RET_SUCCESS)
	{
		if (!m_var.isMember(data_name))
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
	{
		if (m_var[data_name].asString().empty())
			ret = RET_FAIL;

		if (dos_result.find(m_var[data_name].asString()) == string::npos)
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, "PASS");
	else
		log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_check_info2(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string item_name = PARAM_S("item_name");
	string file_name = PARAM_S("file_name");
	string dos_cmd;
	string dos_result = "FAIL";

	if (m_var.isMember("cdrom_drv"))
		ret = RET_SUCCESS;

	if (ret == RET_SUCCESS)
	{
		dos_cmd = "cmd.exe /c type " + m_var["cdrom_drv"].asString() + file_name;
		m_rdlog->WriteLogf(" dos_cmd:%s\n", dos_cmd.c_str());
		ret = m_dos.Send(dos_cmd.c_str(), dos_result, 500);
		m_rdlog->WriteLogf(" dos_result:%s\n", dos_result.c_str());
	}

	if (ret == RET_SUCCESS)
	{
		size_t pos = dos_result.find("\r");
		if (pos != string::npos) dos_result.erase(pos);
		pos = dos_result.find("\n");
		if (pos != string::npos) dos_result.erase(pos);

		ret = log_sfis_and_set_info(item_name.c_str(), dos_result.c_str());
	}
	return ret;
}

int CDut::cmd_check_info3(const char* item, const Json::Value& param)
{
		int ret = RET_FAIL;
		string item_name = PARAM_S("item_name");
		string file_name = PARAM_S("file_name");
		string data_name = PARAM_S("data_name");
		string dos_cmd;
		string dos_result;

		if (m_var.isMember("cdrom_drv"))
			ret = RET_SUCCESS;

		if (ret == RET_SUCCESS)
		{
			dos_cmd = "cmd.exe /c type " + m_var["cdrom_drv"].asString() + file_name;
			m_rdlog->WriteLogf(" dos_cmd:%s\n", dos_cmd.c_str());
			ret = m_dos.Send(dos_cmd.c_str(), dos_result, 500);
			m_rdlog->WriteLogf(" dos_result:%s\n", dos_result.c_str());
		}

		if (ret == RET_SUCCESS)
		{
			if (!m_var.isMember(data_name))
				ret = RET_FAIL;
		}

		if (ret == RET_SUCCESS)
		{
			if (m_var[data_name].asString().empty())
				ret = RET_FAIL;

			size_t pos = dos_result.find(":");
			while (pos != string::npos)
			{
				dos_result.erase(pos, 1);
				pos = dos_result.find(":");
			}

			if (dos_result.find(m_var[data_name].asString()) == string::npos)
				ret = RET_FAIL;
		}

		if (ret == RET_SUCCESS)
			log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Pass, "PASS");
		else
			log_sfis_and_set_info_no_judge(item_name.c_str(), CSfisCsv::Fail, "FAIL");

		return ret;
}

int CDut::cmd_90pn_map_image(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string data_name = PARAM_S("data_name");
	string pn = "N/A";
	string image_path;
	string list_90pn;

	if (m_var.isMember(data_name))
	{
		pn = m_var[data_name].asString();
		ret = RET_SUCCESS;
	}
	
	if (ret == RET_SUCCESS)
	{
		for (unsigned int i = 0; i < param.size(); i++)
		{
			image_path = param.getMemberNames()[i];
			list_90pn = param[image_path].asString();

			if (list_90pn.find(pn) != string::npos)
			{
				m_var["image_path"] = image_path;
				break;
			}
		}

		if (!m_var.isMember("image_path"))
			ret = RET_FAIL;
	}

	if (ret == RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, "PASS");
	else
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_check_reboot(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	unsigned int wait = PARAM_N("wait");
	string adb_cmd = "reboot";
	string adb_result;

	m_rdlog->WriteLogf(" adb_cmd:%s\n", adb_cmd.c_str());
	ret = adb_command(adb_cmd.c_str(), adb_result);
	m_rdlog->WriteLogf(" adb_result:%s<:)\n", adb_result.c_str());

	if (ret == RET_SUCCESS)
		::Sleep(wait);
	else
	{
		wchar_t	temp[128];
		wstring wmsg = SS_REPLUG_USB;
		swprintf_s(temp, L"%S", m_id_name.c_str());
		size_t pos = wmsg.find_first_of('[');
		wmsg.insert(pos + 1, temp);
		if (::MessageBoxW(g_uiwnd, wmsg.c_str(), L"MultiTest", MB_YESNO) == IDYES)
			ret = RET_SUCCESS;
	}

	if (ret == RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, "PASS");
	else
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, "FAIL");

	return ret;
}

int CDut::cmd_get_isn_from_qrcode(const char* item, const Json::Value& param)
{
	int ret = RET_FAIL;
	string chk_route_isn = PARAM_S("chk_route_isn");
	string data_name_src = PARAM_S("data_name_src");
	string data_name_dst = PARAM_S("data_name_dst");
	string qrcode;
	string wifi_mac;
	string isn;
	string reg_rule = "W:([0-9A-F]{12})\\$";
	std::tr1::regex	rx;
	smatch reg_result;
	vector<string> getver;

	if (m_var.isMember(data_name_src))
	{
		qrcode = m_var[data_name_src].asString();
		ret = RET_SUCCESS;
	}
	else
		m_rdlog->WriteLogf(" data_name_src(%s) is empty!\n", data_name_src.c_str());

	if (ret == RET_SUCCESS)
	{
		rx.assign(reg_rule, regex_constants::icase);
		if (regex_search(qrcode, reg_result, rx) == true)
		{
			wifi_mac = reg_result[1].str();
			m_rdlog->WriteLogf(" wifi_mac:%s\n", wifi_mac.c_str());
		}
		else
		{
			ret = RET_FAIL;
			m_rdlog->WriteLogf(" failed to regex_search()!\n reg_rule is [%s]\n", reg_rule.c_str());
		}
	}

	if (ret == RET_SUCCESS)
	{
		ret = sfis_get_version(wifi_mac.c_str(), "ITEMINFO", "", "", getver);
		if ((ret == ERROR_SUCCESS) && (getver.size() > 2))
		{
			isn = getver[5];
			getver.clear();
			m_rdlog->WriteLogf(" getver[5]:%s\n", isn.c_str());
		}
		else
		{
			ret = RET_FAIL;
			m_rdlog->WriteLog(" failed to sfis_get_version()!\n");
		}
	}

	if (ret == RET_SUCCESS)
	{
		ret = sfis_get_version(isn.c_str(), "ITEMINFO", "", "", getver);
		if ((ret == ERROR_SUCCESS) && (getver.size() > 2))
		{
			isn = getver[5];
			m_isn = isn;
			m_rdlog->WriteLogf(" getver[5]:%s\n", isn.c_str());
		}
		else
		{
			ret = RET_FAIL;
			m_rdlog->WriteLog(" failed to sfis_get_version()!\n");
		}
	}

	if (ret == RET_SUCCESS)
	{
		m_var[data_name_dst] = m_isn;

		if (chk_route_isn == "FATP")
			m_isn_fatp = m_isn;
		else if (chk_route_isn == "MLB")
			m_isn_mlb = m_isn;
		
		if (!m_isn.empty())
		{
			m_ui->UpdateIsn(m_isn.c_str());
			m_rdlog->Rename(m_isn.c_str());
			m_sfiscsv->Rename(m_isn.c_str());
		}
	}

	if (ret == RET_SUCCESS)
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Pass, m_isn.c_str());
	else
		log_sfis_and_set_info_no_judge(item, CSfisCsv::Fail, m_isn.c_str());

	return ret;
}






