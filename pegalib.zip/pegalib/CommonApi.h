#include <string>
#include <algorithm> 
#include <cassert>
#include <vector>
#include <math.h>
#include "io.h"
#include <sys/stat.h>



using namespace std;

#pragma once

#define DBGTRACE(A) {	cs_dbg.Enter(); \
						OutputDebug(A); \
						cs_dbg.Leave(); \
					}


//***************************************************************************
// Description: Format Output Debug
//***************************************************************************

static void OutputDebug(const char *fmt, ...)
{
	char buffer[1024];
	va_list	list;

	va_start(list, fmt);
	vsprintf_s(buffer, _countof(buffer), fmt, list);
	va_end(list);
	::OutputDebugStringA(buffer);
}


//***************************************************************************
// Description: GetFileVersion
//***************************************************************************

static void GetFileVersion(const char *filename, string& fileversion)
{
	UINT vsInfoSize = 0;
	VS_FIXEDFILEINFO *vsInfo = NULL;
	char temp[128];

	DWORD dwVerInfoSize = ::GetFileVersionInfoSizeA(filename, &dwVerInfoSize);
	if (dwVerInfoSize == 0)
	{
		fileversion = "::GetFileVersionInfoSize Fail";
	}

	BYTE *InfoBuf = new BYTE[dwVerInfoSize];
	if (::GetFileVersionInfoA(filename, 0, dwVerInfoSize, InfoBuf))
	{
		if (::VerQueryValueA(InfoBuf, "\\", (void**)&vsInfo, &vsInfoSize))
		{
			DWORD dwMajor = HIWORD(vsInfo->dwFileVersionMS);
			DWORD dwMinor = LOWORD(vsInfo->dwFileVersionMS);
			DWORD dwRelease = HIWORD(vsInfo->dwFileVersionLS);
			DWORD dwBuild = LOWORD(vsInfo->dwFileVersionLS);

			sprintf_s(temp, "%d.%d.%d.%d", dwMajor, dwMinor, dwRelease, dwBuild);
			fileversion = temp;
		}
	}
	delete[] InfoBuf;
}


//***************************************************************************
// Description: Critical Section Class
//***************************************************************************

class CCriticalSection
{
public:
	CRITICAL_SECTION CS;
	CCriticalSection()	{ ::InitializeCriticalSection(&CS); };
	~CCriticalSection() { ::DeleteCriticalSection(&CS); };
	void Enter() { ::EnterCriticalSection(&CS); };
	void Leave() { ::LeaveCriticalSection(&CS);	};
};


extern CCriticalSection cs_dbg;


//***************************************************************************
// Description: std::string trim
//***************************************************************************

static std::string & Trim(string& str, char c)
{
  string::size_type pos = str.find_last_not_of(c);
  if(pos != string::npos) {
    str.erase(pos + 1);
    pos = str.find_first_not_of(c);
    if(pos != string::npos) str.erase(0, pos);
  }
  else str.erase(str.begin(), str.end());
  return str;
}


//***************************************************************************
// Description: Calc Period Class
//***************************************************************************

class CCalcPeriod
{
public:
	CCalcPeriod():tickcount_a(0), tickcount_b(0)	{ };
	~CCalcPeriod() { };
	void GetTimeA(SYSTEMTIME* st = NULL) {
		tickcount_a = ::GetTickCount();
		if (st != NULL) {
			::GetLocalTime(st);
		}
	};
	void GetTimeB(SYSTEMTIME* st = NULL) {
		tickcount_b = ::GetTickCount();
		if (st != NULL) {
			::GetLocalTime(st);
		}
	};
	DWORD GetDiff() { return (tickcount_b-tickcount_a); };
private:
  DWORD tickcount_a, tickcount_b;
};


//***************************************************************************
// Description: String Token
//***************************************************************************
 enum StringSplitOptions
{
	NONE,
	REMOVE_EMPTY_ENTRIES

};

static void StringToken(const char* in_str, std::vector<string>& out_str, const char* delim, StringSplitOptions options = NONE)
{
	char* token;
	char* next_token;
	char* data;
	string v;

	if (in_str == NULL) {
		assert(!"[StringToken]in_str == NULL");
	}

	data = new char[strlen(in_str) + 1];
	strcpy_s(data, strlen(in_str) + 1, in_str);

	out_str.clear();
	token = strtok_s(data, delim, &next_token);
	while (token != NULL)
	{
		v = token;
		Trim(v, 0x20);
		if (options == NONE)
		{
			out_str.push_back(v);
		} else if (options == REMOVE_EMPTY_ENTRIES)
		{
			if (v.length() != 0)
				out_str.push_back(v);
		}
		token = strtok_s(NULL, delim, &next_token);
	}
	delete[] data;
}


//***************************************************************************
// Description: Find Files
//***************************************************************************
enum FileNameOptions
{
	FILE_NAME_ONLY,
	FILE_NAME_WITH_PATH

};

static void FindFiles(const char* file_name, std::vector<string>& files, FileNameOptions options = FILE_NAME_ONLY)
{
	WIN32_FIND_DATAA find_data;
	HANDLE find_handle = INVALID_HANDLE_VALUE;
	string path = file_name;
	string new_name;
	
	files.clear();

	find_handle = FindFirstFileA(file_name, &find_data);
	if (find_handle != INVALID_HANDLE_VALUE)
	{
		if ((find_data.dwFileAttributes & (FILE_ATTRIBUTE_ARCHIVE | FILE_ATTRIBUTE_NORMAL)) != 0x00)
		{
			files.push_back(find_data.cFileName);
		}
		while (FindNextFileA(find_handle, &find_data) != 0)
		{
			if ((find_data.dwFileAttributes & (FILE_ATTRIBUTE_ARCHIVE | FILE_ATTRIBUTE_NORMAL)) != 0x00)
			{
				files.push_back(find_data.cFileName);
			}
		}
		FindClose(find_handle);

		if (options == FILE_NAME_WITH_PATH)
		{
			size_t found = path.find_last_of('\\');
			path.erase(found + 1);
			for (std::vector<string>::iterator it = files.begin(); it != files.end(); ++it)
			{
				it->insert(0, path);
			}
		}
	}
	else
	{
		char temp[128];
		sprintf_s(temp, "Invalid file handle. Error is %u.\n", GetLastError());
		::OutputDebugStringA(temp);
		//TRACE("Invalid file handle. Error is %u.\n", GetLastError());
	}
}


//***************************************************************************
// Description: Find Files
//***************************************************************************

static void FindFilesEx(const char* file_name, std::vector<string>& files)
{
	string name;
	size_t pos;
	WIN32_FIND_DATAA find_data;
	HANDLE find_handle = INVALID_HANDLE_VALUE;

	find_handle = FindFirstFileA(file_name, &find_data);
	if (find_handle != INVALID_HANDLE_VALUE)
	{
		if ((find_data.dwFileAttributes & (FILE_ATTRIBUTE_ARCHIVE | FILE_ATTRIBUTE_NORMAL)) != 0x00)
		{
			name = file_name;
			pos = name.find_last_of('\\');
			pos++;
			name.replace(pos, strlen(find_data.cFileName), find_data.cFileName);
			files.push_back(name.c_str());
		}
		while (FindNextFileA(find_handle, &find_data) != 0)
		{
			if ((find_data.dwFileAttributes & (FILE_ATTRIBUTE_ARCHIVE | FILE_ATTRIBUTE_NORMAL)) != 0x00)
			{
				name = file_name;
				pos = name.find_last_of('\\');
				pos++;
				name.replace(pos, strlen(find_data.cFileName), find_data.cFileName);
				files.push_back(name.c_str());
			}
			if (find_data.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY)
			{
				if ((strcmp(find_data.cFileName, ".") != NULL) && (strcmp(find_data.cFileName, "..") != NULL))
				{
					name = file_name;
					pos = name.find_last_of('\\');
					name.insert(pos, "\\");
					pos++;
					name.insert(pos, find_data.cFileName);
					FindFilesEx(name.c_str(), files);
				}

			}
		}
		FindClose(find_handle);
	}
	else
	{
		char temp[128];
		sprintf_s(temp, "Invalid file handle. Error is %u.\n", GetLastError());
		::OutputDebugStringA(temp);
		//TRACE("Invalid file handle. Error is %u.\n", GetLastError());
	}
}


//***************************************************************************
// Description: Get Current Path
//***************************************************************************

static void RemoveAllFiles(const char* dir)
{
	std::vector<std::string> files;

	FindFiles(dir, files, FILE_NAME_WITH_PATH);
	for (unsigned int i = 0; i<files.size(); i++)
	{
		if (remove(files[i].c_str()) != 0)
		{
			::MessageBoxA(NULL, "Failed to delete file", "Warning!", MB_OK);
		}
	}
}

template<typename T>
//***************************************************************************
// Description: calc ave
//***************************************************************************
static T calc_ave(std::vector<T>& value)
{
	T total{};

	for (std::vector<T>::iterator it = value.begin(); it != value.end(); ++it)
	{
		total += *it;
	}
	return (value.size() != 0) ? total / value.size() : 0;
}

template<typename T>
//***************************************************************************
// Description: calc stdev
//***************************************************************************
static T calc_stdev(std::vector<T>& value, T v_ave)
{
	T total{};

	for (std::vector<T>::iterator it = value.begin(); it != value.end(); ++it)
	{
		total += pow((*it - v_ave), 2);
	}
	return sqrt(1.0 / value.size() * total);
}


template<typename T>
//***************************************************************************
// Description: calc noise
//***************************************************************************
static T calc_noise(std::vector<T>& value)
{
	if (value.size() == 1)
	{
		return value[0];
	}

	std::vector<T> each_delta;

	for (auto it=value.begin()+1; it!=value.end(); ++it)
	{
		each_delta.push_back(abs(*(it-1) - *it));
	}
	return *max_element(each_delta.begin(), each_delta.end());
}



//***************************************************************************
// Description: use unicode to display MessageBox to void garbled text
//***************************************************************************

static int my_messagebox(HWND hwnd, const char* msg_text, const char* msg_caption, unsigned int type)
{
	wchar_t text[512] = {0};
	wchar_t caption[128] = {0};

	if ( (msg_text!=NULL) && (strlen(msg_text)!=0) )
		::MultiByteToWideChar(950, 0, msg_text, -1, text, 64);
	
	if ( (msg_caption!=NULL) && (strlen(msg_caption)!=0) )
		::MultiByteToWideChar(950, 0, msg_caption, -1, caption, 64);

	return ::MessageBoxW(hwnd, text, caption, type);
}


//***************************************************************************
// Description: Get Current Path
//***************************************************************************

static void GetCurrentPath(string& path)
{
	char name[512];
	char* p = NULL;

	GetModuleFileNameA(NULL, name, _countof(name));
	p = strrchr(name, '\\');
	if (p != NULL) *p = 0;
	
	path = name;
}


//***************************************************************************
// Description: Read File
//***************************************************************************

static bool ReadFileBin(string name, string& data)
{
	bool	ret = false;
	FILE	*stream;
	char*	pBuff = NULL;
	errno_t	err_no;

	//if (fopen_s(&stream, name.c_str(), "rb") == 0)
	err_no = fopen_s(&stream, name.c_str(), "rb");
	if (err_no != 0)
	{
		::OutputDebugStringA("[fox] failed to open file");
		::OutputDebugStringA("[fox] name");
		::Sleep(1500);
		err_no = fopen_s(&stream, name.c_str(), "rb");
		if (err_no != 0)
			::OutputDebugStringA("[fox] failed to open file(2)");
	}

	if (err_no == 0)
	{
		unsigned long pos = ftell(stream);
		fseek(stream, 0L, SEEK_END);
		pos = ftell(stream);
		fseek(stream, 0L, SEEK_SET);
		pBuff = new char[pos + 1];
		pBuff[pos] = 0;
		fread(pBuff, sizeof(char), pos, stream);
		fclose(stream);

		data = pBuff;
		ret = true;
	}

	delete[] pBuff;
	pBuff = NULL;

	return ret;
}


//***************************************************************************
// Description: CreateFolder
//***************************************************************************

static bool	CreateFolder(const char* path)
{
	char szFolder[512];
	strcpy_s(szFolder, path);
	char *pStart = szFolder;
	char *pEnd = pStart + strlen(szFolder);
	char *p = pEnd;

	for (int i = 0; i < 20; i++)
	{
		BOOL bOK = ::CreateDirectoryA(szFolder, NULL);
		DWORD dwLastError = ::GetLastError();
		if (!bOK && dwLastError == ERROR_PATH_NOT_FOUND)
		{
			while (*p != '\\')
			{
				if (p == pStart) return FALSE;
				p--;
			}
			*p = NULL;
		}
		else if (bOK || (ERROR_ALREADY_EXISTS == dwLastError))
		{
			if (p == pEnd) return TRUE;
			*p = '\\';
			while (*p) p++;
		}
		else
		{
			break;
		}
	}
	return false;
}



//***************************************************************************
// Description: DeleteDirectory
//***************************************************************************
static bool IsDots(const std::string &strName)
{
	return strName == "." || strName == "..";
}

static bool IsDir(const WIN32_FIND_DATAA &fdFile)
{
	return (fdFile.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

static bool DeleteDirectory(const std::string &strDir)
{
	WIN32_FIND_DATAA fdFile;
	::memset(&fdFile, 0, sizeof(fdFile));

	HANDLE hFind = INVALID_HANDLE_VALUE;

	std::string strSearch = strDir + "\\*.*";

	hFind = ::FindFirstFileA(strSearch.data(), &fdFile);

	if (hFind == INVALID_HANDLE_VALUE) {
		return false;
	}

	do {
		std::string strDelete = strDir + "\\" + fdFile.cFileName;

		if (IsDir(fdFile) == true) {
			if (IsDots(fdFile.cFileName) == true) {
				continue;
			}
			DeleteDirectory(strDelete);
		}
		else {
			if (fdFile.dwFileAttributes & FILE_ATTRIBUTE_READONLY) {
				_chmod(strDelete.c_str(), _S_IWRITE);
			}
			::DeleteFileA(strDelete.data());
		}
	} while (::FindNextFileA(hFind, &fdFile) == TRUE);

	::FindClose(hFind);
	::RemoveDirectoryA(strDir.data());

	return true;
}



//***************************************************************************
// Description: Enum CDRom Driver
//***************************************************************************

static void EnumCdromDrive(vector<string>& removable_drv)
{
	DWORD dw;
	DWORD shift = 1;
	char drv[] = "A";
	char temp[32];

	removable_drv.clear();
	dw = GetLogicalDrives();

	for (unsigned int n = 0; n < 26; n++)
	{
		if ((dw & shift) != 0)
		{
			sprintf_s(temp, "%s:\\", drv);
			if (GetDriveTypeA(temp) == DRIVE_CDROM)
				removable_drv.push_back(temp);
		}
		drv[0] = drv[0] + 1;
		shift = shift << 1;
	}
}


//***************************************************************************
// Description: Get standardization for data time formatting, reference ISO 8601
//***************************************************************************

static void GetDateTime(char * datetime, unsigned int size)
{
	SYSTEMTIME sys_t;

	::GetLocalTime(&sys_t);
	sprintf_s(datetime, size, "%.4d-%.2d-%.2dT%.2d:%.2d:%.2dZ", sys_t.wYear, sys_t.wMonth, sys_t.wDay, sys_t.wHour, sys_t.wMinute, sys_t.wSecond);
}


//***************************************************************************
// Description: Get UTC standardization for data time formatting, reference ISO 8601
//***************************************************************************

static void GetSystemDateTime(char * datetime, unsigned int size)
{
	SYSTEMTIME sys_t;

	::GetSystemTime(&sys_t);
	sprintf_s(datetime, size, "%.4d-%.2d-%.2dT%.2d:%.2d:%.2dZ", sys_t.wYear, sys_t.wMonth, sys_t.wDay, sys_t.wHour, sys_t.wMinute, sys_t.wSecond);
}



//***************************************************************************
// Description: MemShortAlloc
//***************************************************************************

class CMemShortAlloc
{
public:
	CMemShortAlloc() :data(NULL), internalData(NULL) {};
	~CMemShortAlloc() { delete[] internalData; internalData = NULL; };
	void AllocSize(unsigned long size) { data = new unsigned short[size]; internalData = data; };
	unsigned short* data;
private:
	unsigned short* internalData;
};

class CMemByteAlloc
{
public:
	CMemByteAlloc() :data(NULL), internalData(NULL) {};
	~CMemByteAlloc() { delete[] internalData; internalData = NULL; };
	void AllocSize(unsigned long size) { data = new unsigned char[size]; internalData = data; };
	unsigned char* data;
private:
	unsigned char* internalData;
};



//***************************************************************************
// Description: connect net neighbor
//***************************************************************************

int ConnectNetNeighbor(const char* path, const char* id, const char* pwd);



//***************************************************************************
// Description: Get file size
//***************************************************************************

long GetFileSize(const char* filename);



//***************************************************************************
// Description: Get Date/Time format A (YYYY-MM-DD hh:mm:ss)
//***************************************************************************

void GetDateTimeFormatA(char* buffer, unsigned int len);



//***************************************************************************
// Description: Get System Date/Time format A (YYYYMMDDhhmmss)
//***************************************************************************

void GetSystemDateTimeFormatB(char* buffer, unsigned int len);



//***************************************************************************
// Description: Get Win version (not detail)
//***************************************************************************

void GetWinVer(char* buffer, unsigned int len);



//***************************************************************************
// Description: Get Win version (not detail)
//***************************************************************************

float MyRandom(float min, float max);




static VOID GPIBTrace(const char* data)
{
	//fox
}