#pragma once

#include <string>
#include <map>
#include "CommonApi.h"

using namespace std;

namespace Together
{
	static CCriticalSection g_together_cs;
};

class CTheNumber
{
public:
	CTheNumber(HANDLE handle, bool is_first) : m_handle(handle), m_is_first(is_first) {
	};
	virtual ~CTheNumber() {		
	};

	bool IsFirst() {
		return m_is_first;
	}

	void Wait() {
		WaitForSingleObject(m_handle, INFINITE);
		ResetEvent(m_handle);
	}

private:
	HANDLE m_handle;
	bool m_is_first;
};



class CGoTogether
{
private:
	CGoTogether();
public:
	virtual ~CGoTogether();
public:
	static CGoTogether* getInstance() {
		static auto_ptr<CGoTogether> pObj(new CGoTogether);
		return pObj.get();
	};

	void Add(const char* id);
	void Remove(const char* id);
	auto_ptr<CTheNumber> TakeNumber(const char* id, int expected_count = DEFAULT);
	enum EXPECTED_COUNT { DEFAULT = -1 };

private:
	unsigned int m_count;
	std::map<string, HANDLE> m_id_handles;
};



