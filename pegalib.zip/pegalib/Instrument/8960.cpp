// 8960.cpp: implementation of the C8960 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "8960.h"

#ifdef _DEBUG
#undef THIS_FILE
static CHAR THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

C8960::C8960()
{
	//Set GSM as default.
	iSystemIndex	= 0;
	m_bFastScreen	= FALSE;
	m_b1968			= FALSE;
	m_bCwMode		= FALSE;
	m_hDLL			= NULL;

	// Load visa32 DLL
	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	//m_hDLL = ::LoadLibraryEx(m_szDLLFile, NULL, DONT_RESOLVE_DLL_REFERENCES);
	if(NULL == m_hDLL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
	}
	else
	{
		viOpenDefaultRM		= (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL,"viOpenDefaultRM");
		viOpen				= (pf_viOpen_t)::GetProcAddress(m_hDLL,"viOpen");
		viPrintf			= (pf_viPrintf_t)::GetProcAddress(m_hDLL,"viPrintf");
		viScanf				= (pf_viScanf_t)::GetProcAddress(m_hDLL,"viScanf");
		viClose				= (pf_viClose_t)::GetProcAddress(m_hDLL,"viClose");
		viQueryf			= (pf_viQueryf_t)::GetProcAddress(m_hDLL,"viQueryf");
		viClear				= (pf_viClear_t)::GetProcAddress(m_hDLL,"viClear");
		viSetAttribute		= (pf_viSetAttribute_t)::GetProcAddress(m_hDLL,"viSetAttribute");
		viWrite				= (pf_viWrite_t)::GetProcAddress(m_hDLL,"viWrite");
		viGpibControlREN	= (pf_viGpibControlREN_t)::GetProcAddress(m_hDLL, "viGpibControlREN");
	}

	//Initialize Global Variable
	if (NULL != m_hDLL)
	{
		memset(m_cFormatType, 0x00, sizeof(m_cFormatType));
		m_iCurrOperMode = GMSK_MODE;
		m_iCurrBand = Band_GSM;
		m_iCurrCallProcessMode = CALLPROCESS_ON;
		m_iCurrModulationMode = MODULATION_ON;
		m_iCurrOutputPattern = PATTERN_BCHTCH;
		memset(m_cDPCHType, 0x00, sizeof(m_cDPCHType));
		memset(m_cPvtTimeOffset, 0x00, sizeof(m_cPvtTimeOffset));
		memset(m_cORFSModOffset, 0x00, sizeof(m_cORFSModOffset));
		memset(m_cORFSSwOffset, 0x00, sizeof(m_cORFSSwOffset));
		memset(m_cMCSUsing, 0x00, sizeof(m_cMCSUsing));
		m_bIsCallConnected = FALSE;
		m_bIsHandoverSetting = FALSE;
	}
}

C8960::~C8960()
{
	if(NULL != m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
}

//System Setting Function

INT C8960::SWITCH_FAST_SCREEN(BOOL bFast)
{
	m_nErrCode = GPIB_SUCCESS;

	m_bFastScreen = bFast;

	if(bFast == TRUE)
		m_nErrCode = Write("DISP:MODE FAST");		//Set screen mode off, it's faster
	else
		m_nErrCode = Write("DISP:MODE TRAC");

	return m_nErrCode;
}

INT C8960::SELECT_VIEW(char* czView) 
{
	m_nErrCode = GPIB_SUCCESS;
	/*
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	sprintf_s( m_szCommand, sizeof(m_szCommand), "SCRSEL %s", czView );
	m_nErrCode = Write(m_szCommand);
	*/
	return m_nErrCode;
}

INT C8960::END_CALL(VOID) 
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:END");
	m_nErrCode = Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::SEND_OPC( int iRetryCount, int iRetryIdle ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czQueryResult[128];
	memset(czQueryResult, 0x00, 128);
	for( int i = 0; i < iRetryCount; i++ )
	{
		m_nErrCode = Query( "*OPC?", czQueryResult );
		if( atoi(czQueryResult) == 1 )
			break;
		m_nErrCode = E_DEVICE_DATA_READ_ERROR;
		Sleep(iRetryIdle);
	}
	return m_nErrCode;
}

INT C8960::QUERY_STD(char* czQueryResult) 
{
	m_nErrCode = GPIB_SUCCESS;
	m_nErrCode = Query( "STDSEL?", czQueryResult );
	return m_nErrCode;
}

INT C8960::SET_RF_OUTPUT_SIGNAL_STATUS( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	if(bStatus)
		sprintf_s(m_szCommand, "%s", "CALL:CELL:POWER:STATE ON");
	else
		sprintf_s(m_szCommand, "%s", "CALL:CELL:POWER:STATE OFF");
	m_nErrCode = Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::SET_OUTPUT_MOD_SIGNAL_STATUS( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	if(bStatus)
		sprintf_s(m_szCommand, "%s", "MOD ON");
	else
		sprintf_s(m_szCommand, "%s", "MOD OFF");
	m_nErrCode = Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::SET_CALL_PROCESSING_MODE( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	if(bStatus)
		sprintf_s(m_szCommand, "%s", "CALLPROC ON");
	else
		sprintf_s(m_szCommand, "%s", "CALLPROC OFF");
	m_nErrCode = Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::GSM_OUTPUT_SIGNAL_PATTERN(const char* czPattern) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( strcmp("BCH", czPattern ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "CALL:OPER:MODE GBT" );
	else if( strcmp("CW", czPattern ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "CALL:OPER:MODE CW" );
	else if( strcmp("BCHTCH", czPattern ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "CALL:OPER:MODE GBTT" );
	else
		return GPIB_WRITE_FAIL;
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_SET_MEASUREMENT_STATUS(const char* czMeasurement, bool bStatus) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( strcmp("MOD", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "MOD_MEAS" );
	else if( strcmp("ORFSMD", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "ORFSMD_MEAS" );
	else if( strcmp("PWR", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "PWR_MEAS" );
	else if( strcmp("VSTIME", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "VSTIME_MEAS" );
	else if( strcmp("TEMP", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "TEMP_MEAS" );
	else if( strcmp("ORFSSW", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "ORFSSW_MEAS" );
	else if( strcmp("BER", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "BER_MEAS" );
	else
		return GPIB_WRITE_FAIL;

	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "%s ON", czCommand );
	else
		sprintf_s(czCommand, sizeof(czCommand), "%s OFF",czCommand );
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::SET_MEASUREMENT_MODE( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "MEASMODE FAST");
	else
		sprintf_s(czCommand, sizeof(czCommand), "MEASMODE NORM");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_SET_BIT_OFFSET(float fBitOfs) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	sprintf_s(czCommand, sizeof(czCommand), "BITOFS %.1f", fBitOfs);
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::SET_SCREEN_DISPLAY( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "SCREEN ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "SCREEN OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_SET_POWER_MEASUREMENT_COUNT( int nCount ) 
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::GSM_SET_TRAINING_SEQUENCE( int nPattern ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	sprintf_s(czCommand, sizeof(czCommand), "CALL:BURS:TYPE TSC%d", nPattern);
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_SET_OPERATING_MODE( const char* czMode ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( strcmp("GSM", czMode ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "OPEMODE GSM" );
	else if( strcmp("GPRS", czMode ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "OPEMODE GPRS" );
	else if( strcmp("EGPRS", czMode ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "OPEMODE EGPRS" );
	else
		return GPIB_WRITE_FAIL;
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_SET_MEASURMENT_OBJECT( const char* czObject ) 
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}


INT C8960::GSM_SET_CABLE_LOSS( float fLoss, int iBand ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);

	//Range ?55.00 to 55.00 dB
	if( fLoss < -55.00 )
		fLoss = -55.00;
	if( fLoss > 55.00 )
		fLoss = 55.00;

	//Resolution 0.01 dB
	switch(iBand)
	{
	case 1:
		sprintf_s(czCommand, sizeof(czCommand), "ULEXTLOSS BAND1,%.2f",fLoss); //GSM 400
		break;
	case 2:
		sprintf_s(czCommand, sizeof(czCommand), "ULEXTLOSS BAND2,%.2f",fLoss); //GSM 900, GSM 850
		break;
	case 3:
	default:
		sprintf_s(czCommand, sizeof(czCommand), "ULEXTLOSS BAND3,%.2f",fLoss); //DCS, PCS
		break;
	}

	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_SET_CABLE_LOSS_STATUS( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "EXTLOSSW ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "EXTLOSSW OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_PREDISTQ_MEASURE( int nDuration, int iPeriods, int iStepLength) 
{
	m_nErrCode = GPIB_SUCCESS;

	double dCenterStep[128] = {0.0};
	char cCenterStep[4096] = {0x00};

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:WAVE:TYPE DISC");
	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:TRIG:SOUR RISE");
	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:TRIG:THR 20");
	m_nErrCode = Write(m_szCommand);

	if(iStepLength == 168)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:FILT ENAR");
	else
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:FILT WIDE");

	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:TIM 10");
	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:RES:TYPE PCAL");
	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:STEP:COUN %d", iPeriods);
	m_nErrCode = Write(m_szCommand);
	
	if(iStepLength == 168)
	{
		sprintf_s(cCenterStep, sizeof(cCenterStep), "SET:PCAL:STEP:CENT 0.000196");
		for(int i=0; i<iPeriods - 1; i++)
		{
			sprintf_s(cCenterStep, sizeof(cCenterStep), "%s,%f", cCenterStep, (0.000196 + ((double)( ( i + 1 ) * nDuration) / 1000000.0 )));
		}
	}
	else
	{
		sprintf_s(cCenterStep, sizeof(cCenterStep), "SET:PCAL:STEP:CENT 0.000465");
		for(int i=0; i<iPeriods - 1; i++)
		{
			sprintf_s(cCenterStep, sizeof(cCenterStep), "%s,%f", cCenterStep, (0.000465 + ((double)( ( i + 1 ) * nDuration) / 1000000.0 )));
		}
	}
	m_nErrCode = Write(cCenterStep);

	memset(cCenterStep, 0x00, sizeof(cCenterStep));
	sprintf_s(cCenterStep, sizeof(cCenterStep), "SET:PCAL:STEP:WID %f",iStepLength/1000000.0);
	for(int i=0; i<iPeriods - 1; i++)
	{
		sprintf_s(cCenterStep, sizeof(cCenterStep), "%s,%f", cCenterStep, iStepLength/1000000.0);
	}
	m_nErrCode = Write(cCenterStep);

	if(iStepLength != 168)
	{

		//sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:FILT WIDE");
		//m_nErrCode = Write(m_szCommand);

		//sprintf_s(m_szCommand, sizeof(m_szCommand), "INIT:PCAL:OFF");
		//m_nErrCode = Write(m_szCommand);

	}
	sprintf_s(m_szCommand, sizeof(m_szCommand), "INIT:PCAL:ON");
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;

}


//INT C8960::GSM_SET_INPUT_LEVEL( float fInputLevel ) 
//{
//	m_nErrCode = GPIB_SUCCESS;
//	char czCommand[128];
//	memset(czCommand, 0x00, 128);
//
//	if( fInputLevel < -30.0 )
//		fInputLevel = -30.0;
//	if( fInputLevel > 40.0 )
//		fInputLevel = 40.0;
//
//	sprintf_s(czCommand, sizeof(czCommand), "CALL:CELL:POW %.1f", fInputLevel); //Resolution 0.1 dBm
//
//	m_nErrCode = Write(czCommand);
//	return m_nErrCode;
//}

INT C8960::GSM_PREDISTQ_MEASURE( int nDuration, int iPeriods, double fRatio ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);

	if( nDuration < 200 )
		nDuration = 200;
	if( nDuration > 4615 )
		nDuration = 4615;

	if( iPeriods < 1 )
		iPeriods = 1;
	if( iPeriods > 500 )
		iPeriods = 500;

	if( fRatio < 0.10 )
		fRatio = 0.10;
	if( fRatio > 1.00 )
		fRatio = 1.00;

	sprintf_s(czCommand, sizeof(czCommand), "SWPPREDISTQ %d,%d,%f", nDuration, iPeriods, fRatio);

	m_nErrCode = Write(czCommand);
	return m_nErrCode;

}


//INT C8960::GSM_SET_OUTPUT_LEVEL_STATUS( bool bStatus ) 
//{
//	m_nErrCode = GPIB_SUCCESS;
//	char czCommand[128];
//	memset(czCommand, 0x00, 128);
//	if(bStatus)
//		sprintf_s(czCommand, sizeof(czCommand), "LVL ON");
//	else
//		sprintf_s(czCommand, sizeof(czCommand), "LVL OFF");
//	m_nErrCode = Write(czCommand);
//	return m_nErrCode;
//}


INT C8960::GSM_SET_OUTPUT_MOD_SIGNAL_STATUS( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if(bStatus)
		sprintf_s(czCommand, sizeof(czCommand), "MOD ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "MOD OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::GSM_PREDISTQ_GET_STATUS( char* pStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	sprintf_s(czCommand, sizeof(czCommand), "FETC:PCAL:INT?");
	m_nErrCode = Query( czCommand, pStatus );
	if(m_nErrCode == GPIB_SUCCESS)
		pStatus = strtok(pStatus, "+");
	return m_nErrCode;
}

INT C8960::GSM_PREDISTQ_GET_POWER( int iPeriods, char* pResult ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);

	if( iPeriods < 1 )
		iPeriods = 1;
	if( iPeriods > 500 )
		iPeriods = 500;

	sprintf_s(czCommand, sizeof(czCommand), "FETCH:PCAL:POW?");
	m_nErrCode = Query( czCommand, pResult );
	return m_nErrCode;
}

INT C8960::WCDMA_SET_OUTPUT_LEVEL_STATUS( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, sizeof(czCommand));
	if(bStatus)
		sprintf_s(czCommand, sizeof(czCommand), "LVL ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "LVL OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_AWGN_OUTPUT_STATUS( bool bStatus ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, sizeof(czCommand));
	if(bStatus)
		sprintf_s(czCommand, sizeof(czCommand), "AWGNLVL ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "AWGNLVL OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::SET_MEASUREMENT_STATUS(const char* czMeasurement, bool bStatus)
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( strcmp("ADJ", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "ADJ_MEAS" );
	else if( strcmp("BER", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "BER_MEAS" );
	else if( strcmp("BLER", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "BLER_MEAS" );
	else if( strcmp("FREQ", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "FREQ_MEAS" );
	else if( strcmp("MOD", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "MOD_MEAS" );
	else if( strcmp("OBW", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "OBW_MEAS" );
	else if( strcmp("PCDE", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "PCDE_MEAS" );
	else if( strcmp("SMASK", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "SMASK_MEAS" );
	else if( strcmp("PWR", czMeasurement ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "PWR_MEAS" );
	else
		return GPIB_WRITE_FAIL;

	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "%s ON", czCommand );
	else
		sprintf_s(czCommand, sizeof(czCommand), "%s OFF",czCommand );
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_POWER_MEASUREMENT_AVERAGE_COUNT( int nCount ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, sizeof(czCommand));
	sprintf_s(czCommand, sizeof(czCommand), "PWR_AVG %d", nCount);
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_RF_SIGNAL_OUTPUT_CONNECTOR_TYPE( const char* czConnectorType )
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, sizeof(czCommand));
	if( strcmp("MAIN", czConnectorType ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "RFOUT MAIN" );
	else if( strcmp("AUX", czConnectorType ) == 0 )
		sprintf_s(czCommand, sizeof(czCommand), "RFOUT AUX" );
	else
		return GPIB_WRITE_FAIL;
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_DL_FREQUENCY( double dFreq ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, sizeof(czCommand));
	sprintf_s(czCommand, sizeof(czCommand), "DLFREQ %.1fMHZ", dFreq );
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_OUTPUT_LEVEL(double dPower ) 
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, sizeof(czCommand));
	sprintf_s(czCommand, sizeof(czCommand), "OLVL %.3f", dPower );
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_AUX_CABLE_LOSS( double dLoss )
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	sprintf_s(czCommand, sizeof(czCommand), "AUEXTLOSS %.1f", dLoss);
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_AUX_CABLE_LOSS_STATUS( bool bStatus )
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "AUEXTLOSSW ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "AUEXTLOSSW OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_DL_CABLE_LOSS( double dLoss )
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	sprintf_s(czCommand, sizeof(czCommand), "DLEXTLOSS %.1f", dLoss);
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_DL_CABLE_LOSS_STATUS( bool bStatus )
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "DLEXTLOSSW ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "DLEXTLOSSW OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::WCDMA_SET_AM_STATUS(bool bStatus)
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	memset(czCommand, 0x00, 128);
	if( bStatus )
		sprintf_s(czCommand, sizeof(czCommand), "AM ON");
	else
		sprintf_s(czCommand, sizeof(czCommand), "AM OFF");
	m_nErrCode = Write(czCommand);
	return m_nErrCode;
}

INT C8960::Band_Calibration()
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "%s", "BANDCAL");
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::SET_TRAINING_SEQUENCE(INT iTSC)
{	
	sprintf_s(m_szCommand,"CALL:BURS:TYPE TSC%d", iTSC);

	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}
/*
INT C8960::Set_Synchronous_Sweep()
{
	return Write("SWP");
}
*/

INT	C8960::Set_Single_Sweep()
{
	return Write("SNGLS");
}

INT	C8960::Set_Continuous_Sweep_Mode()
{
	return Write("CONTS");
}

INT	C8960::Stop_Measurement()
{
	//both GSM and WCDMA
	return Write("MEASSTOP");
}

INT	C8960::Get_Measurement_Status(INT *iMSTAT_Staus)
{
	ViStatus status;

	sprintf_s(m_szCommand,"SWP?");
	status = viQueryf(m_viSession,(CHAR *)m_szCommand,"%d",iMSTAT_Staus);
	
	if (status != VI_SUCCESS)
	{
		return GPIB_WRITE_FAIL;
	}

	return GPIB_SUCCESS;
}

INT C8960::Write(CONST CHAR *pcCommand)
{
	ViStatus status;
	char GPIBLog[4096] = {0x00};
	char m_WrCommand[4096] = {0x00};
	ViUInt32 retCount = 0;

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog),"WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}

	sprintf_s(m_WrCommand, sizeof(m_WrCommand), "%s\n", pcCommand);
	status = viWrite(m_viSession, (ViBuf)m_WrCommand, (ViUInt32)strlen(m_WrCommand), &retCount);


	if (status != VI_SUCCESS)
	{
		return GPIB_WRITE_FAIL;
	}
	return GPIB_SUCCESS;
}

INT C8960::Query(CONST CHAR *pcCommand, CHAR *pcReturnValue)
{
	ViStatus status;
	char GPIBLog[10240] = {0x00};
	char m_WrCommand[10240] = {0x00};
	char sep[] = "\r\n";

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog), "WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}

	sprintf_s(m_WrCommand, sizeof(m_WrCommand), "%s\n", pcCommand);

	status = viQueryf(m_viSession, m_WrCommand, "%t", pcReturnValue);
	if (status != VI_SUCCESS)
	{
		return GPIB_QUERY_FAIL;
	}

	pcReturnValue = strtok(pcReturnValue, sep);

	if (m_bGPIB_Log_Enable == TRUE)
	{
		memset(GPIBLog, 0x00, sizeof(GPIBLog));
		sprintf_s(GPIBLog, sizeof(GPIBLog), "RE: %s", pcReturnValue);
		GPIBTrace(GPIBLog);
	}

	return GPIB_SUCCESS;
}

INT C8960::Read(CHAR *pcReturnValue, INT length)
{
	ViStatus	status = VI_SUCCESS;

	m_nErrCode = GPIB_SUCCESS;

	status = viScanf(m_viSession, "%s", pcReturnValue);
	if (status != VI_SUCCESS)
	{
		m_nErrCode = GPIB_READ_FAIL;
	}

	return m_nErrCode;
}

INT	C8960::VISA32_SET_VI_SESSION(DWORD vi)
{
	m_viSession = (ViSession)vi;
	return GPIB_SUCCESS;
}

INT	C8960::VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable)
{
	m_bGPIB_Log_Enable = bGPIBLog_Enable;
	GPIBTrace("##########		8960 Test Start		##########");
	return GPIB_SUCCESS;
}

INT C8960::CALL_TEST_FETCH(CONST CHAR* in_psCommand, CHAR *out_psResult)
{
	m_nErrCode=Query(in_psCommand,out_psResult);
	return m_nErrCode;
}

INT	C8960::Set_Output_Signal_Pattern(CHAR* cMode)
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	if(_stricmp(cMode,"BCH")==0)
	{
		sprintf_s(m_szCommand,"OSIGPAT CCH;*OPC?");
	}
	else if(_stricmp(cMode,"BCHTCH")==0)
	{
		sprintf_s(m_szCommand,"OSIGPAT CCHTCH;*OPC?");
	}
	else if(_stricmp(cMode,"CW")==0)
	{
		sprintf_s(m_szCommand,"MOD OFF;*OPC?"); // NOT SURE
	}

	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;

}

INT C8960::SEND_RESET(VOID)
{
	return Write("*CLS;*RST");
}

int C8960::SET_SYSTEM_COMBINATION(CONST CHAR *cSyscmb)
{
	char sResult[100];

	memset(m_szCommand,0,sizeof(m_szCommand));
	memset(sResult,0,sizeof(sResult));

	sprintf_s(m_szCommand, "CALL:BAND %s", cSyscmb);
	m_nErrCode = Write(m_szCommand);
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand,0,sizeof(m_szCommand));
		sprintf_s(m_szCommand, "CALL:BAND?");
		m_nErrCode = Query(m_szCommand, sResult);
		if (m_nErrCode == GPIB_SUCCESS)
		{
			if (strstr(sResult, cSyscmb) == NULL)
			{
				m_nErrCode = E_DEVICE_SETTING_ERROR;
			}
		}
	}

	return m_nErrCode;
}

INT C8960::SET_CALL_PROCESSING_MODE(CONST CHAR *in_psMode)
{
	m_nErrCode = GPIB_SUCCESS;

	return m_nErrCode;
}

INT C8960::SET_CELL_POWER(double fPower)
{
	char	sResult[10] = {0};

	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"CALL:CELL:POW %f",fPower);
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}


INT C8960::Set_Input_Power_Lev( FLOAT fIL)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"ILVL %f",fIL);
	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::SET_PDTCH_CHANNEL( UINT arfcn)
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:PDTCH:ARFCn %d", arfcn);
	return Write(m_szCommand);
}

INT C8960::SET_BCH_ARFCn(UINT arfcn)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "CALL:BCH:ARFCn %d", arfcn);
	return Write(m_szCommand);
}

INT	C8960::SET_EXTERNAL_LOSS_TABLE(CHAR *cStandard, double dFrequency[], double dCableLoss[], INT num)
{
	INT i = 0;

	m_nErrCode = GPIB_SUCCESS;

	if(num > 20)
		num = 20;

	//	Reset RF Cable Loss
	sprintf_s(m_szCommand, "SYST:CORR:SFR");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "SYST:CORR:SGA");
		m_nErrCode = Write(m_szCommand);
	}

	//	Set RF Cable Loss Frequency
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "SYST:CORR:SFR");
		for(i=0; i<num; i++)
		{
			if (i == 0)
				sprintf_s(m_szCommand, "%s %.2f MHZ", m_szCommand, dFrequency[i]);
			else
				sprintf_s(m_szCommand, "%s,%.2f MHZ", m_szCommand, dFrequency[i]);
		}

		m_nErrCode = Write(m_szCommand);
	}

	//Set RF Cable Loss Offset
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "SYST:CORR:SGA");
		for(i=0; i<num; i++)
		{
			if (i == 0)
				sprintf_s(m_szCommand, "%s %.2f", m_szCommand, dCableLoss[i]);
			else
				sprintf_s(m_szCommand, "%s,%.2f", m_szCommand, dCableLoss[i]);
		}

		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		Send_OPC();

	return m_nErrCode;
}

INT C8960::Set_MS_Power_Level( INT iPowerLevel)
{
	memset(m_szCommand,0,sizeof(m_szCommand));		
	sprintf_s(m_szCommand,"MSPWR %d",iPowerLevel);
	m_nErrCode=Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::SET_EXP_POWER_LEVEL(INT iPowerLevel, E_BAND iBand)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand,0x00,sizeof(m_szCommand));

	sprintf_s(m_szCommand,"CALL:MS:TXL %d",iPowerLevel);
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::Set_Exp_Power(FLOAT fPower, E_BAND iBand)
{
	memset(m_szCommand,0,sizeof(m_szCommand));	
	
	sprintf_s(m_szCommand,"ILVL %f",fPower);
	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::Read_Tx_Power(CHAR *out_psResult)
{
	m_nErrCode = GPIB_SUCCESS;
	
	CHAR sResult[RF_TEST_FETCH_BUFFER_SIZE];
	memset(sResult,0,sizeof(sResult));

	DWORD	time = GetTickCount();
	DWORD	timeExperity = time + 3000;
	INT index_MSTAT=0; 
	INT iMSTAT_Staus=1;
	INT iMSTAT_STATUS;
	
	//sprintf_s(m_szCommand,"AVG_TXPWR? DBM");
	//m_nErrCode=Write(m_szCommand);
	

	while (time <= timeExperity)
	{
		time = GetTickCount();
		do
		{
	
			iMSTAT_STATUS = SET_SYNCHRONOUS_SINGLE_SWEEP();
			Sleep(50);
			iMSTAT_STATUS = Get_Measurement_Status(&iMSTAT_Staus);
			index_MSTAT++;

		} while (iMSTAT_Staus !=0 && index_MSTAT < 5);
	
		
		if (iMSTAT_STATUS==0)
		{
			m_nErrCode = CALL_TEST_FETCH("AVG_TXPWR?", sResult);
			
			if (m_nErrCode!= GPIB_SUCCESS)
			{
				//show error message
			}
			else
			{

				CHAR *pDest1;
				pDest1 = sResult;
				strcpy_s(out_psResult, 256, pDest1);
				return m_nErrCode;
			}
		}
		else
		{
			m_nErrCode=E_FETCH_PVT_FAIL;
		}
	}

	return m_nErrCode;
}

INT C8960::Set_Power_Measurement_Mode(CHAR *cOnOff)
{
	sprintf_s(m_szCommand,"PWR_MEAS %s",cOnOff);
	m_nErrCode=Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::Set_PFER_Measurement_Mode(CHAR *cOnOff)
{
	sprintf_s(m_szCommand,"MOD_MEAS %s",cOnOff);
	m_nErrCode=Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::Set_Modulation_Analysis_Count(INT nCount)
{
	memset(m_szCommand,0,sizeof(m_szCommand));	
	
	sprintf_s(m_szCommand,"MOD_COUNT %d",nCount);
	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;
}


INT C8960::AFC_Fetch_Freq_Error( CHAR *cReturn)
{
	CHAR	sResult[RF_TEST_FETCH_BUFFER_SIZE];
	INT		index_MSTAT=0; 
	INT		iMSTAT_Staus=1;
	INT		iMSTAT_STATUS;
	DWORD	time = GetTickCount();
	DWORD	timeExperity = time + 3000;

	m_nErrCode = GPIB_SUCCESS;
	
	memset(sResult,0,sizeof(sResult));
	//sprintf_s(m_szCommand,"AVG_TXPWR? DBM");
	//m_nErrCode=Write(m_szCommand);
	

	while (time <= timeExperity)
	{
		time = GetTickCount();
		do
		{
	
			iMSTAT_STATUS = SET_SYNCHRONOUS_SINGLE_SWEEP();
			Sleep(50);
			iMSTAT_STATUS = Get_Measurement_Status(&iMSTAT_Staus);
			index_MSTAT++;

		} while (iMSTAT_Staus !=0 && index_MSTAT < 5);
	
		
		if (iMSTAT_STATUS==0)
		{
			m_nErrCode = CALL_TEST_FETCH("AVG_CARRFERR? Hz", sResult);
			
			if (m_nErrCode!= GPIB_SUCCESS)
			{
				//show error message
			}
			else
			{
				sprintf_s(cReturn, "%s", sResult);
				return m_nErrCode;
			}
		}
		else
		{
			m_nErrCode=E_FETCH_PVT_FAIL;
		}
	}

	return m_nErrCode;
}

INT C8960::Set_All_Fundamental_Measurement_Items()
{
	memset(m_szCommand,0,sizeof(m_szCommand));	
	
	sprintf_s(m_szCommand,"ALLMEASITEMS ON,ON,20,OFF,OFF,OFF,OFF,OFF,OFF,100,OFF,OFF,100,OFF,OFF,100,OFF,OFF");
	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::Set_Power_Measurement_Count(INT nCount)
{
	memset(m_szCommand,0,sizeof(m_szCommand));		
	sprintf_s(m_szCommand,"PWR_AVG %d",nCount);
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::FETCH_PFER( CHAR *out_psResult)
{
	return CALL_TEST_FETCH("FETC:PFER:FERR:WORSt?", out_psResult);
}

INT C8960::FETCH_PEAKPH( CHAR *out_psResult)
{
	return CALL_TEST_FETCH("FETC:PFER:PEAK:MAX?", out_psResult);
}

INT C8960::FETCH_RMSPH( CHAR *out_psResult)
{
	return CALL_TEST_FETCH("FETC:PFER:RMS:MAX?", out_psResult);
}

INT C8960::ORFS_MEASUREMENT(CHAR *cSW_Result, CHAR *cMOD_Result, CHAR *cOrfsSwFreqOffset, CHAR *cOrfsModFreqOffset)
{
	m_nErrCode = GPIB_SUCCESS;

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"FETCH:ORFS:SWIT:FREQ:OFFS? %s",cOrfsSwFreqOffset);
		m_nErrCode=Query(m_szCommand,cSW_Result);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"FETCH:ORFS:MOD:FREQ:OFFS? %s",cOrfsModFreqOffset);
		m_nErrCode=Query(m_szCommand,cMOD_Result);
	}

	return m_nErrCode;
}

INT C8960::FETCH_FBER( CHAR *out_psResult)
{
	return CALL_TEST_FETCH("FETC:FBER:RAT?", out_psResult);
}

INT C8960::FETCH_POWER( CHAR *out_psResult)
{
	return CALL_TEST_FETCH("FETC:TXP:POW:AVER?", out_psResult);
}

INT C8960::Set_Input_Lev(FLOAT fIL)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"OLVL %f",fIL);

	m_nErrCode=Write(m_szCommand);
	m_nErrCode=Send_OPC();
	return m_nErrCode;	
}

INT C8960::SET_TCH_BAND(CONST CHAR in_sBand[])
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "CALL:TCH:BAND %s", in_sBand);
	return Write(m_szCommand);
}

INT C8960::SET_TCH_ARFCn(const UINT in_uiARFCn)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "CALL:TCH:ARFCn %d", in_uiARFCn);
	return Write(m_szCommand);
}

INT C8960::Fetch_RSSI( CHAR *out_psRxQ, CHAR *out_psRxL)
{
	CHAR cResult[200] = {0};
	CHAR *token;
	CHAR seps[]   = "{} ,\t\n";

	m_nErrCode = Single_Measurement();
	
	if(m_nErrCode != GPIB_SUCCESS)
		return m_nErrCode;
	
	DWORD	time = GetTickCount();
	DWORD	timeExperity = time + 3000;
	INT		iID = 0;

	sprintf_s(m_szCommand, "CALLREP?");
	while (time <= timeExperity)
	{
		time = GetTickCount();
		m_nErrCode = CALL_TEST_FETCH(m_szCommand, cResult);
		
		if(m_nErrCode == GPIB_SUCCESS)
		{
			token = strtok(cResult,seps);
			iID = atoi(token);
			if(iID == 1)
			{				
				token = strtok( NULL, seps );
				if (token != NULL)
					sprintf_s(out_psRxL, 16,token);

				token = strtok( NULL, seps );
				if(token != NULL)
					sprintf_s(out_psRxQ, 16, token);
				
				break;
			}
		}
	}

	if((iID != 1) && (m_nErrCode == GPIB_SUCCESS))
		return E_FETCH_RSSI_FAIL;

	return m_nErrCode;	
}

INT C8960::SET_INIT_FBER()
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = Write("INIT:FBER:ON");
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE("FBER");
	}

	return m_nErrCode;
}

INT C8960::SET_END_FBER()
{
	if ((m_nErrCode = Write("INIT:FBER:OFF")) != GPIB_SUCCESS)
		return m_nErrCode;
	else
		return GPIB_SUCCESS;
}


INT C8960::SET_FBER(INT nCount, INT nTimeOut)
{
	sprintf_s(m_szCommand,"SETUP:FBER:CONT OFF");
	m_nErrCode = Write(m_szCommand);

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:FBER:CLSD:TIME 1.5 S");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:FBER:COUNT %d", nCount);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:FBER:TIMEOUT:TIME %d", nTimeOut);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:FBER:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;

	//sprintf_s(m_szCommand,"LOOPBACK ON");
	//m_nErrCode = Write(m_szCommand);
	//
	//if(m_nErrCode == GPIB_SUCCESS)
	//{
	//	sprintf_s(m_szCommand,"LBTYPE FAST");
	//	m_nErrCode = Write(m_szCommand);
	//}

	//if(m_nErrCode == GPIB_SUCCESS)
	//{
	//	sprintf_s(m_szCommand,"BER_SAMPLE FAST,%d",nCount);
	//	m_nErrCode = Write(m_szCommand);
	//}

	//if(m_nErrCode == GPIB_SUCCESS)
	//{
	//	sprintf_s(m_szCommand,"BER_MEAS OFF");
	//	m_nErrCode = Write(m_szCommand);
	//}

	//return m_nErrCode;
}

INT C8960::Set_ORFS(INT iModCount, INT iSWCount, INT nTimeOut)
{
	CHAR	m_szCommand2[200];

	sprintf_s(m_szCommand,"ORFSSW_COUNT %d",iSWCount);
	sprintf_s(m_szCommand2,"ORFSMD_COUNT %d",iModCount);

	if (iSystemIndex == 1)		//WCDMA
	{
		if ((m_nErrCode = Write("ORFSSW_MEAS ON")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write("ORFSMD_MEAS ON")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write("ORFSMD_PHOLD ON")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write("ORFSSW_PHOLD ON")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write(m_szCommand)) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write(m_szCommand2)) != GPIB_SUCCESS)
			return m_nErrCode;
		else
			return GPIB_SUCCESS;
	}
	else if (iSystemIndex == 0)		//GSM
	{
		if ((m_nErrCode = Write("ORFSSW_MEAS OFF")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write("ORFSMD_MEAS OFF")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write("ORFSMD_PHOLD ON")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write("ORFSSW_PHOLD ON")) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write(m_szCommand)) != GPIB_SUCCESS)
			return m_nErrCode;
		else if ((m_nErrCode = Write(m_szCommand2)) != GPIB_SUCCESS)
			return m_nErrCode;
		else
			return GPIB_SUCCESS;
	}
	return GPIB_SUCCESS;
}

INT C8960::Set_TCH_PAT()
{
	sprintf_s(m_szCommand,"TESTPAT ECHO");
	return Write(m_szCommand);
}

INT C8960::Set_TCH_Time_Advance(UINT timeadv)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"TMADVANCE %d",timeadv);

	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::SET_POWER(INT nCount, INT nTimeOut)
{

	sprintf_s(m_szCommand,"SETUP:TXP:CONT OFF");
	m_nErrCode = Write(m_szCommand);

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:TXP:COUNT %d", nCount);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:TXP:COUNT:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:TXP:TRIG:SOURCE AUTO");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:TXP:TIM:TIME %dS", nTimeOut);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:TXP:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;

}

INT C8960::SET_PFER(INT nCount, INT nTimeOut)
{
	sprintf_s(m_szCommand,"SETUP:PFER:CONT OFF");
	m_nErrCode = Write(m_szCommand);

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PFER:COUNT %d", nCount);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:PFER:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PFER:TRIGGER:SOURCE AUTO");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PFER:SYNC MIDAMBLE");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PFERROR:TIMEOUT:TIME %d", nTimeOut);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:PFER:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::Single_Measurement(VOID)
{
	DWORD	time = GetTickCount();
	DWORD	timeExperity = time + 3000;
	INT		iState = -1;
	
	m_nErrCode = SET_SYNCHRONOUS_SINGLE_SWEEP();
	if(m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = E_FETCH_TIME_OUT;
		while(time < timeExperity)
		{
			time = GetTickCount();
			Get_Measurement_Status(&iState);
			if(iState == 0)
			{
				m_nErrCode = GPIB_SUCCESS;
				break;
			}
		}	
	}

	//Measure again if measurement fail.
	if (m_nErrCode != GPIB_SUCCESS)
	{
		time = GetTickCount();
		timeExperity = time + 3000;
		
		m_nErrCode = SET_SYNCHRONOUS_SINGLE_SWEEP();
		if(m_nErrCode == GPIB_SUCCESS)
		{
			m_nErrCode = E_FETCH_TIME_OUT;
			while(time < timeExperity)
			{
				time = GetTickCount();
				Get_Measurement_Status(&iState);
				if(iState == 0)
				{
					m_nErrCode = GPIB_SUCCESS;
					break;
				}
			}	
		}
	}

	return m_nErrCode;
}

//WB Function
INT C8960::SET_ALL_FUNDAMENTAL_MEASUREMENT_ITEMS_OFF(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand,"ABORt:ALL");
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}
/*
INT C8960::End_Call(VOID)
{
	sprintf_s (m_szCommand, "CALLSO");
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;
	return m_nErrCode;
}
*/
INT C8960::MT_Call(VOID)
{
	sprintf_s (m_szCommand, "CALLSA");
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;
	return m_nErrCode;
}


INT C8960::WB_Set_International_Mobile_Subscriber_Identity(CHAR pagingIMSI[])
{
	sprintf_s (m_szCommand, "IMSI %s", pagingIMSI);
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;
	
	return m_nErrCode;
}

INT C8960::WB_Set_Paging_IMSI(CHAR pagingIMSI[])
{
	sprintf_s (m_szCommand, "IMSI %s", pagingIMSI);
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;
	
	return m_nErrCode;
}

INT C8960::WB_Set_Authentication_Key (CHAR value[])
{
	//8960 cmd example
	//AUTHENT_KEYALL 55555555,55555555,55555555,55555555
	

	CString temp;

	temp = value;

	CString value1;
	CString value2;
	CString value3;
	CString value4;

	for (INT i=0; i<8;i++)
	{		
		value1+= temp.GetAt(i);
		value2+= temp.GetAt(i+8);
		value3+= temp.GetAt(i+16);
		value4+= temp.GetAt(i+24);
	}		
	
	
	sprintf_s (m_szCommand, "AUTHENT_KEYALL %s,%s,%s,%s", value1,value2,value3,value4);
	
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;

	sprintf_s (m_szCommand, "INTEGRITY ON");
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;
	
	return m_nErrCode;
}

INT C8960::WB_Query_Status(CHAR *cStatus)
{
	m_nErrCode = GPIB_SUCCESS;
	
	sprintf_s(m_szCommand,"CALLSTAT?");
	
	m_nErrCode=Query(m_szCommand,cStatus);
	
	return m_nErrCode;
}

INT C8960::WB_SET_FUNDAMENTAL_MEASUREMENT(char *selectScr)
{
	CHAR			cReceiveBuffer[128] = {0};
	
	sprintf_s(m_szCommand, "SCRSEL?");

	m_nErrCode = Query(m_szCommand, cReceiveBuffer);

	if ((m_nErrCode == GPIB_SUCCESS) && (_stricmp(cReceiveBuffer, "FMEAS") != 0))
	{
		sprintf_s (m_szCommand, "SCRSEL FMEAS");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}
/*
INT C8960::WCDMA_SET_EXTERNAL_LOSS_TABLE(double dFrequency[], double dCableLoss[],INT num)
{
	CHAR cCmd[2000];
	if(num > 20)
		num = 20;
	for(INT i=0;i<num;i++)
	{
		fCableLoss[i]=0-dCableLoss[i];
		sprintf_s(cCmd,"LOSSTBLVAL %.2lfMHZ,%.2lf,%.2lf,%.2lf",dFrequency[i],dCableLoss[i],dCableLoss[i],dCableLoss[i]);
		m_nErrCode=Write(cCmd);
	}
	
	sprintf_s(m_szCommand,"DLEXTLOSSW COMMON;ULEXTLOSSW COMMON");
	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;

}
*/

INT C8960::WB_Set_Handoff_UARFCN(INT handoffUARFCN)
{

	sprintf_s (m_szCommand, "DLCHAN %d", handoffUARFCN);
	
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;

}

INT C8960::WB_Set_DL_Freq(double fFrequencyMHz)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	
	sprintf_s(m_szCommand, "DLFREQ %f", fFrequencyMHz*1000000);
			
	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::WB_SET_OUTPUT_LEVEL(double dPower)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "OLVL %f", dPower);
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = SET_CELL_POWER_STATE_ON();
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = Send_OPC();
	}

	return m_nErrCode;
}

INT C8960::WB_Set_Output_Level_State_ON_OFF(bool bStatus)
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	if (bStatus)
	{
		sprintf_s(m_szCommand,"LVL ON");
	}
	else
	{
		sprintf_s(m_szCommand,"LVL OFF");
	}
	
	m_nErrCode=Write(m_szCommand);


	return m_nErrCode;
}

INT C8960::WB_SET_INPUT_LEVEL(double fPower)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	
	sprintf_s(m_szCommand,"ILVL %f;*OPC?",fPower);
	m_nErrCode=Write(m_szCommand);
	//m_nErrCode=Send_OPC();
	return m_nErrCode;
}


INT C8960::WB_Get_Output_Level(CHAR *cPower)
{
	sprintf_s(m_szCommand,"OLVL?");
	
	m_nErrCode=Query(m_szCommand,cPower);

	return m_nErrCode;
}

INT C8960::WB_Set_Output_Measurement(CHAR *cPattern,INT count)
{
	
	sprintf_s(m_szCommand,"TPCPAT %s",cPattern);

	m_nErrCode=Write(m_szCommand);

	Sleep(100);
					  //ALLMEASITEMS power freq  OBW  SEM  ACPL MdAn PCDE BER BLER
	sprintf_s(m_szCommand,"ALLMEASITEMS ON,%d,ON,5,ON,5,ON,5,ON,5,ON,5,ON,5,OFF,OFF",count);
	
	m_nErrCode=Write(m_szCommand);
		
	return m_nErrCode;
}

INT C8960::WB_Set_Ref_Senstivity_Measurement(CHAR *cPattern,INT count)
{
	sprintf_s(m_szCommand,"TPCPAT %s",cPattern);

	m_nErrCode=Write(m_szCommand);

					  //ALLMEASITEMS power  freq  OBW   SEM   ACPL  MdAn  PCDE  BER BLER
	sprintf_s(m_szCommand,"ALLMEASITEMS OFF,5,OFF,5,OFF,5,OFF,5,OFF,5,OFF,5,OFF,5,ON, OFF");
	
	m_nErrCode=Write(m_szCommand);
		
	return m_nErrCode;

}
	
INT C8960::WB_GET_MEASUREMENT_POWER(CHAR *cAvgPower)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	m_nErrCode = Single_Measurement();
	
	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "AVG_POWER?");
		m_nErrCode = Query(m_szCommand, cAvgPower);
	}
	
	return m_nErrCode;
}

INT C8960::WB_Get_Measurement_OBW(CHAR *cOBW)
{
	INT index_MSTAT=0; 
	INT iMSTAT_Staus=1;
	INT iMSTAT_STATUS;

	do
	{
		iMSTAT_STATUS = SET_SYNCHRONOUS_SINGLE_SWEEP();
		Sleep(50);
		iMSTAT_STATUS = Get_Measurement_Status(&iMSTAT_Staus);
		index_MSTAT++;

	} while (iMSTAT_Staus !=0 && index_MSTAT < 5);
	sprintf_s(m_szCommand,"OBW?");

	m_nErrCode=Query(m_szCommand,cOBW);
	
	return m_nErrCode;
}

INT C8960::WB_GET_MEASUREMENT_SEM(CHAR *cSEM)
{

	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0, sizeof(m_szCommand));

	m_nErrCode = Single_Measurement();

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SMASKPASS?");

		m_nErrCode = Query(m_szCommand, cSEM);
	}
	
	/*
	INT iMSTAT_Staus=1;
	INT iMSTAT_STATUS;
	INT index_MSTAT=0;
	//CHAR cBuf[256]={0x00};
	do
	{
	
		iMSTAT_STATUS = SET_SYNCHRONOUS_SINGLE_SWEEP();
		Sleep(50);
		iMSTAT_STATUS = Get_Measurement_Status(&iMSTAT_Staus);
		index_MSTAT++;

	} while (iMSTAT_Staus !=0 && index_MSTAT < 5);

	sprintf_s(m_szCommand,"SMASKPASS?");

	m_nErrCode=Query(m_szCommand,cSEM);
	*/

	return m_nErrCode;
}

INT C8960::WB_GET_MEASUREMENT_ACLR(CHAR *cLow_5_MHZ,CHAR *cLow_10_MHZ,CHAR *cUp_5_MHZ,CHAR *cUp_10_MHZ)
{
	m_nErrCode = GPIB_SUCCESS;
	
	sprintf_s(m_szCommand,"AVG_MODPWR? LOW5");
	
	if ((m_nErrCode = Query(m_szCommand, cLow_5_MHZ)) != GPIB_SUCCESS)
		return m_nErrCode;

	sprintf_s(m_szCommand,"AVG_MODPWR? LOW10");

	if ((m_nErrCode = Query(m_szCommand, cLow_10_MHZ)) != GPIB_SUCCESS)
		return m_nErrCode;
	
	sprintf_s(m_szCommand,"AVG_MODPWR? UP5");

	if ((m_nErrCode = Query(m_szCommand, cUp_5_MHZ)) != GPIB_SUCCESS)
		return m_nErrCode;

	sprintf_s(m_szCommand,"AVG_MODPWR? UP10");

	if ((m_nErrCode = Query(m_szCommand, cUp_10_MHZ)) != GPIB_SUCCESS)
		return m_nErrCode;

	return m_nErrCode;
}

INT C8960::WB_GET_MEASUREMENT_EVM(CHAR *cEVM)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	m_nErrCode = Single_Measurement();
	
	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "MAX_EVM?");
		m_nErrCode = Query(m_szCommand, cEVM);
	}

	return m_nErrCode;
}

INT C8960::WB_Get_Measurement_PCDE(CHAR *cPCDE)
{
	INT index_MSTAT=0; 
	INT iMSTAT_Staus=1;
	INT iMSTAT_STATUS;

	do
	{
		iMSTAT_STATUS = SET_SYNCHRONOUS_SINGLE_SWEEP();
		Sleep(50);
		iMSTAT_STATUS = Get_Measurement_Status(&iMSTAT_Staus);
		index_MSTAT++;

	} while (iMSTAT_Staus !=0 && index_MSTAT < 5);
	sprintf_s(m_szCommand,"MAX_PCDERR?");

	m_nErrCode=Query(m_szCommand,cPCDE);

	return m_nErrCode;
}

INT C8960::WB_GET_MEASUREMENT_FREQUENCY_ERROR(CHAR *cFreqErr)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	m_nErrCode = Single_Measurement();
	
	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "AVG_CARRFERR?");
		m_nErrCode = Query(m_szCommand, cFreqErr);
	}

	return m_nErrCode;
}

INT C8960::WB_GET_MEASUREMENT_BER(CHAR *cPercent)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	m_nErrCode = Single_Measurement();
	
	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "BER? PER");
		m_nErrCode = Query(m_szCommand, cPercent);
	}
	else
	{
		sprintf_s(cPercent, "-999");
	}

	return m_nErrCode;
}


INT C8960::WB_SET_MEASUREMENT_INNER_LOOP_POWER(const char* csSegment, int Number_ofSlots,int TPC_Step, double Start_Power,double Stop_Power, int Algorithm)
{
	char cSegment[5];
	sprintf_s(cSegment,csSegment);

	// TPC Pattern ILPC
	sprintf_s(m_szCommand,"TPCPAT ILPC");
	m_nErrCode=Write(m_szCommand);

	// TPC Algorithm 2
	sprintf_s(m_szCommand,"TPCALGO 2");
	m_nErrCode=Write(m_szCommand);

	// TPC Step Size 1dB
	sprintf_s(m_szCommand,"TPCSTEP 1");
	m_nErrCode=Write(m_szCommand);

	// Time domain measurement screen
	sprintf_s(m_szCommand,"SCRSEL TDMEAS");
	m_nErrCode=Write(m_szCommand);

	// measuring object is set to inner loop power control
	sprintf_s(m_szCommand,"MEASOBJ ILPC");
	m_nErrCode=Write(m_szCommand);

	// Slot List ON
	sprintf_s(m_szCommand,"SLOTLIST ON");
	m_nErrCode=Write(m_szCommand);

	// Registering measurement slot INTo list
	sprintf_s(m_szCommand,"REGSLOTLIST 0-60");
	m_nErrCode=Write(m_szCommand);

	// Time span
	sprintf_s(m_szCommand,"TIMSPAN 50MS");
	m_nErrCode=Write(m_szCommand);

	// Trigger Delay of screen
	sprintf_s(m_szCommand,"TRGDELAY -5.0MS");
	m_nErrCode=Write(m_szCommand);

	// Slot list is active
	sprintf_s(m_szCommand,"SCRACT PWRLIST");
	m_nErrCode=Write(m_szCommand);

	// confirmation of operation completed
	sprintf_s(m_szCommand,"*OPC?");
	m_nErrCode=Write(m_szCommand);
	
	switch(*cSegment) {
	case 'A':
		/* Step A : -10dBm to -10dBm */
		sprintf_s(m_szCommand,"ILP_TPC A");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"TPCPAT ILPC");
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"ILVL %fDBM", Start_Power);
		m_nErrCode=Write(m_szCommand);

		break;

	case 'B':
		/* Step B : -10dBm to 0dBm */
		sprintf_s(m_szCommand,"ILP_TPC B");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"TPCPAT ALT");
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"ILVL %fDBM", Start_Power);
		m_nErrCode=Write(m_szCommand);
		
		break;
	case 'C':
		/* Step C : 0dBm to -10dBm */
		sprintf_s(m_szCommand,"ILP_TPC C");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"TPCPAT ALT");
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"ILVL %fDBM", Start_Power);
		m_nErrCode=Write(m_szCommand);
		
		break;
	case 'D':
		/* Step D : -10dBm to +23dBm */
		sprintf_s(m_szCommand,"TPCALGO 1");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILP_TPC D");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"TPCPAT ALT");
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"ILVL %fDBM", Start_Power);
		m_nErrCode=Write(m_szCommand);

		break;

	case 'E':
		/* Step E : +23dBm to -10dBm */
		/* Step E : -10dBm to -50dBm */
		sprintf_s(m_szCommand,"ILP_TPC E");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"TPCPAT ILPC");
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"ILVL %fDBM", Start_Power);
		m_nErrCode=Write(m_szCommand);

		
		break;
	case 'F':
		/* Step F : -50dBm to -10dBm */
		/* Step F : -10dBm to +23dBm */
		sprintf_s(m_szCommand,"ILP_TPC F");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILP_CMDSLOT F,%d",Number_ofSlots);
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"TPCPAT ILPC");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILVL %fDBM",Start_Power);
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"TPCPAT ALT");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILVL %fDBM",Start_Power);
		m_nErrCode=Write(m_szCommand);

		break;
	case 'G':
		sprintf_s(m_szCommand,"TPCSTEP 2");
		m_nErrCode=Write(m_szCommand);
		/* Step G : +23dBm to -15dBm */
		/* Step G : -10dBm to -50dBm */		
		sprintf_s(m_szCommand,"ILP_TPC G");
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"TPCPAT ILPC");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILVL %fDBM",Start_Power);
		m_nErrCode=Write(m_szCommand);

		break;
	case 'H':

		/* Step H : -50dBm to -10dBm */
		/* Step H : -10dBm to +23dBm */
		
		sprintf_s(m_szCommand,"ILP_TPC H");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILP_CMDSLOT H,%d",Number_ofSlots);
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"TPCPAT ILPC");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILVL %fDBM",Start_Power);
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"TPCPAT ALT");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"ILVL %fDBM",Start_Power);
		m_nErrCode=Write(m_szCommand);



		break;

		
	default:
		break;
	}
	
	
	return m_nErrCode;
}

INT C8960::WB_GET_MEASUREMENT_INNER_LOOP_POWER(CHAR *slot_list)
{

	CString csSlotTemp;
	ViStatus status;
	CHAR slot_temp[1024];

	sprintf_s(m_szCommand,"SLOT_PWR? ALL");
	//m_nErrCode=Query(m_szCommand,slot_list);
	m_nErrCode=Write(m_szCommand);
	status = viScanf(m_viSession,"%s",slot_temp);
	strcpy(slot_list,slot_temp);
	
	return m_nErrCode;
}

// INT C8960::Read( CHAR *cReturnValue, INT length)
// {
// 	
// 	if(m_viSession == -1)
// 		return GPIB_READ_FAIL;
// 
// 	ibrd(m_iCalDeviceID, cReturnValue, length);
// 
// 	if (ibsta & ERR)
// 	{
// 		CHAR cErrorMessage[400];
// 		sprintf_s(cErrorMessage,"Gpib read \"%s\" error %d ",cReturnValue,ibsta);
// 		return GPIB_READ_FAIL;
// 	}
// 	cReturnValue[ibcnt] = '\0';
// 
// 	return GPIB_SUCCESS;
// }

INT C8960::WB_Read(CHAR *rdBuf)
{
	ViStatus status;
	CHAR buf[1024] = {0};

	status = viScanf(m_viSession, "%s", buf);
	if (status == VI_SUCCESS)
	{
		m_nErrCode = GPIB_SUCCESS;
		strcpy(rdBuf, buf);
	}
	else
	{
		m_nErrCode = GPIB_READ_FAIL;
	}

	return m_nErrCode;
}

INT C8960::Set_DL_Cable_Loss(FLOAT fLoss, E_BAND iBand)
{
	if(fLoss < 0)
		fLoss *= (FLOAT)(-1);
	
	switch(iBand) {
	case Band_GSM:
	case Band_GSM850:
		sprintf_s(m_szCommand,"DLEXTLOSS BAND2,%1.3f;EXTLOSSW ON",fLoss);
		break;
	default:
		sprintf_s(m_szCommand,"DLEXTLOSS BAND3,%1.3f;EXTLOSSW ON",fLoss);
		break;
	}
	
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::Set_UL_Cable_Loss(FLOAT fLoss, E_BAND iBand)
{
	if(fLoss < 0)
		fLoss *= (FLOAT)(-1);

	switch(iBand) {
	case Band_GSM:
	case Band_GSM850:
		sprintf_s(m_szCommand,"ULEXTLOSS BAND2,%1.3f;EXTLOSSW ON",fLoss);
		break;
	default:
		sprintf_s(m_szCommand,"ULEXTLOSS BAND3,%1.3f;EXTLOSSW ON",fLoss);
		break;
	}
	
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::Set_BCH_DL_Freq(FLOAT fFreq)
{
	sprintf_s(m_szCommand,"CTRLDLFREQ %.6fMHZ",fFreq);
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::WB_Reset(VOID)
{
	
	m_nErrCode = Write("*CLS;*RST"); // send reset and clear command
	WB_Close_ALL_Measurement(); // close all measurement
	m_nErrCode = Write("LVL OFF;DLEXTLOSSW ON;ULEXTLOSSW ON"); //Disabled the cable loss
	m_nErrCode = Write("MEASOBJ OTHER" );//Set measurement object to others, not time domain
	m_nErrCode = Write("DCCHPAT ALL1");//Set DCCH data type to ALL_ZEROS.

	return m_nErrCode;

}

INT C8960::WB_Close_ALL_Measurement(VOID)
{

	m_nErrCode = Write("PWR_MEAS OFF;FREQ_MEAS OFF;MOD_MEAS OFF;OBW_MEAS OFF;SMASK_MEAS OFF;ADJ_MEAS OFF;PCDE_MEAS OFF;BER_MEAS OFF;BLER_MEAS OFF");

	return m_nErrCode;
}

INT C8960::WB_Set_Downlink_Power_Level(double dPower)
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	sprintf_s(m_szCommand,"OLVL %f",dPower);
			
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::WB_Set_Downlink_Power_Level_On_Off(INT iOnOff)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	
	if (iOnOff == 0)
	{	
		sprintf_s(m_szCommand,"LVL ON");
	}
	else if (iOnOff == 1)
	{
		sprintf_s(m_szCommand,"LVL OFF");
	}	

	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::WB_SET_DOWNLINK_SCRAMBLING_CODES( INT nPrimary, INT nDPCHSecondary )
{
	m_nErrCode = GPIB_SUCCESS;

	return m_nErrCode;
}

INT C8960::WB_Set_Uplink_Power_Level( double dLevel )
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	sprintf_s(m_szCommand,"ILVL %f",dLevel);
			
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
	
}

INT C8960::WB_Set_Uplink_Scrambling_Codes( INT nDPCH, INT nPRACHPreamble )
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	if ( nPRACHPreamble == -1)
	{
		sprintf_s(m_szCommand,"UDPCHSCRCODE %X",nDPCH);			
		m_nErrCode=Write(m_szCommand);
	}else
	{	
		sprintf_s(m_szCommand,"UDPCHSCRCODE %X;PRACHSCRCODE %d",nDPCH,nPRACHPreamble);			
		m_nErrCode=Write(m_szCommand);		
	}

	return m_nErrCode;
}

INT C8960::WB_Set_Expected_Power_Level( double dLevel )
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	sprintf_s(m_szCommand,"ILVL %f",dLevel);
			
	m_nErrCode=Write(m_szCommand);
	m_nErrCode=Send_OPC();

	return m_nErrCode;
	
}

INT C8960::WB_Release_Connection(VOID)
{
	END_CALL();
	return m_nErrCode;
}

INT C8960::WB_Setup_Connection(CHAR *eType)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	
	if(_stricmp(eType,"STANDARD")==0)
	{
		strcpy( m_szCommand, "TESTMODE OFF" );

	}else if (_stricmp(eType,"MODE1")==0)
	{
		strcpy( m_szCommand, "TESTMODE MODE1" );

	}else if (_stricmp(eType,"MODE2")==0)
	{
		strcpy( m_szCommand, "TESTMODE MODE2" );
	}
	
	m_nErrCode=Write(m_szCommand);
	MT_Call();

	return m_nErrCode;

}
INT C8960::WB_Set_Frequency_Marker( double dFrequency )
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	strcpy(m_szCommand,"ZMKR_SPM ON");	
	m_nErrCode=Write(m_szCommand);
	sprintf_s( m_szCommand, "ZMKRP_SPM %f", dFrequency );
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
	
}

INT C8960::WB_Set_Frequency_Marker_On_Off(INT iOnOff)
{
	m_nErrCode = GPIB_SUCCESS;
	
	memset(m_szCommand,0,sizeof(m_szCommand));
	
	if (iOnOff == 0)
	{	
		sprintf_s(m_szCommand,"ZMKR_SPM ON");
	}
	else if (iOnOff == 1)
	{
		sprintf_s(m_szCommand,"ZMKR_SPM OFF");
	}	

	m_nErrCode = Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::WB_SET_INSTRUMENT_MODE(CONST CHAR *in_psMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand,0,sizeof(m_szCommand));

	if(_stricmp(in_psMode,"TEST") == 0)
	{
		sprintf_s(m_szCommand, "CALL:OPER:MODE FDDT");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:CONT:DOWN:FREQ:AUTO OFF");
		m_nErrCode=Write(m_szCommand);  
	}
	else if(_stricmp(in_psMode,"CALL") == 0)
	{
		sprintf_s(m_szCommand, "CALL:OPER:MODE CALL");
		m_nErrCode=Write(m_szCommand);
	}
	
	return m_nErrCode;
}

INT C8960::WB_Set_Modulation_Measurement_Conditions(CONST CHAR *in_moMode )
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	if(_stricmp(in_moMode,"WCDMA")==0)
	{
		strcpy(m_szCommand, "MA_MEASOBJ WCDMA");
	}
	else if(_stricmp(in_moMode,"QPSK")==0)
	{
		strcpy(m_szCommand, "MA_MEASOBJ QPSK"); 
	}	
	m_nErrCode=Write(m_szCommand);
	
	return m_nErrCode;

}

INT C8960::WB_Set_Generator_Frequency(double dFrequency)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "RFREQ %f", dFrequency);
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		Send_OPC();
	}

	return m_nErrCode;
}

INT C8960::WB_SET_PHYSICAL_CHANNEL( E_PHYSICAL_CHANNEL eChannel, double dLevel, E_PHYSICAL_CHANNEL eState )
{
	INT nChannelState = -1;
	CHAR szString[ 100 ] = "";
	memset(szString,0,sizeof(szString));

	switch (eState) //Turn channel on or off depending on state flag
	{
		case imON:
			nChannelState = 1;
			break;

		case imOFF:
			nChannelState = 0;
			break;

		case imNONE:
			nChannelState = -1;
			break;

		default:
			return m_nErrCode=E_FUNC_PARAMETER;
	}
	
	switch (eChannel)
	{
		case imCPICH:
			if (nChannelState == -1) 
				sprintf_s( szString, "CPICHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "CPICHPWR %fDB;CPICH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "CPICHPWR %fDB;CPICH OFF", dLevel );

			m_nErrCode=Write(szString);
			return m_nErrCode;

			break;

		case imSCH:
			if (nChannelState == -1) 
				sprintf_s( szString, "SCHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "SCHPWR %fDB;SCH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "SCHPWR %fDB;SCH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;

			break;

		case imP_CCPCH:
			if (nChannelState == -1) 
				sprintf_s( szString, "PCCPCHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "PCCPCHPWR %fDB;PCCPCH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "PCCPCHPWR %fDB;PCCPCH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;

			break;

		case imS_CCPCH:
			if (nChannelState == -1) 
				sprintf_s( szString, "SCCPCHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "SCCPCHPWR %fDB;SCCPCH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "SCCPCHPWR %fDB;SCCPCH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;
			
			break;

		case imPICH:
			if (nChannelState == -1) 
				sprintf_s( szString, "PICHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "PICHPWR %fDB;PICH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "PICHPWR %fDB;PICH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;
			
			break;

		case imAICH:
			if (nChannelState == -1) 
				sprintf_s( szString, "AICHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "AICHPWR %fDB;AICH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "AICHPWR %fDB;AICH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;

			break;

		case imD_DPCH:
			if (nChannelState == -1) 
				sprintf_s( szString, "DDPCHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "DDPCHPWR %fDB;DDPCH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "DDPCHPWR %fDB;DDPCH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;

			break;

		case imD_DPCCH:
			if (nChannelState == -1) 
				sprintf_s( szString, "DDPCCHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "DDPCCHPWR %fDB;DDPCCH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "DDPCCHPWR %fDB;DDPCCH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;

			break;

		case imD_DPDCH:
			if (nChannelState == -1) 
				sprintf_s( szString, "DDPDCHPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "DDPDCHPWR %fDB;DDPDCH ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "DDPDCHPWR %fDB;DDPDCH OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;

			break;

		case imAWGN:
			if (nChannelState == -1) 
				sprintf_s( szString, "AWGNPWR %fDB", dLevel );
			if (nChannelState == 1)
				sprintf_s( szString, "AWGNPWR %fDB;AWGNLVL ON", dLevel );
			if (nChannelState == 0)
				sprintf_s( szString, "AWGNPWR %fDB;AWGNLVL OFF", dLevel );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;
			
			break;
		
		default:
			return m_nErrCode=E_FUNC_PARAMETER;
	}
}

INT C8960::WB_Set_Physical_Channel_with_Symbol_Rate( E_PHYSICAL_CHANNEL eChannel, INT nChannelisationCode, INT nSymbolRate, INT nTimingOffset )
{

	CHAR szString[100] = {0};
	INT m_nErrCode=E_FUNC_PARAMETER;

	switch (eChannel)
	{
		case imS_CCPCH:
			if ( nSymbolRate == -1 && nTimingOffset == -1 )
				sprintf_s( szString, "SCCPCHCODE %d", nChannelisationCode );
			if ( nSymbolRate > -1 && nTimingOffset == -1 )
				sprintf_s( szString, "SCCPCHCODE %d;SCCPCHRATE %d", nChannelisationCode, nSymbolRate );
			if ( nTimingOffset > -1 && nSymbolRate == -1 )
				sprintf_s( szString, "SCCPCHCODE %d;SCCPCHTOFS %d", nChannelisationCode, nTimingOffset );
			if ( nSymbolRate > -1 && nTimingOffset > -1 )
				sprintf_s( szString, "SCCPCHCODE %d;SCCPCHRATE %d;SCCPCHTOFS %d", nChannelisationCode, nSymbolRate, nTimingOffset );

			m_nErrCode=Write(szString);
			return m_nErrCode;
			
			break;

		case imPICH:
			//	Check if nSymbolRate or nTimingOffset is set then return Error
			if (nSymbolRate != -1 || nTimingOffset != -1)
				return m_nErrCode; //PICH parameter error in method SetPhysicalChannel.

			sprintf_s( szString, "PICHCODE %d", nChannelisationCode );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;
			
			break;

		case imAICH:
			//	Check if nSymbolRate or nTimingOffset is set then return Error
			if (nSymbolRate != -1 || nTimingOffset != -1)
				return m_nErrCode; //AICH parameter error in method SetPhysicalChannel.

			sprintf_s( szString, "AICHCODE %d", nChannelisationCode );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;
			
			break;

		case imD_DPCH:
			sprintf_s( szString, "DDPCHCODE %d;DDPCHSACODE %d", nChannelisationCode, nChannelisationCode );
			
			m_nErrCode=Write(szString);
			return m_nErrCode;
			
			if (nSymbolRate != -1)
			{
				switch (nSymbolRate)
				{
				case imRMC_12_2_KBPS:
					m_nErrCode = Write("CHCODING REFMEASCH");
					return m_nErrCode;
					m_nErrCode = Write("MAXRATE 12.2");
					return m_nErrCode;
					break;

				case imRMC_64_KBPS:
					m_nErrCode = Write("CHCODING REFMEASCH");
					return m_nErrCode;
					m_nErrCode = Write( "MAXRATE 64");
					return m_nErrCode;
					break;
				
				case imRMC_144_KBPS:
					m_nErrCode = Write("CHCODING REFMEASCH");
					return m_nErrCode;
					m_nErrCode = Write( "MAXRATE 144");
					return m_nErrCode;
					break;

				case imRMC_384_KBPS:
					m_nErrCode = Write("CHCODING REFMEASCH");
					return m_nErrCode;
					m_nErrCode = Write( "MAXRATE 384");
					return m_nErrCode;
					break;

				case imVOICE_CHANNEL:
					m_nErrCode = Write("CHCODING VOICE");
					return m_nErrCode;
					break;

				default:
					return m_nErrCode;
				}
			}

			if (nTimingOffset > -1)
			{
				sprintf_s( szString, "DDPCHTOFS %d", nTimingOffset );
				m_nErrCode = Write(szString);
				return m_nErrCode;
			}
			break;

		case imPRACH:
			//	Check if nChannelisationCode or nTimingOffset is set then return Error
			if (nChannelisationCode != -1 || nTimingOffset != -1)
				return m_nErrCode;

			if (nSymbolRate > -1)
			{
				sprintf_s( szString, "PRACHRATE %d", nSymbolRate );
				m_nErrCode = Write(szString);
				return m_nErrCode;
			}
			break;

		case imU_DPCH:
			//	Check if nChannelisationCode or nTimingOffset is set then return Error
			if (nChannelisationCode != -1 || nTimingOffset != -1)
				return m_nErrCode;

			if (nSymbolRate > -1)
			{
				sprintf_s( szString, "UDPCHRATE %d", nSymbolRate );
				m_nErrCode = Write(szString);
				return m_nErrCode; // server error has occured in method SetPhysicalChannel
			}
			break;

		default:
			return m_nErrCode=E_FUNC_PARAMETER;
			
	}

	return m_nErrCode;
}

INT C8960::WB_Set_Receiver_Measurement_Conditions(UINT nNumberOfBits)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "BER_SAMPLE %d;BLER_SAMPLE %d", nNumberOfBits, (INT)(ceil(nNumberOfBits / 244.0)));
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::WB_Set_Sequential_Output( INT nRatioPerStep, INT nNumberOfSteps, E_PHYSICAL_CHANNEL eState )
{
	INT nChannelState = -1;
	CHAR szString[ 100 ] = "";
	INT m_nErrCode=E_FUNC_PARAMETER;
	
	switch (eState) //Turn Sequential Output on or off depending on state flag
	{
		case imON:
			nChannelState = 1;
			break;

		case imOFF:
			nChannelState = 0;
			break;

		case imNONE:
			nChannelState = -1;
			break;

		default:
			return m_nErrCode;
	}
	
	//	Set ratio per step and number of steps
	sprintf_s( szString, "SEQOUTSTEP %d;SEQOUTLENG %d", nRatioPerStep, nNumberOfSteps );
	m_nErrCode = Write(szString);
	return m_nErrCode;
	
	//	Turn Sequential Output on
	if (nChannelState == 1)
	{
		sprintf_s( szString, "SEQOUTSW ON" );
		m_nErrCode = Write(szString);
		return m_nErrCode;
	}

	//	Turn Sequential Output off
	if (nChannelState == 0)
	{
		sprintf_s( szString, "SEQOUTSW OFF" );
		m_nErrCode = Write(szString);
		return m_nErrCode;
	}
}

INT C8960::WB_Set_Spectrum_Center_Frequency(double dFrequency )
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	sprintf_s( m_szCommand, "TFREQ %f", dFrequency );
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;

}

INT C8960::WB_SET_DATA_PATTERN(CHAR *eDTCHPattern)
{
	m_nErrCode = GPIB_SUCCESS;
	
	sprintf_s(m_szCommand, "DTCHPAT %s", eDTCHPattern);
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::WB_SET_TRANSMISSION_POWER_CONTROL(CHAR *cPattern, INT nStepSize, INT nAlgorithm )
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));
	
	//setting power control bit pattern
	sprintf_s(m_szCommand, "TPCPAT %s", cPattern);
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		Sleep(100);
		
		//setting TPC step size
		sprintf_s(m_szCommand, "TPCSTEP %d", nStepSize);
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		//setting Inner Loop Power Control algorithm
		sprintf_s(m_szCommand,"TPCALGO %d",nAlgorithm);
		m_nErrCode=Write(m_szCommand);
	}
		
	return m_nErrCode;
}

INT C8960::WB_Set_Beta_Factors( INT nBetaC, INT nBetaD )
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	//setting Beta C for Uplink DPCCH
	sprintf_s(m_szCommand,"UDPCCHBETAC %d",nBetaC);
	m_nErrCode=Write(m_szCommand);

	//setting Beta D for Uplink DPCCH
	sprintf_s(m_szCommand,"UDPDCHBETAD %d",nBetaD);
	m_nErrCode=Write(m_szCommand);
		
	return m_nErrCode;

}

INT C8960::WB_Set_Spectrum_Measurement_Conditions(double dSpan, double dResolutionBandwidth,CHAR *cDetectorMode)
{
	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand,0,sizeof(m_szCommand));

	if ((dSpan < 0) || (dSpan > 25000000))
	{
		m_nErrCode = E_FUNC_PARAMETER;
		return m_nErrCode;
	}

	if ((dResolutionBandwidth < 0) || (dResolutionBandwidth > 300000))
	{
		m_nErrCode = E_FUNC_PARAMETER;
		return m_nErrCode;
	}
	
	sprintf_s(m_szCommand,"SCRSEL SPMON"); 
	m_nErrCode=Write(m_szCommand);
	if (m_nErrCode != GPIB_SUCCESS)
	{
		return m_nErrCode;
	}

	//Setting the frequency span for Spectrum Monitor
	if ((dSpan >=0) && (dSpan <= 25000000))
	{
		if (dSpan <= 5000000)
		{
			m_nErrCode = Write("SPMSPAN 5");

		}
		else if ((dSpan > 5000000) && (dSpan <= 25000000))
		{
			m_nErrCode=Write("SPMSPAN 25");
		}
	}
	
	if (m_nErrCode != GPIB_SUCCESS)
	{
		return m_nErrCode;
	}

	//Setting Frequency Span of Spectrum Monitor RBW
	if ((dResolutionBandwidth > 0) && (dResolutionBandwidth <= 30000))
	{
		m_nErrCode = Write("SPMRBW 30KHZ");
	}
	else if ((dResolutionBandwidth > 30000) && (dResolutionBandwidth <= 100000))
	{
		m_nErrCode = Write("SPMRBW 100KHZ");
	}
	else if ((dResolutionBandwidth > 100000) && (dResolutionBandwidth <= 300000))
	{
		m_nErrCode = Write("SPMRBW 300KHZ");
	}

	if (m_nErrCode != GPIB_SUCCESS)
	{
		return m_nErrCode;
	}
	
	//Setting the detection mode for Spectrum Monitor
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"SPMDETECT %s", cDetectorMode); //default:PEAR / RMS
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::WB_Set_Spectrum_Emission_Mask_Limits( double *rgdLimitsArray, INT nArrayLength, E_PHYSICAL_CHANNEL eAdditionalBandIILimit )
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	INT m_nErrCode=E_FUNC_PARAMETER;

	//Selecting screen to fundamental Measurement screen and opening the template
	m_nErrCode=Write("SCRSEL FMEAS;TEMPOPN SMASK"); 

	for( INT i = 0; i < 5 ; i++ )
	{
		sprintf_s( m_szCommand, "TEMPLVL_SMASK %d,%lf", i + 1, rgdLimitsArray[i] );
		m_nErrCode=Write(m_szCommand);
		return m_nErrCode;
	}
	if ( nArrayLength >= 6 )
	{
		sprintf_s( m_szCommand, "LMTLVL_SMASK %lf", rgdLimitsArray[5] );
		m_nErrCode=Write(m_szCommand);
		return m_nErrCode;
	}

	//Closing the template
	m_nErrCode=Write("TEMPCLS SMASK" ); 

	switch ( eAdditionalBandIILimit )
	{
		case imON:
			strcpy(m_szCommand,"SMASK_ADDLIMIT WCDMA1900");
			break;

		case imOFF:
			strcpy(m_szCommand,"SMASK_ADDLIMIT NON");
			break;

		default:
			return m_nErrCode;
	}

	m_nErrCode=Write(m_szCommand);
	return m_nErrCode;
}

INT C8960::WB_SET_TRIGGER(CHAR *cMode, double dDelay)
{
	m_nErrCode = GPIB_SUCCESS;

	//SetTrigger only works in measurement object "OTHER". For InnerLoopPower and SlotModulation TPC trigger is always used.
	memset(m_szCommand,0,sizeof(m_szCommand));
	m_nErrCode=Write("MEASOBJ OTHER");

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"TRGSRC %s",cMode); //cMode: EXT,FREE,INT,FREE,RISEVIDEO,FALLVIDEO
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"TRGDELAY %f", dDelay*1000);  //Setting the trigger delay in ms
		m_nErrCode=Write(m_szCommand);
	}
	
	return m_nErrCode;
}

INT C8960::WB_SET_CHANNEL(INT nDownlink, INT nUplink)
{
	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0, sizeof(m_szCommand));
	sprintf_s(m_szCommand,"ULCHAN %d", nUplink);
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		Send_OPC();
	}

	return m_nErrCode;
}

INT C8960::WB_GET_MEASURED_IQ_ERROR(double *pdOffset, double *pdImbalance)
{
	m_nErrCode = GPIB_SUCCESS;
	
	INT nINTegrity = 0;
	CHAR szResult[100] = {0};

	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "AVG_ORGNOFS?");
	m_nErrCode = Query(m_szCommand, szResult);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		*pdOffset = atof(szResult);
	}
	
	if (*pdOffset == 999999.0)
	{
		return m_nErrCode = E_DEVICE_DATA_READ_ERROR;
	}

	memset(szResult, 0, sizeof(szResult));
	sprintf_s(m_szCommand, "AVG_IQIMB?");
	m_nErrCode = Query(m_szCommand, szResult);
	if (m_nErrCode == GPIB_SUCCESS)
	{
		*pdImbalance = atof(szResult);
	}

	if (*pdImbalance == 999999.0)
	{
		return m_nErrCode = E_DEVICE_DATA_READ_ERROR;
	}
	else
	{
		//Definition: IQImbalance = (|I-Q|/|I+Q|) * 100 [%]
		//Returned from instrument:(I/Q)*100 [%].
		//Transformation:
		//IQ =: IQImbalance value returned from the instrument
		// |I - Q| / |I + Q| * 100 [%] = |I / Q * 100 - 100| / |I / Q * 100 + 100| * 100 [%] = fabs(IQ - 100) / (IQ + 100) * 100 [%]
		*pdImbalance = ((fabs(*pdImbalance - 100) / (*pdImbalance + 100)) * 100);
	}

	return m_nErrCode;
}

INT C8960::Convert_Integrity_To_Enum(INT nIntegrityCode, E_INTEGRITY_CODE *peIntegrityCode)
{
	CHAR szString[100] = {0};

	// Set default for INTegrity value
	*peIntegrityCode = imNO_INTEGRITY;

	if (nIntegrityCode == 0)
		*peIntegrityCode = imOK;

	if (nIntegrityCode == 1)
		*peIntegrityCode = imGENERAL_ERROR;

	if (nIntegrityCode == 2)
		*peIntegrityCode = imOVER_RANGE_ERROR;

	if (nIntegrityCode == 3)
		*peIntegrityCode = imUNDER_RANGE_ERROR;

	if (nIntegrityCode == 4)
		*peIntegrityCode = imGENERAL_ERROR;

	if (nIntegrityCode == 5)
		*peIntegrityCode = imUNABLE_TO_INTERPRET_SIGNAL_ERROR;

	if (nIntegrityCode >= 6)
		*peIntegrityCode = imGENERAL_ERROR;

	if ( nIntegrityCode != 0 )
	{
		//ESR register must be cleared???
		/*
		sprintf_s( m_szCommand, "ESR3?" );
		m_nErrCode = Query(m_szCommand,szResult);
		return m_nErrCode;
		*/
	}
	return 0;
}
INT C8960::WB_SET_TRIGGER_START_AND_DURATION(double SLOT_START_TIME, double SLOT_DURATION_TIME)
{
	
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"PWRCALSTTM %d",SLOT_START_TIME); //range:0us-200us
	m_nErrCode=Write(m_szCommand);
	return m_nErrCode;

	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"PWRCALDURAT %f",SLOT_DURATION_TIME);  //range:0.1us-666.7us
	m_nErrCode=Write(m_szCommand);
	return m_nErrCode;

}

INT C8960::WB_SET_SLOT_POWER_MEASUREMENT(double dTimeSpan, INT nStartSlotList, INT nEndSlotList, double dThreshold_Level)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SCRSEL TDMEAS");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "TIMSPAN %.2fMS", dTimeSpan);
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s (m_szCommand, "SLOTLIST ON");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s (m_szCommand, "DELSLOTLIST -15-164");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s (m_szCommand, "REGSLOTLIST %d-%d", nStartSlotList, nEndSlotList);
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"TDM_RRC OFF");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"VFILTLEN 0.1US");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Send_OPC();
	
	return m_nErrCode;

}
/*******************************************************************************
//Name : WB_GetSlotPower()
//Author : Zona Tzou
//Date : 2007/03/020
//Description : Get Slot Power
//Modify : 
*******************************************************************************/

INT C8960::WB_GET_SLOT_POWER(double *pdPowerArray, INT nNumberOfSlots)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));
	
	CHAR	slot_temp[1024] = {0};
	INT		i = 0;
	CHAR	seps[] = " ,";
	CHAR*	token = NULL;

	m_nErrCode = Single_Measurement();
	
	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "SLOT_PWR? ALL");
		m_nErrCode = Query(m_szCommand, slot_temp);
	}

	if (m_nErrCode != GPIB_SUCCESS)
	{
		return m_nErrCode;
	}

	i = 0;
	token = strtok(slot_temp, seps);
	while((token != NULL) && (i < nNumberOfSlots))
	{
		pdPowerArray[i] = atof(token);
		i++;
		token = strtok(NULL, seps);
	}

	return m_nErrCode;
}

/*******************************************************************************
//Name : SetCellPowerStateOn()
//Author : Tomy Chen
//Date : 2007/03/06
//Description : Turn On output cell power
//Modify : 
*******************************************************************************/
INT C8960::SET_CELL_POWER_STATE_ON(VOID)
{
	return Write("CALL:POW:STAT ON");
}

/*******************************************************************************
//Name : SetCellPowerStateOff()
//Author : Tomy Chen
//Date : 2007/03/06
//Description : Turn On output cell power
//Modify : 
*******************************************************************************/
INT C8960::SET_CELL_POWER_STATE_OFF(VOID)
{
	return Write("CALL:POW:STAT OFF");
}

/*************************************************************************************
//Name			: EG_SetInstrumentMode
//Auhtor		: Tomy Chen
//Date			: 2007/03/06
//Description	: Set 8960 GSM/EDGE operate mode
//Parameter		: iOperateMode
//0:Signaling, 1:Non-Signaling-GMSK, 2:Non-Signaling-8PSK, 3:CW
*************************************************************************************/
INT C8960::EG_SET_INSTRUMENT_MODE(INT iOperateMode)
{
	m_nErrCode = GPIB_SUCCESS;
	
	//Turn off cell power first
	m_nErrCode = SET_CELL_POWER_STATE_OFF();

	if (m_nErrCode == GPIB_SUCCESS)
	{
		switch(iOperateMode)
		{
		case 0:		//Signaling
			//Turn off cell
			sprintf_s(m_szCommand, "CALL:OPER:MODE OFF");
			m_nErrCode = Write(m_szCommand);

			//set BCC Code
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:CELL:BCCODE 5");
				m_nErrCode = Write(m_szCommand);
			}

			//set NCC code
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:CELL:NCCODE 1");
				m_nErrCode = Write(m_szCommand);
			}

			//Turn on Cell
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:OPER:MODE CALL");
				m_nErrCode = Write(m_szCommand);
			}			

			//Turn expected power level to Auto
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "RFAN:CONT:POW:AUTO ON");
				m_nErrCode = Write(m_szCommand);
			}

			//Send *OPC?
			if (m_nErrCode == GPIB_SUCCESS)
			{
				m_nErrCode = SendOPC();
			}
			break;

		case 1:		//Non-Signaling-GMSK
			//Set mode to GBTT
			sprintf_s(m_szCommand, "CALL:OPER:MODE GBTT");
			m_nErrCode = Write(m_szCommand);

			//Turn expected power level to manual
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "RFAN:CONT:POW:AUTO OFF");
				m_nErrCode = Write(m_szCommand);
			}

			//Set Measurement Frequncy control to manual
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "RFAN:CONT:MEAS:FREQ:AUTO OFF");
				m_nErrCode = Write(m_szCommand);
			}

			//Send *OPC?
			if (m_nErrCode == GPIB_SUCCESS)
			{
				m_nErrCode = SendOPC();
			}
			break;

		case 2:		//Non-Signaling-8PSK
			sprintf_s(m_szCommand, "CALL:OPER:MODE OFF");
			m_nErrCode = Write(m_szCommand);

			//set BCC Code
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:CELL:BCCODE 0");
				m_nErrCode = Write(m_szCommand);
			}

			//Set mode to EBPT
			sprintf_s(m_szCommand, "CALL:OPER:MODE EBPT");
			m_nErrCode = Write(m_szCommand);

			//Set Modulation format control to Manual
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:MOD:CONT:AUTO OFF");
				m_nErrCode = Write(m_szCommand);
			}

			//Sets/queries the modulation format manually for the burst you specify in the multislot configuration.
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:MOD:MAN:BURS1 EPSK");
				m_nErrCode = Write(m_szCommand);
			}

			//Turn expected power level to manual
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "RFAN:CONT:POW:AUTO ON");
				m_nErrCode = Write(m_szCommand);
			}

			//Set Measurement Frequency control to manual
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "RFAN:CONT:MEAS:FREQ:AUTO ON");
				m_nErrCode = Write(m_szCommand);
			}

			//set multi slot configuration
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:PDTCH:MSLot:CONFig D1U1");
				m_nErrCode = Write(m_szCommand);
			}

			//set 1st slot to loop
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:PDTCH:MSLot:DOWNlink:LOOPback 1");
				m_nErrCode = Write(m_szCommand);
			}

			//set coding scheme
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:PDTCH:MCSCheme:EBPTest MCS5P1");
				m_nErrCode = Write(m_szCommand);
			}

			//Send *OPC?
			if (m_nErrCode == GPIB_SUCCESS)
			{
				m_nErrCode = SendOPC();
			}
			break;

		case 3:		//CW			
			//Set mode to gsm
			sprintf_s(m_szCommand, "CALL:OPER:MODE CW");
			m_nErrCode = Write(m_szCommand);

			//Send *OPC?
			if (m_nErrCode == GPIB_SUCCESS)
			{
				m_nErrCode = SendOPC();
			}

			m_bCwMode = TRUE;
			break;

		case 4:		//For Fast Call reduced signalling
			//Turn off cell
			sprintf_s(m_szCommand, "CALL:OPER:MODE OFF");
			m_nErrCode = Write(m_szCommand);

			//set BCC Code
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:CELL:BCCODE 0");
				m_nErrCode = Write(m_szCommand);
			}

			//set NCC code
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:CELL:NCCODE 0");
				m_nErrCode = Write(m_szCommand);
			}

			//Turn on Cell
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:OPER:MODE GBTT");
				m_nErrCode = Write(m_szCommand);
			}			

			//Channel Mode Setup
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:TCH:CMODe FRSPeech");
				m_nErrCode = Write(m_szCommand);
			}

			//Turn expected power level to Auto
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "RFAN:CONT:POW:AUTO ON");
				m_nErrCode = Write(m_szCommand);
			}

			//Turn expected power level to Auto
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "RFAN:CONT:MEAS:FREQ:AUTO ON");
				m_nErrCode = Write(m_szCommand);
			}

			//Set Mobile Loopback
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:TCH:LOOPback C");
				m_nErrCode = Write(m_szCommand);
			}

			//Send *OPC?
			if (m_nErrCode == GPIB_SUCCESS)
			{
				m_nErrCode = SendOPC();
			}
			break;
		}
	}

	//Turn on Signal when CW Mode or Signaling Mode
	if((m_nErrCode == GPIB_SUCCESS) && ((iOperateMode == 0) || (iOperateMode == 3) || (iOperateMode == 4) || (iOperateMode == 2)))
	{
		m_nErrCode = SET_CELL_POWER_STATE_ON();
		if (m_nErrCode == GPIB_SUCCESS)
		{
			m_nErrCode = Send_OPC();
		}
	}

	return m_nErrCode;
}

//Query if operation complete.
INT C8960::Send_OPC()
{
	CHAR	sResult[50] = {0};
	INT		i_Count = 0;
	INT		iResult = 0;

	for (i_Count = 0; i_Count < 20; i_Count++)
	{
		m_nErrCode = Query("*OPC?", sResult);
		if (m_nErrCode == GPIB_SUCCESS)
		{
			iResult = atoi(sResult);
			if (iResult == 1)
				break;
			else
			{
				Sleep(50);
				continue;
			}
		}
		else
			Sleep(10);
	}
	if(iResult != 1)
	{
		m_nErrCode = E_DEVICE_DATA_READ_ERROR;
	}	

	return m_nErrCode;
}

/*************************************************************************************
//Name			: EG_SetIQVectorMeasCondition
//Auhtor		: Tomy Chen
//Date			: 2007/03/06
//Description	: Set RF Test Set IQ Vector Measurement Condition for EMP U360 Power Calibration & Pre-Distortion.
*************************************************************************************/
INT C8960::EG_Set_IQ_Vector_Meas_Condition(double dTriggerDelay, double dMeasTime, INT *piNoOfIQMeas, double *pdSamplingFreq)
{
	m_nErrCode = GPIB_SUCCESS;

	m_dTriggerDelay = dTriggerDelay;

	// PoINTer set to the fixed sampling frequency
	*pdSamplingFreq = AGLIENT_IQVECTOR_SAMPLING_FREQUENCY;

	*piNoOfIQMeas = (INT) (*pdSamplingFreq * dMeasTime);

	//Check if the IQ Measurement count can be handled by 8960
	if (*piNoOfIQMeas > AGLIENT_MAX_IQVECTOR_ARRAY_LEN)
	{	
		m_nErrCode = E_DEVICE_IQMEAS_COUNT_FAIL;
	}

	m_nNumberOfIQMeasurements = *piNoOfIQMeas;

	return m_nErrCode;
}

/*************************************************************************************
//Name			: EG_SetTriggerSource
//Auhtor		: Tomy Chen
//Date			: 2007/03/06
//Description	: Set RF Test Set Trigger Source
*************************************************************************************/
INT C8960::EG_Set_Trigger_Source(INT iOperateMode, INT iModulationType, double dExpectLevel)
{
	m_nErrCode = GPIB_SUCCESS;

	m_dTriggerLevel = dExpectLevel;

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "MEASTRG TS");
		m_nErrCode = Write(m_szCommand);
	}
	
	return m_nErrCode;
}

/*************************************************************************************
//Name			: EG_InitPCAL()
//Auhtor		: Tomy Chen
//Date			: 2007/03/19
//Description	: Init Pollar Calibration
//Modify		: Tomy Chen
//Date			: 2007/12/28
//Description	: Add *CLS before Init PCAL and check Trigger is ready after Init PCAL.
*************************************************************************************/
INT C8960::EG_Init_PCAL(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	CHAR		cReceiveBuff[10] = {0};
	INT			iPCALIsReady = 0, iCheckLoopCount = 0;

	memset(m_szCommand, 0, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "*CLS");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "SNGLSPREDISTE %.1f,%d", m_dTriggerLevel, (INT)(m_dTriggerDelay * AGLIENT_IQVECTOR_SAMPLING_FREQUENCY));
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "PREDISTE_READY?");
		do
		{
			iCheckLoopCount += 1;
			memset(cReceiveBuff, 0, sizeof(cReceiveBuff));
			Sleep(100);
			m_nErrCode = Query(m_szCommand, cReceiveBuff);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				iPCALIsReady = atoi(cReceiveBuff);
			}
			else
			{
				m_nErrCode = GPIB_SUCCESS;
				continue;
			}
		}while((iPCALIsReady != 1) && (iCheckLoopCount <= 10));
	}

	if (iPCALIsReady != 1)
		m_nErrCode = E_DEVICE_SETTING_ERROR;
	else
		m_nErrCode = GPIB_SUCCESS;

	//sprintf_s(m_szCommand, "SWPPREDISTE %.1f,%d", m_dTriggerLevel, (INT) (m_dTriggerDelay * AGLIENT_IQVECTOR_SAMPLING_FREQUENCY));
	//m_nErrCode = Write(m_szCommand);
	
	return m_nErrCode;
}

/*************************************************************************************
//Name			: EG_SetEndPCAL()
//Auhtor		: Tomy Chen
//Date			: 2007/03/19
//Description	: End Pollar Calibration
*************************************************************************************/
INT C8960::EG_Set_End_PCAL(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	
	return m_nErrCode;
}

/*************************************************************************************
//Name			: EG_FetchPCALINTegrity(CHAR *out_psResult)
//Auhtor		: Tomy Chen
//Date			: 2007/03/20
//Description	: Fetch PCAL measurement INTegrity.
*************************************************************************************/
INT C8960::EG_Fetch_PCAL_Integrity(CHAR *out_psResult)
{
	m_nErrCode = GPIB_SUCCESS;
	INT			iStateCode = 0, iCheckLoopCount = 0;
	CHAR		cStateCode[10] = {0};

	sprintf_s(m_szCommand, "PREDISTE_STAT?");
	do
	{
		iCheckLoopCount += 1;
		memset(cStateCode, 0, sizeof(cStateCode));
		Sleep(100);
		m_nErrCode = Query(m_szCommand, cStateCode);
		if (m_nErrCode == GPIB_SUCCESS)
		{
			iStateCode = atoi(cStateCode);
		}
		else
		{
			m_nErrCode = GPIB_SUCCESS;
			continue;
		}
	}while((iStateCode != 0) && (iCheckLoopCount <= 10));

	if (iStateCode != 0)
		m_nErrCode = E_DEVICE_SETTING_ERROR;
	else
		m_nErrCode = GPIB_SUCCESS;

	strcpy(out_psResult, cStateCode);

	return m_nErrCode;
}

/*************************************************************************************
//Name			: EG_FetchPCAL(CHAR *out_psResult)
//Auhtor		: Tomy Chen
//Date			: 2007/03/20
//Description	: Fetch PCAL measurement result.
*************************************************************************************/
INT C8960::EG_Fetch_PCAL(CHAR *out_psResult)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "PREDISTE_BIN? 0,%d", m_nNumberOfIQMeasurements);
	m_nErrCode = Query(m_szCommand, out_psResult);

	return m_nErrCode;
}
/*************************************************************************************
//Name			: WB_Get_FilterMeasurementPower(CHAR *cAvgPower)
//Auhtor		: Zona Tzou
//Date			: 2007/03/28
//Description	: Querying average value of Filtered Power
//Modified		: Tomy Chen
//Date			: 2007/11/08
//Description	: Using Single_Measurement function instead of SET_SYNCHRONOUS_SINGLE_SWEEP.
*************************************************************************************/
INT C8960::WB_GET_FILTER_MEASUREMENT_POWER(CHAR *cAvgPower)
{
	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0, sizeof(m_szCommand));

	m_nErrCode = Single_Measurement();

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"AVG_FILTPWR?");

		m_nErrCode = Query(m_szCommand, cAvgPower);
	}

	return m_nErrCode;
}

/*************************************************************************************
//Name			: WB_Set_Measurement_SEM()
//Auhtor		: Zona Tzou
//Date			: 2007/04/01
//Description	: Turn On Spectrum Emission Mask Measurement
*************************************************************************************/
INT C8960::WB_Set_Measurement_SEM(VOID)
{
	sprintf_s(m_szCommand,"SMASK_MEAS ON");

	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

/*************************************************************************************
//Name			: WB_SetChannelPowerMeasurementConditions()
//Auhtor		: Zona Tzou
//Date			: 2007/04/02
//Description	: Set Channel Power Measurement Conditions
*************************************************************************************/
INT C8960::WB_Set_Channel_Power_Measurement_Conditions(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	
	sprintf_s(m_szCommand,"OBW_DET AVG;SMASK_DET AVG");
	m_nErrCode=Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"PWR_MEAS ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"ADJ_MEAS ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SMASK_MEAS OFF");
		m_nErrCode=Write(m_szCommand);
	}

	return m_nErrCode;
}

/*************************************************************************************
//Name			: WB_SetModulationAccuracyConditionsON()
//Auhtor		: Zona Tzou
//Date			: 2007/04/03
//Description	: Set Modulation Accuracy Measurement Conditions ON
*************************************************************************************/
INT C8960::WB_Set_Modulation_Accuracy_Conditions_ON(VOID)
{

	sprintf_s(m_szCommand,"FASTPWRMODE OFF");
	m_nErrCode=Write(m_szCommand);
	sprintf_s(m_szCommand,"PWR_MEAS OFF");
	m_nErrCode=Write(m_szCommand);
	sprintf_s(m_szCommand,"FREQ_MEAS ON");
	m_nErrCode=Write(m_szCommand);
	sprintf_s(m_szCommand,"MOD_MEAS ON");
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

/*************************************************************************************
//Name			: WB_SetModulationAccuracyConditionsOFF()
//Auhtor		: Zona Tzou
//Date			: 2007/04/03
//Description	: Set Modulation Accuracy Measurement Conditions OFF
*************************************************************************************/
INT C8960::WB_Set_Modulation_Accuracy_Conditions_OFF(VOID)
{

	sprintf_s(m_szCommand,"FASTPWRMODE OFF");
	m_nErrCode=Write(m_szCommand);
	sprintf_s(m_szCommand,"PWR_MEAS ON");
	m_nErrCode=Write(m_szCommand);
	sprintf_s(m_szCommand,"FREQ_MEAS OFF");
	m_nErrCode=Write(m_szCommand);
	sprintf_s(m_szCommand,"MOD_MEAS OFF");
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}


/*************************************************************************************
//Name			: WB_SetupCallCondition()
//Auhtor		: Zona Tzou
//Date			: 2007/04/03
//Description	: Set WB Setup Call Condition
*************************************************************************************/
INT C8960::WB_Setup_Call_Condition(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand,"DCCHPAT ALL1");
	m_nErrCode=Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"CALLPROC OFF;MOD ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"PRISCRCODE 0");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"UDPCHSCRCODE 1");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"CPICHPWR -3.300000DB;CPICH ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"PCCPCHPWR -5.300000DB;PCCPCH ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SCHPWR -5.300000DB;SCH ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"PICHCODE 16");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"PICHPWR -8.300000DB;PICH ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"DDPCHCODE 9;DDPCHSACODE 9;CHCODING REFMEASCH;MAXRATE 12.2");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"DDPCHPWR -10.300000DB;DDPCH ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SCCPCHPWR 0.000000DB;SCCPCH OFF");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"AICHPWR 0.000000DB;AICH OFF");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"UDPCCHBETAC 8");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"UDPDCHBETAD 15");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"TPCPAT ALL1");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"TPCSTEP 1");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"TPCALGO 1");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"DTCHPAT PN9");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"OLVL -80.000000");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"LVL ON");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"ILVL 22.0");
		m_nErrCode=Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode=Send_OPC();

	return m_nErrCode;
}

/*************************************************************************************
//Name			: WB_SetReferenceSensitivityConditions()
//Auhtor		: Zona Tzou
//Date			: 2007/04/03
//Description	: Set Reference Sensitivity Measurement Conditions
*************************************************************************************/
INT C8960::WB_Set_Reference_Sensitivity_Conditions(INT OnOff)
{

	if(OnOff == 1)
	{
		sprintf_s(m_szCommand,"FREQ_MEAS OFF");
		m_nErrCode=Write(m_szCommand);
		
		sprintf_s(m_szCommand,"MOD_MEAS OFF");
		m_nErrCode=Write(m_szCommand);

		sprintf_s(m_szCommand,"BER_MEAS ON");
		m_nErrCode=Write(m_szCommand);
	}
	else if(OnOff ==0)
	{
		sprintf_s(m_szCommand,"BER_MEAS OFF");
		m_nErrCode=Write(m_szCommand);
	}
	return m_nErrCode;
}

/*************************************************************************************
//Name			: WB_SetPowerDynamicConditionsOn()
//Auhtor		: Zona Tzou
//Date			: 2007/04/11
//Description	: Set Open Power Dynamic Conditions On
*************************************************************************************/
INT C8960::WB_SET_ILPC_CONDITION_ON(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand,"SCRSEL FMEAS");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"FASTPWRMODE OFF");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"PWR_MEAS OFF");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		Send_OPC();
	}
	return m_nErrCode;
}

/*************************************************************************************
//Name			: ResetCableLoss()
//Auhtor		: Zona Tzou
//Date			: 2007/04/12
//Description	: Reset Cable loss
*************************************************************************************/
INT C8960::Reset_Cable_Loss(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "DELLOSSTBL");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

/*************************************************************************************
//Name			: WB_SetAverageCount(INT nAverageCount)
//Auhtor		: Zona Tzou
//Date			: 2007/04/15
//Description	: Set Average Count
*************************************************************************************/
INT C8960::WB_Set_Average_Count(INT nAverageCount)
{

	sprintf_s(m_szCommand, "PWR_AVG %d;FREQ_AVG %d;MOD_AVG %d;OBW_AVG %d", nAverageCount, nAverageCount, nAverageCount, nAverageCount);
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}


/*************************************************************************************
//Name			: WB_Get_Measurement_SpuriousEmission(double *pdAmplitude)
//Auhtor		: Zona Tzou
//Date			: 2007/04/15
//Description	: Set Average Count
*************************************************************************************/
INT C8960::WB_Get_Measurement_Spurious_Emission(double *pdAmplitude)
{
	CHAR sResult[128] = {0};

	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0, sizeof(m_szCommand));

	m_nErrCode = Single_Measurement();

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"ZMKRL_SPM?");

		m_nErrCode = Query(m_szCommand, sResult);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sscanf(sResult, "%lf", pdAmplitude);
	}

	/*
	CHAR sResult[64];

	INT iMSTAT_Staus=1;
	INT iMSTAT_STATUS;
	INT index_MSTAT=0;

	do
	{
	
		iMSTAT_STATUS = SET_SYNCHRONOUS_SINGLE_SWEEP();
		Sleep(50);
		iMSTAT_STATUS = Get_Measurement_Status(&iMSTAT_Staus);
		index_MSTAT++;

	} while (iMSTAT_Staus !=0 && index_MSTAT < 5);

	sprintf_s(m_szCommand,"ZMKRL_SPM?"); 
	m_nErrCode = Query(m_szCommand, sResult);
	sscanf( sResult, "%lf", pdAmplitude);
	*/
	return m_nErrCode;
}

/*************************************************************************************
//Name			: SetTCHTimeSlot(UINT timeslot)
//Auhtor		: Tomy Chen
//Date			: 2007/06/06
//Description	: Set TCH Time Slot
*************************************************************************************/
INT C8960::SET_TCH_TIME_SLOT(UINT timeslot)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	sprintf_s(m_szCommand,"CALL:TCH:TSL %d",timeslot);
	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

/*************************************************************************************
//Name			: SetFrequency_RFAN(FLOAT fFreq)
//Auhtor		: Tomy Chen
//Date			: 2007/06/06
//Description	: Set 8960 Uplink Frequency in MHz
*************************************************************************************/
INT C8960::Set_Frequency_RFAN(FLOAT fFreq)
{
	m_nErrCode = GPIB_SUCCESS;

	//Set CCH Frequency
	memset(m_szCommand, 0, sizeof(m_szCommand));
	sprintf_s(m_szCommand, "CTRLULFREQ %fMHZ", fFreq);
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "TXFREQ %fMHZ", fFreq);
		m_nErrCode = Write(m_szCommand);
	}
	
	return m_nErrCode;
}

/*************************************************************************************
//Name			: SetFrequency_RFG(FLOAT fFreq)
//Auhtor		: Tomy Chen
//Date			: 2007/06/06
//Description	: Set 8960 Downlink Frequency in MHz
*************************************************************************************/
INT C8960::Set_Frequency_RFG(FLOAT fFreq)
{
	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0, sizeof(m_szCommand));
	sprintf_s(m_szCommand, "CTRLDLFREQ %fMHZ", fFreq);
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "RXFREQ %fMHZ", fFreq);
		m_nErrCode = Write(m_szCommand);
	}
	
	return m_nErrCode;
}

/*************************************************************************************
//Name			: SetRxInputPowerLv(FLOAT fPower)
//Auhtor		: Tomy Chen
//Date			: 2007/06/06
//Description	: Set 8960 Downlink Power --> BsPower
*************************************************************************************/
INT C8960::Set_Rx_Input_Power_Lv(FLOAT fPower)
{
	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0, sizeof(m_szCommand));
	sprintf_s(m_szCommand, "OLVL %fDBM", fPower);
	m_nErrCode = Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::INIT_TX_POWER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = Write("INIT:TXP:ON");
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE("TXP");
	}

	return m_nErrCode;
}

INT C8960::SET_END_TXP()
{
	return Write("INIT:TXP:OFF");
}
INT C8960::AFC_Init_Freq_Error(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand,"MOD_MEAS ON");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = Single_Measurement();
	}
	
	return m_nErrCode;
}

INT C8960::SET_END_PFER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = Write("INIT:PFER:OFF");
	m_nErrCode = Write(m_szCommand);
	
	return m_nErrCode;
}
INT C8960::SET_END_EMAC(VOID)
{
	return Write("INIT:EMAC:OFF");
}

INT C8960::SET_END_PVT(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	return Write("INIT:PVT:OFF");
}

INT C8960::EG_Fetch_PCAL_AMP(CHAR *out_psResult)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "PREDISTE_AMP? 0,%d", m_nNumberOfIQMeasurements);
	m_nErrCode = Query(m_szCommand, out_psResult);
	
	return m_nErrCode;
}

INT C8960::EG_Fetch_PCAL_Phase(CHAR *out_psResult)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "PREDISTE_PHASE? 0,%d", m_nNumberOfIQMeasurements);
	m_nErrCode = Query(m_szCommand, out_psResult);
	
	return m_nErrCode;
}

INT C8960::FETCH_95th_EVM(CHAR *out_psResult)
{
	return CALL_TEST_FETCH("FETC:EMAC:EVM:PERC?", out_psResult);
}

INT C8960::Setup_BLER(INT nCount, INT nTimeOut)
{
	m_nErrCode = GPIB_SUCCESS;

	//Set USF BLER Count
	sprintf_s(m_szCommand,"USFBLER_SAMPLE %d", nCount);
	m_nErrCode = Write(m_szCommand);

	//Set BLER Count
	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"BLER_SAMPLE %d", nCount);
		m_nErrCode = Write(m_szCommand);
	}
	
	//Set USF BLER Measurement off.
	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"USFBLER_MEAS OFF");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::Set_Speech_Source(CHAR *cSpeechType)
{
	m_nErrCode = GPIB_SUCCESS;

	if (_stricmp(cSpeechType, "PRBS15") == 0)
	{
		sprintf_s(m_szCommand, "TESTPAT PN15");
	}
	else if (_stricmp(cSpeechType, "ECHO") == 0)
	{
		sprintf_s(m_szCommand, "TESTPAT ECHO");
	}
	m_nErrCode = Write(m_szCommand);
	
	return m_nErrCode;
}

INT C8960::FETCH_ORFS_30KHz_BW_POWER(CHAR *out_psResult)
{
	return CALL_TEST_FETCH("FETC:ORFS:POW:BWID:AVER?", out_psResult);
}

INT C8960::Query_Signal_Status(CHAR *cStatus)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "CALLSTAT?");

	m_nErrCode = Query(m_szCommand, cStatus);

	return m_nErrCode;
}

INT C8960::Set_GSM_Active_Cell(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "OPEMODE GSM");
	m_nErrCode = Write(m_szCommand);
	
	//set measurement object
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "MEASOBJ MSNB");
		m_nErrCode = Write(m_szCommand);
	}
	
	//set NCC & BCC code
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "NIDNCC 1");
		m_nErrCode = Write(m_szCommand);
	}
	
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "NIDBCC 5");
		m_nErrCode = Write(m_szCommand);
	}
	
	//Turn on call processing
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "CALLPROC ON");
		m_nErrCode = Write(m_szCommand);
	}
	
	//Turn on modulation analysis measurement
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "MOD ON");
		m_nErrCode = Write(m_szCommand);
	}
	
	//Set ms power as power contrl level
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "ILVLCTRL PCL");
		m_nErrCode = Write(m_szCommand);
	}			
	
	//Send *OPC?
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = Send_OPC();
	}

	return m_nErrCode;
}

INT C8960::Set_EDGE_Active_Cell(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	sprintf_s(m_szCommand, "OPEMODE EGPRS");
	m_nErrCode = Write(m_szCommand);
	
	//set measurement object
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "MEASOBJ 8PSK");
		m_nErrCode = Write(m_szCommand);
	}
	
	//set NCC & BCC code
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "NIDNCC 1");
		m_nErrCode = Write(m_szCommand);
	}
	
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "NIDBCC 5");
		m_nErrCode = Write(m_szCommand);
	}
	
	//Turn on call processing
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "CALLPROC ON");
		m_nErrCode = Write(m_szCommand);
	}
	
	//Turn on modulation analysis measurement
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "MOD ON");
		m_nErrCode = Write(m_szCommand);
	}
	
	//Set ms power as power contrl level
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "ILVLCTRL PCL");
		m_nErrCode = Write(m_szCommand);
	}			
	
	//Send *OPC?
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = Send_OPC();
	}

	return m_nErrCode;
}

INT C8960::INSTRUMENT_CALIBRATION(VOID)
{
	INT		iCurrCheckCount = 0, iMaxCheckCount = 20, iCheckInterval = 10000;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CAL:SMON?");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		for(iCurrCheckCount = 0; iCurrCheckCount < iMaxCheckCount; iCurrCheckCount++)\
		{
			Sleep(iCheckInterval);

			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

			m_nErrCode = Read(m_szReadBuffer);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 == atoi(m_szReadBuffer))
				{
					m_nErrCode = GPIB_SUCCESS;
					break;
				}
				else
				{
					m_nErrCode = GPIB_READ_FAIL;
					continue;
				}
			}
			else
			{
				m_nErrCode = GPIB_READ_FAIL;
				continue;
			}
		}
	}

	//Close calibration window and event status.
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "*CLS");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}
//***************************************************************************
// Description: GSM_CAL_RX_INIT
//***************************************************************************
INT C8960::GSM_CAL_RX_INIT(VOID)
{
	INT _iGPIBRet;
	sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:CELL:CONT:DOWN:FREQ:AUTO OFF");	//Output Level
	_iGPIBRet = Write(m_szCommand);
	_iGPIBRet = SET_RF_OUTPUT_SIGNAL_STATUS(1);
	sprintf_s(m_szCommand, sizeof(m_szCommand), "RFG:OUTP IO");	//Output Level
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}
INT C8960::WCDMA_CAL_RX_INIT(VOID)
{
	WCDMA_SET_OUTPUT_LEVEL_STATUS(1);
	WCDMA_CLOSE_ALL_MEASUREMENT();
	return	GPIB_SUCCESS;
}
//***************************************************************************
// Description: GSM_CAL_SET_BAND
//***************************************************************************
INT C8960::GSM_CAL_SET_BAND(int iBand)
{
	INT _iGPIBRet;

	switch(iBand)
	{
	case 0:	//GSM850
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SYSCMB PCS1900;*OPC?");
		_iGPIBRet = Write(m_szCommand);

	case 1: //GSM900
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SYSCMB DCS1800;*OPC?");
		_iGPIBRet = Write(m_szCommand);

	case 2:	//DCS1800
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SYSCMB DCS1800;*OPC?");
		_iGPIBRet = Write(m_szCommand);

	case 3:	//PCS1900
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SYSCMB PCS1900;*OPC?");
		_iGPIBRet = Write(m_szCommand);
	}
	return _iGPIBRet;
}

//***************************************************************************
// Description: Set CCH & TCH Channel
//***************************************************************************
INT C8960::GSM_CAL_SET_CH(int iCCH, int iTCH)
{	
	INT _iGPIBRet;

	if(iCCH!=0)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "CTRLCH %d", iCCH);	//set CCH 
		_iGPIBRet = Write(m_szCommand);	

		sprintf_s(m_szCommand, sizeof(m_szCommand), "*OPC?");	
		_iGPIBRet = Write(m_szCommand);
	}
	if(iTCH!=0)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "CHAN %d", iTCH);		//set TCH
		_iGPIBRet = Write(m_szCommand);	

		sprintf_s(m_szCommand, sizeof(m_szCommand), "*OPC?");	
		_iGPIBRet = Write(m_szCommand);
	}
	return _iGPIBRet;
}
//***************************************************************************
// Set CCH & TCH UL & DL FREQ   
// CCH UL:0, CCH DL:1, TCH UL:2, TCH DL:3
//***************************************************************************
INT C8960::GSM_CAL_SET_FREQ(int isel, double dFreq)
{	
	INT _iGPIBRet;

	switch(isel)
	{
	case 0://CCH UL
		sprintf_s(m_szCommand, sizeof(m_szCommand), "CTRLULFREQ %f%s", dFreq, "MHZ");
		_iGPIBRet = Write(m_szCommand);	
		break;
	case 1://CCH DL
		sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:CELL:RFG:FREQ %.2f %s", dFreq, "MHZ");
		_iGPIBRet = Write(m_szCommand);
		break;
	case 2://TCH UL
		sprintf_s(m_szCommand, sizeof(m_szCommand), "RFAN:MAN:MEAS:MFR %.2f %s", dFreq, "MHZ");
		_iGPIBRet = Write(m_szCommand);
		break;
	case 3://TCH DL
		sprintf_s(m_szCommand, sizeof(m_szCommand), "DLFREQ %f%s", dFreq, "MHZ");
		_iGPIBRet = Write(m_szCommand);
		break;
	}
	return _iGPIBRet;
}

//***************************************************************************
// GSM IM2 Initialize
//***************************************************************************
INT C8960::GSM_CAL_IM2_INIT(VOID)
{
	INT _iGPIBRet;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "LVL OFF");
	_iGPIBRet = Write(m_szCommand);	

	sprintf_s(m_szCommand, sizeof(m_szCommand), "MOD OFF");
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "OLVL -30");		//Output Level
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "LVL ON");			//LEVEL
	_iGPIBRet = Write(m_szCommand);

	//sprintf_s(m_szCommand, sizeof(m_szCommand), "OSIGPAT CCH");		//Output Signal Patter
	//_iGPIBRet = Write(m_szCommand);

	//sprintf_s(m_szCommand, sizeof(m_szCommand), "TSPAT TSC5");		//Training Sequence
	//_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "AM ON");			//set TCH
	_iGPIBRet = Write(m_szCommand);	

	sprintf_s(m_szCommand, sizeof(m_szCommand), "*OPC?");	
	_iGPIBRet = Write(m_szCommand);

	return _iGPIBRet;
}

//***************************************************************************
// GSM IM2 UnInitialize  
//***************************************************************************
INT C8960::GSM_CAL_IM2_UNINIT(VOID)
{
	INT _iGPIBRet;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "AM OFF");
	_iGPIBRet = Write(m_szCommand);	

	sprintf_s(m_szCommand, sizeof(m_szCommand), "MOD ON");
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "OLVL -65");		//Output Level
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "LVL ON");			//LEVEL
	_iGPIBRet = Write(m_szCommand);

	return _iGPIBRet;
}
//***************************************************************************
// GSM Set Input or Output Level  
// case 0 is output
// case 1 is intput 
//***************************************************************************
INT C8960::GSM_SET_POWER_LEVEL(int isel, double dlevel)
{
	INT _iGPIBRet;

	if(isel==0)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:CELL:POW:AMPL %.0f", dlevel);				//LEVEL
	else
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:OPER:MODE CW");	
		_iGPIBRet = Write(m_szCommand);

		sprintf_s(m_szCommand, sizeof(m_szCommand), "RFANALYZER:CW:EXPECTED:POWER %.0f", dlevel + 3);				//LEVEL
	}
	_iGPIBRet = Write(m_szCommand);

	return _iGPIBRet;

}

INT C8960::GSM_SET_LEVEL(int isel, double dlevel)
{
	INT _iGPIBRet;


	sprintf_s(m_szCommand, sizeof(m_szCommand), "RFAN:CONT:POW:AUTO OFF");
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand),"RFAN:MAN:POW:SEL:BURS1 %.1f", dlevel);
	_iGPIBRet = Write(m_szCommand);

	return _iGPIBRet;

}
//***************************************************************************
// GSM_CAL_SYNC_SINGLE_MODE
//***************************************************************************

INT C8960::GSM_CAL_SYNC_SINGLE_MODE(int iDuration,int iNum, double dRatio)
{	
	INT _iGPIBRet;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SWPPREDISTQ %i,%i,%f",iDuration,iNum,dRatio);		//SWPPREDISTE duartion,n,ratio
	_iGPIBRet = Write(m_szCommand);	

	return _iGPIBRet;

}

//***************************************************************************
// GSM_CAL_PREDISTQ_POWER
//***************************************************************************
INT C8960::GSM_CAL_PREDISTQ_POWER(char *cPower,int iPREDISTQ_No)
{
	INT _iGPIBRet;
	int i=0;
	char cSTAT[128] = {0x00};

	memset(cSTAT, 0x00, sizeof(cSTAT));
	for(i=0;i<5;i++)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "FETC:PCAL:INT?");	
		_iGPIBRet = Query(m_szCommand,cSTAT);
		if(_iGPIBRet == GPIB_SUCCESS)
		{
			if (strcmp("+0",cSTAT) == 0)
			{
				sprintf_s(m_szCommand, sizeof(m_szCommand), "FETC:PCAL:POW?");	
				_iGPIBRet = Query(m_szCommand,cPower);
				break;
			}
		}
	}

	if(i == 5)
		_iGPIBRet = GPIB_DEVICE_NOT_READY;

	return _iGPIBRet;
}

//***************************************************************************
// GSM_CAL_PREDISTQ_PHASE 
//***************************************************************************
INT C8960::GSM_CAL_PREDISTQ_PHASE(char *cPhase,int iPREDISTQ_No)
{
	INT _iGPIBRet;
	char cSTAT[128];
	memset(cSTAT,0x00,128);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "FETC:PCAL:PHAS?");	
	_iGPIBRet = Query(m_szCommand,cPhase);

	return _iGPIBRet;
}

//***************************************************************************
// GSM_CAL_PRESET_DEVICE
//***************************************************************************

INT C8960::GSM_CAL_PRESET_DEVICE(VOID)
{
	INT _iGPIBRet;
	sprintf_s(m_szCommand, sizeof(m_szCommand), "PRESET");	
	_iGPIBRet = Write(m_szCommand);

	return _iGPIBRet;
}
//=============== Add by MF ================
INT C8960::RESET()
{
	INT _iGPIBRet;	
	_iGPIBRet = Write("*RST");
	return _iGPIBRet;
}

INT C8960::QUERY_SW_VERSION(const int iStandardNumber, char* szSWVersion)
{
	INT _iGPIBRet;
	sprintf_s(m_szCommand, sizeof(m_szCommand), "MCMSV? %d", iStandardNumber);	
	_iGPIBRet = Query(m_szCommand, szSWVersion);
	return _iGPIBRet;
}

INT C8960::SET_POWER_COUNT(const int iPowerCount)
{
	INT _iGPIBRet = GPIB_SUCCESS;
	//sprintf_s(m_szCommand, sizeof(m_szCommand), "PWR_COUNT %d",iPowerCount);	
	//_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}

INT C8960::SET_INSTRUMENT_MODE(const char *szBand, /*const char *szMeasureObj, */bool bUSFBlockERR)
{
	INT _iGPIBRet = GPIB_SUCCESS;
	//Non-Signaling-8PSK
	//Set mode to gsm
	/*
	if(strcmp(szBand,"EGPRS") == 0)
	{
		sprintf_s(m_szCommand, "OPEMODE EGPRS");
		_iGPIBRet = Write(m_szCommand);

			//set measurement object
		if (_iGPIBRet == GPIB_SUCCESS)
		{
			sprintf_s(m_szCommand, "MEASOBJ 8PSK");
			_iGPIBRet = Write(m_szCommand);
		}
		
		//Turn off USF Block Error Rate measurement
		if (_iGPIBRet == GPIB_SUCCESS )
		{
			if(bUSFBlockERR == 0)			
				sprintf_s(m_szCommand, "USFBLER_MEAS OFF");
			_iGPIBRet = Write(m_szCommand);
		}
	}
	*/
	return _iGPIBRet;	
}

INT C8960::SET_CODE_SCHEME(const char* szCodeSchemeType, const int iCodeScheme)
{
	INT _iGPIBRet;
	sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:PDTCH:MCSC:EBPT %s%dP1",szCodeSchemeType, iCodeScheme);	
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}

INT C8960::SET_RF_OUTPUT(const int iOutputConnector)//0 = MAIN; 1 = AUX
{
	//INT _iGPIBRet;
	//sprintf_s(m_szCommand, sizeof(m_szCommand), "RFG:OUTP IO");	

	//_iGPIBRet = Write(m_szCommand);
	return GPIB_SUCCESS;
}

INT C8960::SET_BIT_OFFSET( const int iBitOffsetType)
{// 0 = offset 0 ; 1 = offset 0.5
	INT _iGPIBRet;
	if(iBitOffsetType == 0)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "BITOFS 0");
	else if(iBitOffsetType == 1)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "BITOFS 0.5");

	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}

INT C8960::SET_ORFS_COUNT(const int iORFSMode, const int iCount) //0 = Modulation , 1 = Switching
{
	INT _iGPIBRet;
	if(iORFSMode == 0)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:MOD:COUN:SNUM %d",iCount);
		_iGPIBRet = Write(m_szCommand);

		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:MOD:FREQ:OFFS -600 KHZ,-400 KHZ,400 KHZ,600KHZ",iCount);
		_iGPIBRet = Write(m_szCommand);
	}	
	else if(iORFSMode == 1)
	{	
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:SWIT:FREQ:ALL OFF");
		_iGPIBRet = Write(m_szCommand);

		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:TIM 2.255S");
		_iGPIBRet = Write(m_szCommand);

		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:CONT OFF");
		_iGPIBRet = Write(m_szCommand);

		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:TRIG:SOUR AUTO");
		_iGPIBRet = Write(m_szCommand);

		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:TRIG:DEL 0S");
		_iGPIBRet = Write(m_szCommand);

		sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:FAST OFF");
		_iGPIBRet = Write(m_szCommand);



	}
	return _iGPIBRet;
}

INT C8960::SET_EXTURNAL_CABLE_LOSS(const int iDLULSelect, const int iBand, const int iCableLoss)// 0 = DL, 1= UL
{
	INT _iGPIBRet;	
	if(iDLULSelect == 0)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "DLEXTLOSS BAND%d,%d",iBand , iCableLoss);
	if(iDLULSelect == 1)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "ULEXTLOSS BAND%d,%d",iBand , iCableLoss);
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}

INT C8960::EXT_LOSS_SWITCH(const bool bLossSwitch)
{
	INT _iGPIBRet;	
	if(bLossSwitch == 0)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "EXTLOSSW OFF");
	if(bLossSwitch == 1)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "EXTLOSSW ON");
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}

INT C8960::QUERY_MEASUREMENT_STATUS(const int iQuaryRFPath, char *szRFStatus)
{//MF   0 = TX , 1 = RX
	INT _iGPIBRet;	
	if(iQuaryRFPath == 0)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "TXMSTAT?");
	if(iQuaryRFPath == 1)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "RXMSTAT?");
	_iGPIBRet = Query(m_szCommand, szRFStatus);
	return _iGPIBRet;
}

INT C8960::QUERY_ALL_MEASURE_RESULT(const char *szQueryItem, char *szQueryResult)
{
	INT _iGPIBRet;
	CHAR	*token, *next_token = NULL;
	CHAR    szQueryResult1[256] = {0x00};
	CHAR	seps[]   = " ,\t\n";
	INT     iItem = 0;
	bool bInitORFS = false;

	for(int i = 0; i < 50; i++)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "INIT:DONE?");
		_iGPIBRet = Query(m_szCommand, szQueryResult);
		if(strcmp(szQueryResult,"ORFS") == 0)
		{
			sprintf_s(m_szCommand, sizeof(m_szCommand), "INIT:ORFS:OFF");
			Write(m_szCommand);
			bInitORFS = true;
			SEND_OPC(20,50);
			break;
		}
		Sleep(100);
	}

	if(!bInitORFS)
		return TEST_FAIL;

	Sleep(100);
	sprintf_s(m_szCommand, sizeof(m_szCommand), "FETC:ORFS:MOD:ALL?");
	_iGPIBRet = Query(m_szCommand, szQueryResult);

	token = strtok_s( szQueryResult, seps, &next_token);
	while(token != NULL)
	{			
		if(strcmp(token, "9.99E+37") == 0)
			return TEST_FAIL;

		iItem++;
		token = strtok_s( NULL, seps, &next_token);
		if(iItem >0 && iItem<5)
		{
			if(iItem == 1)
				sprintf_s(szQueryResult1, 256, "%s", token);
			else
				sprintf_s(szQueryResult1, 256, "%s,%s", szQueryResult1, token);
		}

	}

	strcpy_s(szQueryResult, 256, szQueryResult1);



	return _iGPIBRet;
}
/*
INT C8960::SET_STD_SELECT(const char* szStd)
{
	INT _iGPIBRet;
	sprintf_s(m_szCommand, sizeof(m_szCommand), "STDSEL %s",szStd);
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}
*/
INT C8960::SCREEN_SWITCH(const bool bScreenSwitch)
{
	INT _iGPIBRet;
	if(bScreenSwitch)
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SCREEN ON");
	else
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SCREEN OFF");
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}

INT C8960::SET_SYNCHRONOUS_SINGLE_SWEEP()
{
	INT _iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, sizeof(m_szCommand), "INIT:ORFS");
	_iGPIBRet = Write(m_szCommand);
	sprintf_s(m_szCommand, sizeof(m_szCommand), "*CLS");
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}

INT C8960::QUERY_SWP_STATUS(char* szSWPstatus)
{
	INT _iGPIBRet;		
	sprintf_s(m_szCommand, sizeof(m_szCommand), "SWP?");	
	_iGPIBRet = Query(m_szCommand, szSWPstatus);
	return _iGPIBRet;
}

INT C8960::GSM_CAL_INIT(VOID)
{
	INT _iGPIBRet;

	//_iGPIBRet = SEND_RESET();

	_iGPIBRet = END_CALL();

	_iGPIBRet = SET_STANDARD_SELECT("GSM");

	sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:OPER:MODE CW");	
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:PCAL:FILT ENAR");	
	_iGPIBRet = Write(m_szCommand);
	

	sprintf_s(m_szCommand, sizeof(m_szCommand), "*RST");	
	_iGPIBRet = Write(m_szCommand);

	_iGPIBRet = SET_RF_OUTPUT_SIGNAL_STATUS(false);

	//memset(m_szCommand, 0x00, sizeof(m_szCommand));
	//sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:AWGN:POWER:STAT:SEL OFF");	
	//_iGPIBRet = Write(m_szCommand);

	_iGPIBRet = GSM_OUTPUT_SIGNAL_PATTERN("BCHTCH");

	//sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:SERV:RBT:RAB RMC12");	
	//_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "RFAN:CONT:POW:AUTO OFF" );
	m_nErrCode = Write(m_szCommand);	

	sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:CELL:CONT:DOWN:FREQ:AUTO OFF");	
	_iGPIBRet = Write(m_szCommand);

	_iGPIBRet = GSM_SET_TRAINING_SEQUENCE( 5 );

	_iGPIBRet = GSM_OUTPUT_SIGNAL_PATTERN("BCHTCH");

	return _iGPIBRet;
}
//***************************************************************************
// Description: GSM_CAL_POLAR_INIT			
//***************************************************************************
INT C8960::GSM_CAL_POLAR_INIT(VOID)
{
	INT _iGPIBRet;

	//sprintf_s(m_szCommand, sizeof(m_szCommand), "END:CALL");	
	//_iGPIBRet = Write(m_szCommand);

	//sprintf_s(m_szCommand, sizeof(m_szCommand), "SYST:CORR:STATE ON");	
	//_iGPIBRet = Write(m_szCommand);	

	sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:CELL:OPER:MODE CW");	
	_iGPIBRet = Write(m_szCommand);	

	return _iGPIBRet;
}

INT C8960::GSM_CAL_CS_INIT(VOID)
{
	//GSM_OUTPUT_SIGNAL_PATTERN("CW");

	//if(m_nErrCode!=GPIB_SUCCESS)
	//	return GPIB_INIT_FAIL;

	return GPIB_SUCCESS;
}

INT C8960::GSM_CAL_PHASEDELAY_INIT(const int iCount)
{
	sprintf_s(m_szCommand, sizeof(m_szCommand), "CALL:CELL:OPERATING:MODE EBPT",iCount);
	m_nErrCode = Write(m_szCommand);

	m_nErrCode = SET_CODE_SCHEME("MCS",5);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "RFG:OUTP IO");
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:MOD:COUN:SNUM %d",iCount);
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;
	
	m_nErrCode = GSM_SET_TRAINING_SEQUENCE(0);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:MOD:FREQ:OFFS -400 KHZ,400 KHZ,-600 KHZ,600KHZ",iCount);
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:SWIT:FREQ:ALL OFF");
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:TIM 2.255S");
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:CONT OFF");
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:TRIG:SOUR AUTO");
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:TRIG:DEL 0S");
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SET:ORFS:FAST OFF");
	m_nErrCode = Write(m_szCommand);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	return GPIB_SUCCESS;
}

INT C8960::CLOSE_ALL_MEASUREMENT(VOID)
{
	return GPIB_SUCCESS;
}

INT C8960::SET_STANDARD_SELECT(CHAR *cStandard)
{
	memset(m_szCommand,0,sizeof(m_szCommand));
	
	if(_stricmp(cStandard,"GSM")==0)
	{
		sprintf_s(m_szCommand, "%s", "SYSTEM:APPLICATION:FORMAT:NAME \'GSM/GPRS\'");
	}
	else if(_stricmp(cStandard,"WCDMA")==0)
	{
		sprintf_s(m_szCommand, "%s", "SYSTEM:APPLICATION:FORMAT:NAME \'WCDMA\'");
	}
	else 
		return GPIB_INIT_FAIL;
		
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = SEND_OPC(20,50);
	}


	return m_nErrCode;

}

INT C8960::WB_ANT8960_RESET(VOID)
{
	/*
	sprintf_s (m_szCommand, "*RST");
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;
*/
	sprintf_s(m_szCommand, "%s", "PRESET_3GPP;REMDISP REMAIN");
	if ((m_nErrCode = Write(m_szCommand)) < 0)
		return m_nErrCode;
	
	return m_nErrCode;
}

INT C8960::WCDMA_MEAS_AVG_PWR(double dILVL, double *dPower)
{
	INT _iGPIBRet;
	char cSTAT[128], cPower[100]={0};
	int iCnt=0,iTimes=0;
	memset(cSTAT,0x00,128);
//	double dDiff;
	bool bRetry=false;

	do{
		
		//Sleep(50);
		sprintf_s(m_szCommand, sizeof(m_szCommand), "SWP");	
		_iGPIBRet = Write(m_szCommand);			
		
		sprintf_s(m_szCommand, sizeof(m_szCommand), "TXMSTAT?");	
		_iGPIBRet = Query(m_szCommand,cSTAT);	

		if(atoi(cSTAT)==2)//level over
		{
			dILVL = dILVL-10;
			bRetry = true;
		}
		else if(atoi(cSTAT)==3) //level under
		{
			dILVL = dILVL+10;
		}
		else if(atoi(cSTAT)==0)
		{

			/*do{
				sprintf_s(m_szCommand, sizeof(m_szCommand), "SWP?");	
				_iGPIBRet = Query(m_szCommand,cSTAT);			
				iCnt++;
			}while(atoi(cSTAT)!=0 && iCnt<100);
			
			if(iCnt==10)
				return 1;*/

			sprintf_s(m_szCommand, sizeof(m_szCommand), "AVG_FILTPWR?");	
			_iGPIBRet = Query(m_szCommand,cPower);
			*dPower = atof(cPower);
			/*dDiff = fabs(*dPower-dILVL);
			if(dDiff>15 && *dPower<9999)
			{
				dILVL = *dPower;
				sprintf_s(m_szCommand,"ILVL %f",dILVL);
				_iGPIBRet=Write(m_szCommand);
			}*/
			iTimes++;
			if(iTimes==10)
				return 1;
		}

	}while((*dPower>=9999 || bRetry) && iTimes<10);

	return _iGPIBRet;
}

INT C8960::WCDMA_CLOSE_ALL_MEASUREMENT(VOID)
{
	//DWORD	time = GetTickCount();
	//DWORD	timeExperity = time + 3000;
	//INT		iState = -1;

	//m_nErrCode = Write("PWR_MEAS OFF;FREQ_MEAS OFF;OBW_MEAS OFF;SMASK_MEAS OFF;ADJ_MEAS OFF;MOD_MEAS OFF;PCDE_MEAS OFF;BER_MEAS OFF;BLER_MEAS OFF");

	return GPIB_SUCCESS;
}

INT C8960::WCDMA_SET_CABLE_LOSS_STATUS(char *cSTATUS)
{
	INT _iGPIBRet;

	if(_stricmp(cSTATUS,"ON")==0)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "ULEXTLOSSW ON");	
		_iGPIBRet = Write(m_szCommand);
		sprintf_s(m_szCommand, sizeof(m_szCommand), "DLEXTLOSSW ON");
		_iGPIBRet = Write(m_szCommand);
	}
	else if(_stricmp(cSTATUS,"OFF")==0)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "ULEXTLOSSW OFF");
		_iGPIBRet = Write(m_szCommand);
		sprintf_s(m_szCommand, sizeof(m_szCommand), "DLEXTLOSSW OFF");
		_iGPIBRet = Write(m_szCommand);
	}
	else if(_stricmp(cSTATUS,"COMMON")==0)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "ULEXTLOSSW COMMON");
		_iGPIBRet = Write(m_szCommand);
		sprintf_s(m_szCommand, sizeof(m_szCommand), "DLEXTLOSSW COMMON");	
		_iGPIBRet = Write(m_szCommand);
	}

	return _iGPIBRet;
}

INT C8960::WCDMA_SET_UL_CHAN(int iCH)
{
	m_nErrCode = GPIB_SUCCESS;
	char czCommand[128];
	if(!(iCH>=150 && iCH<=12550))//unit:channel number
	{
		if(!(iCH==12  || iCH==37  || iCH==62  || iCH==87 ||	iCH==112 || iCH==137) )
		return 1;
	}
	sprintf_s(czCommand, "CHAN %d",iCH);
	m_nErrCode = Write(czCommand);	
	return m_nErrCode;
}

INT C8960::WCDMA_GET_SWP_PWR(int iSTEP,char *cPower)
{
	INT _iGPIBRet;
	char cSTAT[128];
	int iTemp=0;
	memset(cSTAT,0x00,128);
	memset(cPower,0x00,128);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "MSTAT?");	
	_iGPIBRet = Query(m_szCommand,cSTAT);
	iTemp = atoi(cSTAT);	
	if(iTemp!=0)
		return 1;

	sprintf_s(m_szCommand, sizeof(m_szCommand), "MRFPWR? 0,%d",iSTEP);	
	_iGPIBRet = Query(m_szCommand,cPower);

	return _iGPIBRet;
}
INT C8960::WCDMA_MEAS_SWP_PWR(void)
{
	INT _iGPIBRet;
	

	sprintf_s(m_szCommand, sizeof(m_szCommand), "SWPMPMEAS");	
	_iGPIBRet = Write(m_szCommand);
	return _iGPIBRet;
}
INT C8960::WCDMA_SWP_PWR_SET(int iSTEP, int iNUM, int iTimeout)
{
	INT _iGPIBRet;
	char cSTAT[128];
	int iCnt=0;
	memset(cSTAT,0x00,128);
	
	sprintf_s(m_szCommand, sizeof(m_szCommand), "MPMEAS_STEPTIME %i",iSTEP);	
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "MPMEAS_NUMSTEP %i",iNUM);	
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "MPMEAS_TIMEOUT %i",iTimeout);	
	_iGPIBRet = Write(m_szCommand);

	sprintf_s(m_szCommand, sizeof(m_szCommand), "*OPC?");	
	_iGPIBRet = Query(m_szCommand,cSTAT);

	if(cSTAT=="0")
		return 1;

	return _iGPIBRet;
}
INT C8960::GSM_CAL_FREQ_EOR_AVG(char *szBuf)
{
	INT _iGPIBRet;
	CHAR szQueryResult[128] = {0};
	/*char szBuff[32];*/
	memset(szBuf, 0x00, sizeof(szBuf));

	Write("CALL:MS:TXL 0");

	Write("INIT:PFER");

	for(int i = 0; i < 20; i++)
	{
		sprintf_s(m_szCommand, sizeof(m_szCommand), "INIT:DONE?");
		_iGPIBRet = Query(m_szCommand, szQueryResult);
		if(strcmp(szQueryResult,"PFER") == 0)
		{
			break;
		}
		Sleep(100);
	}

	sprintf_s(m_szCommand, sizeof(m_szCommand), "FETCh:PFERror:FERRor:AVERage?");	
	_iGPIBRet = Query(m_szCommand,szBuf);

	return _iGPIBRet;
}

INT C8960::WAIT_for_MEASUREMENT_COMPLETE(char *cTestItem)
{
	INT				iCurrCounter = 0, iMaxCounter = 300;
	CHAR			cTempResult[128] = {0x00}, cFinalResult[1024] = {0x00};
	string			szTestItemUppercase = "", szResultString = "";
				

	szTestItemUppercase = cTestItem;
	for (auto & c : szTestItemUppercase) c = toupper(c);
	

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));
	memset(cTempResult, 0, sizeof(cTempResult));
	memset(cFinalResult, 0, sizeof(cFinalResult));

	sprintf_s(m_szCommand, "INIT:DONE?");

	for (iCurrCounter = 0; iCurrCounter < iMaxCounter; iCurrCounter ++)
	{
		Sleep(50);
		m_nErrCode = Query(m_szCommand, cTempResult);
		if (m_nErrCode == GPIB_SUCCESS)
		{
			strcat(cFinalResult, cTempResult);
			szResultString = cFinalResult;
			for (auto & c : szResultString) c = toupper(c);

			if (szResultString.find(szTestItemUppercase) == string::npos)
			{
				m_nErrCode = GPIB_INIT_FAIL;
				memset(cTempResult, 0, sizeof(cTempResult));
				continue;
			}
			else
			{
				m_nErrCode = GPIB_SUCCESS;
				break;
			}
		}
		else
		{
			m_nErrCode = GPIB_INIT_FAIL;
			memset(cTempResult, 0, sizeof(cTempResult));
			continue;
		}
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
		sprintf_s(m_szCommand, "FETC:%s:INT?", cTestItem);
		m_nErrCode = Query(m_szCommand, m_szReadBuffer);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			if ((0 != atoi(m_szReadBuffer)) && (5 != atoi(m_szReadBuffer)) && (6 != atoi(m_szReadBuffer)))
				m_nErrCode = GPIB_INIT_FAIL;
		}
	}

	return m_nErrCode;
}
//***************************************************************************
// Description: GSM_CAL_VCO_INIT			
//***************************************************************************
INT C8960::GSM_CAL_VCO_INIT(VOID)
{
	INT _iGPIBRet = GPIB_SUCCESS;

	_iGPIBRet = GSM_OUTPUT_SIGNAL_PATTERN("BCHTCH");

	m_nErrCode = GSM_SET_TRAINING_SEQUENCE(5);
	if(m_nErrCode!=GPIB_SUCCESS)
		return GPIB_INIT_FAIL;

	_iGPIBRet = Write("SET:PFER:TIM 10");
	_iGPIBRet = Write("SET:PFER:COUNT 10");
	_iGPIBRet = Write("SET:PFER:TRIG:SOUR IMM");
	return _iGPIBRet;
}

INT C8960::FETCH_POWER_INIT_DONE(char *out_psResult)
{
	return CALL_TEST_FETCH("INIT:DONE?", out_psResult);
}

INT C8960::SET_PDTCH_BAND(const char in_sBand[])
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:PDTChannel:BAND %s", in_sBand);
	return Write(m_szCommand);
}

INT C8960::SET_PDTCH_MS_TX_LEVEL(const UINT Device_in_uiTxLevel)
{
	memset(m_szCommand,0,sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:PDTCH:MS:TXLevel:BURSt1 %d", Device_in_uiTxLevel);
	return Write(m_szCommand);
}

INT C8960::SET_PCS_PVT()
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s (m_szCommand, "SETup:PVTime:LIMit:ETSI:PCS REL");
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::SET_EDGE_CODE_SCHEME(char *in_pSchemeSetting)
{
	sprintf_s(m_szCommand, "CALL:PDTCH:MCSCheme:EBPTest:BURSt1 %s", in_pSchemeSetting);

	return Write(m_szCommand);
}

INT C8960::SET_PVT_TIME_OFFSET(char *cPvtTimeOffset)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand,"SETUP:PVTIME:TIME:OFFSET %s", cPvtTimeOffset);

	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::SET_ORFS_MOD_FREQ_OFFSET(char *cOrfsFreqOffset)
{
	sprintf_s(m_szCommand,"SETUP:ORFS:MOD:FREQ:OFFSET %s", cOrfsFreqOffset);

	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::SET_ORFS_SWIT_FREQ_OFFSET(char *cOrfsFreqOffset)
{
	sprintf_s(m_szCommand,"SETUP:ORFS:SWIT:FREQ:OFFSET %s", cOrfsFreqOffset);

	m_nErrCode=Write(m_szCommand);

	return m_nErrCode;
}
/********** EGPRS TX Power Functions **********/
INT C8960::SET_ETXP(int nCount, int nTimeOut)
{
	sprintf_s(m_szCommand,"SET:ETXP:CONT OFF");
	m_nErrCode = Write(m_szCommand);

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:ETXP:COUN:NUMB %d", nCount);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:ETXP:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:ETXP:TRIG:SOUR AUTO");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:ETXP:TIM:TIME %dS", nTimeOut);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:ETXP:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}
INT C8960::SET_PVT(int nCount, int nTimeOut)
{
	sprintf_s(m_szCommand,"SETUP:PVT:CONT OFF");
	m_nErrCode = Write(m_szCommand);

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PVT:COUNT %d", nCount);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:PVT:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PVTIME:TRIGGER:SOURCE AUTO");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PVT:SYNC MIDAMBLE");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SETUP:PVTIME:TIMEOUT:TIME %d", nTimeOut);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:PVT:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;

}

/********** EGPRS Modulation Accuracy Functions **********/
INT C8960::SET_EMAC(int nCount, int nTimeOut)
{
	sprintf_s(m_szCommand,"SET:EMAC:CONT OFF");
	m_nErrCode = Write(m_szCommand);

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:EMAC:COUN:NUMB %d", nCount);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:EMAC:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:EMAC:TRIG:SOUR AUTO");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:EMAC:HIST:MAX:EVM PCT100");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:EMAC:IQIM:STAT OFF");
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:EMAC:TIM:TIME %d", nTimeOut);
		m_nErrCode = Write(m_szCommand);
	}

	if(m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand,"SET:EMAC:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::SET_ORFS(int iModCount, int iSWCount, int nTimeOut)
{
	char	m_szCommand2[200], m_szCommand3[200];
	sprintf_s(m_szCommand,"SETUP:ORFS:SWIT:COUNT:NUMBER %d",iSWCount);
	sprintf_s(m_szCommand2,"SETUP:ORFS:MOD:COUNT:NUMBER %d",iModCount);
	sprintf_s(m_szCommand3,"SETUP:ORFSPECTRUM:TIMEOUT:TIME %d",nTimeOut);

	if ((m_nErrCode = Write("SETUP:ORFS:CONT OFF")) != GPIB_SUCCESS)
		return m_nErrCode;
	else if ((m_nErrCode = Write("SETUP:ORFS:COUNT:STATE ON")) != GPIB_SUCCESS)
		return m_nErrCode;
	else if ((m_nErrCode = Write("SETUP:ORFS:TRIGGER:SOURCE AUTO")) != GPIB_SUCCESS)
		return m_nErrCode;
	else if ((m_nErrCode = Write("SET:ORFS:TIM:STAT ON")) != GPIB_SUCCESS)
		return m_nErrCode;
	else if ((m_nErrCode = Write(m_szCommand)) != GPIB_SUCCESS)
		return m_nErrCode;
	else if ((m_nErrCode = Write(m_szCommand2)) != GPIB_SUCCESS)
		return m_nErrCode;
	else if ((m_nErrCode = Write(m_szCommand3)) != GPIB_SUCCESS)
		return m_nErrCode;
	else if ((m_nErrCode = Write("SETUP:ORFS:FILT:TYPE DIG")) != GPIB_SUCCESS)
		return m_nErrCode;
	else
		return GPIB_SUCCESS;
}
INT C8960::INIT_ETXP()
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = Write("INIT:ETXP:ON");
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE("ETXP");
	}

	return m_nErrCode;
}

INT C8960::FETCH_ETXP(char *out_psResult)
{
	return CALL_TEST_FETCH("FETC:ETXP:POW:BURS:AVER?", out_psResult);
}

INT C8960::SET_END_ETXP()
{
	return Write("INIT:ETXP:OFF");
}

INT C8960::INIT_PVT()
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	sprintf_s(m_szCommand,"INIT:PVT:ON");
	m_nErrCode = Write(m_szCommand);
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE("PVT");
	}

	return m_nErrCode;
}
INT C8960::PVT_MEASUREMENT(BOOL &bMaskOK, char *cPVT_Result, char *cPvtTimeOffset)
{
	int iPass = 0;
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = FETCH_PVT(&iPass);

	if(m_nErrCode == GPIB_SUCCESS)
	{
		if(iPass == 0)
			bMaskOK = TRUE;
		else
			bMaskOK = FALSE;

		sprintf_s(m_szCommand,"FETC:PVT:POW:TIME:OFFS:AVER? %s",cPvtTimeOffset);
		m_nErrCode=Query(m_szCommand,cPVT_Result);
	}

	return m_nErrCode;
}
INT C8960::FETCH_PVT(int *out_pnResult)
{
	m_nErrCode = GPIB_SUCCESS;
	char sResult[RF_TEST_FETCH_BUFFER_SIZE];
	memset(sResult,0,sizeof(sResult));

	if ((m_nErrCode = CALL_TEST_FETCH("FETC:PVT:MASK?", sResult)) != GPIB_SUCCESS)
		return m_nErrCode;
	else if (atof(sResult) == 0.0)
		*out_pnResult = 0; // PASS
	else
		*out_pnResult = 1; // FAIL

	return GPIB_SUCCESS;

}
INT C8960::INIT_FREQ_ERROR()
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = Write("INIT:PFER:ON");
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE("PFER");
	}

	return m_nErrCode;
}

INT C8960::INIT_EMAC()
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = Write("INIT:EMAC:ON");
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE("EMAC");
	}

	return m_nErrCode;
}
INT C8960::FETCH_PEAK_EVM(char *out_psResult)
{
	return CALL_TEST_FETCH("FETC:EMAC:EVM:PEAK:AVER?", out_psResult);
}

INT C8960::FETCH_RMS_EVM(char *out_psResult)
{
	return CALL_TEST_FETCH("FETC:EMAC:EVM:RMS:MAX?", out_psResult);
}
INT C8960::FETCH_EFREQ_ERR(char *out_psResult)
{
	return CALL_TEST_FETCH("FETC:EMAC:FERR:MAX?", out_psResult);
}
INT C8960::INIT_ORFS()
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0, sizeof(m_szCommand));

	sprintf_s(m_szCommand,"INIT:ORFS:ON");
	m_nErrCode = Write(m_szCommand);
	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE("ORFS");
	}

	return m_nErrCode;
}
INT C8960::SET_END_ORFS()
{
	return Write("INIT:ORFS:OFF");
}
INT C8960::SendOPC(VOID)
{
	char	sResult[50] = {0};
	int		i_Count = 0;
	int		iResult = 0;

	for (i_Count = 0; i_Count < 20; i_Count++)
	{
		m_nErrCode = Query("*OPC?", sResult);
		if (m_nErrCode == GPIB_SUCCESS)
		{
			iResult = atoi(sResult);
			if (iResult == 1)
				break;
			else
			{
				Sleep(50);
				continue;
			}
		}
		else
			Sleep(10);
	}
	if(iResult != 1)
	{
		m_nErrCode = E_DEVICE_DATA_READ_ERROR;
	}	

	return m_nErrCode;
}

/********************		Start -- RRT virtual functions		********************/
/**********		Start -- Common Functions		**********/
INT C8960::RRT_RESET(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "*RST");
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

/*****		Execution 8960 Spectrum Monitor calibration		*****/
INT C8960::RRT_FULL_CALIBRATION(VOID)
{
	INT		iCurrCheckCount = 0, iMaxCheckCount = 20, iCheckInterval = 10000;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CAL:SMON?");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		for(iCurrCheckCount = 0; iCurrCheckCount < iMaxCheckCount; iCurrCheckCount++)\
		{
			Sleep(iCheckInterval);

			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

			m_nErrCode = Read(m_szReadBuffer);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 == atoi(m_szReadBuffer))
				{
					m_nErrCode = GPIB_SUCCESS;
					break;
				}
				else
				{
					m_nErrCode = GPIB_READ_FAIL;
					continue;
				}
			}
			else
			{
				m_nErrCode = GPIB_READ_FAIL;
				continue;
			}
		}
	}

	//Close calibration window and event status.
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "*CLS");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_BAND_CALIBRATION(VOID)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_QUERY_CALIB_DATE(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "CAL:DATE?");
	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_CALIB_DATE(VOID)
{
	SYSTEMTIME	stCurrentTime;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	::GetLocalTime(&stCurrentTime);

	sprintf_s(m_szCommand, "CAL:DATE %.4d,%.2d,%.2d", stCurrentTime.wYear, stCurrentTime.wMonth, stCurrentTime.wDay);
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_QUERY_SYS_DATE(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "SYST:DATE?");
	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_QUERY_SYS_TIME(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "SYST:TIME?");
	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_SYS_DATE(VOID)
{
	SYSTEMTIME	stCurrentTime;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	::GetLocalTime(&stCurrentTime);

	sprintf_s(m_szCommand, "SYST:DATE %.4d,%.2d,%.2d", stCurrentTime.wYear, stCurrentTime.wMonth, stCurrentTime.wDay);
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_SYS_TIME(VOID)
{
	SYSTEMTIME	stCurrentTime;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	::GetLocalTime(&stCurrentTime);

	sprintf_s(m_szCommand, "SYST:TIME %d,%d,%d", stCurrentTime.wHour, stCurrentTime.wMinute, stCurrentTime.wSecond);
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SWITCH_FAST_SCREEN(BOOL bFastScreenOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "DISPlay:MODE");

	if (bFastScreenOn == TRUE)
		sprintf_s(m_szCommand, "%s FAST", m_szCommand);
	else
		sprintf_s(m_szCommand, "%s TRACK", m_szCommand);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_GPIB_LOG_ON(BOOL bLogOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SYST:LOG:UI:CLEAR");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "SYST:LOG:UI:GPIB:STAT");

		if (bLogOn == TRUE)
			sprintf_s(m_szCommand, "%s ON", m_szCommand);
		else
			sprintf_s(m_szCommand, "%s OFF", m_szCommand);

		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SEND_OPC(VOID)
{
	INT		iCurrCount = 0, iMaxCount = 200;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	sprintf_s(m_szCommand, "*OPC?");

	for (iCurrCount = 0; iCurrCount < iMaxCount; iCurrCount++)
	{
		memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

		m_nErrCode = Query(m_szCommand, m_szReadBuffer);
		if (m_nErrCode == GPIB_SUCCESS)
		{
			if (1 == atoi(m_szReadBuffer))
			{
				m_nErrCode = GPIB_SUCCESS;
				break;
			}
			else
			{
				m_nErrCode = GPIB_READ_FAIL;
				Sleep(50);
				continue;
			}
		}
		else
		{
			m_nErrCode = GPIB_READ_FAIL;
			Sleep(50);
			continue;
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_RESET_CABLELOSS(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SYST:CORR:SFR");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "SYST:CORR:SGA");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_CABLELOSS(double dLossFreq[], double dLossGain[], INT iLossCount)
{
	INT		i = 0, iMaxLossCount = 20;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iLossCount > iMaxLossCount)
		iLossCount = iMaxLossCount;

	//Step1. Cable Loss Frequency Value
	sprintf_s(m_szCommand, "SYST:CORR:SFR");

	for (i = 0; i < iLossCount; i++)
	{
		if (i == 0)
		{
			sprintf_s(m_szCommand, "%s %.2f MHZ", m_szCommand, dLossFreq[i]);
		}
		else
		{
			sprintf_s(m_szCommand, "%s, %.2f MHZ", m_szCommand, dLossFreq[i]);
		}
	}
	m_nErrCode = Write(m_szCommand);

	//Step2. Set Cable Loss Gain Value
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "SYST:CORR:SGA");

		for (i = 0; i < iLossCount; i++)
		{
			if (i == 0)
			{
				sprintf_s(m_szCommand, "%s %.2f", m_szCommand, dLossGain[i]);
			}
			else
			{
				sprintf_s(m_szCommand, "%s, %.2f", m_szCommand, dLossGain[i]);
			}
		}
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_CABLELOSS_STATE(CHAR* cState)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SYST:CORR:STAT");

	if ((0 == _stricmp(cState, "ON")) || (0 == _stricmp(cState, "COMMON")))
	{
		sprintf_s(m_szCommand, "%s ON", m_szCommand);
	}
	else if (0 == _stricmp(cState, "OFF"))
	{
		sprintf_s(m_szCommand, "%s OFF", m_szCommand);
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_RF_CONNECTOR(INT iRFConnector)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_QUERY_CURR_APP(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "SYST:CURR:TA:MOD?");
	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_APP_SECADDR(INT iAddr, INT iOptIndex)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_QUERY_APP_SECADDR(CHAR *cAPPList)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SELECT_APPLICATION(CHAR* cAppName)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SYSTEM:APPLICATION:FORMAT:NAME");

	if (0 == _stricmp(cAppName, "GSM"))
	{
		sprintf_s(m_szCommand, "%s \'GSM/GPRS\'", m_szCommand);
		sprintf_s(m_cFormatType, "GSM");
	}
	else if (0 == _stricmp(cAppName, "WCDMA") || 0 == _stricmp(cAppName, "HSDPA"))//mzlin 20090702
	{
		sprintf_s(m_szCommand, "%s \'WCDMA\'", m_szCommand);
		sprintf_s(m_cFormatType, "WCDMA");
	}
	else
	{
		sprintf_s(m_szCommand, "%s \'GSM/GPRS\'", m_szCommand);			//Set GSM/GPRS as default
		sprintf_s(m_cFormatType, "GSM");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SELECT_SCREEN(CHAR* cScreenName)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_QUERY_SCREEN(CHAR* cValue)
{
	return GPIB_SUCCESS;
}

/*****		Instrument set call to UE		*****/
INT C8960::RRT_SET_MOCALL(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if ((m_iCurrCallProcessMode == CALLPROCESS_ON) && (m_iCurrModulationMode == MODULATION_ON))
	{
		if (m_iCurrOperMode == GMSK_MODE)
		{
			sprintf_s(m_szCommand, "CALL:ORIG");
		}
		else if (m_iCurrOperMode == EPSK_MODE)
		{
			sprintf_s(m_szCommand, "CALL:FUNC:DATA:START");
		}
		else if (m_iCurrOperMode == WCDMA_MODE)
		{
			sprintf_s(m_szCommand, "CALL:ORIG");
		}

		m_nErrCode = Write(m_szCommand);
	}
	else
	{
		m_nErrCode = GPIB_WRITE_FAIL;
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_ENDCALL(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if ((m_iCurrCallProcessMode == CALLPROCESS_ON) && (m_iCurrModulationMode == MODULATION_ON))
	{
		if (m_iCurrOperMode == GMSK_MODE)
		{
			sprintf_s(m_szCommand, "CALL:END");
		}
		else if (m_iCurrOperMode == EPSK_MODE)
		{
			sprintf_s(m_szCommand, "CALL:FUNC:DATA:STOP");
		}
		else if (m_iCurrOperMode == WCDMA_MODE)
		{
			sprintf_s(m_szCommand, "CALL:END");
		}

		m_nErrCode = Write(m_szCommand);
	}
	else
	{
		m_nErrCode = GPIB_WRITE_FAIL;
	}

	return m_nErrCode;
}

INT C8960::RRT_QUERY_CALLSTATUS(CHAR* cStatus)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	if (m_iCurrOperMode == GMSK_MODE)
	{
		sprintf_s(m_szCommand, "CALL:STAT?");
	}
	else if (m_iCurrOperMode == EPSK_MODE)
	{
		sprintf_s(m_szCommand, "CALL:STAT:DATA?");
	}
	else if (m_iCurrOperMode == WCDMA_MODE)
	{
		sprintf_s(m_szCommand, "CALL:STAT?");
	}
	else if (m_iCurrOperMode == HSDPA_MODE)//mzlin 20091204
	{
		sprintf_s(m_szCommand, "CALL:STAT?");
	}
	else if (m_iCurrOperMode == TDSCDMA_MODE)//mzlin 20091204
	{
		sprintf_s(m_szCommand, "CALL:STAT?");
	}
	else if (m_iCurrOperMode == TD_HSDPA_MODE)//mzlin 20091204
	{
		sprintf_s(m_szCommand, "CALL:STAT?");
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	strcpy_s(cStatus, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SERVICE_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:PAG:SERV:TYPE");

	if (0 == _stricmp(cType, "TEST"))
	{
		sprintf_s(m_szCommand, "%s RBTest", m_szCommand);
	}
	else if (0 == _stricmp(cType, "VOICE"))
	{
		sprintf_s(m_szCommand, "%s AMR", m_szCommand);
	}

	m_nErrCode = Write(m_szCommand);

	if ((m_nErrCode == GPIB_SUCCESS) && (0 == _stricmp(cType, "TEST")))
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "CALL:RLC:REES OFF");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_TESTLOOPMODE(CHAR* cMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:MS:LOOP:TYPE");

	if (0 == _stricmp(cMode, "MODE1"))
	{
		sprintf_s(m_szCommand, "%s TYPE1", m_szCommand);
	}
	else if (0 == _stricmp(cMode, "MODE2"))
	{
		sprintf_s(m_szCommand, "%s TYPE2", m_szCommand);
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_3GPP_PRESET(VOID)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_HANDOVER_TARGET(INT iBandIndex)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		if (m_iCurrOperMode == GMSK_MODE)
		{
			sprintf_s(m_szCommand, "CALL:SET:TCH:BAND");
			switch(iBandIndex)
			{
			case Band_GSM:
				sprintf_s(m_szCommand, "%s EGSM", m_szCommand);
				break;
			case Band_GSM850:
				sprintf_s(m_szCommand, "%s GSM850", m_szCommand);
				break;
			case Band_DCS:
				sprintf_s(m_szCommand, "%s DCS", m_szCommand);
				break;
			case Band_PCS:
				sprintf_s(m_szCommand, "%s PCS", m_szCommand);
				break;
			}
			m_nErrCode = Write(m_szCommand);
		}
		else if (m_iCurrOperMode == EPSK_MODE)
		{
			sprintf_s(m_szCommand, "CALL:SET:PDTCH:BAND");
			switch(iBandIndex)
			{
			case Band_GSM:
				sprintf_s(m_szCommand, "%s EGSM", m_szCommand);
				break;
			case Band_GSM850:
				sprintf_s(m_szCommand, "%s GSM850", m_szCommand);
				break;
			case Band_DCS:
				sprintf_s(m_szCommand, "%s DCS", m_szCommand);
				break;
			case Band_PCS:
				sprintf_s(m_szCommand, "%s PCS", m_szCommand);
				break;
			}
			m_nErrCode = Write(m_szCommand);
		}
		else if (m_iCurrOperMode == WCDMA_MODE)
		{
			sprintf_s(m_szCommand, "CALL:SET:HAND:SYST:TYPE GSM");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "CALL:BAND");
				switch(iBandIndex)
				{
				case Band_GSM:
					sprintf_s(m_szCommand, "%s EGSM", m_szCommand);
					break;
				case Band_GSM850:
					sprintf_s(m_szCommand, "%s GSM850", m_szCommand);
					break;
				case Band_DCS:
					sprintf_s(m_szCommand, "%s DCS", m_szCommand);
					break;
				case Band_PCS:
					sprintf_s(m_szCommand, "%s PCS", m_szCommand);
					break;
				}
				m_nErrCode = Write(m_szCommand);
			}

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "CALL:TCH:BAND");

				switch(iBandIndex)
				{
				case Band_GSM:
					sprintf_s(m_szCommand, "%s EGSM", m_szCommand);
					break;
				case Band_GSM850:
					sprintf_s(m_szCommand, "%s GSM850", m_szCommand);
					break;
				case Band_DCS:
					sprintf_s(m_szCommand, "%s DCS", m_szCommand);
					break;
				case Band_PCS:
					sprintf_s(m_szCommand, "%s PCS", m_szCommand);
					break;
				}
				m_nErrCode = Write(m_szCommand);
			}
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_HANDOVER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrOperMode == WCDMA_MODE)
	{
		sprintf_s(m_szCommand, "CALL:HAND:SYST");
	}
	else if ((m_iCurrOperMode == EPSK_MODE) || (m_iCurrOperMode == GMSK_MODE))
	{
		sprintf_s(m_szCommand, "CALL:HAND:IMM");
	}

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_SET_HANDOVER_ALERT_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:SET:SYST:GSM:ALER");

	if (bMode == TRUE)
	{
		sprintf_s(m_szCommand, "%s ON", m_szCommand);
	}
	else
	{
		sprintf_s(m_szCommand, "%s OFF", m_szCommand);
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_HANDOVER_WAIT_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:HAND:SYST:RLC:WAIT");

	if (bMode == TRUE)
	{
		sprintf_s(m_szCommand, "%s ON", m_szCommand);
	}
	else
	{
		sprintf_s(m_szCommand, "%s OFF", m_szCommand);
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_CLEAR_STATUS(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "*CLS");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_NCC(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:CELL:NCCODE %d", iCode);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_BCC(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:CELL:BCCODE %d", iCode);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_LOOPBACK_ON(BOOL bLoopOn)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_LOOPBACK_TYPE(INT iLoopType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrOperMode == GMSK_MODE)
	{
		switch(iLoopType)
		{
		case LBT_TYPEA:
			sprintf_s(m_szCommand, "CALL:TCH:LOOP A");
			break;
		case LBT_TYPEB:
			sprintf_s(m_szCommand, "CALL:TCH:LOOP B");
			break;
		case LBT_TYPEC:
			sprintf_s(m_szCommand, "CALL:TCH:LOOP C");
		}

		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_TIMESLOT(INT iSlotNumber)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrOperMode == GMSK_MODE)
	{
		sprintf_s(m_szCommand, "CALL:TCH:TSL %d", iSlotNumber);
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_BITOFFSET(INT iBitOffsetType)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_FAST_MEASURE_MODE(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_RF_CONNECTOR_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (0 == _stricmp(cType, "MAIN"))
	{
		sprintf_s(m_szCommand, "RFG:OUTP IO");
	}
	else if (0 == _stricmp(cType, "AUX"))
	{
		sprintf_s(m_szCommand, "RFG:OUTP OUT");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_QUERY_CALLSTATUS_V2(CHAR* cMode, INT iQueryType)
{
	CHAR	sz_QueryResult[1024] = {0x00};
	m_nErrCode = GPIB_SUCCESS;

	if (0 == _stricmp(cMode, "GSM"))
	{
		switch(iQueryType)
		{
		case CS_IDLE:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "IDLE"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = FALSE;
			}
			break;
		case CS_CONNECTED:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "CONN"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = TRUE;
			}
			break;
		case CS_ALERTING:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "ALER"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = FALSE;
			}
			break;
		}
	}
	else if (0 == _stricmp(cMode, "EDGE"))
	{
		switch(iQueryType)
		{
		case CS_IDLE:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "IDLE"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = FALSE;
			}
			break;
		case CS_ATTACHED:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "ATT"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = FALSE;
			}
			break;
		case CS_TRANSFERRING:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "TRAN"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = TRUE;
			}
			break;
		}
	}
	else if (0 == _stricmp(cMode, "WCDMA"))
	{
		switch(iQueryType)
		{
		case CS_IDLE:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "IDLE"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = FALSE;
			}
			break;
		case CS_REGISTERED:
			memset(m_szCommand, 0x00, sizeof(m_szCommand));
			sprintf_s(m_szCommand, "CALL:STAT:MM?");

			m_nErrCode = Query(m_szCommand, sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "MMSTATUS3"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = FALSE;
			}
			break;
		case CS_CONNECTED:
			m_nErrCode = RRT_QUERY_CALLSTATUS(sz_QueryResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (0 != _stricmp(sz_QueryResult, "CONN"))
					m_nErrCode = GPIB_QUERY_FAIL;
				else
					m_bIsCallConnected = TRUE;
			}
			break;
		}
	}
	return m_nErrCode;
}

INT C8960::RRT_QUERY_RFG_CALIB_DATE(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}
/**********		End -- Common Functions		**********/

/**********		Start -- Setting Functions		**********/
INT C8960::RRT_SET_ALL_MEASURE_OFF(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "ABORt:ALL");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_CALLPROCESS_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;

	if (bModeOn == TRUE)
		m_iCurrCallProcessMode = CALLPROCESS_ON;
	else
		m_iCurrCallProcessMode = CALLPROCESS_OFF;

	return m_nErrCode;
}

INT C8960::RRT_SET_MODULATION_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;

	if (bModeOn == TRUE)
		m_iCurrModulationMode =	MODULATION_ON;
	else
		m_iCurrModulationMode =	MODULATION_OFF;

	return m_nErrCode;
}

INT C8960::RRT_SET_OPERATION_MODE(INT iOpeMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iOpeMode == OFF_MODE)
	{
		sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE OFF");
		m_nErrCode = Write(m_szCommand);
		return m_nErrCode;
	}

	m_iCurrOperMode = iOpeMode;

	if (m_iCurrModulationMode == MODULATION_OFF)
	{
		sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE CW");
	}
	else
	{
		if (m_iCurrCallProcessMode == CALLPROCESS_ON)
		{
			switch(iOpeMode)
			{
			case GMSK_MODE:
				sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE OFF");
				m_nErrCode = Write(m_szCommand);

				if (m_nErrCode == GPIB_SUCCESS)
				{
					memset(m_szCommand, 0x00, sizeof(m_szCommand));

					sprintf_s(m_szCommand, "CALL:CELL:BCHANNEL:SCELL GSM");
					m_nErrCode = Write(m_szCommand);
				}

				if (m_nErrCode == GPIB_SUCCESS)
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE CALL");

				break;

			case GPRS_MODE:
				sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE OFF");
				m_nErrCode = Write(m_szCommand);

				if (m_nErrCode == GPIB_SUCCESS)
				{
					memset(m_szCommand, 0x00, sizeof(m_szCommand));

					sprintf_s(m_szCommand, "CALL:CELL:BCHANNEL:SCELL GPRS");
					m_nErrCode = Write(m_szCommand);
				}

				if (m_nErrCode == GPIB_SUCCESS)
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE CALL");

				break;

			case EPSK_MODE:
				sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE OFF");
				m_nErrCode = Write(m_szCommand);

				if (m_nErrCode == GPIB_SUCCESS)
				{
					memset(m_szCommand, 0x00, sizeof(m_szCommand));

					sprintf_s(m_szCommand, "CALL:CELL:BCHANNEL:SCELL EGPRS");
					m_nErrCode = Write(m_szCommand);
				}

				if (m_nErrCode == GPIB_SUCCESS)
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE CALL");

				break;

			case WCDMA_MODE:
				sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE CALL");
				break;
			}
		}
		else
		{
			switch(iOpeMode)
			{
			case GMSK_MODE:
				switch(m_iCurrOutputPattern)
				{
				case PATTERN_BCH:
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE GBTest");
					break;

				case PATTERN_TCH:
				case PATTERN_BCHTCH:
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE GBTTest");
					break;
				}
				break;

			case GPRS_MODE:
				switch(m_iCurrOutputPattern)
				{
				case PATTERN_BCH:
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE PBTest");
					break;
				case PATTERN_TCH:
				case PATTERN_BCHTCH:
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE PBPTest");
					break;
				}
				break;

			case EPSK_MODE:
				switch(m_iCurrOutputPattern)
				{
				case PATTERN_BCH:
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE EBTest");
					break;
				case PATTERN_TCH:
				case PATTERN_BCHTCH:
					sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE EBPTest");
					break;
				}
				break;

			case WCDMA_MODE:
				sprintf_s(m_szCommand, "CALL:CELL:OPER:MODE FDDT");
				break;
			}
		}
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_TSC(INT iTSC)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:BURS:TYPE TSC%d", iTSC);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_BCH_BAND(INT iBandIndex)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:CELL:BAND");

	switch(iBandIndex)
	{
	case Band_GSM850:
		sprintf_s(m_szCommand, "%s GSM850", m_szCommand);
		break;
	case Band_GSM:
		sprintf_s(m_szCommand, "%s EGSM", m_szCommand);
		break;
	case Band_DCS:
		sprintf_s(m_szCommand, "%s DCS", m_szCommand);
		break;
	case Band_PCS:
		sprintf_s(m_szCommand, "%s PCS", m_szCommand);
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_TCH_BAND(INT iBandIndex)
{
	CHAR		cTargetBand[10] = {0x00};
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	m_iCurrBand = iBandIndex;

	switch(iBandIndex)
	{
	case Band_GSM850:
		sprintf_s(cTargetBand, "GSM850");
		break;
	case Band_GSM:
		sprintf_s(cTargetBand, "EGSM");
		break;
	case Band_DCS:
		sprintf_s(cTargetBand, "DCS");
		break;
	case Band_PCS:
		sprintf_s(cTargetBand, "PCS");
		break;
	}

	if (m_iCurrOperMode == GMSK_MODE)
		sprintf_s(m_szCommand, "CALL:TCH:BAND?");
	else if (m_iCurrOperMode == EPSK_MODE)
		sprintf_s(m_szCommand, "CALL:PDTCH:BAND?");
	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		if (0 != _stricmp(m_szReadBuffer, cTargetBand))
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			if (m_iCurrOperMode == GMSK_MODE)
				sprintf_s(m_szCommand, "CALL:TCH:BAND %s", cTargetBand);
			else if (m_iCurrOperMode == EPSK_MODE)
				sprintf_s(m_szCommand, "CALL:PDTCH:BAND %s", cTargetBand);

			m_nErrCode = Write(m_szCommand);
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_BCH_ARFCN(INT iArfcn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:BCH:ARFCN %d", iArfcn);

	m_nErrCode = Write(m_szCommand);

	m_iCurrBCHArfcn = iArfcn;

	return m_nErrCode;
}

INT C8960::RRT_SET_TCH_ARFCN(INT iArfcn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		if (m_bIsCallConnected == TRUE)
		{
			if (m_iCurrOperMode == GMSK_MODE)
				sprintf_s(m_szCommand, "CALL:SET:TCH:ARFCN %d", iArfcn);
			else if (m_iCurrOperMode == EPSK_MODE)
				sprintf_s(m_szCommand, "CALL:SET:PDTCH:ARFCN %d", iArfcn);

			m_nErrCode = Write(m_szCommand);

			if ((m_nErrCode == GPIB_SUCCESS) && (m_bIsHandoverSetting == FALSE))
			{
				m_nErrCode = RRT_SET_HANDOVER();
				m_nErrCode = RRT_SET_HANDOVER();
			}
		}
		else
		{
			if (m_iCurrOperMode == GMSK_MODE)
				sprintf_s(m_szCommand, "CALL:TCH:ARFCN %d", iArfcn);
			else if (m_iCurrOperMode == EPSK_MODE)
				sprintf_s(m_szCommand, "CALL:PDTCH:ARFCN %d", iArfcn);

			m_nErrCode = Write(m_szCommand);
		}
	}
	else
	{
		if (m_iCurrOperMode == GMSK_MODE)
			sprintf_s(m_szCommand, "CALL:TCH:ARFCN %d", iArfcn);
		else if (m_iCurrOperMode == EPSK_MODE)
			sprintf_s(m_szCommand, "CALL:PDTCH:ARFCN %d", iArfcn);

		m_nErrCode = Write(m_szCommand);
	}

	m_iCurrTCHArfcn = iArfcn;

	return m_nErrCode;
}

INT C8960::RRT_SET_BSPOWER(double dPowerLev)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:POWer %.2f", dPowerLev);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_BSPOWER_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bModeOn == TRUE)
		sprintf_s(m_szCommand, "CALL:POW:STAT ON");
	else if (bModeOn == FALSE)
		sprintf_s(m_szCommand, "CALL:POW:STAT OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_AUTO_EXPECTED_POWER(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bModeOn == TRUE)
		sprintf_s(m_szCommand, "RFAN:CONT:POW:AUTO ON");
	else if (bModeOn == FALSE)
		sprintf_s(m_szCommand, "RFAN:CONT:POW:AUTO OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_EXPECTED_POWER(INT iSlot, double dPowerLev)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrModulationMode == MODULATION_OFF)
	{
		sprintf_s(m_szCommand, "RFAN:CW:EXP:POWer %.2f", dPowerLev);
	}
	else
	{
		if (m_iCurrOperMode == GMSK_MODE)
		{
			sprintf_s(m_szCommand, "RFAN:MAN:POW:BURS %.2f", dPowerLev);
		}
		else if (m_iCurrOperMode == EPSK_MODE)
		{
			sprintf_s(m_szCommand, "RFAN:MAN:POW:BURS%d %.2f", iSlot, dPowerLev);
		}
		else if (m_iCurrOperMode == WCDMA_MODE)
		{
			sprintf_s(m_szCommand, "RFAN:MAN:POW %.2f", dPowerLev);
		}
	}

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		if (m_iCurrOperMode == WCDMA_MODE)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));
			sprintf_s(m_szCommand, "CALL:MS:POW:TARG:AMPL %.2f", dPowerLev);
			m_nErrCode = Write(m_szCommand);
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_EXPECTED_POWER_LEVEL(INT iSlot, INT iPCL)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	m_iEPSKSlotUsed = iSlot;

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		if (m_bIsCallConnected == TRUE)
		{
			if (m_iCurrOperMode == GMSK_MODE)
				sprintf_s(m_szCommand, "CALL:SET:TCH:MS:TXL %d", iPCL);
			else if (m_iCurrOperMode == EPSK_MODE)
				sprintf_s(m_szCommand, "CALL:SET:PDTCH:MS:TXL:BURS%d %d", iSlot, iPCL);

			m_nErrCode = Write(m_szCommand);

			if ((m_nErrCode == GPIB_SUCCESS) && (m_bIsHandoverSetting == FALSE))
			{
				m_nErrCode = RRT_SET_HANDOVER();
				if (m_iCurrBand == Band_PCS)
				{
					Sleep(500);
					m_nErrCode = RRT_SET_HANDOVER();
				}
			}
		}
		else
		{
			if (m_iCurrOperMode == GMSK_MODE)
				sprintf_s(m_szCommand, "CALL:MS:TXL %d", iPCL);
			else if (m_iCurrOperMode == EPSK_MODE)
				sprintf_s(m_szCommand, "CALL:PDTCH:MS:TXL:BURS%d %d", iSlot, iPCL);

			m_nErrCode = Write(m_szCommand);
		}
	}
	else
	{
		if (m_iCurrOperMode == GMSK_MODE)
			sprintf_s(m_szCommand, "CALL:MS:TXL %d", iPCL);
		else if (m_iCurrOperMode == EPSK_MODE)
			sprintf_s(m_szCommand, "CALL:PDTCH:MS:TXL:BURS%d %d", iSlot, iPCL);

		m_nErrCode = Write(m_szCommand);
	}

	m_iCurrPCL = iPCL;

	return m_nErrCode;
}

INT C8960::RRT_SET_SPEECH_SOURCE(CHAR* cSourceStr)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:TCH:DOWN:SPE");

	if (0 == _stricmp(cSourceStr, "ECHO"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "ECHO");
	else if (0 == _stricmp(cSourceStr, "PRBS9"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "PRBS9");
	else if (0 == _stricmp(cSourceStr, "PRBS15"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "PRBS15");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_CODE_SCHEME(CHAR* cCodeScheme)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	sprintf_s(m_cMCSUsing, "%s", cCodeScheme);

	if (m_iCurrOperMode == EPSK_MODE)
	{
		if (m_iCurrCallProcessMode == CALLPROCESS_ON)
		{
			if (m_bIsCallConnected == FALSE)
				sprintf_s(m_szCommand, "CALL:PDTC:MCSC");
			else
				sprintf_s(m_szCommand, "CALL:SET:PDTCH:MCSC");

			if (0 == _stricmp(cCodeScheme, "MCS1"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS1", "MCS1");
			else if (0 == _stricmp(cCodeScheme, "MCS2"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS2", "MCS2");
			else if (0 == _stricmp(cCodeScheme, "MCS3"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS3", "MCS3");
			else if (0 == _stricmp(cCodeScheme, "MCS4"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS4", "MCS4");
			else if (0 == _stricmp(cCodeScheme, "MCS5"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS5", "MCS5");
			else if (0 == _stricmp(cCodeScheme, "MCS6"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS6", "MCS6");
			else if (0 == _stricmp(cCodeScheme, "MCS7"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS7", "MCS7");
			else if (0 == _stricmp(cCodeScheme, "MCS8"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS8", "MCS8");
			else if (0 == _stricmp(cCodeScheme, "MCS9"))
				sprintf_s(m_szCommand, "%s %s, %s", m_szCommand, "MCS9", "MCS9");
		}
		else
		{
			sprintf_s(m_szCommand, "CALL:PDTC:MCSC:EBPT");

			if (0 == _stricmp(cCodeScheme, "MCS1"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS1", "P1");
			else if (0 == _stricmp(cCodeScheme, "MCS2"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS2", "P1");
			else if (0 == _stricmp(cCodeScheme, "MCS3"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS3", "P1");
			else if (0 == _stricmp(cCodeScheme, "MCS4"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS4", "P1");
			else if (0 == _stricmp(cCodeScheme, "MCS5"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS5", "P1");
			else if (0 == _stricmp(cCodeScheme, "MCS6"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS6", "P1");
			else if (0 == _stricmp(cCodeScheme, "MCS7"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS7", "P1_1");
			else if (0 == _stricmp(cCodeScheme, "MCS8"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS8", "P1_1");
			else if (0 == _stricmp(cCodeScheme, "MCS9"))
				sprintf_s(m_szCommand, "%s %s%s", m_szCommand, "MCS9", "P1_1");
		}
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_MODULATION_CONTROL_AUTO(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
		sprintf_s(m_szCommand, "CALL:MOD:CONT:AUTO ON");
	else
		sprintf_s(m_szCommand, "CALL:MOD:CONT:AUTO OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_MULTISLOT_CONFIG(INT iUpSlot, INT iDownSlot)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	m_iULSlotCount = iUpSlot;
	m_iDLSlotCount = iDownSlot;

	if ((m_iCurrOperMode == GPRS_MODE) || (m_iCurrOperMode == EPSK_MODE))
	{
		if (m_bIsCallConnected == FALSE)
			sprintf_s(m_szCommand, "CALL:PDTCH:MSL:CONF D%dU%d", iDownSlot, iUpSlot);
		else
			sprintf_s(m_szCommand, "CALL:SET:PDTCH:MSL:CONF D%dU%d", iDownSlot, iUpSlot);

		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_MEASURE_OBJECT(INT iSlot, CHAR* cMeasObj)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (0 == _stricmp(cMeasObj, "GMSK"))
		sprintf_s(m_szCommand, "CALL:MOD:MAN:BURS%d GMSK", iSlot);
	else if ((0 == _stricmp(cMeasObj, "EPSK")) || (0 == _stricmp(cMeasObj, "8PSK")))
		sprintf_s(m_szCommand, "CALL:MOD:MAN:BURS%d EPSK", iSlot);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_OUTPUT_PATTERN(CHAR* cPattern)
{
	m_nErrCode = GPIB_SUCCESS;

	if (0 == _stricmp(cPattern, "BCH"))
		m_iCurrOutputPattern = PATTERN_BCH;
	else if (0 == _stricmp(cPattern, "TCH"))
		m_iCurrOutputPattern = PATTERN_TCH;
	else if (0 == _stricmp(cPattern, "BCHTCH"))
		m_iCurrOutputPattern = PATTERN_BCHTCH;

	return m_nErrCode;
}

INT C8960::RRT_SET_RFG_FREQ_AUTO(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
		sprintf_s(m_szCommand, "CALL:CONT:DOWN:FREQ:AUTO ON");
	else
		sprintf_s(m_szCommand, "CALL:CONT:DOWN:FREQ:AUTO OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_RFG_FREQ(double dFreqMHz)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:RFG:FREQ %.2f MHz", dFreqMHz);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_RFG_BURSTTYPE(CHAR *cType)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_RFAN_FREQ_AUTO(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
	{
		sprintf_s(m_szCommand, "RFAN:CONT:MEAS:FREQ:AUTO ON");
		m_nErrCode = Write(m_szCommand);
	}
	else
	{
		sprintf_s(m_szCommand, "RFAN:CONT:MEAS:FREQ:AUTO OFF");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
	{
		if (bMode == TRUE)
		{
			sprintf_s(m_szCommand, "RFAN:CONT:UPL:FREQ:AUTO ON");
			m_nErrCode = Write(m_szCommand);
		}
		else
		{
			sprintf_s(m_szCommand, "RFAN:CONT:UPL:FREQ:AUTO OFF");
			m_nErrCode = Write(m_szCommand);
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_RFAN_FREQ(double dFreqMHz)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "RFAN:MAN:MEAS:FREQ %.2f MHz", dFreqMHz);
	m_nErrCode = Write(m_szCommand);

	if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
	{
		sprintf_s(m_szCommand, "RFAN:MAN:UPL:FREQ %.2f MHz", dFreqMHz);
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_RFAN_ATTENUATION(INT iType)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_TPC_TYPE(INT iIndex, CHAR* cPattern)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_WB_TPC_PATTERN(CHAR* cPattern)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrOperMode == WCDMA_MODE)
	{
		if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
		{
			sprintf_s(m_szCommand, "CALL:FDDT:CLPC:UPL:MODE");
		}
		else if (m_iCurrCallProcessMode == CALLPROCESS_ON)
		{
			sprintf_s(m_szCommand, "CALL:CLPC:UPL:MODE");
		}

		if (0 == _stricmp(cPattern, "ALL0"))
			sprintf_s(m_szCommand, "%s %s", m_szCommand, "DOWN");
		else if (0 == _stricmp(cPattern, "ALL1"))
			sprintf_s(m_szCommand, "%s %s", m_szCommand, "UP");
		else if (0 == _stricmp(cPattern, "ILPC"))
			sprintf_s(m_szCommand, "%s %s", m_szCommand, "ACT");
		else if (0 == _stricmp(cPattern, "ALT"))
			sprintf_s(m_szCommand, "%s %s", m_szCommand, "UDOW");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_TPC_STEPSIZE(INT iStepsize)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrOperMode == WCDMA_MODE)
	{
		if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
		{
			sprintf_s(m_szCommand, "CALL:FDDT:CLPC:UPL:STEP %d dB", iStepsize);
		}
		else if (m_iCurrCallProcessMode == CALLPROCESS_ON)
		{
			if (m_bIsCallConnected == FALSE)
				sprintf_s(m_szCommand, "CALL:CLPC:UPL:STEP %d dB", iStepsize);
		}
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_TPC_ALGORITHM(INT iALG)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrOperMode == WCDMA_MODE)
	{
		if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
		{
			sprintf_s(m_szCommand, "CALL:FDDT:CLPC:UPL:ALG ALG%d", iALG);
		}
		else if (m_iCurrCallProcessMode == CALLPROCESS_ON)
		{
			if (m_bIsCallConnected == FALSE)
				sprintf_s(m_szCommand, "CALL:CLPC:UPL:ALG ALG%d", iALG);
		}
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ACTIVATE_TPC_PATTERN(VOID)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_WB_CHANNEL(INT iDLChannel, INT iUPChannel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
	{
		sprintf_s(m_szCommand, "CALL:UPL:CHAN:CONT:AUTO ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));
			sprintf_s(m_szCommand, "CALL:CHAN %d", iDLChannel);

			m_nErrCode = Write(m_szCommand);
		}
	}
	else
	{
		if (m_bIsCallConnected == TRUE)
		{
			sprintf_s(m_szCommand, "CALL:HAND:TCR:CHAN:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));
				sprintf_s(m_szCommand, "CALL:SET:TCR:CHAN:DOWN %d", iDLChannel);
				m_nErrCode = Write(m_szCommand);
			}

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));
				sprintf_s(m_szCommand, "CALL:HAND:TCR:IMM");
				m_nErrCode = Write(m_szCommand);
			}
		}
		else
		{
			m_nErrCode = RRT_SET_OPERATION_MODE(OFF_MODE);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(m_szCommand, "CALL:UPL:CHAN:CONT:AUTO ON");
				m_nErrCode = Write(m_szCommand);
			}

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));
				sprintf_s(m_szCommand, "CALL:CHAN %d", iDLChannel);

				m_nErrCode = Write(m_szCommand);
			}

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_OPERATION_MODE(WCDMA_MODE);
		}
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_SET_SPECTRUM_MONITOR_TRIGGER(CHAR* cMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:SMON:TRIG:SOUR");

	if (0 == _stricmp(cMode, "FREE"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "IMM");
	else if (0 == _stricmp(cMode, "PROTOCOL"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "PROT");
	else if (0 == _stricmp(cMode, "RISEVIDEO"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "RISE");
	else if (0 == _stricmp(cMode, "EXTERNAL"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "EXT");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_TDMEAS_TRIGGER(CHAR* cMode)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_TRIGGER(CHAR* cMode, CHAR *cSlope, double dThreshold)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_SPECTRUM_MONITOR_TRIGGER_DELAY(double dDelay_ms)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:SMON:TRiG:DEL %.2fMS", dDelay_ms);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_TDMEAS_TRIGGER_DELAY(double dDelay_ms)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_TRIGGER_DELAY(double dDelay_ms)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_SLOTPOWER_STARTTIME(double dTime_us)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:WDPA:TRIG:DEL %.2f US", dTime_us);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_SLOTPOWER_DURATION(double dTimeperiod_us)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:WDPA:INT %f US", dTimeperiod_us);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_FASTPOWER_MEAS_MODE_ON(BOOL bMode)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_SLOTPOWER_MEAS_ON(BOOL bMode)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_SLOTPOWER_MEASSLOT(INT iStartslot, INT iEndslot)
{
	INT		iNumberOfSlot = 0;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	iNumberOfSlot = iEndslot - iStartslot + 1;

	sprintf_s(m_szCommand, "SET:WDPA:STEP %d", iNumberOfSlot);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_SLOTPOWER_DEL_SLOT(INT iStartslot, INT iEndslot)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_SLOTPOWER_THRESHOLD(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:WDPA:TRIG:THR %f", dLevel);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_TDMEAS_TIMESPAN(double dTimespan_ms)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_TDMEAS_RRC_FILTER_ON(BOOL bMode)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_VIDEO_FILTER_LENGTH(double dLength_us)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_WB_DTCH_DATATYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:DTCH:DATA");

	if (0 == _stricmp(cType, "ALL0"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "ZER");
	else if (0 == _stricmp(cType, "ALL1"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "ONES");
	else if (0 == _stricmp(cType, "PN9"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "PRBS9");
	else if (0 == _stricmp(cType, "PN15"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "PRBS15");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_PRIMARY_SCRAMBING_CODE(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:CELL:SCOD:PRIM %d", iCode);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_CPICH_STATE_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:CPIC:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:CPIC:STAT OFF");
	}
	else if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:FDDT:CPIC:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:FDDT:CPIC:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_CPICH_LEVEL(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		sprintf_s(m_szCommand, "CALL:CPIC:LEV %.2f", dLevel);
	}
	else if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
	{
		sprintf_s(m_szCommand, "CALL:FDDT:CPIC:LEV %.2f", dLevel);
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_PRIMARY_CCPC_STATE_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:CCPC:PRIM:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:CCPC:PRIM:STAT OFF");
	}
	else if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:FDDT:CCPC:PRIM:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:FDDT:CCPC:PRIM:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_PRIMARY_CCPC_LEVEL(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		sprintf_s(m_szCommand, "CALL:CCPC:PRIM:LEV %.2f", dLevel);
	}
	else if (m_iCurrCallProcessMode == CALLPROCESS_OFF)
	{
		sprintf_s(m_szCommand, "CALL:FDDT:CCPC:PRIM:LEV %.2f", dLevel);
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SECONDARY_CCPCH_STATE_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
		sprintf_s(m_szCommand, "CALL:CCPC:SEC:STAT ON");
	else
		sprintf_s(m_szCommand, "CALL:CCPC:SEC:STAT OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SECONDARY_CCPCH_LEVEL(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:CCPC:SEC:LEV %.2f", dLevel);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SCH_STATE_ON(BOOL bMode)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_WB_SCH_LEVEL(double dLevel)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_WB_PICH_CODE(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:CELL:PICH:CCOD CODE%d", iCode);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_PICH_STATE_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:CELL:PICH:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:CELL:PICH:STAT OFF");
	}
	else
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:FDDT:PICH:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:FDDT:PICH:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_PICH_LEVEL(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
		sprintf_s(m_szCommand, "CALL:CELL:PICH:LEV %.2f", dLevel);
	else
		sprintf_s(m_szCommand, "CALL:FDDT:PICH:LEV %.2f", dLevel);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_DPCH_CHANNEL_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:DPCH:TYP");

	if (0 == _stricmp(cType, "RMC12"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "RMC12");
	else if (0 == _stricmp(cType, "RMC64"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "RMC64");
	else if (0 == _stricmp(cType, "RMC384"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "RMC384");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		sprintf_s(m_cDPCHType, "%s", cType);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_DPCH_CODE(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:DPCH:%s:CCOD CODE%d", m_cDPCHType, iCode);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_DPCH_STATE_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:DPCH:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:DPCH:STAT OFF");
	}
	else
	{
		if (bMode == TRUE)
			sprintf_s(m_szCommand, "CALL:FDDT:DPCH:STAT ON");
		else
			sprintf_s(m_szCommand, "CALL:FDDT:DPCH:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_DPCH_LEVEL(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrCallProcessMode == CALLPROCESS_ON)
	{
		sprintf_s(m_szCommand, "CALL:DPCH:LEV %.2f", dLevel);
	}
	else
	{
		sprintf_s(m_szCommand, "CALL:FDDT:DPCH:LEV %.2f", dLevel);
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_DPCH_SACODE(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_WB_DPCH_DOWNLINK_SEC_SCRAMBLING_CODE(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_WB_DPCH_UPLINK_SCRAMBLING_CODE(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:UPL:DPCH:SCOD %d", iCode);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AICH_CODE(INT iCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:AICH:CCOD CODE%d", iCode);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AICH_STATE_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
		sprintf_s(m_szCommand, "CALL:AICH:STAT ON");
	else
		sprintf_s(m_szCommand, "CALL:AICH:STAT OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AICH_LEVEL(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:AICH:LEV %.2f", dLevel);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_UL_GAIN_FACTOR(INT iBetaC, INT iBetaD)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:UPL:DPCH:BETA:AUT OFF");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "CALL:UPL:DPCH:MAN:CBET %d", iBetaC);
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "CALL:UPL:DPCH:MAN:DBET %d", iBetaD);
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ULDPCH_GAIN_MODE(BOOL bIsAuto)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bIsAuto == TRUE)
		sprintf_s(m_szCommand, "CALL:UPL:DPCH:BETA:AUT ON");
	else
		sprintf_s(m_szCommand, "CALL:UPL:DPCH:BETA:AUT OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DATA_CONNECTION_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:FUNC:CONN:TYPE");

	if (0 == _stricmp(cType, "AUTO"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "AUTO");
	else if (0 == _stricmp(cType, "TYPEA"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "A");
	else if (0 == _stricmp(cType, "TYPEB"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "B");
	else if (0 == _stricmp(cType, "BLER"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "BLER");
	else if (0 == _stricmp(cType, "SRB"))
		sprintf_s(m_szCommand, "%s %s", m_szCommand, "SRBL");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AUTH_KEY(CHAR* cKey)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:SEC:AUTH:KEY \'%s\'", cKey);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_MS_IMSI(CHAR* cIMSI)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	//Set as Call Off mode and clear UE information
	m_nErrCode = RRT_SET_OPERATION_MODE(OFF_MODE);

	//Set IMSI
	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "CALL:PAG:IMSI \'%s\'", cIMSI);
		m_nErrCode = Write(m_szCommand);
	}

	//Set Repeat paging must set under cell off mode
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "CALL:PAG:REP:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	//Set IMSI Attach Flag as Set, default is Not Set
	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "CALL:ATTF:STAT ON");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(WCDMA_MODE);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AUTH_STATE_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
		sprintf_s(m_szCommand, "CALL:SEC:OPER %s", "AUTHINT");
	else
		sprintf_s(m_szCommand, "CALL:SEC:OPER %s", "NONE");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_CELL_OFF(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:OPER:MODE OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_ACTIVE_SLOTPOWER_WINDOW(VOID)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_WB_ILPC_TPC_STEP(CHAR* cStep)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:WILP:SEG %s", cStep);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ILPC_TPC_COMMAND_LENGTH(CHAR *cStep, INT iLength)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ILPC_MAX_THRESHOLD(BOOL bAutoModeOn, double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_nErrCode));

	if (TRUE == bAutoModeOn)
	{
		sprintf_s(m_szCommand, "SET:WILP:MAX:POW:THR:TEST:CONT:AUTO ON");
		m_nErrCode = Write(m_szCommand);
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WILP:MAX:POW:THR:TEST:CONT:AUTO OFF");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_nErrCode));

			sprintf_s(m_szCommand, "SET:WILP:MAX:POW:THR:TEST:MAN %.2f", dLevel);
			m_nErrCode = Write(m_szCommand);
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ILPC_MIN_THRESHOLD(BOOL bAutoModeOn, double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_nErrCode));

	if (TRUE == bAutoModeOn)
	{
		sprintf_s(m_szCommand, "SET:WILP:Minimum:POW:THR:TEST:CONT:AUTO ON");
		m_nErrCode = Write(m_szCommand);
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WILP:Minimum:POW:THR:TEST:CONT:AUTO OFF");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_nErrCode));

			sprintf_s(m_szCommand, "SET:WILP:Minimum:POW:THR:TEST:MAN %.2f", dLevel);
			m_nErrCode = Write(m_szCommand);
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AWGN_STATE_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (TRUE == bModeOn)
		sprintf_s(m_szCommand, "CALL:AWGN:POW:STAT:SEL ON");
	else
		sprintf_s(m_szCommand, "CALL:AWGN:POW:STAT:SEL OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AWGN_LEVEL(double dLevel)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:AWGN:INT:POW:AMPL:SEL %.2f", dLevel);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_AM_SIGNAL_ON(BOOL bModeON)
{
	m_nErrCode = GPIB_SUCCESS;
	//Must switch to CW mode first

	if (TRUE == bModeON)
	{
		m_nErrCode = RRT_SET_MODULATION_ON(FALSE);
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = RRT_SET_OPERATION_MODE(WCDMA_MODE);

		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = RRT_SEND_OPC();

		if (m_nErrCode == GPIB_SUCCESS)
		{
			sprintf_s(m_szCommand, "CALL:WAV:TYPE:CW AM");
			m_nErrCode = Write(m_szCommand);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "CALL:WAV:TYPE:CW CW");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = RRT_SET_OPERATION_MODE(WCDMA_MODE);

		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = RRT_SEND_OPC();
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_EG_MS_IMSI(CHAR* cIMSI)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:PAG:IMSI \'%s\'", cIMSI);

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "CALL:PAG:REP ON");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_EG_BAND_INDICATOR(BOOL bIsDCSIndicator)
{
	m_nErrCode = GPIB_SUCCESS;
	m_bBandIndicatorSet = FALSE;

	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "CALL:BIND?");
	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		if ((bIsDCSIndicator == TRUE) && (0 != _stricmp(m_szReadBuffer, "DCS")))
		{
			sprintf_s(m_szCommand, "CALL:BIND DCS");
			m_nErrCode = Write(m_szCommand);
			m_bBandIndicatorSet = TRUE;
		}
		else if ((bIsDCSIndicator == FALSE) && (0 != _stricmp(m_szReadBuffer, "PCS")))
		{
			sprintf_s(m_szCommand, "CALL:BIND PCS");
			m_nErrCode = Write(m_szCommand);
			m_bBandIndicatorSet = TRUE;
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_QUERY_EG_BAND_INDICATOR(CHAR* cStatus)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "CALL:BIND?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cStatus, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_QUERY_EG_REG_STATUS(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_WB_FREQ(BOOL bIsULFreq, double dFreqMHz)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_WB_REG_TXRX_FREQ(INT iSeqNum, CHAR *cFreqstr)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_WB_REG_RX_PWR(CHAR *cRXPWr)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_WB_REG_TX_PWR(CHAR *cTXPWr)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_BSPOWER_CONTINUOUS(BOOL bContOn)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_UE_MEAS_REPORT_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

/**********		End -- Setting Functions		**********/

/**********		Start -- Measurement Functions		**********/
INT C8960::RRT_SET_POWER_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (iCount <= 1)
		{
			sprintf_s(m_szCommand, "SET:TXP:COUN:STAT OFF");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:TXP:COUN:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:TXP:COUN %d", iCount);
			}
		}
		break;

	case EPSK_MODE:
		if (iCount <= 1)
		{
			sprintf_s(m_szCommand, "SET:ETXP:COUN:STAT OFF");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:ETXP:COUN:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:ETXP:COUN %d", iCount);
			}
		}
		break;

	case WCDMA_MODE:
		if (iCount <= 1)
		{
			sprintf_s(m_szCommand, "SET:WCP:COUN:STAT OFF");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WCP:COUN:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:WCP:COUN %d", iCount);
			}
		}
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_POWER_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (iTimeoutS <= 0)
		{
			sprintf_s(m_szCommand, "SET:TXP:TIM:STAT OFF");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:TXP:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:TXP:TIM %d S", iTimeoutS);
			}
		}
		break;

	case EPSK_MODE:
		if (iTimeoutS <= 0)
		{
			sprintf_s(m_szCommand, "SET:ETXP:TIM:STAT OFF");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:ETXP:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:ETXP:TIM %d S", iTimeoutS);
			}
		}
		break;

	case WCDMA_MODE:
		if (iTimeoutS <= 0)
		{
			sprintf_s(m_szCommand, "SET:WCP:TIM:STAT OFF");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WCP:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:WCP:TIM %d S", iTimeoutS);
			}
		}
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_POWER_CONTINUOUS_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (bModeOn == TRUE)
			sprintf_s(m_szCommand, "SET:TXP:CONT ON");
		else
			sprintf_s(m_szCommand, "SET:TXP:CONT OFF");
		break;

	case EPSK_MODE:
		if (bModeOn == TRUE)
			sprintf_s(m_szCommand, "SET:ETXP:CONT ON");
		else
			sprintf_s(m_szCommand, "SET:ETXP:CONT OFF");
		break;

	case WCDMA_MODE:
		if (bModeOn == TRUE)
			sprintf_s(m_szCommand, "SET:WCP:CONT ON");
		else
			sprintf_s(m_szCommand, "SET:WCP:CONT OFF");
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_TXP(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(cMeasItem, "TXP");
		sprintf_s(m_szCommand, "INIT:TXP:ON");
		break;

	case EPSK_MODE:
		sprintf_s(cMeasItem, "ETXP");
		sprintf_s(m_szCommand, "INIT:ETXP:ON");
		break;
	}

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_TXP(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "FETC:TXP:POW:AVER?");
		break;

	case EPSK_MODE:
		//sprintf_s(m_szCommand, "FETC:ETXP:POW:BURS:AVER?");
		sprintf_s(m_szCommand, "FETC:ETXP:POW:CARR:AVER?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_TXP(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "INIT:TXP:OFF");
		break;

	case EPSK_MODE:
		sprintf_s(m_szCommand, "INIT:ETXP:OFF");
		break;

	case WCDMA_MODE:
		sprintf_s(m_szCommand, "INIT:WCP:OFF");
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PVT_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iCount > 1)
	{
		sprintf_s(m_szCommand, "SET:PVT:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:PVT:COUN %d", iCount);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:PVT:COUN:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PVT_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iTimeoutS > 0)
	{
		sprintf_s(m_szCommand, "SET:PVT:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:PVT:TIM %d S", iTimeoutS);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:PVT:TIM:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PVT_CONTINUOUS_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bModeOn == TRUE)
	{
		sprintf_s(m_szCommand, "SET:PVT:CONT ON");
	}
	else
	{
		sprintf_s(m_szCommand, "SET:PVT:CONT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PVT_TIMEOFFSET(CHAR* cTimeoffset)
{
	CHAR	*token;
	CHAR	seps[]   = "{} MKHZUSmkhzus,\t\n";
	CHAR	cPvtOffset[SIZE_256_LENGTH] = {0x00};
	INT		iPvtOffsetCount = 0, i = 0;
	double	dPvtTimeOffset[MAX_PVT_OFFSET_COUNT] = {0};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cPvtOffset, "%s", cTimeoffset);
	token = strtok(cPvtOffset, seps);
	while ((token != NULL) && (iPvtOffsetCount < MAX_PVT_OFFSET_COUNT))
	{
		dPvtTimeOffset[iPvtOffsetCount++] = atof(token);
		token = strtok(NULL, seps);
	}

	memset(m_cPvtTimeOffset, 0x00, sizeof(m_cPvtTimeOffset));
	for(i = 0; i < iPvtOffsetCount; i ++)
	{
		if (i == 0)
			sprintf_s(m_cPvtTimeOffset, "%.2fUS", dPvtTimeOffset[i]);
		else
			sprintf_s(m_cPvtTimeOffset, "%s, %.2fUS", m_cPvtTimeOffset, dPvtTimeOffset[i]);
	}

	sprintf_s(m_szCommand, "SET:PVT:TIME:OFFS %s", m_cPvtTimeOffset);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PVT_PCS_LIMIT(CHAR* cLimitMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:PVT:LIM:ETSI:PCS");

	if (0 == _stricmp(cLimitMode, "NAR"))
		sprintf_s(m_szCommand, "%s NARR", m_szCommand);
	else if (0 == _stricmp(cLimitMode, "REL"))
		sprintf_s(m_szCommand, "%s REL", m_szCommand);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PVT_BURST_SYNC_MODE(CHAR* cSyncMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:PVT:SYNC");

	if (0 == _stricmp(cSyncMode, "MID"))
		sprintf_s(m_szCommand, "%s MIDAMBLE", m_szCommand);
	else if (0 == _stricmp(cSyncMode, "AMPL"))
		sprintf_s(m_szCommand, "%s AMPLITUDE", m_szCommand);
	else if (0 == _stricmp(cSyncMode, "NONE"))
		sprintf_s(m_szCommand, "%s NONE", m_szCommand);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_PVT(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "PVT");
	sprintf_s(m_szCommand, "INIT:PVT:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_PVT(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:PVT:POW:TIME:OFFS:AVER? %s", m_cPvtTimeOffset);

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_PVT(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:PVT:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PFER_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (iCount > 1)
		{
			sprintf_s(m_szCommand, "SET:PFER:COUN:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:PFER:COUN %d", iCount);
			}
		}
		else
		{
			sprintf_s(m_szCommand, "SET:PFER:COUN:STAT OFF");
		}
		break;

	case EPSK_MODE:
		if (iCount > 1)
		{
			sprintf_s(m_szCommand, "SET:EMAC:COUN:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:EMAC:COUN %d", iCount);
			}
		}
		else
		{
			sprintf_s(m_szCommand, "SET:EMAC:COUN:STAT OFF");
		}
		break;

	case WCDMA_MODE:
		if (iCount > 1)
		{
			sprintf_s(m_szCommand, "SET:WWQ:COUN:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:WWQ:COUN %d", iCount);
			}
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WWQ:COUN:STAT OFF");
		}
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PFER_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (iTimeoutS > 0)
		{
			sprintf_s(m_szCommand, "SET:PFER:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:PFER:TIM %d S", iTimeoutS);
			}
		}
		else
		{
			sprintf_s(m_szCommand, "SET:PFER:TIM:STAT OFF");
		}
		break;

	case EPSK_MODE:
		if (iTimeoutS > 0)
		{
			sprintf_s(m_szCommand, "SET:EMAC:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:EMAC:TIM %d S", iTimeoutS);
			}
		}
		else
		{
			sprintf_s(m_szCommand, "SET:EMAC:TIM:STAT OFF");
		}
		break;

	case WCDMA_MODE:
		if (iTimeoutS > 0)
		{
			sprintf_s(m_szCommand, "SET:WWQ:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));

				sprintf_s(m_szCommand, "SET:WWQ:TIM %d S", iTimeoutS);
			}
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WWQ:TIM:STAT OFF");
		}
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PFER_CONTINUOUS_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (bModeOn == TRUE)
		{
			sprintf_s(m_szCommand, "SET:PFER:CONT ON");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:PFER:CONT OFF");
		}
		break;

	case EPSK_MODE:
		if (bModeOn == TRUE)
		{
			sprintf_s(m_szCommand, "SET:EMAC:CONT ON");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:EMAC:CONT OFF");
		}
		break;

	case WCDMA_MODE:
		if (bModeOn == TRUE)
		{
			sprintf_s(m_szCommand, "SET:WWQ:CONT ON");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WWQ:CONT OFF");
		}
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_PFER(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(cMeasItem, "PFER");
		sprintf_s(m_szCommand, "INIT:PFER:ON");
		break;

	case EPSK_MODE:
		sprintf_s(cMeasItem, "EMAC");
		sprintf_s(m_szCommand, "INIT:EMAC:ON");
		break;

	case WCDMA_MODE:
		sprintf_s(cMeasItem, "WWQ");
		sprintf_s(m_szCommand, "INIT:WWQ:ON");
		break;
	case HSDPA_MODE://mzlin 20091204
		sprintf_s(m_szCommand, "CALL:CELL:CLPControl:UPLink:MODE ACTive");
		m_nErrCode = Write(m_szCommand);
		
		sprintf_s(m_szCommand, "CALL:MS:POW:TARG 17");
		m_nErrCode = Write(m_szCommand);
		Sleep(500);

		sprintf_s(m_szCommand, "SETUP:WPDiscon:TRIGGER:SOURCE HSDPcchannel;:SETup:WPDiscon:TRIGger:ALIGnment:HSDPcchannel:SUBFrame 0;:SETup:WPDiscon:TRIGger:ALIGnment:HSDPcchannel:SLOT ACKNack;:SETup:WPDiscon:STEP:INTerval 0.5;:SETup:WPDiscon:STEP:COUNt 21;:SETup:WPDiscon:TIMeout 5");
		m_nErrCode = Write(m_szCommand);


		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(cMeasItem, "WPD");
		sprintf_s(m_szCommand, "INIT:WPD:ON");
		break;
	}

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_FREQ_ERR(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "FETCh:PFER:FERR:WORS?");
		break;

	case EPSK_MODE:
		sprintf_s(m_szCommand, "FETC:EMAC:FERR:WORS?");
		break;

	case WCDMA_MODE:
		sprintf_s(m_szCommand, "FETC:WWQ:FERR:WORS?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_PEAK_PHASE_ERR(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "FETC:PFER:PEAK:MAX?");
		break;
	case EPSK_MODE:
		sprintf_s(m_szCommand, "FETC:EMAC:PERR:PEAK:WORS?");
		break;
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "FETC:WWQ:PERR:MAX?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_RMS_PHASE_ERR(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "FETC:PFER:RMS:MAX?");
		break;

	case EPSK_MODE:
		sprintf_s(m_szCommand, "FETC:EMAC:PERR:RMS:AVER?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_PEAK_EVM(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case EPSK_MODE:
		sprintf_s(m_szCommand, "FETC:EMAC:EVM:PEAK:AVER?");
		break;
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "FETC:WWQ:EVM:MAX?");
		break;
	case HSDPA_MODE://mzlin 20091204
		sprintf_s(m_szCommand, "FETCH:WPD:TRACe? EVM;FETCh:WPDiscon:TRACe? DISC");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	switch(m_iCurrOperMode)//mzlin 20091204
	{
	case HSDPA_MODE://mzlin 20091204
		{
			CHAR	cEVM_temp[SIZE_2048_LENGTH] = {0x00};
			double	dpoint_EVM_temp[42] = {0.0};
			INT		iStatus = TEST_SUCCESS;
			CHAR	seps[]   = ",;";
			CHAR	*token;
			INT		i_Index = 0;
			INT		i_temp = 0;
			i_Index = 0;
			token = strtok(cEVM_temp, seps);
			while(i_Index < 42)
			{

				if ((token == "0") || (token == "-1") || (token == NULL))
				{
					dpoint_EVM_temp[i_Index] = -1;
				}
				else
				{
					dpoint_EVM_temp[i_Index] = atof(token);
				}
				token = strtok(NULL, seps);
				i_Index += 1;
			}
			sprintf_s(cValue, 128, "%f,%f,%f,%f,%f,%f", dpoint_EVM_temp[0], dpoint_EVM_temp[1], dpoint_EVM_temp[20], dpoint_EVM_temp[21], dpoint_EVM_temp[24], dpoint_EVM_temp[41]);
		}
		break;
	}

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_RMS_EVM(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case EPSK_MODE:
		sprintf_s(m_szCommand, "FETC:EMAC:EVM:RMS:MAX?");
		break;
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "FETC:WWQ:EVM:AVER?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_95TH(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case EPSK_MODE:
		sprintf_s(m_szCommand, "FETC:EMAC:EVM:PERC?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_ORIGIN_OFFSET(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case EPSK_MODE:
		sprintf_s(m_szCommand, "FETC:EMAC:OOFF:AVER?");
		break;
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "FETC:WWQ:OOFF:MAX?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_PFER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "INIT:PFER:OFF");
		break;

	case EPSK_MODE:
		sprintf_s(m_szCommand, "INIT:EMAC:OFF");
		break;

	case WCDMA_MODE:
		sprintf_s(m_szCommand, "INIT:WWQ:OFF");
		break;
	case HSDPA_MODE://mzlin 20091204
		sprintf_s(m_szCommand, "INIT:WPD:OFF");
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_ORFS_COUNT(INT iMod_Count, INT iSw_Count)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if ((iMod_Count > 1) || (iSw_Count > 1))
	{
		sprintf_s(m_szCommand, "SET:ORFS:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:ORFS:MOD:COUN %d", iMod_Count);
			m_nErrCode = Write(m_szCommand);
		}

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:ORFS:SWIT:COUN %d", iSw_Count);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:ORFS:COUN:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_ORFS_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iTimeoutS > 0)
	{
		sprintf_s(m_szCommand, "SET:ORFS:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:ORFS:TIM %d S", iTimeoutS);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:ORFS:TIM:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_ORFS_CONTINUOUS_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bModeOn == TRUE)
	{
		sprintf_s(m_szCommand, "SET:ORFS:CONT ON");
	}
	else
	{
		sprintf_s(m_szCommand, "SET:ORFS:CONT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_ORFS_FREQOFFSET(CHAR* cMod_Freq, CHAR* cSw_Freq)
{
	CHAR	*token;
	CHAR	seps[]   = "{} MKHZUSmkhzus,\t\n";
	CHAR	cORFSOffset[SIZE_256_LENGTH] = {0x00};
	INT		iORFSCount = 0, i = 0;
	double	dORFSOffset[MAX_ORFS_MOD_COUNT] = {0};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	//ORFS Modulation Freq Offsets
	sprintf_s(cORFSOffset, "%s", cMod_Freq);
	token = strtok(cORFSOffset, seps);
	while ((token != NULL) && (iORFSCount < MAX_ORFS_MOD_COUNT))
	{
		dORFSOffset[iORFSCount++] = atof(token);
		token = strtok(NULL, seps);
	}

	memset(m_cORFSModOffset, 0x00, sizeof(m_cORFSModOffset));
	for(i = 0; i < iORFSCount; i ++)
	{
		if (i == 0)
			sprintf_s(m_cORFSModOffset, "%.1fKHZ", dORFSOffset[i]);
		else
			sprintf_s(m_cORFSModOffset, "%s, %.1fKHZ", m_cORFSModOffset, dORFSOffset[i]);
	}

	sprintf_s(m_szCommand, "SET:ORFS:MOD:FREQ:OFFS %s", m_cORFSModOffset);

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		iORFSCount = 0;
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		memset(cORFSOffset, 0x00, sizeof(cORFSOffset));
		memset(dORFSOffset, 0x00, sizeof(dORFSOffset));

		//ORFS Switching Freq Offsets
		sprintf_s(cORFSOffset, "%s", cSw_Freq);
		token = strtok(cORFSOffset, seps);
		while ((token != NULL) && (iORFSCount < MAX_ORFS_SW_COUNT))
		{
			dORFSOffset[iORFSCount++] = atof(token);
			token = strtok(NULL, seps);
		}

		memset(m_cORFSSwOffset, 0x00, sizeof(m_cORFSSwOffset));
		for(i = 0; i < iORFSCount; i ++)
		{
			if (i == 0)
				sprintf_s(m_cORFSSwOffset, "%.1fKHZ", dORFSOffset[i]);
			else
				sprintf_s(m_cORFSSwOffset, "%s, %.1fKHZ", m_cORFSSwOffset, dORFSOffset[i]);
		}

		sprintf_s(m_szCommand, "SET:ORFS:SWIT:FREQ:OFFS %s", m_cORFSSwOffset);

		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_ORFS_FILTER_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (0 == _stricmp(cType, "AUTO"))
		sprintf_s(m_szCommand, "SET:ORFS:FILT:TYPE AUTO");
	else if (0 == _stricmp(cType, "ANALOG"))
		sprintf_s(m_szCommand, "SET:ORFS:FILT:TYPE ANAL");
	else if (0 == _stricmp(cType, "DIGITAL"))
		sprintf_s(m_szCommand, "SET:ORFS:FILT:TYPE DIG");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_QUERY_ORFS_FILTER_TYPE(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "SET:ORFS:FILT:TYPE?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_ORFS(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "ORFS");
	sprintf_s(m_szCommand, "INIT:ORFS:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_ORFS(CHAR* cModResult, CHAR* cSwResult)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:ORFS:MOD:FREQ:OFFS:AVER? %s", m_cORFSModOffset);

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cModResult, 512, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

		sprintf_s(m_szCommand, "FETC:ORFS:SWIT:FREQ:OFFS:MAX? %s", m_cORFSSwOffset);

		m_nErrCode = Query(m_szCommand, m_szReadBuffer);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cSwResult, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_ORFS(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:ORFS:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_ORFS_30KHZ_BW_POWER(CHAR* cPower)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:ORFS:POW:BWID:AVER?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cPower, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_FBER_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "SET:FBER:COUN %d", iCount);
		m_nErrCode = Write(m_szCommand);
		break;

	case WCDMA_MODE:
		sprintf_s(m_szCommand, "SET:WBER:COUN %d", iCount);
		m_nErrCode = Write(m_szCommand);
		break;
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_FBER_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (iTimeoutS > 0)
		{
			sprintf_s(m_szCommand, "SET:FBER:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));
				sprintf_s(m_szCommand, "SET:FBER:TIM %d S", iTimeoutS);
			}
		}
		else
			sprintf_s(m_szCommand, "SET:FBER:TIM:STAT OFF");

		m_nErrCode = Write(m_szCommand);
		break;

	case WCDMA_MODE:
		if (iTimeoutS > 0)
		{
			sprintf_s(m_szCommand, "SET:WBER:TIM:STAT ON");
			m_nErrCode = Write(m_szCommand);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				memset(m_szCommand, 0x00, sizeof(m_szCommand));
				sprintf_s(m_szCommand, "SET:WBER:TIM %d S", iTimeoutS);
			}
		}
		else
			sprintf_s(m_szCommand, "SET:WBER:TIM:STAT OFF");

		m_nErrCode = Write(m_szCommand);
		break;
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_FBER_CONTINUOUS_ON(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		if (bModeOn == TRUE)
			sprintf_s(m_szCommand, "SET:FBER:CONT ON");
		else
			sprintf_s(m_szCommand, "SET:FBER:CONT OFF");

		m_nErrCode = Write(m_szCommand);
		break;
	case WCDMA_MODE:
		if (bModeOn == TRUE)
			sprintf_s(m_szCommand, "SET:WBER:CONT ON");
		else
			sprintf_s(m_szCommand, "SET:WBER:CONT OFF");

		m_nErrCode = Write(m_szCommand);
		break;
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_FBER(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(cMeasItem, "FBER");
		sprintf_s(m_szCommand, "INIT:FBER:ON");
		break;
	case WCDMA_MODE:
		sprintf_s(cMeasItem, "WBER");
		sprintf_s(m_szCommand, "INIT:WBER:ON");
		break;
	}

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_FBER(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "FETC:FBER:RAT?");
		break;
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "FETC:WBER:RAT?");
		break;
	}

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_FBER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(m_iCurrOperMode)
	{
	case GMSK_MODE:
		sprintf_s(m_szCommand, "INIT:FBER:OFF");
		break;
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "INIT:WBER:OFF");
		break;
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_FBER_TEST_SETUP(INT iTestIndex)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_FBER_TCH_LEVEL(double dLevel)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_FBER_CLOSELOOP_DELAY(INT iDelayms)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (m_iCurrOperMode == GMSK_MODE)
	{
		if (iDelayms == 0)
			sprintf_s(m_szCommand, "SET:FBER:CLSD:STAT OFF");
		else
			sprintf_s(m_szCommand, "SET:FBER:CLSD:STIM %d MS", iDelayms);

		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_FBER_UL_TFCI_AUTO_CONTROL(BOOL bModeOn)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (TRUE == bModeOn)
		sprintf_s(m_szCommand, "CALL:FDDT:UPL:TFCI:CONT:AUTO ON");
	else
		sprintf_s(m_szCommand, "CALL:FDDT:UPL:TFCI:CONT:AUTO OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_FBER_DL_TFCI(CHAR* cCode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:FDDT:TFCI \'%s\'", cCode);
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_MAXTXP(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WCP");

	sprintf_s(m_szCommand, "SET:WCP:FILT OFF");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "INIT:WCP:ON");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_MAXTXP(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:WCP:POW:AVER?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_MAXTXP(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WCP:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_MINTXP(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WCP");

	sprintf_s(m_szCommand, "SET:WCP:FILT ON");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		sprintf_s(m_szCommand, "INIT:WCP:ON");
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_MINTXP(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:WCP:POW:AVER?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_MINTXP(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WCP:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_OPENLOOP_POWER(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WCP");
	sprintf_s(m_szCommand, "INIT:WCP:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_OPENLOOP_POWER(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:WCP:POW:AVER?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_OPENLOOP_POWER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WCP:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_SLOTPOWER(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WDPA");
	sprintf_s(m_szCommand, "INIT:WDPA:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_SLOTPOWER(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:WDPA:ALL?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_SLOTPOWER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WDPA:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SEM_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iCount > 1)
	{
		sprintf_s(m_szCommand, "SET:WSEM:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:WSEM:COUN %d", iCount);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WSEM:COUN:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SEM_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iTimeoutS > 0)
	{
		sprintf_s(m_szCommand, "SET:WSEM:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:WSEM:TIM %d S", iTimeoutS);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WSEM:TIM:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SEM_COUTINUOUS_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
	{
		sprintf_s(m_szCommand, "SET:WSEM:CONT ON");
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WSEM:CONT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_SEM_DETECTMODE(CHAR* cMode)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_INIT_WB_SEM(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WSEM");
	sprintf_s(m_szCommand, "INIT:WSEM:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_SEM(CHAR* cValue)
{
	INT		iIndex = 0;
	CHAR	cTempSEMResult[SIZE_32_LENGTH] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
	memset(cValue, 0x00, sizeof(cValue));

	sprintf_s(m_szCommand, "FETCh:WSEMask:RANGe?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		for (iIndex = 3; iIndex <= 16; iIndex += 4)
		{
			memset(cTempSEMResult, 0x00, sizeof(cTempSEMResult));

			m_nErrCode = RRT_GET_VALUE_FROM_STRING_LIST(m_szReadBuffer, iIndex, cTempSEMResult);
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (iIndex == 3)
					strcpy_s(cValue, 32, cTempSEMResult);
				else
					sprintf_s(cValue, 64, "%s,%s", cValue, cTempSEMResult);
			}
			else
				break;
		}
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_SEM(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WSEM:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ACLR_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iCount > 1)
	{
		sprintf_s(m_szCommand, "SET:WACL:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:WACL:COUN %d", iCount);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WACL:COUN:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ACLR_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iTimeoutS > 0)
	{
		sprintf_s(m_szCommand, "SET:WACL:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:WACL:TIM %d S", iTimeoutS);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WACL:TIM:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ACLR_COUTINUOUS_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
	{
		sprintf_s(m_szCommand, "SET:WACL:CONT ON");
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WACL:CONT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_ACLR_QUERY_STATUS(BOOL bN10On, BOOL bN5On, BOOL bP5On, BOOL bP10On)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bN10On == TRUE)
	{
		sprintf_s(m_szCommand, "SET:WACL:LOWer2:STAT ON");
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WACL:LOWer2:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		if (bN5On == TRUE)
		{
			sprintf_s(m_szCommand, "SET:WACL:LOWer1:STAT ON");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WACL:LOWer1:STAT OFF");
		}

		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		if (bP5On == TRUE)
		{
			sprintf_s(m_szCommand, "SET:WACL:UPPer1:STAT ON");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WACL:UPPer1:STAT OFF");
		}

		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));

		if (bP10On == TRUE)
		{
			sprintf_s(m_szCommand, "SET:WACL:UPPer2:STAT ON");
		}
		else
		{
			sprintf_s(m_szCommand, "SET:WACL:UPPer2:STAT OFF");
		}

		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_ACLR(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WACL");
	sprintf_s(m_szCommand, "INIT:WACL:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_ACLR(CHAR* cValueN5, CHAR* cValueN10, CHAR* cValueP5, CHAR* cValueP10)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	strcpy_s(m_szCommand, "FETC:WACL:AVER:ALL?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		RRT_GET_VALUE_FROM_STRING_LIST(m_szReadBuffer, 1, cValueN5);
		RRT_GET_VALUE_FROM_STRING_LIST(m_szReadBuffer, 2, cValueP5);
		RRT_GET_VALUE_FROM_STRING_LIST(m_szReadBuffer, 3, cValueN10);
		RRT_GET_VALUE_FROM_STRING_LIST(m_szReadBuffer, 4, cValueP10);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_ACLR(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	strcpy_s(m_szCommand, "INIT:WACL:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

//		!!!!!	iNumber -- Start from 1 NOT 0	!!!!!
INT C8960::RRT_GET_VALUE_FROM_STRING_LIST(CHAR* pSource, int iNumber, CHAR* out_pResult)
{
	CHAR	*p = NULL;
	CHAR	seps[]   = ", \n\t";
	CHAR	cSource[SIZE_1024_LENGTH] = {0x00};
	int		iCount = 0;

	m_nErrCode = GPIB_SUCCESS;

	strcpy_s(cSource, pSource);

	p = strtok(cSource, seps);
	while(p != NULL)
	{
		iCount++;
		if(iCount == iNumber)
		{
			strcpy_s(out_pResult, 512, p);
			break;
		}
		p = strtok(NULL, seps);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_OBW_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iCount > 1)
	{
		sprintf_s(m_szCommand, "SET:WOBW:COUN:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:WOBW:COUN %d", iCount);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WOBW:COUN:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_OBW_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iTimeoutS > 0)
	{
		sprintf_s(m_szCommand, "SET:WOBW:TIM:STAT ON");
		m_nErrCode = Write(m_szCommand);

		if (m_nErrCode == GPIB_SUCCESS)
		{
			memset(m_szCommand, 0x00, sizeof(m_szCommand));

			sprintf_s(m_szCommand, "SET:WOBW:TIM %d S", iTimeoutS);
		}
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WOBW:TIM:STAT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_OBW_COUTINUOUS_ON(BOOL bMode)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (bMode == TRUE)
	{
		sprintf_s(m_szCommand, "SET:WOBW:CONT ON");
	}
	else
	{
		sprintf_s(m_szCommand, "SET:WOBW:CONT OFF");
	}

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_OBW(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WOBW");
	sprintf_s(m_szCommand, "INIT:WOBW:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_OBW(CHAR* cValue)
{
	double	dMeasuredOBW = 0.0;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "FETC:WOBW:BAND:AVER?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		dMeasuredOBW = atof(m_szReadBuffer) * 1E6;
		sprintf_s(cValue, 16, "%.4f", dMeasuredOBW);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_OBW(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WOBW:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_ILPC(VOID)
{
	CHAR	cMeasItem[10] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(cMeasItem, "WILP");
	sprintf_s(m_szCommand, "INIT:WILP:ON");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_ILPC(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "FETC:WILP:TRAC?");

	m_nErrCode = Query(m_szCommand, cValue);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_ILPC_TESTED_SLOT(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "FETC:WILP:NSLO?");

	m_nErrCode = Query(m_szCommand, cValue);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_ILPC(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WILP:OFF");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_FILTER_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (0 == _stricmp(cType, "WIDE"))
		sprintf_s(m_szCommand, "SET:PCAL:FILT WIDE");
	else if (0 == _stricmp(cType, "NARR"))
		sprintf_s(m_szCommand, "SET:PCAL:FILT NARR");
	else if (0 == _stricmp(cType, "ENAR"))
		sprintf_s(m_szCommand, "SET:PCAL:FILT ENAR");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_WAVEFORM_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (0 == _stricmp(cType, "DISC"))
		sprintf_s(m_szCommand, "SET:PCAL:WAV:TYPE DISC");
	else if (0 == _stricmp(cType, "CONT"))
		sprintf_s(m_szCommand, "SET:PCAL:WAV:TYPE CONT");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_TRIGGER_SOURCE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (0 == _stricmp(cType, "RISE"))
		sprintf_s(m_szCommand, "SET:PCAL:TRIG:SOUR RISE");
	else if (0 == _stricmp(cType, "IMM"))
		sprintf_s(m_szCommand, "SET:PCAL:TRIG:SOUR IMM");
	else if (0 == _stricmp(cType, "EXT"))
		sprintf_s(m_szCommand, "SET:PCAL:TRIG:SOUR EXT");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_TRIGGER_THRESHOLD(double dValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:PCAL:TRIG:THR %.1f", dValue);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_RESULT_TYPE(CHAR* cType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (0 == _stricmp(cType, "PCAL"))
		sprintf_s(m_szCommand, "SET:PCAL:RES:TYPE PCAL");
	else if (0 == _stricmp(cType, "SAMP"))
		sprintf_s(m_szCommand, "SET:PCAL:RES:TYPE SAMP");
	else if (0 == _stricmp(cType, "BOTH"))
		sprintf_s(m_szCommand, "SET:PCAL:RES:TYPE BOTH");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_STEP_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:PCAL:STEP:COUN %d", iCount);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_STEP_CENTER(double dValueS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:PCAL:STEP:CENT %.6 S", dValueS);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_STEP_WIDTH(INT iValueMS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "SET:PCAL:STEP:WIDT %d MS", iValueMS);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_PCAL_TIMEOUT(INT iTimeoutS)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (iTimeoutS == 0)
		sprintf_s(m_szCommand, "SET:PCAL:TIM:STAT OFF");
	else
		sprintf_s(m_szCommand, "SET:PCAL:TIM:STIM %d S", iTimeoutS);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_PCAL(INT iDuration, INT iPeriodNumber, double dRatio, INT iType)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:PCAL:ON");

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_PCAL_MEAS_COMPLETE(VOID)
{
	INT		i = 0, iMaxRetry = 10;
	CHAR	cState[128] = {0x00};

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "FETC:PCAL:INT?");

	for(i = 0; i < iMaxRetry; i++)
	{
		memset(cState, 0x00, sizeof(cState));

		m_nErrCode = Query(m_szCommand, cState);
		if (m_nErrCode == GPIB_SUCCESS)
		{
			if (strcmp("+0", cState) == 0)
				break;
			else
			{
				m_nErrCode = GPIB_QUERY_FAIL;
				continue;
			}
		}
		else
			continue;
	}

	return m_nErrCode;
}

INT C8960::RRT_FETCH_PCAL_POWER(INT iSampleCount, CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "FETC:PCAL:POW?");

	m_nErrCode = Query(m_szCommand, cValue);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_PCAL_PHASE(INT iSampleCount, CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "FETC:PCAL:PHAS?");

	m_nErrCode = Query(m_szCommand, cValue);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_MULTIPOWER(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	if (stParameter.iWBSweep_TimeInterval <= 20)
		sprintf_s(m_szCommand, "SET:WTDP:STEP:TIME MS20");
	else if ((20 < stParameter.iWBSweep_TimeInterval) && (stParameter.iWBSweep_TimeInterval <= 40))
		sprintf_s(m_szCommand, "SET:WTDP:STEP:TIME MS40");
	else if (40 < stParameter.iWBSweep_TimeInterval)
		sprintf_s(m_szCommand, "SET:WTDP:STEP:TIME MS80");

	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "SET:WTDP:STEP:COUN %d", stParameter.iWBSweep_Counter);
/*
		if (stParameter.iWBSweep_PALoop == 0)
			sprintf_s(m_szCommand, "SET:WTDP:STEP:COUN %d", stParameter.iWBSweep_Counter + 16);
		else
			sprintf_s(m_szCommand, "SET:WTDP:STEP:COUN %d", stParameter.iWBSweep_Counter);
*/
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "SET:WTDP:TIM:STIM %d S", stParameter.iWBSweep_Timeout);
		m_nErrCode = Write(m_szCommand);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		if (stParameter.iWBSweep_PALoop == 0)
			sprintf_s(m_szCommand, "SET:WTDP:STEP -1.6");
		else
			sprintf_s(m_szCommand, "SET:WTDP:STEP -1.2");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_MULTIPOWER(VOID)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "INIT:WTDP:ON");
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_MULTIPOWER(INT iStepNumber, CHAR* cValue)
{
	CHAR	cMeasItem[10] = {0x00};
	CHAR	*token;
	INT		i = 0;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(cMeasItem, "WTDP");
	m_nErrCode = WAIT_for_MEASUREMENT_COMPLETE(cMeasItem);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		sprintf_s(m_szCommand, "FETC:WTDP?");
		m_nErrCode = Query(m_szCommand, m_szReadBuffer);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		token = strtok(m_szReadBuffer, ",");
		i = 0;
		token = strtok(NULL, ",");
		while ((token != NULL) && (i <= iStepNumber))
		{
			if (i == 0)
				strcpy_s(cValue, 64, token);
			else
				sprintf_s(cValue, 512, "%s,%s", cValue, token);

			token = strtok(NULL, ",");
			i++;
		}
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "INIT:WTDP:OFF");
		m_nErrCode = Write(m_szCommand);
	}

	return m_nErrCode;
}

INT C8960::RRT_FETCH_RSSI(CHAR *out_psRxQ, CHAR *out_psRxL)
{
	INT			i = 0, j = 0;
	CHAR		seps[]   = ";";
	CHAR		*token;

	m_nErrCode = GPIB_SUCCESS;

	//RX Quality
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "CALL:MS:REP:RXQ:NEW?;NEW?;NEW?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);
	if (m_nErrCode != GPIB_SUCCESS)
	{
		return m_nErrCode;
	}
	else
	{
		j = 0;
		token = strtok(m_szReadBuffer, seps);
		while(j < 3)
		{
			if (j == 2)
			{
				if (token == NULL)
				{
					m_nErrCode = GPIB_READ_FAIL;
					return m_nErrCode;
				}
				else
				{
					strcpy_s(out_psRxQ, 512, token);
				}
			}
			else
			{
				token = strtok(NULL, seps);
			}
			j += 1;
		}
	}

	//RX Level
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "CALL:MS:REP:RXL:NEW?;NEW?;NEW?");

	m_nErrCode = Query(m_szCommand, m_szReadBuffer);
	if (m_nErrCode != GPIB_SUCCESS)
	{
		return m_nErrCode;
	}
	else
	{
		j = 0;
		token = strtok(m_szReadBuffer, seps);
		while(j < 3)
		{
			if (j == 2)
			{
				if (token == NULL)
				{
					m_nErrCode = GPIB_READ_FAIL;
					return m_nErrCode;
				}
				else
				{
					strcpy_s(out_psRxL, 512, token);
				}
			}
			else
			{
				token = strtok(NULL, seps);
			}
			j += 1;
		}
	}

	return m_nErrCode;	
}

INT C8960::RRT_SET_INIT_WB_TXRX_FREQ_MEASUREMENT(INT iSegment, INT iSequence)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_TXRX_FREQ_MEASUREMENT(CHAR *cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_FETCH_UE_CPICH_RSCP(CHAR *cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	sprintf_s(m_szCommand, "CALL:MS:REP:MEAS:REQ");
	m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	if (m_nErrCode == GPIB_SUCCESS)
	{
		Sleep(500);
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "CALL:MS:REP:CPIC:RSCP?");
		m_nErrCode = Query(m_szCommand, m_szReadBuffer);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 512, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_WB_PCDE_COUNT(INT iCount)
{
	m_nErrCode = GPIB_SUCCESS;
	return m_nErrCode;
}

INT C8960::RRT_SET_INIT_WB_PCDE(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_INIT_PFER();

	return m_nErrCode;
}

INT C8960::RRT_FETCH_WB_PCDE(CHAR* cValue)
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	switch(m_iCurrOperMode)
	{
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "FETC:WWQ:PCER:MAX?");
		m_nErrCode = Query(m_szCommand, m_szReadBuffer);
		break;
	}

	if (m_nErrCode == GPIB_SUCCESS)
		strcpy_s(cValue, 128, m_szReadBuffer);

	return m_nErrCode;
}

INT C8960::RRT_SET_END_WB_PCDE(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_END_PFER();

	return m_nErrCode;
}

//=============================================================================================HSDPA Start=============================================================================================
INT C8960::RRT_SET_DPA_CHANNEL_CODING(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(stParameter.iDPA_Channel_Coding)
	{
	case REFERENCE_MEASUERMENT_CHANNEL:
		sprintf_s(m_szCommand, "CALL:SERVice:RBTest:RAB RMC12");
		break;
	//case VOICE:
	//	break;
	case FIXED_REFERENCE_CHANNEL:
		sprintf_s(m_szCommand, "CALL:SERVice:RBTest:RAB HSDP12");
		break;
	//case E_DCH_RF_TEST:
	//	break;
	}

	m_nErrCode = Write(m_szCommand);

	//if (m_nErrCode == GPIB_SUCCESS)
	//	sprintf_s(m_cDPCHType, "%s", cType);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_REGISTRATION_MODE(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(stParameter.iDPA_Registration_Mode)
	{
	case AUTO:
		sprintf_s(m_szCommand, "CALL:PSDomain ABS");
		break;
	//case CS:
	//	break;
	//case CSPS:
	//	break;
	case COMBINED:
		sprintf_s(m_szCommand, "CALL:PSDomain PRES");
		break;
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_HSHSET(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(stParameter.iDPA_Hshset)
	{
	case HSET1_QPSK:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QPSK1");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		
		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '0,2,5,6,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET1_16QAM:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QAM1");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '6,2,1,5,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET2_QPSK:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QPSK2");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '0,2,5,6,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET2_16QAM:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QAM2");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '6,2,1,5,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET3_QPSK:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QPSK3");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '0,2,5,6,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET3_16QAM:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QAM3");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '6,2,1,5,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET4_QPSK:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QPSK4");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '0,2,5,6,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET5_QPSK:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QPSK5");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '0,2,5,6,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET6_QPSK:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QPSK6");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '0,2,5,6,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSET6_16QAM:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:FRC:TYPE QAM6");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '6,2,1,5,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	//case HSET8_64QAM:
	//	sprintf_s(m_szCommand, "HSHSET HSET8_64QAM");
	//	break;
	case CAT6_MAX:
	case CAT8_MAX:
	case CAT10_MAX:
		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:HSDSchannel:CONFig UDEFined");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:UDEFined:HSPDschannel:COUNt 5");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:UDEFined:TBSize:INDex 44");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:UDEFined:MODulation QAM16");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:UDEFined:ITTI 1");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:SERVice:RBTest:UDEFined:HARQ:PROCess:COUNt 6");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:HARQ:PROCess:COUNt 6");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:HSDPa:MACHs:RVSequence '6,2,1,5,0,0,0,0'");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	//case CAT14_MAX:
	//	sprintf_s(m_szCommand, "HSHSET CAT14_MAX");
	//	break;
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_DPCH_OFFSET(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(stParameter.iOperationMode)
	{
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "CALL:DPCHANNEL:DOFFset 0");//Default DPCH Offset
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:DPCHannel:DOFFset 0");//TCR Default DPCH Offset
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSDPA_MODE:
		sprintf_s(m_szCommand, "CALL:DPCHANNEL:DOFFset 3");//Default DPCH Offset
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:DPCHannel:DOFFset 3");//TCR Default DPCH Offset
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_FDD_TEST_DPCH_LEVEL(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(stParameter.iOperationMode)
	{
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "CALL:FDDTest:DPCHannel:HSDPa -10.3");
		break;
	case HSDPA_MODE:
		sprintf_s(m_szCommand, "CALL:FDDTest:DPCHannel:HSDPa -9");
		break;
	default:
		sprintf_s(m_szCommand, "CALL:FDDTest:DPCHannel:HSDPa -10.3");
		break;
	}
	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_PHYSICAL_CHANNEL_LEVEL(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	switch(stParameter.iOperationMode)
	{
	case WCDMA_MODE:
		sprintf_s(m_szCommand, "CALL:FDDTest:DPCHannel:HSDPa -10");//set DPCH level to -10(default)
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:FDDTest:HSSCchannel1 -10");//set HSSCCH level to -10(default)
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	case HSDPA_MODE:
		sprintf_s(m_szCommand, "CALL:FDDTest:DPCHannel:HSDPa -9");//set DPCH level to -9
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);

		sprintf_s(m_szCommand, "CALL:FDDTest:HSSCchannel1 -8");//set HSSCCH level to -8
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
		break;
	}

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_DELTA_ACK(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));


	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:UPLink:DACK %d", stParameter.iDPA_DeltaACK);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_DELTA_NACK(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));


	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:UPLink:DNACk %d", stParameter.iDPA_DeltaNACK);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_DELTA_CQI(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));


	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:UPLink:DCQI %d", stParameter.iDPA_DeltaCQI);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_ACKNACK_REPETITION_FACTOR(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));


	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:UPLink:ANACk:RFACtor %d", stParameter.iDPA_AckNack_Repetition_Factor);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_CQI_FEEDBACK_CYCLE(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));


	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:UPLink:CQI:FCYCle %d", stParameter.iDPA_CQI_Feedback_Cycle);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_CQI_REPETITION_FACTOR(RRT_PARAMETERS &stParameter)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));


	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:UPLink:CQI:RFACtor %d", stParameter.iDPA_CQI_Repetition_Factor);

	m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_BetaC_BetaD(INT iBetaC, INT iBetaD)//mzlin 20090702
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:HANDoff:TCReconfig:CHANnel:STATe OFF");
	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:DPCHannel:BETA:AUTO OFF");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:DPCHannel:MANual:CBETa %d", iBetaC);
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:SETup:TCReconfig:DPCHannel:MANual:DBETa %d", iBetaD);
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:HANDoff:TCReconfig");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:HANDoff:TCReconfig:CHANnel:STATe ON");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_CHANNEL(INT iDLChannel, INT iUPChannel)//mzlin 20091204
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:HANDoff:PCReconfig:CFNHandling MAINtain");
	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:HANDoff:PCReconfig:ATIMe 100");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	if(4400 == iDLChannel)
	{
		sprintf_s(m_szCommand, "CALL:SETup:CHANnel:BARBitrator BAND5");
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = Write(m_szCommand);
	}

	sprintf_s(m_szCommand, "CALL:MS:POW:TARG 0");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(m_szCommand, 0x00, sizeof(m_szCommand));
		sprintf_s(m_szCommand, "CALL:SET:CHAN:DOWN %d", iDLChannel);

		m_nErrCode = Write(m_szCommand);
	}

	sprintf_s(m_szCommand, "CALL:HANDoff:PCReconfig");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	/*
	sprintf_s(m_szCommand, "CALL:MS:POW:TARG 24");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);
	*/

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_8960_TCR_HANDOVER(VOID)//mzlin 20091204
{
	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	sprintf_s(m_szCommand, "CALL:HANDoff:TCReconfig:CHANnel:STATe OFF");
	m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:HANDoff:TCReconfig");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	sprintf_s(m_szCommand, "CALL:HANDoff:TCReconfig:CHANnel:STATe ON");
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = Write(m_szCommand);

	return m_nErrCode;
}

INT C8960::RRT_SET_DPA_MEASURE_OBJECT(CHAR* cMeasObj)//mzlin 20091204
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_SET_DPA_HSMA_ITEM(CHAR* cMeasItem)//mzlin 20091204
{
	return GPIB_SUCCESS;
}

//==============================================================================================HSDPA End==============================================================================================

/**********		End -- Measurement Functions		**********/

/**********		Start -- Combined Functions		**********/
INT C8960::RRT_CX_INSTRUMENT_RESET(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_CLEAR_STATUS();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_RESET();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_INSTRUMENT_CALIBRATION(VOID)
{
	SYSTEMTIME	stCurrentTime;
	CHAR		seps[] = " ,+.\n\t";
	CHAR		*token;
	INT			iLastCalDate[3] = {0};
	INT			iCurrDate[3] = {0};
	CHAR		cLastCalDate[SIZE_256_LENGTH] = {0x00};
	CHAR		cTempBuff[SIZE_256_LENGTH] = {0x00};
	INT			i = 0;

	m_nErrCode = GPIB_SUCCESS;

	//Current Date
	::GetLocalTime(&stCurrentTime);
	for (i = 0; i < sizeof(iCurrDate); i++)
	{
		switch(i)
		{
		case 0:
			iCurrDate[i] = (int)stCurrentTime.wYear;
			break;
		case 1:
			iCurrDate[i] = (int)stCurrentTime.wMonth;
			break;
		case 2:
			iCurrDate[i] = (int)stCurrentTime.wDay;
			break;
		}
	}

	m_nErrCode = RRT_QUERY_CALIB_DATE(cLastCalDate);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		strncpy(cTempBuff, cLastCalDate, sizeof(cTempBuff));
		i = 0;
		token = strtok(cTempBuff, seps);
		while(token != NULL)
		{
			iLastCalDate[i++] = atoi(token);
			token = strtok(NULL, seps);
		}

		if ((iCurrDate[0] != iLastCalDate[0]) || (iCurrDate[1] != iLastCalDate[1]))
			m_nErrCode = RRT_FULL_CALIBRATION();
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CALIB_DATE();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_CLEAR_STATUS();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_INSTRUMENT_CABLELOSS(CHAR *cState, double dLossFreq[], double dLossGain[], INT iLossCount)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_RESET_CABLELOSS();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CABLELOSS(dLossFreq, dLossGain, iLossCount);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CABLELOSS_STATE(cState);

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_INSTRUMENT_MODE(RRT_PARAMETERS &stParameter)
{
	CHAR	cCodeScheme[10] = {0x00};
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_BSPOWER_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(OFF_MODE);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		switch(stParameter.iOperationMode)
		{
		case GMSK_MODE:
			m_nErrCode = RRT_SET_NCC(stParameter.iNCCCode);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_BCC(stParameter.iBCCCode);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (stParameter.iSignal_Flag == SIGNAL_MODE)
					m_nErrCode = RRT_SET_CALLPROCESS_ON(TRUE);
				else if (stParameter.iSignal_Flag == N0N_SIGNAL_MODE)
					m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);
			}

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (stParameter.iSignal_Flag == N0N_SIGNAL_MODE)
					m_nErrCode = RRT_SET_OUTPUT_PATTERN("BCHTCH");
			}

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_OPERATION_MODE(stParameter.iOperationMode);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_AUTO_EXPECTED_POWER(TRUE);

			//Connection type
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (stParameter.iSignal_Flag == SIGNAL_MODE)
					m_nErrCode = RRT_SET_DATA_CONNECTION_TYPE("AUTO");
			}

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SEND_OPC();
			break;

		case EPSK_MODE:
			m_nErrCode = RRT_SET_NCC(stParameter.iNCCCode);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_BCC(stParameter.iBCCCode);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (stParameter.iSignal_Flag == SIGNAL_MODE)
					m_nErrCode = RRT_SET_CALLPROCESS_ON(TRUE);
				else if (stParameter.iSignal_Flag == N0N_SIGNAL_MODE)
					m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);
			}

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (stParameter.iSignal_Flag == N0N_SIGNAL_MODE)
					m_nErrCode = RRT_SET_OUTPUT_PATTERN("BCHTCH");
			}

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_OPERATION_MODE(stParameter.iOperationMode);

			//Set Modulation Format
			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_MODULATION_CONTROL_AUTO(FALSE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_MEASURE_OBJECT(1, "EPSK");

			//Code Scheme
			if (m_nErrCode == GPIB_SUCCESS)
			{
				sprintf_s(cCodeScheme, "MCS%d", stParameter.iEPSK_CodeScheme);
				m_nErrCode = RRT_SET_CODE_SCHEME(cCodeScheme);
			}

			//Connection type
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (stParameter.iSignal_Flag == SIGNAL_MODE)
					m_nErrCode = RRT_SET_DATA_CONNECTION_TYPE(stParameter.cEPSK_ConnType);
			}

			//Multi-Slot setting
			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_MULTISLOT_CONFIG(1, 1);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_AUTO_EXPECTED_POWER(TRUE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_RFAN_FREQ_AUTO(TRUE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SEND_OPC();
			break;

		case WCDMA_MODE:
			if (m_nErrCode == GPIB_SUCCESS)
			{
				if (stParameter.iSignal_Flag == SIGNAL_MODE)
					m_nErrCode = RRT_SET_CALLPROCESS_ON(TRUE);
				else if (stParameter.iSignal_Flag == N0N_SIGNAL_MODE)
					m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);
			}

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_WB_UL_GAIN_FACTOR(stParameter.iWB_BetaC, stParameter.iWB_BetaD);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_OPERATION_MODE(stParameter.iOperationMode);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SEND_OPC();
			break;

		case CW_MODE:
			m_nErrCode = RRT_SET_MODULATION_ON(FALSE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_OPERATION_MODE(stParameter.iOperationMode);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SEND_OPC();
			break;

		case HSDPA_MODE://mzlin 20090702

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_OPERATION_MODE(stParameter.iOperationMode);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_DPA_CHANNEL_CODING(stParameter);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_DPA_HSHSET(stParameter);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_DPA_PHYSICAL_CHANNEL_LEVEL(stParameter);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_DPA_DPCH_OFFSET(stParameter);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_WB_UL_GAIN_FACTOR(stParameter.iWB_BetaC, stParameter.iWB_BetaD);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SEND_OPC();

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_CALLPROCESS_ON(TRUE);

			if (m_nErrCode == GPIB_SUCCESS)
				m_nErrCode = RRT_SET_DPA_REGISTRATION_MODE(stParameter);
			break;
		}
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		m_nErrCode = RRT_SET_BSPOWER_ON(TRUE);
		if (m_nErrCode == GPIB_SUCCESS)
			m_nErrCode = RRT_SEND_OPC();
	}

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_EG_POWER(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_POWER_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_POWER_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_POWER_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_EG_PVT(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_PVT_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PVT_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PVT_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PVT_TIMEOFFSET(stParameter.cMeasPvTOffsets);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PVT_BURST_SYNC_MODE(stParameter.cMeasPvTSyncMode);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_EG_PFER(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_PFER_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PFER_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PFER_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_EG_ORFS(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_ORFS_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_COUNT(stParameter.iMeasORFSModCounter, stParameter.iMeasORFSSwCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_FREQOFFSET(stParameter.cMeasORFSMod, stParameter.cMeasORFSSw);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_FILTER_TYPE("DIGITAL");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_EG_FBER(RRT_PARAMETERS &stParameter)
{
	INT		iFBER_CloseLoop_Delay = 1500;

	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_FBER_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_FBER_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_FBER_CLOSELOOP_DELAY(iFBER_CloseLoop_Delay);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_FBER_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_LOOPBACK_TYPE(LBT_TYPEC);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_DPCH_PARAMETER(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_WB_DPCH_CHANNEL_TYPE(stParameter.cDPCH_ChannelType);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_DPCH_CODE(stParameter.iDPCH_ChannelCode);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_POWER(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_END_TXP();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_POWER_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_POWER_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_POWER_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_SEM(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_END_WB_SEM();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_SEM_COUTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_SEM_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_SEM_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_ACLR(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_END_WB_ACLR();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_ACLR_COUTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_ACLR_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_ACLR_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_ACLR_QUERY_STATUS(stParameter.bWB_ACLR_N10On, stParameter.bWB_ACLR_N5On, stParameter.bWB_ACLR_P5On, stParameter.bWB_ACLR_P10On);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_OBW(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_END_WB_OBW();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_OBW_COUTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_OBW_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_OBW_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_BER(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_END_FBER();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_FBER_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_FBER_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_FBER_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_FBER_UL_TFCI_AUTO_CONTROL(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_FBER_DL_TFCI("003");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_TRANSMISSION_POWER_CONTROL(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_WB_TPC_PATTERN(stParameter.cTPC_Pattern);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_TPC_ALGORITHM(stParameter.iTPC_ALG);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_TPC_STEPSIZE(stParameter.iTPC_StepSize);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_TRIGGER(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_SPECTRUM_MONITOR_TRIGGER(stParameter.cWBTriggerSource);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_SPECTRUM_MONITOR_TRIGGER_DELAY(stParameter.dTriggetDelayMS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_ILPC(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_WB_ILPC_TPC_STEP(stParameter.cWB_ILPC_Segment);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_ILPC_MAX_THRESHOLD(FALSE, stParameter.dWB_ILPC_StartPwr);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_ILPC_MIN_THRESHOLD(FALSE, stParameter.dWB_ILPC_EndPwr);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_SET_WB_PCDE(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_PFER_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PFER_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PFER_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

//	Start -- Combined functions for calibration
INT C8960::RRT_CX_QCOMM_GSM_CAL_INIT(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SELECT_APPLICATION("GSM");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_BSPOWER_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OUTPUT_PATTERN("BCHTCH");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(GMSK_MODE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PCAL_FILTER_TYPE("ENAR");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_AUTO_EXPECTED_POWER(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_RFAN_FREQ_AUTO(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_TSC(5);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_QCOMM_WB_CAL_INIT(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SELECT_APPLICATION("WCDMA");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(WCDMA_MODE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ALL_MEASURE_OFF();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_WB_AWGN_STATE_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_RF_CONNECTOR_TYPE("MAIN");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_QCOMM_GSM_RX_CAL_INIT(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(GMSK_MODE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_RFG_FREQ_AUTO(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_BSPOWER(-65.0);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_BSPOWER_ON(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_QCOMM_GSM_POLAR_CAL_INIT(VOID)
{
	m_nErrCode = GPIB_SUCCESS;

	//Set as CW mode
	m_nErrCode = RRT_SET_MODULATION_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_BSPOWER_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OUTPUT_PATTERN("BCHTCH");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(GMSK_MODE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PCAL_FILTER_TYPE("ENAR");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_AUTO_EXPECTED_POWER(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_RFAN_FREQ_AUTO(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_QCOMM_SET_GSM_POLAR_MEAS_INIT(RRT_PARAMETERS &stParameter)
{
	double	dCenterStep[128] = {0.0};
	CHAR	cCenterStep[4096] = {0x00};
	INT		i = 0;

	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_PCAL_WAVEFORM_TYPE("DISC");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PCAL_TRIGGER_SOURCE("RISE");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PCAL_TRIGGER_THRESHOLD(20.0);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		if(stParameter.iPCAL_StepLength == 168)
			m_nErrCode = RRT_SET_PCAL_FILTER_TYPE("ENAR");
		else
			m_nErrCode = RRT_SET_PCAL_FILTER_TYPE("WIDE");
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PCAL_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PCAL_RESULT_TYPE("PCAL");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PCAL_STEP_COUNT(stParameter.iPCAL_Period);

	if (m_nErrCode == GPIB_SUCCESS)
	{
		if(stParameter.iPCAL_StepLength == 168)
		{
			sprintf_s(cCenterStep, sizeof(cCenterStep), "SET:PCAL:STEP:CENT 0.000196");
			for(i=0; i < stParameter.iPCAL_Period - 1; i++)
			{
				sprintf_s(cCenterStep, sizeof(cCenterStep), "%s,%f", cCenterStep, (0.000196 + ((double)( ( i + 1 ) * stParameter.iPCAL_Duration) / 1E6 )));
			}
		}
		else
		{
			sprintf_s(cCenterStep, sizeof(cCenterStep), "SET:PCAL:STEP:CENT 0.000465");
			for(i=0; i < stParameter.iPCAL_Period - 1; i++)
			{
				sprintf_s(cCenterStep, sizeof(cCenterStep), "%s,%f", cCenterStep, (0.000465 + ((double)( ( i + 1 ) * stParameter.iPCAL_Duration) / 1E6 )));
			}
		}
		m_nErrCode = Write(cCenterStep);
	}

	if (m_nErrCode == GPIB_SUCCESS)
	{
		memset(cCenterStep, 0x00, sizeof(cCenterStep));

		sprintf_s(cCenterStep, sizeof(cCenterStep), "SET:PCAL:STEP:WID %f",stParameter.iPCAL_StepLength/1E6);
		for(i=0; i < stParameter.iPCAL_Period - 1; i++)
		{
			sprintf_s(cCenterStep, sizeof(cCenterStep), "%s,%f", cCenterStep, stParameter.iPCAL_StepLength/1E6);
		}
		m_nErrCode = Write(cCenterStep);
	}

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_INIT_PCAL();

	return m_nErrCode;
}

INT C8960::RRT_CX_QCOMM_SET_GSM_PHASEDELAY_INIT(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OUTPUT_PATTERN("BCH");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(EPSK_MODE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MULTISLOT_CONFIG(1, 1);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CODE_SCHEME("MCS5");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_TSC(0);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_AUTO_EXPECTED_POWER(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_RFAN_FREQ_AUTO(FALSE);

	//Set Modulation Format
	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MODULATION_CONTROL_AUTO(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MEASURE_OBJECT(1, "EPSK");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_COUNT(stParameter.iMeasCounter, stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_FREQOFFSET("-400 KHZ,400 KHZ,-600 KHZ,600 KHZ", "-400 KHZ,400 KHZ,-600 KHZ,600 KHZ");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_ORFS_FILTER_TYPE("DIGITAL");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_QCOMM_SET_GSM_VCO_INIT(RRT_PARAMETERS &stParameter)
{
	m_nErrCode = GPIB_SUCCESS;

	m_nErrCode = RRT_SELECT_APPLICATION("GSM");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MODULATION_ON(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CALLPROCESS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_BSPOWER_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OUTPUT_PATTERN("BCHTCH");

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_OPERATION_MODE(GMSK_MODE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_AUTO_EXPECTED_POWER(TRUE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_RFAN_FREQ_AUTO(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_TSC(5);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PFER_COUNT(stParameter.iMeasCounter);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PFER_TIMEOUT(stParameter.iMeasTimeoutS);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_PFER_CONTINUOUS_ON(FALSE);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	return m_nErrCode;
}

INT C8960::RRT_CX_QCOMM_NSCALL_HANDOVER(RRT_PARAMETERS &stParameter)
{
	return GPIB_SUCCESS;
}

INT C8960::RRT_CX_QCOMM_SIGCALL_HANDOVER(RRT_PARAMETERS &stParameter)
{
	INT		iHandoverArfcn = 0;
	INT		iHandoverPCL = 0;

	m_nErrCode = GPIB_SUCCESS;
	memset(m_szCommand, 0x00, sizeof(m_szCommand));

	m_bIsHandoverSetting = TRUE;

	switch(stParameter.iHandOverTarget)
	{
	case Band_GSM850:
		iHandoverArfcn = 128;
		iHandoverPCL = 8;
		break;
	case Band_GSM:
		iHandoverArfcn = 975;
		iHandoverPCL = 8;
		break;
	case Band_DCS:
		iHandoverArfcn = 512;
		iHandoverPCL = 2;
		break;
	case Band_PCS:
		iHandoverArfcn = 512;
		iHandoverPCL = 2;
		break;
	}

	if ((stParameter.iHandOverTarget == Band_GSM850) || (stParameter.iHandOverTarget == Band_PCS))
		m_nErrCode = RRT_SET_EG_BAND_INDICATOR(FALSE);
	else if ((stParameter.iHandOverTarget == Band_GSM) || (stParameter.iHandOverTarget == Band_DCS))
		m_nErrCode = RRT_SET_EG_BAND_INDICATOR(TRUE);
	else
		m_nErrCode = E_DEVICE_SETTING_ERROR;

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	if ((m_nErrCode == GPIB_SUCCESS) && (m_bBandIndicatorSet == TRUE))
		Sleep(stParameter.iDelay_After_BandIndicator);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_HANDOVER_TARGET(stParameter.iHandOverTarget);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_TCH_ARFCN(iHandoverArfcn);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_CODE_SCHEME(m_cMCSUsing);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_MULTISLOT_CONFIG(m_iULSlotCount, m_iDLSlotCount);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_EXPECTED_POWER_LEVEL(m_iEPSKSlotUsed, iHandoverPCL);

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SEND_OPC();

	if (m_nErrCode == GPIB_SUCCESS)
		m_nErrCode = RRT_SET_HANDOVER();

	m_bIsHandoverSetting = FALSE;

	return m_nErrCode;
}
//	End -- Combined functions for calibration
/**********		End -- Combined Functions		**********/
/********************		End -- RRT virtual functions		********************/
