#ifndef _8960_H
#define _8960_H

#include "math.h"
#include "visa_ExportApi.h"
#include "ReturnType.h"
#include "GlobalVar.h"
#include "VirtualFunction.h"
#include "CommonAPI.h"

#define AGLIENT_IQVECTOR_SAMPLING_FREQUENCY		(1.625*1000000.0000000000000)
#define AGLIENT_MAX_IQVECTOR_ARRAY_LEN			7999
#define	RF_TEST_FETCH_BUFFER_SIZE				256

class C8960 : public CVirtualInstrument
{
public:
	C8960();
	virtual ~C8960();

public:
	CHAR					m_szDLLFile[MAX_PATH];
	CHAR					m_szCommand[1024];
	CHAR					m_szReadBuffer[1024];
	INT						m_iPowDeviceID;
	INT						m_iCalDeviceID;
	BOOL					m_b1968;
	BOOL					m_bCwMode;
	INT						m_nErrCode;
	ViSession				m_viSession;

	/*		Start -- Variable of virtual functions		*/
	CHAR					m_cFormatType[20];
	INT						m_iCurrOperMode;
	INT						m_iCurrBand;
	INT						m_iCurrCallProcessMode;
	INT						m_iCurrModulationMode;
	INT						m_iCurrOutputPattern;
	CHAR					m_cDPCHType[20];
	CHAR					m_cPvtTimeOffset[SIZE_512_LENGTH];
	CHAR					m_cORFSModOffset[SIZE_512_LENGTH];
	CHAR					m_cORFSSwOffset[SIZE_512_LENGTH];
	/*		End -- Variable of virtual functions		*/

	HINSTANCE				m_hDLL;
	pf_viOpen_t				viOpen;
	pf_viScanf_t			viScanf;
	pf_viClose_t			viClose;
	pf_viPrintf_t			viPrintf;
	pf_viOpenDefaultRM_t	viOpenDefaultRM;
	pf_viQueryf_t			viQueryf;
	pf_viClear_t			viClear;
	pf_viSetAttribute_t		viSetAttribute;
	pf_viWrite_t			viWrite;
	pf_viGpibControlREN_t   viGpibControlREN;
	BOOL					m_bFastScreen;

	//Tomy Chen, 2009/09/30, Parameters for Handover using
	CHAR					m_cMCSUsing[SIZE_32_LENGTH];
	INT						m_iULSlotCount;
	INT						m_iDLSlotCount;
	INT						m_iEPSKSlotUsed;
	INT						m_iCurrTCHArfcn;
	INT						m_iCurrBCHArfcn;
	INT						m_iCurrPCL;
	BOOL					m_bIsCallConnected;
	BOOL					m_bIsHandoverSetting;
	BOOL					m_bBandIndicatorSet;
	
	/*add two enum structure by zona at 20070131*/
	
	typedef enum _PHYSICAL_CHANNEL {
		// State 
		imNONE				= -1, 
		imOFF				= 0, 
		imON				= 1,
		
		// Physical channels
		imCPICH				= 1000, 
		imSCH				= 1002, 
		imP_CCPCH			= 1004, 
		imS_CCPCH			= 1005, 
		imPICH				= 1006, 
		imAICH				= 1008, 
		imD_DPCH			= 1011,
		imD_DPCCH			= 1012, 
		imD_DPDCH			= 1013, 
		imPRACH				= 1150, 
		imU_DPCH			= 1160, 
		imOCNS				= 1200, 
		imAWGN				= 1201,
		// Radio Meassurement Channel(RMC) setting
		imVOICE_CHANNEL		= 100, 
		imRMC_12_2_KBPS		= 101, 
		imRMC_64_KBPS		= 102, 
		imRMC_144_KBPS		= 103, 
		imRMC_384_KBPS		= 104,
		// Data pattern
		imALL_ZERO			= 110, 
		imALL_ONE			= 111, 
		imPN9				= 112, 
		imPN15				= 113, 
		imECHO				= 114, 
		imNO_DATA			= 115,
	} E_PHYSICAL_CHANNEL, *LPE_PHYSICAL_CHANNEL;

	typedef enum _INTEGRITY_CODE {
		imNO_INTEGRITY						= -1,
		imOK								= 0,
		imOVER_RANGE_ERROR					= 2,
		imUNDER_RANGE_ERROR					= 3,
		imUNABLE_TO_INTERPRET_SIGNAL_ERROR	= 4,
		imGENERAL_ERROR						= 5,
	} E_INTEGRITY_CODE;

public:
	//Variable Definition
	double		m_dTriggerLevel;
	double		m_dTriggerDelay;
	INT			m_nNumberOfIQMeasurements;
	//Tomy Chen, 2009/03/31, Flag to indicate to save GPIB log or not.
	BOOL		m_bGPIB_Log_Enable;

	//Function Definition
	INT Write(CONST CHAR *pcCommand);
	INT Query(CONST CHAR *pcCommand, CHAR *pcReturnValue);
	INT Read(CHAR *pcReturnValue, INT length = 0);

	INT VISA32_SET_VI_SESSION(DWORD vi);
	INT	VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable);
	
	INT SWITCH_FAST_SCREEN(BOOL bFast);
	INT SEND_RESET(VOID);
	INT SELECT_VIEW(char* czView); 
	INT END_CALL(VOID);
	INT SEND_OPC( int iRetryCount, int iRetryIdle ); 
	INT QUERY_STD(char* czQueryResult); 
	INT SET_RF_OUTPUT_SIGNAL_STATUS( bool bStatus ); 
	INT SET_OUTPUT_MOD_SIGNAL_STATUS( bool bStatus ); 
	INT SET_CALL_PROCESSING_MODE( bool bStatus );
	INT GSM_OUTPUT_SIGNAL_PATTERN(const char* czPattern); 
	INT GSM_SET_MEASUREMENT_STATUS(const char* czMeasurement, bool bStatus); 
	INT SET_MEASUREMENT_MODE( bool bStatus ); 
	INT GSM_SET_BIT_OFFSET(float fBitOfs); 
	INT SET_SCREEN_DISPLAY( bool bStatus ); 
	INT GSM_SET_POWER_MEASUREMENT_COUNT( int nCount ); 
	INT GSM_SET_TRAINING_SEQUENCE( int nPattern ); 
	INT GSM_SET_OPERATING_MODE( const char* czMode ); 
	INT GSM_SET_MEASURMENT_OBJECT( const char* czObject ); 
	INT GSM_SET_CABLE_LOSS( float fLoss, int iBand ); 
	INT GSM_SET_CABLE_LOSS_STATUS( bool bStatus ); 
	//INT GSM_SET_INPUT_LEVEL*/( float fInputLevel ); 
	INT GSM_PREDISTQ_MEASURE( int nDuration, int iPeriods, int iStepLength );
	INT GSM_PREDISTQ_MEASURE( int nDuration, int iPeriods, double fRatio );
	INT GSM_PREDISTQ_GET_STATUS( char* pStatus ); 
	INT GSM_PREDISTQ_GET_POWER( int iPeriods, char* pResult ); 
	INT GSM_SET_OUTPUT_MOD_SIGNAL_STATUS( bool bStatus ); 
	//INT GSM_SET_OUTPUT_LEVEL_STATUS( bool bStatus ); 

	INT WCDMA_SET_OUTPUT_LEVEL_STATUS( bool bStatus ); 
	INT WCDMA_SET_AWGN_OUTPUT_STATUS( bool bStatus ); 
	INT SET_MEASUREMENT_STATUS(const char* czMeasurement, bool bStatus); 
	INT WCDMA_SET_POWER_MEASUREMENT_AVERAGE_COUNT( int nCount ); 
	INT WCDMA_SET_RF_SIGNAL_OUTPUT_CONNECTOR_TYPE( const char* czConnectorType ); 
	INT WCDMA_SET_DL_FREQUENCY( double dFreq ); 
	INT WCDMA_SET_OUTPUT_LEVEL( double dPower ); 
	INT WCDMA_SET_AUX_CABLE_LOSS( double dLoss ); 
	INT WCDMA_SET_AUX_CABLE_LOSS_STATUS( bool bStatus ); 
	INT WCDMA_SET_DL_CABLE_LOSS( double dLoss ); 
	INT WCDMA_SET_DL_CABLE_LOSS_STATUS( bool bStatus ); 
	INT WCDMA_SET_AM_STATUS(bool bStatus); 

	INT RESET(VOID); //MF
	INT QUERY_SW_VERSION(const int iStandardNumber, char* szSWVersion); //MF
	INT SET_POWER_COUNT(const int iPowerCount); //MF
	INT SET_INSTRUMENT_MODE(const char* szBand,/*const char* szMeasureObj,*/bool bUSFBlockERR ); //MF
	INT SET_CODE_SCHEME(const char* szCodeSchemeType, const int iCodeScheme); //MF
	INT SET_RF_OUTPUT(const int iOutputConnector); //MF  0 = MAIN; 1 = AUX
	INT SET_BIT_OFFSET( const int iBitOffsetType);//MF    0 = offset 0 ; 1 = offset 0.5
	INT SET_ORFS_COUNT(const int iORFSMode, const int iCount);//MF 0 = Modulation , 1 = Switching
	INT SET_EXTURNAL_CABLE_LOSS(const int iDLULSelect, const int iBand, const int iCableLoss); //MF
	INT EXT_LOSS_SWITCH(const bool bLossSwitch); //MF
	INT QUERY_MEASUREMENT_STATUS(const int iQuaryRFPath, char* szRFStatus); //MF   0 = TX , 1 = RX
	INT QUERY_ALL_MEASURE_RESULT(const char* szQueryItem, char* szQueryResult); //MF
	//szQueryItem = "ORFSMD", "ORFSSW", "PWR", "OBW", "ADJ", "BER", "a "         7 types
	//INT SET_STD_SELECT(const char* szStd); //MF
	INT SCREEN_SWITCH(const bool bScreenSwitch); //MF
	//INT SET_TRAINING_SEQUENCE(INT iTSC); //MF
	INT SET_SYNCHRONOUS_SINGLE_SWEEP(VOID); //MF
	INT QUERY_SWP_STATUS(char* szSWPstatus);
	INT GSM_CAL_RX_INIT(VOID);
	INT GSM_CAL_SET_BAND(int iBand);
	INT GSM_CAL_SET_CH(int iCCH, int iTCH);
	INT GSM_CAL_SET_FREQ(int isel, double dFreq);
	INT GSM_CAL_IM2_INIT(VOID);
	INT GSM_CAL_IM2_UNINIT(VOID);
	INT GSM_SET_LEVEL(int isel, double level);
	INT GSM_SET_POWER_LEVEL(int isel, double level);
	INT GSM_CAL_SYNC_SINGLE_MODE(int iDuration,int iNum, double dRatio);
	INT GSM_CAL_PREDISTQ_POWER(char *cPower,int iPREDISTQ_No);
	INT GSM_CAL_PREDISTQ_PHASE(char *cPhase,int iPREDISTQ_No);
	INT GSM_CAL_PRESET_DEVICE(VOID);
	INT	SET_EXTERNAL_LOSS_TABLE(CHAR *cStandard, double fFrequency[], double fCableLoss[], INT num);
	INT GSM_CAL_POLAR_INIT(VOID);
	INT GSM_CAL_CS_INIT(VOID);
	INT GSM_CAL_FREQ_EOR_AVG(char *szBuf);
	INT GSM_CAL_VCO_INIT(VOID);
	INT GSM_CAL_PHASEDELAY_INIT(const int iCount);
	INT GSM_CAL_INIT(VOID);
	INT WCDMA_CAL_RX_INIT(VOID);

	INT CLOSE_ALL_MEASUREMENT(VOID);
	INT SET_STANDARD_SELECT(CHAR *cStandard);
	INT WB_ANT8960_RESET(VOID);
	INT WCDMA_MEAS_AVG_PWR(double dILVL, double *dPower);	//Shania
	INT WCDMA_SET_CABLE_LOSS_STATUS(char *cSTATUS);//Shania
	INT WCDMA_SET_UL_CHAN(int iCH);	//Shania
	INT	WCDMA_GET_SWP_PWR(int iSTEP,char *cPower);
	INT WCDMA_MEAS_SWP_PWR(void);	//Shania
	INT WCDMA_SWP_PWR_SET(int iSTEP, int iNUM, int iTimeout);	//Shania
	INT WCDMA_CLOSE_ALL_MEASUREMENT(VOID);
	INT WB_SET_INPUT_LEVEL(double fPower);

	INT CALL_TEST_FETCH(CONST CHAR* in_psCommand, CHAR *out_psResult);
	INT SET_CALL_PROCESSING_MODE( CONST CHAR *in_psMode);
	//INT Set_External_Loss_Table(FLOAT fFrequency[], FLOAT fCableLoss[], INT num);
	INT Reset_Cable_Loss(VOID);
	
	//Calibration Function

	INT Set_Output_Signal_Pattern(CHAR *cMode);	
	INT SET_SYSTEM_COMBINATION(CONST CHAR *cSyscmb);
	INT SET_CELL_POWER(double fPower);
	INT Set_Input_Power_Lev( float fIL);
	INT SET_PDTCH_CHANNEL(UINT arfcn);
	INT SET_BCH_ARFCn(UINT arfcn);	
	INT Set_MS_Power_Level(INT iPowerLevel);
	INT SET_EXP_POWER_LEVEL(INT iPowerLevel, E_BAND iBand);
	INT Set_Exp_Power(FLOAT fPower, E_BAND iBand);

	INT Read_Tx_Power(CHAR *out_psResult);
	INT Read_Tx_Power2(CHAR *out_psINTegrity, CHAR *out_psResult);	
	INT AFC_Fetch_Freq_Error(CHAR *cReturn);
	

	//New common
	INT Set_Training_Sequence(INT iTSC);
	
	// MT8960 only
	INT Band_Calibration(VOID);
	//INT Set_Synchronous_Single_Sweep(VOID);
	INT Set_Continuous_Sweep_Mode(VOID);
	INT Stop_Measurement(VOID);
	INT Get_Measurement_Status(INT *iMSTAT_Staus);
	INT Set_Power_Measurement_Mode(CHAR *cOnOff);
	INT Set_PFER_Measurement_Mode(CHAR *cOnOff);
	INT Set_Modulation_Analysis_Count(INT nCount);
	INT Set_Power_Measurement_Count(INT nCount);
	INT Set_All_Fundamental_Measurement_Items(VOID);
	INT Set_Single_Sweep(VOID);

	INT SET_ALL_FUNDAMENTAL_MEASUREMENT_ITEMS_OFF(VOID);

	//INT End_Call(VOID);
	INT MT_Call(VOID);
	//RFTest
	INT FETCH_PFER( CHAR *out_psResult);
	INT FETCH_PEAKPH( CHAR *out_psResult);
	INT FETCH_RMSPH( CHAR *out_psResult);
	INT PVT_MEASUREMENT(BOOL &bMaskOK, CHAR *cPVT_Result, CHAR *cPvtTimeOffset);
	INT FETCH_FBER( CHAR *out_psResult);
	//INT Fetch_RxQ(CHAR *out_psResult);
	//INT Fetch_RxL(CHAR *out_psResult);
	INT FETCH_POWER(CHAR *out_psResult);

	INT Set_Input_Lev(float fIL);
	INT SET_TCH_BAND(CONST CHAR in_sBand[]);
	INT SET_TCH_ARFCn(const UINT in_uiARFCn);
	INT Set_MS_TX_Level(const UINT in_uiTxLevel);

	INT Fetch_RSSI(CHAR *out_psRxQ, CHAR *out_psRxL);

	INT SET_FBER(INT nCount, INT nTimeOut);
	INT Set_ORFS(INT iModCount, INT iSWCount, INT nTimeOut);
	INT Set_TCH_PAT(VOID);
	INT Set_TCH_Time_Advance(UINT timeadv);
	INT SET_POWER(INT nCount, INT nTimeOut);
	INT SET_PVT(INT nCount, INT nTimeOut);
	INT SET_PFER(INT nCount, INT nTimeOut);
	INT SET_INIT_FBER(VOID);
	INT SET_END_FBER(VOID);

	INT Single_Measurement(VOID);
	
	INT WB_Read(CHAR *rdBuf);

	//WB Function add by Brian for U250
	INT WB_Set_Paging_IMSI(CHAR pagingIMSI[]);
	INT WB_Set_Authentication_Key (CHAR value[]);
	INT WB_SET_FUNDAMENTAL_MEASUREMENT(char *selectScr);

	//INT WB_Set_External_Loss_Table(FLOAT fFrequency[], FLOAT fCableLoss[],INT num);

	INT WB_Query_Status(CHAR *cStatus);
	INT WB_Set_Handoff_UARFCN(INT handoffUARFCN);

	INT WB_Set_DL_Freq(double fFrequencyMHz);
	INT WB_SET_OUTPUT_LEVEL(double fPower);
	INT WB_Set_Output_Level_State_ON_OFF(bool bStatus);
	INT WB_Set_Input_Level(double fPower);
	INT WB_Get_Output_Level(CHAR *cPower);

	INT WB_Set_Output_Measurement(CHAR *cPattern,INT count);
	INT WB_Set_Ref_Senstivity_Measurement(CHAR *cPattern,INT count);
	
	INT WB_GET_MEASUREMENT_POWER(CHAR *cAvgPower);
	INT WB_Get_Measurement_OBW(CHAR *dOBW_MHz);
	INT WB_GET_MEASUREMENT_SEM(CHAR *cSEM);
	INT WB_GET_MEASUREMENT_ACLR(CHAR *cLow_5_MHZ,CHAR *cLow_10_MHZ,CHAR *cUp_5_MHZ,CHAR *cUp_10_MHZ);
	INT WB_GET_MEASUREMENT_EVM(CHAR *cEVM);
	INT WB_Get_Measurement_PCDE(CHAR *cPCDE);
	INT WB_GET_MEASUREMENT_FREQUENCY_ERROR(CHAR *cFreqErr);
	INT WB_GET_MEASUREMENT_BER(CHAR *cPercent);
	//add by zona at 20070207
	INT WB_GET_MEASURED_IQ_ERROR(double *pdOffset, double *pdImbalance); 

	INT WB_SET_MEASUREMENT_INNER_LOOP_POWER(const char* csSegment, int Number_ofSlots, int TPC_Step, double Start_Power, double Stop_Power, int Algorithm);
	INT WB_GET_MEASUREMENT_INNER_LOOP_POWER(CHAR *slot_list);
	INT WB_Cal_Device_Read(CHAR *rdBuf);
	INT Set_DL_Cable_Loss(FLOAT fLoss, E_BAND iBand);
	INT Set_UL_Cable_Loss(FLOAT fLoss, E_BAND iBand);
	INT Set_BCH_DL_Freq(FLOAT fFreq);

	//WCDMA_MX896000B software function, add by zona at 20070131//
	INT WB_Reset(VOID);
	INT WB_Close_ALL_Measurement(VOID);
	INT WB_Release_Connection(VOID);
	INT WB_Setup_Connection(CHAR *eType);


	/*Measurement methods*/

	//virtual INT GetMeasuredAdjacentChannelLeakagePower( C3gppMobileTester::EConstant ePowerRatioMode, double *pdPowerArray, INT nArrayLength, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	//virtual INT GetMeasuredBitErrorRate( double *pdBitErrorRate, bool *pfValidation, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredBlockErrorRate( double *pdBlockErrorRate, bool *pfValidation, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredFrequencyError( double *pdFrequency, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	//virtual INT GetMeasuredInnerLoopPower2( double *pdPowerArray, INT nNumberOfSlots, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	//virtual INT GetMeasuredIQError( double *pdOffset, double *pdImbalance, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	//virtual INT GetMeasuredOccupiedBandwidth( double *pdOccupiedBandWidth, double *pdUpperFrequency, double *pdLowerFrequency, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredPhaseDiscontinuity( double *pdPhaseDiscontinuityArray, INT nNumberOfSlots, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredPower( double *pdFilterPower, double *pdBroadBandPower, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredFilterPower( double *pdFilterPower, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	
	//virtual INT GetMeasuredBroadBandPower( double *pdBroadBandPower, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	//virtual INT GetMeasuredSlotFrequencyError( double *pdFrequencyErrorArray, INT nNumberOfSlots, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredSlotPower( double *pdPowerArray, INT nNumberOfSlots, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredSlotVectorError( double *pdVectorErrorArray, INT nNumberOfSlots, C3gppMobileTester::EINTegrityCode *peINTegrityValue );
	//virtual INT GetMeasuredSpectrumEmissionMask( bool *pfValidation, double *pdMargINToMaskArray, const INT nNumberOfFrequencyBands, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	//virtual INT GetMeasuredVectorError( double *pdMagnitudeRMS, double *pdMagnitudePeak, double *pdPhaseRMS, double *pdAmplitudeRMS, C3gppMobileTester::EINTegrityCode *peINTegrityValue ); 
	//virtual INT MarkerAmplitude( double *pdAmplitude );
	//virtual INT MarkerFrequency( double *pdFrequency );
	//virtual INT StartMeasurement( INT nMeasurement );
	//virtual INT WaitForMeasurementComplete( INT nMeasurement ); 

	/* Setup methods*/

	//virtual INT FindPeak( C3gppMobileTester::EConstant ePeak );
	//virtual INT InstrumentCalibration( tm *pLastCalibrationTime, bool fDoINTernalCalibration );
	//virtual INT SetAverageCount( INT nAverageCount );
	//virtual INT SetChannelPowerMeasurementConditions( C3gppMobileTester::EConstant eDetectorMode, INT nAdjacentChannelPairs );
	INT WB_SET_DATA_PATTERN(CHAR *eDTCHPattern);
	INT WB_SET_CHANNEL(INT nDownlink, INT nUplink);
	//virtual INT SetDeltaFrequencyMarker(double dFrequency);

	INT WB_Set_Downlink_Power_Level(double fPower);
	INT WB_Set_Downlink_Power_Level_On_Off(INT iOnOff);
	INT WB_SET_DOWNLINK_SCRAMBLING_CODES(INT nPrimary, INT nDPCHSecondary);
	INT WB_Set_Uplink_Power_Level(double dLevel);
	INT WB_Set_Uplink_Scrambling_Codes( INT nDPCH, INT nPRACHPreamble);
	INT WB_Set_Expected_Power_Level(double dLevel);
	INT WB_Set_Frequency_Marker(double dFrequency);
	INT WB_Set_Frequency_Marker_On_Off(INT iOnOff);
	INT WB_Set_Generator_Frequency(double dFrequency); //set downlink frequency
	INT WB_Set_Spectrum_Center_Frequency(double dFrequency); //set uplink frequency
	INT WB_SET_INSTRUMENT_MODE(CONST CHAR *in_psMode);
	INT WB_Set_International_Mobile_Subscriber_Identity(CHAR pagingIMSI[]);
	INT WB_Set_Modulation_Measurement_Conditions(CONST CHAR *in_moMode);
	INT WB_SET_PHYSICAL_CHANNEL(E_PHYSICAL_CHANNEL eChannel, double dLevel, E_PHYSICAL_CHANNEL eState);
	INT WB_Set_Physical_Channel_with_Symbol_Rate(E_PHYSICAL_CHANNEL eChannel, INT nChannelisationCode, INT nSymbolRate, INT nTimingOffset);
	INT WB_Set_Receiver_Measurement_Conditions(UINT nNumberOfBits);
	INT WB_Set_Sequential_Output(INT nRatioPerStep, INT nNumberOfSteps, E_PHYSICAL_CHANNEL eState);
	INT WB_SET_TRANSMISSION_POWER_CONTROL(CHAR *cPattern, INT nStepSize, INT nAlgorithm);
	INT WB_Set_Beta_Factors(INT nBetaC, INT nBetaD );
	INT WB_Set_Spectrum_Measurement_Conditions(double dSpan, double dResolutionBandwidth,CHAR *cDetectorMode );
	INT WB_Set_Spectrum_Emission_Mask_Limits(double *rgdLimitsArray, INT nArrayLength, E_PHYSICAL_CHANNEL eAdditionalBandIILimit );
	INT WB_SET_TRIGGER(CHAR *cMode, double dDelay);
	INT WB_SET_TRIGGER_START_AND_DURATION(double SLOT_START_TIME, double SLOT_DURATION_TIME );
	INT WB_SET_SLOT_POWER_MEASUREMENT(double dTimeSpan,INT nStartSlotList, INT nEndSlotList, double dThreshold_Level);
	INT WB_GET_SLOT_POWER(double *pdPowerArray, INT nNumberOfSlots);
	INT WB_GET_FILTER_MEASUREMENT_POWER(CHAR *cAvgPower);
	INT WB_Set_Measurement_SEM(VOID);
	INT WB_Set_Channel_Power_Measurement_Conditions(VOID);
	INT WB_Set_Modulation_Accuracy_Conditions_ON(VOID);
	INT WB_Set_Modulation_Accuracy_Conditions_OFF(VOID);
	INT WB_Setup_Call_Condition(VOID);
	INT WB_Set_Reference_Sensitivity_Conditions(INT OnOff);
	INT WB_SET_ILPC_CONDITION_ON(VOID);
	INT WB_Set_Average_Count(INT nAverageCount);
	INT WB_Get_Measurement_Spurious_Emission(double *pdAmplitude);

	INT Convert_Integrity_To_Enum(INT nIntegrityCode, E_INTEGRITY_CODE *peIntegrityCode);

	//virtual INT SetFrequencyReference( C3gppMobileTester::EConstant eSource, double dFrequency );
	//virtual INT SetNetworkParameters( INT nMcc, INT nMnc, INT nLac );
	//virtual INT SetParameter( C3gppMobileTester::EParameter eParameter, double dValue );
	//virtual INT SetParameter( C3gppMobileTester::EParameter eParameter, INT nValue );	
	//virtual INT SetSlotModulationMeasurementConditions( INT nNumberOfSlots, C3gppMobileTester::EConstant eSlotModulationPowerPattern );
	//virtual INT SetSlotPowerMeasurementConditions( INT nNumberOfSlots );

	//ConnectionStatus( C3gppMobileTester::EConstant *peStatus );=WB_QueryStatus
	//SetInnerLoopPowerMeasurementConditions(C3gppMobileTester::EConstant eTransmissionStep );=WB_SetMeasurementInnerLoopPower
	//SetSignallingSecurity( CHAR *szAuthenticationKeys, C3gppMobileTester::EConstant eINTegrityProtection );=WB_SetAuthenticationKey()

	//Tomy Chen, 2007/03/06, Add for EMP U360
	INT SET_CELL_POWER_STATE_ON(VOID);
	INT SET_CELL_POWER_STATE_OFF(VOID);
	INT EG_SET_INSTRUMENT_MODE(INT iOperateMode);
	INT Send_OPC(VOID);
	//Tomy Chen, 2007/03/15, Set RF Test Set IQ Vector Measurement Condition for EMP U360 Power Calibration & Pre-Distortion.
	INT EG_Set_IQ_Vector_Meas_Condition(double dTriggerDelay, double dMeasTime, INT *piNoOfIQMeas, double *pdSamplingFreq);

	//Set Instrument source
	INT EG_Set_Trigger_Source(INT iOperateMode, INT iModulationType = NULL, double dExpectLevel = NULL);

	//Functions for Pollar Calibration
	INT EG_Init_PCAL(VOID);
	INT EG_Set_End_PCAL(VOID);
	INT EG_Fetch_PCAL_Integrity(CHAR *out_psResult);
	INT EG_Fetch_PCAL(CHAR *out_psResult);

	//Tomy Chen, 2006/06/21, Fetch Phase & Amplitude value from instrument.
	INT EG_Fetch_PCAL_AMP(CHAR *out_psResult);
	INT EG_Fetch_PCAL_Phase(CHAR *out_psResult);

	//Tomy Chen, 2007/06/06, Function to set RF Test Set Time Slot
	INT SET_TCH_TIME_SLOT(UINT timeslot);
	INT Set_Frequency_RFAN(float fFreq);
	INT Set_Frequency_RFG(float fFreq);
	INT Set_Rx_Input_Power_Lv(float fPower);

	INT INIT_TX_POWER(VOID);
	INT SET_END_TXP(VOID);
	INT AFC_Init_Freq_Error(VOID);
	INT SET_END_PFER(VOID);
	INT SET_END_EMAC(VOID);
	//INT Init_Pvt(VOID);
	INT SET_END_PVT(VOID);
	INT FETCH_RMS_EVM(CHAR *out_psResult);
	INT FETCH_PEAK_EVM(CHAR *out_psResult);
	INT FETCH_95th_EVM(CHAR *out_psResult);
	INT Setup_BLER(INT nCount, INT nTimeOut);

	//Set Speech Source
	INT Set_Speech_Source(CHAR *cSpeechType);

	//Variable to indicate system type. 0 = GSM, 1 = WCDMA, 2 = PHS
	INT	iSystemIndex;

	INT FETCH_ORFS_30KHz_BW_POWER(CHAR *out_psResult);

	INT Query_Signal_Status(CHAR *cStatus);
	INT Set_GSM_Active_Cell(VOID);
	INT Set_EDGE_Active_Cell(VOID);

	INT INSTRUMENT_CALIBRATION(VOID);

	INT FETCH_POWER_INIT_DONE(char *out_psResult);
	INT SET_PDTCH_BAND(const char in_sBand[]);
	INT SET_PDTCH_MS_TX_LEVEL(const UINT Device_in_uiTxLevel);
	INT SET_PCS_PVT(VOID);

	//******************* EDGE non-signaling test ********************
	INT SET_EDGE_CODE_SCHEME(char *in_pSchemeSetting);
	INT SET_TRAINING_SEQUENCE(INT iTSC);
	INT SET_PVT_TIME_OFFSET(char *cPvtTimeOffset);
	INT SET_ORFS_MOD_FREQ_OFFSET(char *cOrfsFreqOffset);
	INT SET_ORFS_SWIT_FREQ_OFFSET(char *cOrfsFreqOffset);
	INT SET_ETXP(int nCount, int nTimeOut);
	INT SET_EMAC(int nCount, int nTimeOut);
	INT SET_ORFS(int iModCount, int iSWCount, int nTimeOut);

	INT INIT_ETXP(VOID);
	INT FETCH_ETXP(char *out_psResult);
	INT SET_END_ETXP(VOID);
	INT INIT_PVT(VOID);
	INT INIT_FREQ_ERROR(VOID);
	INT INIT_EMAC(VOID);
	INT INIT_ORFS(VOID);
	INT ORFS_MEASUREMENT(CHAR *cSW_Result, CHAR *cMOD_Result, CHAR *cOrfsSwFreqOffset, CHAR *cOrfsModFreqOffset);
	INT SET_END_ORFS(VOID);
	INT FETCH_EFREQ_ERR(char *out_psResult);
	INT FETCH_PVT(int *out_pnResult);
	INT SendOPC(VOID);
	INT WAIT_for_MEASUREMENT_COMPLETE(char *cTestItem);

	/********************		Start -- RRT virtual functions		********************/
	//	Common Functions
	INT RRT_RESET(VOID);
	INT RRT_FULL_CALIBRATION(VOID);
	INT RRT_BAND_CALIBRATION(VOID);
	INT RRT_QUERY_CALIB_DATE(CHAR* cValue);
	INT RRT_SET_CALIB_DATE(VOID);
	INT RRT_QUERY_SYS_DATE(CHAR* cValue);
	INT RRT_QUERY_SYS_TIME(CHAR* cValue);
	INT RRT_SET_SYS_DATE(VOID);
	INT RRT_SET_SYS_TIME(VOID);
	INT RRT_SWITCH_FAST_SCREEN(BOOL bFastScreenOn);
	INT RRT_GPIB_LOG_ON(BOOL bLogOn);
	INT RRT_SEND_OPC(VOID);
	INT RRT_RESET_CABLELOSS(VOID);
	INT RRT_SET_CABLELOSS(double dLossFreq[], double dLossGain[], INT iLossCount);
	INT RRT_SET_CABLELOSS_STATE(CHAR* cState);
	INT RRT_SET_RF_CONNECTOR(INT iRFConnector);
	INT RRT_QUERY_CURR_APP(CHAR* cValue);
	INT RRT_SET_APP_SECADDR(INT iAddr, INT iOptIndex);
	INT RRT_QUERY_APP_SECADDR(CHAR *cAPPList);
	INT RRT_SELECT_APPLICATION(CHAR* cAppName);
	INT RRT_SELECT_SCREEN(CHAR* cScreenName);
	INT RRT_QUERY_SCREEN(CHAR* cValue);
	INT RRT_SET_MOCALL(VOID);
	INT RRT_SET_ENDCALL(VOID);
	INT RRT_QUERY_CALLSTATUS(CHAR* cStatus);
	INT RRT_SET_WB_SERVICE_TYPE(CHAR* cType);
	INT RRT_SET_WB_TESTLOOPMODE(CHAR* cMode);
	INT RRT_3GPP_PRESET(VOID);
	INT RRT_SET_HANDOVER_TARGET(INT iBandIndex);
	INT RRT_SET_HANDOVER(VOID);
	INT RRT_SET_HANDOVER_ALERT_ON(BOOL bMode);
	INT RRT_SET_HANDOVER_WAIT_ON(BOOL bMode);
	INT RRT_CLEAR_STATUS(VOID);
	INT RRT_SET_NCC(INT iCode);
	INT RRT_SET_BCC(INT iCode);
	INT RRT_SET_LOOPBACK_ON(BOOL bLoopOn);
	INT RRT_SET_LOOPBACK_TYPE(INT iLoopType);
	INT RRT_SET_TIMESLOT(INT iSlotNumber);
	INT RRT_SET_BITOFFSET(INT iBitOffsetType);
	INT RRT_SET_FAST_MEASURE_MODE(BOOL bModeOn);
	INT RRT_SET_RF_CONNECTOR_TYPE(CHAR* cType);
	INT RRT_QUERY_CALLSTATUS_V2(CHAR* cMode, INT iQueryType);

	//Add for Agilent E6601A
	INT RRT_QUERY_RFG_CALIB_DATE(CHAR* cValue);

	//	Setting Functions
	INT RRT_SET_ALL_MEASURE_OFF(VOID);
	INT RRT_SET_CALLPROCESS_ON(BOOL bModeOn);
	INT RRT_SET_MODULATION_ON(BOOL bModeOn);
	INT RRT_SET_OPERATION_MODE(INT iOpeMode);
	INT RRT_SET_TSC(INT iTSC);
	INT RRT_SET_BCH_BAND(INT iBandIndex);
	INT RRT_SET_TCH_BAND(INT iBandIndex);
	INT RRT_SET_BCH_ARFCN(INT iArfcn);
	INT RRT_SET_TCH_ARFCN(INT iArfcn);
	INT RRT_SET_BSPOWER(double dPowerLev);
	INT RRT_SET_BSPOWER_ON(BOOL bModeOn);
	INT RRT_SET_AUTO_EXPECTED_POWER(BOOL bModeOn);
	INT RRT_SET_EXPECTED_POWER(INT iSlot, double dPowerLev);
	INT RRT_SET_EXPECTED_POWER_LEVEL(INT iSlot, INT iPCL);
	INT RRT_SET_SPEECH_SOURCE(CHAR* cSourceStr);
	INT RRT_SET_CODE_SCHEME(CHAR* cCodeScheme);
	INT RRT_SET_MODULATION_CONTROL_AUTO(BOOL bMode);
	INT RRT_SET_MULTISLOT_CONFIG(INT iUpSlot, INT iDownSlot);
	INT RRT_SET_MEASURE_OBJECT(INT iSlot, CHAR* cMeasObj);
	INT RRT_SET_OUTPUT_PATTERN(CHAR* cPattern);
	INT RRT_SET_RFG_FREQ_AUTO(BOOL bMode);
	INT RRT_SET_RFG_FREQ(double dFreqMHz);
	INT RRT_SET_RFG_BURSTTYPE(CHAR *cType);
	INT RRT_SET_RFAN_FREQ_AUTO(BOOL bMode);
	INT RRT_SET_RFAN_FREQ(double dFreqMHz);
	INT RRT_SET_RFAN_ATTENUATION(INT iType);
	INT RRT_SET_TPC_TYPE(INT iIndex, CHAR* cPattern);
	INT RRT_SET_WB_TPC_PATTERN(CHAR* cPattern);
	INT RRT_SET_WB_TPC_STEPSIZE(INT iStepsize);
	INT RRT_SET_WB_TPC_ALGORITHM(INT iALG);
	INT RRT_SET_WB_ACTIVATE_TPC_PATTERN(VOID);
	INT RRT_SET_WB_CHANNEL(INT iDLChannel, INT iUPChannel);
	INT RRT_SET_SPECTRUM_MONITOR_TRIGGER(CHAR* cMode);
	INT RRT_SET_TDMEAS_TRIGGER(CHAR* cMode);
	INT RRT_SET_TRIGGER(CHAR* cMode, CHAR *cSlope, double dThreshold);
	INT RRT_SET_SPECTRUM_MONITOR_TRIGGER_DELAY(double dDelay_ms);
	INT RRT_SET_TDMEAS_TRIGGER_DELAY(double dDelay_ms);
	INT RRT_SET_TRIGGER_DELAY(double dDelay_ms);
	INT RRT_SET_SLOTPOWER_STARTTIME(double dTime_us);
	INT RRT_SET_SLOTPOWER_DURATION(double dTimeperiod_us);
	INT RRT_SET_FASTPOWER_MEAS_MODE_ON(BOOL bMode);
	INT RRT_SET_SLOTPOWER_MEAS_ON(BOOL bMode);
	INT RRT_SET_SLOTPOWER_MEASSLOT(INT iStartslot, INT iEndslot);
	INT RRT_SET_SLOTPOWER_DEL_SLOT(INT iStartslot, INT iEndslot);
	INT RRT_SET_SLOTPOWER_THRESHOLD(double dLevel);
	INT RRT_SET_TDMEAS_TIMESPAN(double dTimespan_ms);
	INT RRT_SET_TDMEAS_RRC_FILTER_ON(BOOL bMode);
	INT RRT_SET_VIDEO_FILTER_LENGTH(double dLength_us);
	INT RRT_SET_WB_DTCH_DATATYPE(CHAR* cType);
	INT RRT_SET_WB_PRIMARY_SCRAMBING_CODE(INT iCode);
	INT RRT_SET_WB_CPICH_STATE_ON(BOOL bMode);
	INT RRT_SET_WB_CPICH_LEVEL(double dLevel);
	INT RRT_SET_WB_PRIMARY_CCPC_STATE_ON(BOOL bMode);
	INT RRT_SET_WB_PRIMARY_CCPC_LEVEL(double dLevel);
	INT RRT_SET_WB_SECONDARY_CCPCH_STATE_ON(BOOL bMode);
	INT RRT_SET_WB_SECONDARY_CCPCH_LEVEL(double dLevel);
	INT RRT_SET_WB_SCH_STATE_ON(BOOL bMode);
	INT RRT_SET_WB_SCH_LEVEL(double dLevel);
	INT RRT_SET_WB_PICH_CODE(INT iCode);
	INT RRT_SET_WB_PICH_STATE_ON(BOOL bMode);
	INT RRT_SET_WB_PICH_LEVEL(double dLevel);
	INT RRT_SET_WB_DPCH_CHANNEL_TYPE(CHAR* cType);
	INT RRT_SET_WB_DPCH_CODE(INT iCode);
	INT RRT_SET_WB_DPCH_STATE_ON(BOOL bMode);
	INT RRT_SET_WB_DPCH_LEVEL(double dLevel);
	INT RRT_SET_WB_DPCH_SACODE(INT iCode);
	INT RRT_SET_WB_DPCH_DOWNLINK_SEC_SCRAMBLING_CODE(INT iCode);
	INT RRT_SET_WB_DPCH_UPLINK_SCRAMBLING_CODE(INT iCode);
	INT RRT_SET_WB_AICH_CODE(INT iCode);
	INT RRT_SET_WB_AICH_STATE_ON(BOOL bMode);
	INT RRT_SET_WB_AICH_LEVEL(double dLevel);
	INT RRT_SET_WB_UL_GAIN_FACTOR(INT iBetaC, INT iBetaD);
	INT RRT_SET_WB_ULDPCH_GAIN_MODE(BOOL bIsAuto);
	INT RRT_SET_DATA_CONNECTION_TYPE(CHAR* cType);
	INT RRT_SET_WB_AUTH_KEY(CHAR* cKey);
	INT RRT_SET_WB_MS_IMSI(CHAR* cIMSI);
	INT RRT_SET_WB_AUTH_STATE_ON(BOOL bMode);
	INT RRT_SET_CELL_OFF(VOID);
	INT RRT_SET_ACTIVE_SLOTPOWER_WINDOW(VOID);
	INT RRT_SET_WB_ILPC_TPC_STEP(CHAR* cStep);
	INT RRT_SET_WB_ILPC_TPC_COMMAND_LENGTH(CHAR *cStep, INT iLength);
	INT RRT_SET_WB_ILPC_MAX_THRESHOLD(BOOL bAutoModeOn, double dLevel);
	INT RRT_SET_WB_ILPC_MIN_THRESHOLD(BOOL bAutoModeOn, double dLevel);
	INT RRT_SET_WB_AWGN_STATE_ON(BOOL bModeOn);
	INT RRT_SET_WB_AWGN_LEVEL(double dLevel);
	INT RRT_SET_WB_AM_SIGNAL_ON(BOOL bModeON);
	INT RRT_SET_EG_MS_IMSI(CHAR* cIMSI);
	INT RRT_SET_EG_BAND_INDICATOR(BOOL bIsDCSIndicator);
	INT RRT_QUERY_EG_BAND_INDICATOR(CHAR* cStatus);
	INT RRT_QUERY_EG_REG_STATUS(VOID);
	INT RRT_SET_WB_FREQ(BOOL bIsULFreq, double dFreqMHz);
	INT RRT_SET_WB_REG_TXRX_FREQ(INT iSeqNum, CHAR *cFreqstr);
	INT RRT_SET_WB_REG_RX_PWR(CHAR *cRXPWr);
	INT RRT_SET_WB_REG_TX_PWR(CHAR *cTXPWr);
	INT RRT_SET_BSPOWER_CONTINUOUS(BOOL bContOn);
	INT RRT_SET_UE_MEAS_REPORT_ON(BOOL bModeOn);

	INT RRT_SET_DPA_CHANNEL_CODING(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_REGISTRATION_MODE(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_HSHSET(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_DPCH_OFFSET(RRT_PARAMETERS &stParameter);//mzlin 20090702 //Default DPCH Offset 0~5;TCR Default DPCH Offset  0~5;(HSDPA set 3, WCDMA set 0)
	INT RRT_SET_DPA_FDD_TEST_DPCH_LEVEL(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_PHYSICAL_CHANNEL_LEVEL(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_DELTA_ACK(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_DELTA_NACK(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_DELTA_CQI(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_ACKNACK_REPETITION_FACTOR(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_CQI_FEEDBACK_CYCLE(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_CQI_REPETITION_FACTOR(RRT_PARAMETERS &stParameter);//mzlin 20090702
	INT RRT_SET_DPA_BetaC_BetaD(INT iBetaC, INT iBetaD);//mzlin 20090702
	INT RRT_SET_DPA_MEASURE_OBJECT(CHAR* cMeasObj);//mzlin 20091204
	INT RRT_SET_DPA_HSMA_ITEM(CHAR* cMeasItem);//mzlin 20091204

	INT RRT_SET_DPA_CHANNEL(INT iDLChannel, INT iUPChannel);//mzlin 20091204
	INT RRT_SET_DPA_8960_TCR_HANDOVER(VOID);//mzlin 20091204

	//	Measurement Functions
	INT RRT_SET_POWER_COUNT(INT iCount);
	INT	RRT_SET_POWER_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_POWER_CONTINUOUS_ON(BOOL bModeOn);
	INT RRT_SET_INIT_TXP(VOID);
	INT RRT_FETCH_TXP(CHAR* cValue);
	INT RRT_SET_END_TXP(VOID);
	INT RRT_SET_PVT_COUNT(INT iCount);
	INT RRT_SET_PVT_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_PVT_CONTINUOUS_ON(BOOL bModeOn);
	INT RRT_SET_PVT_TIMEOFFSET(CHAR* cTimeoffset);
	INT RRT_SET_PVT_PCS_LIMIT(CHAR* cLimitMode);
	INT RRT_SET_PVT_BURST_SYNC_MODE(CHAR* cSyncMode);
	INT RRT_SET_INIT_PVT(VOID);
	INT RRT_FETCH_PVT(CHAR* cValue);
	INT RRT_SET_END_PVT(VOID);
	INT RRT_SET_PFER_COUNT(INT iCount);
	INT RRT_SET_PFER_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_PFER_CONTINUOUS_ON(BOOL bModeOn);
	INT RRT_SET_INIT_PFER(VOID);
	INT RRT_FETCH_FREQ_ERR(CHAR* cValue);
	INT RRT_FETCH_PEAK_PHASE_ERR(CHAR* cValue);
	INT RRT_FETCH_RMS_PHASE_ERR(CHAR* cValue);
	INT RRT_FETCH_PEAK_EVM(CHAR* cValue);
	INT RRT_FETCH_RMS_EVM(CHAR* cValue);
	INT RRT_FETCH_95TH(CHAR* cValue);
	INT RRT_FETCH_ORIGIN_OFFSET(CHAR* cValue);
	INT RRT_SET_END_PFER(VOID);
	INT RRT_SET_ORFS_COUNT(INT iMod_Count, INT iSw_Count);
	INT RRT_SET_ORFS_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_ORFS_CONTINUOUS_ON(BOOL bModeOn);
	INT RRT_SET_ORFS_FREQOFFSET(CHAR* cMod_Freq, CHAR* cSw_Freq);
	INT RRT_SET_ORFS_FILTER_TYPE(CHAR* cType);
	INT RRT_QUERY_ORFS_FILTER_TYPE(CHAR* cValue);
	INT RRT_SET_INIT_ORFS(VOID);
	INT RRT_FETCH_ORFS(CHAR* cModResult, CHAR* cSwResult);
	INT RRT_SET_END_ORFS(VOID);
	INT RRT_FETCH_ORFS_30KHZ_BW_POWER(CHAR* cPower);
	INT RRT_SET_FBER_COUNT(INT iCount);
	INT RRT_SET_FBER_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_FBER_CONTINUOUS_ON(BOOL bModeOn);
	INT RRT_SET_INIT_FBER(VOID);
	INT RRT_FETCH_FBER(CHAR* cValue);
	INT RRT_SET_END_FBER(VOID);
	INT RRT_FBER_TEST_SETUP(INT iTestIndex);
	INT RRT_SET_FBER_TCH_LEVEL(double dLevel);
	INT RRT_SET_FBER_CLOSELOOP_DELAY(INT iDelayms);
	INT RRT_SET_WB_FBER_UL_TFCI_AUTO_CONTROL(BOOL bModeOn);
	INT RRT_SET_WB_FBER_DL_TFCI(CHAR* cCode);
	INT RRT_SET_INIT_WB_MAXTXP(VOID);
	INT RRT_FETCH_WB_MAXTXP(CHAR* cValue);
	INT RRT_SET_END_WB_MAXTXP(VOID);
	INT RRT_SET_INIT_WB_MINTXP(VOID);
	INT RRT_FETCH_WB_MINTXP(CHAR* cValue);
	INT RRT_SET_END_WB_MINTXP(VOID);
	INT RRT_SET_INIT_WB_OPENLOOP_POWER(VOID);
	INT RRT_FETCH_WB_OPENLOOP_POWER(CHAR* cValue);
	INT RRT_SET_END_WB_OPENLOOP_POWER(VOID);
	INT RRT_SET_INIT_WB_SLOTPOWER(VOID);
	INT RRT_FETCH_WB_SLOTPOWER(CHAR* cValue);
	INT RRT_SET_END_WB_SLOTPOWER(VOID);
	INT RRT_SET_WB_SEM_COUNT(INT iCount);
	INT RRT_SET_WB_SEM_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_WB_SEM_COUTINUOUS_ON(BOOL bMode);
	INT RRT_SET_WB_SEM_DETECTMODE(CHAR* cMode);
	INT RRT_SET_INIT_WB_SEM(VOID);
	INT RRT_FETCH_WB_SEM(CHAR* cValue);
	INT RRT_SET_END_WB_SEM(VOID);
	INT RRT_SET_WB_ACLR_COUNT(INT iCount);
	INT RRT_SET_WB_ACLR_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_WB_ACLR_COUTINUOUS_ON(BOOL bMode);
	INT RRT_SET_WB_ACLR_QUERY_STATUS(BOOL bN10On, BOOL bN5On, BOOL bP5On, BOOL bP10On);
	INT RRT_SET_INIT_WB_ACLR(VOID);
	INT RRT_FETCH_WB_ACLR(CHAR* cValueN5, CHAR* cValueN10, CHAR* cValueP5, CHAR* cValueP10);
	INT RRT_SET_END_WB_ACLR(VOID);
	INT RRT_GET_VALUE_FROM_STRING_LIST(CHAR* pSource, int iNumber, CHAR* out_pResult);
	INT RRT_SET_WB_OBW_COUNT(INT iCount);
	INT RRT_SET_WB_OBW_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_WB_OBW_COUTINUOUS_ON(BOOL bMode);
	INT RRT_SET_INIT_WB_OBW(VOID);
	INT RRT_FETCH_WB_OBW(CHAR* cValue);
	INT RRT_SET_END_WB_OBW(VOID);
	INT RRT_SET_INIT_WB_ILPC(VOID);
	INT RRT_FETCH_WB_ILPC(CHAR* cValue);
	INT RRT_FETCH_WB_ILPC_TESTED_SLOT(CHAR* cValue);
	INT RRT_SET_END_WB_ILPC(VOID);
	INT RRT_SET_PCAL_FILTER_TYPE(CHAR* cType);
	INT RRT_SET_PCAL_WAVEFORM_TYPE(CHAR* cType);
	INT RRT_SET_PCAL_TRIGGER_SOURCE(CHAR* cType);
	INT RRT_SET_PCAL_TRIGGER_THRESHOLD(double dValue);
	INT RRT_SET_PCAL_RESULT_TYPE(CHAR* cType);
	INT RRT_SET_PCAL_STEP_COUNT(INT iCount);
	INT RRT_SET_PCAL_STEP_CENTER(double dValueS);
	INT RRT_SET_PCAL_STEP_WIDTH(INT iValueMS);
	INT RRT_SET_PCAL_TIMEOUT(INT iTimeoutS);
	INT RRT_SET_INIT_PCAL(INT iDuration = 0.0, INT iPeriodNumber = 0, double dRatio = 0.0, INT iType = 0);
	INT RRT_FETCH_PCAL_MEAS_COMPLETE(VOID);
	INT RRT_FETCH_PCAL_POWER(INT iSampleCount, CHAR* cValue);
	INT RRT_FETCH_PCAL_PHASE(INT iSampleCount, CHAR* cValue);
	INT RRT_SET_WB_MULTIPOWER(RRT_PARAMETERS &stParameter);
	INT RRT_SET_INIT_WB_MULTIPOWER(VOID);
	INT RRT_FETCH_WB_MULTIPOWER(INT iStepNumber, CHAR* cValue);
	INT RRT_FETCH_RSSI(CHAR *out_psRxQ, CHAR *out_psRxL);
	INT RRT_SET_INIT_WB_TXRX_FREQ_MEASUREMENT(INT iSegment, INT iSequence);
	INT RRT_FETCH_WB_TXRX_FREQ_MEASUREMENT(CHAR *cValue);
	INT RRT_FETCH_UE_CPICH_RSCP(CHAR *cValue);
	INT RRT_SET_WB_PCDE_COUNT(INT iCount);
	INT RRT_SET_INIT_WB_PCDE(VOID);
	INT RRT_FETCH_WB_PCDE(CHAR* cValue);
	INT RRT_SET_END_WB_PCDE(VOID);

	//	Combined RRT functions
	INT RRT_CX_INSTRUMENT_RESET(VOID);
	INT RRT_CX_INSTRUMENT_CALIBRATION(VOID);
	INT RRT_CX_SET_INSTRUMENT_CABLELOSS(CHAR *cState, double dLossFreq[], double dLossGain[], INT iLossCount);
	INT RRT_CX_SET_INSTRUMENT_MODE(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_EG_POWER(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_EG_PVT(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_EG_PFER(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_EG_ORFS(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_EG_FBER(RRT_PARAMETERS &stParameter);

	INT RRT_CX_SET_WB_DPCH_PARAMETER(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_POWER(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_SEM(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_ACLR(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_OBW(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_BER(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_TRANSMISSION_POWER_CONTROL(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_TRIGGER(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_ILPC(RRT_PARAMETERS &stParameter);
	INT RRT_CX_SET_WB_PCDE(RRT_PARAMETERS &stParameter);

	//	Combined functions for calibration
	INT RRT_CX_QCOMM_GSM_CAL_INIT(VOID);
	INT RRT_CX_QCOMM_WB_CAL_INIT(VOID);
	INT RRT_CX_QCOMM_GSM_RX_CAL_INIT(RRT_PARAMETERS &stParameter);
	INT RRT_CX_QCOMM_GSM_POLAR_CAL_INIT(VOID);
	INT RRT_CX_QCOMM_SET_GSM_POLAR_MEAS_INIT(RRT_PARAMETERS &stParameter);
	INT RRT_CX_QCOMM_SET_GSM_PHASEDELAY_INIT(RRT_PARAMETERS &stParameter);
	INT RRT_CX_QCOMM_SET_GSM_VCO_INIT(RRT_PARAMETERS &stParameter);
	INT RRT_CX_QCOMM_NSCALL_HANDOVER(RRT_PARAMETERS &stParameter);
	INT RRT_CX_QCOMM_SIGCALL_HANDOVER(RRT_PARAMETERS &stParameter);
	/********************		End -- RRT virtual functions		********************/
};

#endif // !defined(AFX_8960_H__D0364F02_E89E_43DA_B752_00EE9B3997B6__INCLUDED_)
