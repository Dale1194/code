// AgilentE3646A.cpp: implementation of the CAgilentE3646A class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "AgilentE3646A.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAgilentE3646A::CAgilentE3646A()
{
	m_hDLL	= NULL;

	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	//m_hDLL = ::LoadLibraryEx(m_szDLLFile, NULL, DONT_RESOLVE_DLL_REFERENCES);
	if(NULL == m_hDLL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
	}
	else
	{
		viOpenDefaultRM	= (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL,"viOpenDefaultRM");
		viOpen			= (pf_viOpen_t)::GetProcAddress(m_hDLL,"viOpen");
		viPrintf		= (pf_viPrintf_t)::GetProcAddress(m_hDLL,"viPrintf");
		viScanf			= (pf_viScanf_t)::GetProcAddress(m_hDLL,"viScanf");
		viClose			= (pf_viClose_t)::GetProcAddress(m_hDLL,"viClose");
		viQueryf		= (pf_viQueryf_t)::GetProcAddress(m_hDLL,"viQueryf");
		viClear			= (pf_viClear_t)::GetProcAddress(m_hDLL,"viClear");
		viSetAttribute	= (pf_viSetAttribute_t)::GetProcAddress(m_hDLL,"viSetAttribute");
	}
}
CAgilentE3646A::~CAgilentE3646A()
{
	if(m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
}

//***************************************************************************
// Description: Send GPIB command to Device via Visa
//***************************************************************************
INT CAgilentE3646A::Write(CONST CHAR *pcCommand)
{
	ViStatus		status;
	CHAR			GPIBLog[1024] = {0x00};

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog), "WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viPrintf(m_viSession, m_szCommand);

	if (status != VI_SUCCESS)
	{
		return GPIB_WRITE_FAIL;
	}
	return GPIB_SUCCESS;
}

//***************************************************************************
// Description: Execute Query command & get value from Device via Visa
//***************************************************************************
INT CAgilentE3646A::Query(CONST CHAR *pcCommand, CHAR *pcReturnValue)
{
	ViStatus		status;
	CHAR			GPIBLog[1024] = {0x00};

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog), "WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}
	
	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viQueryf(m_viSession, m_szCommand, "%t", pcReturnValue);
	if (status != VI_SUCCESS)
	{
		return GPIB_QUERY_FAIL;
	}

	if (m_bGPIB_Log_Enable == TRUE)
	{
		memset(GPIBLog, 0x00, sizeof(GPIBLog));
		sprintf_s(GPIBLog, sizeof(GPIBLog), "RE: %s", pcReturnValue);
		GPIBTrace(GPIBLog);
	}

	return GPIB_SUCCESS;
}
//***************************************************************************
// Description: Virtual Function
//***************************************************************************
INT	CAgilentE3646A::VISA32_SET_VI_SESSION(DWORD vi)
{
	m_viSession = (ViSession)vi;
	return GPIB_SUCCESS;
}

INT	CAgilentE3646A::VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable)
{
	m_bGPIB_Log_Enable = bGPIBLog_Enable;
	GPIBTrace("##########		E3646A Test Start		##########");
	return GPIB_SUCCESS;
}

INT	CAgilentE3646A::PPS_SET_VOLTAGE(double dVoltage)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "INST:SEL OUT1");
	iGPIBRet = Write(m_szCommand);
	sprintf_s(m_szCommand, "VOLT %2.2f",dVoltage);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CAgilentE3646A::PPS_SET_VOLTAGE_CH2(double dVoltage)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "INST:SEL OUT2");
	iGPIBRet = Write(m_szCommand);
	sprintf_s(m_szCommand, "VOLT %2.2f",dVoltage);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CAgilentE3646A::PPS_SET_CURRENT(double dCurrLimit)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "INST:SEL OUT1");
	iGPIBRet = Write(m_szCommand);
	sprintf_s(m_szCommand, "CURR %2.1f",dCurrLimit);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CAgilentE3646A::PPS_SET_CURRENT_CH2(double dCurrLimit)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "INST:SEL OUT2");
	iGPIBRet = Write(m_szCommand);
	sprintf_s(m_szCommand, "CURR %2.1f",dCurrLimit);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CAgilentE3646A::PPS_SET_POWER_ON(VOID)
{
	sprintf_s(m_szCommand, "OUTP ON");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CAgilentE3646A::PPS_SET_POWER_ON_CH2(VOID)
{
	sprintf_s(m_szCommand, "OUTP2 ON");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CAgilentE3646A::PPS_SET_POWER_OFF(VOID)
{
	sprintf_s(m_szCommand, "OUTP OFF");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CAgilentE3646A::PPS_SET_POWER_OFF_CH2(VOID)
{
	sprintf_s(m_szCommand, "OUTP2 OFF");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

//***************************************************************************
// Description: End
//***************************************************************************