#ifndef _GPIBDEVICE_H
#define _GPIBDEVICE_H

#include "visa_ExportApi.h"
//#include "8820.h"
//#include "8960.h"
//#include "Cmu200.h"
#include "Agilent34970A.h"
//#include "Agilent3458A.h"
#include "AgilentE3646A.h"
#include "Agilent663x.h"
#include "Keithley230x.h"
#include "ReturnType.h"
#include "VirtualFunction.h"
//#include "E6601A.h"
//#include "Agilent53131A.h"
#include "Motech1201.h"
//#include "AdvanTestR3131A.h"
//#include "Rohde_Schwarz_FSP.h"
//#include "Anritsu.h"
#include "LitePointXstreamM.h"
#include <map>
#include "..\modules\outputlog\OutputDebug.h"
#include "..\modules\outputlog\DebugMessage.h"

#pragma once

class CGPIBDevice
{
public:
	CGPIBDevice();
	virtual ~CGPIBDevice();

public:
	CVirtualInstrument*		m_PPSObj;
	CVirtualInstrument*		m_PPS2Obj;
	CVirtualInstrument*		m_RRTObj;
	CVirtualInstrument*		m_DMMObj;
	CVirtualInstrument*		m_DMM2Obj;
	CVirtualInstrument*		m_DMM3Obj;	// 2012/12/12 0505/PM Brighd for new DMM 3458A
	CVirtualInstrument*		m_FREObj;
	CVirtualInstrument*		m_FRE2Obj;
	CVirtualInstrument*		m_FRE3Obj;
	CVirtualInstrument*		m_FRE4Obj;

	CHAR                    m_szDLLFile[MAX_PATH];
	CHAR					m_szCommand[256];
	CHAR					m_szGetDeviceName[256];
		
	BOOL					m_bPPSExist;
	BOOL					m_bPPS2Exist;
	BOOL					m_bRRTExist;
	BOOL					m_bDMMExist;
	BOOL					m_bDMM2Exist;
	BOOL					m_bDMM3Exist;	// 2012/12/12 0505/PM Brighd for new DMM 3458A
	BOOL					m_bFREExist;
	BOOL					m_bFRE2Exist;
	BOOL					m_bFRE3Exist;
	BOOL					m_bFRE4Exist;
	INT						m_iRRTBrandType;
	INT						m_i8820Type;

	BOOL					m_isPPS1_DualCH;
	BOOL					m_isPPS2_DualCH;
	
	HINSTANCE				m_hDLL;
	ViSession				m_viOpenDefaultRM_RRT, m_viSession_RRT;
	ViSession				m_viOpenDefaultRM_PPS, m_viSession_PPS;
	ViSession				m_viOpenDefaultRM_PPS2, m_viSession_PPS2;
	ViSession				m_viOpenDefaultRM_DMM, m_viSession_DMM;
	ViSession				m_viOpenDefaultRM_DMM2, m_viSession_DMM2;
	ViSession				m_viOpenDefaultRM_DMM3, m_viSession_DMM3;	// 2012/12/12 0505/PM Brighd for new DMM 3458A
	ViSession				m_viOpenDefaultRM_FRE, m_viSession_FRE;
	ViSession				m_viOpenDefaultRM_FRE2, m_viSession_FRE2;
	ViSession				m_viOpenDefaultRM_FRE3, m_viSession_FRE3;
	ViSession				m_viOpenDefaultRM_FRE4, m_viSession_FRE4;
	
	pf_viOpen_t				viOpen;
	pf_viScanf_t			viScanf;
	pf_viClose_t			viClose;
	pf_viPrintf_t			viPrintf;
	pf_viOpenDefaultRM_t	viOpenDefaultRM;
	pf_viQueryf_t			viQueryf;
	pf_viClear_t			viClear;
	pf_viSetAttribute_t		viSetAttribute;
	pf_viWrite_t			viWrite;
	pf_viGpibControlREN_t	viGpibControlREN;

	
	struct VIRESOURCE {
		ViSession			viDefaultRM;
		ViSession			viSession;
		CVirtualInstrument* vInst;
	};

private:
	// ++++++++ Fox +++++++++
	map<string, VIRESOURCE*> m_vi;
	CDebugMessage m_dbgmsg;
	// -------- Fox ---------


	
public:
	INT		DETECT_DEVICE(DEVICE_CONTROL stDevice);
	INT		CLOSE_ALL_SESSION(VOID);
	INT		CLOSE_PPS_SESSION(VOID);
	INT		CLOSE_RRT_SESSION(VOID);
	INT		CLOSE_DMM_SESSION(VOID);
	INT		CLOSE_FRE_SESSION(VOID);
	INT		SELECT_PPS(ViSession defaultRM, CHAR *pcCommand);
	INT     SELECT_PPS2(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_RRT(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_DMM(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_DMM2(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_DMM3(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_FRE(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_FRE2(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_FRE3(ViSession defaultRM, CHAR *pcCommand);
	INT		SELECT_FRE4(ViSession defaultRM, CHAR *pcCommand);
	INT		UNLOAD_DLL(VOID);


	// ++++++++ Fox +++++++++
public:
	void AddOutput(COutputDebug* output);
	int Init(const char* alias_name, const char* gpib_ins, const char* vesa_res_name, int gpib_board, int bpib_addr);
	bool HaveInit(const char* alias_name);
	CVirtualInstrument* use(const char* alias_name);
private:
	int LoadDll(void);
	int select_pps(ViSession defaultRM, char *pcCommand, ViSession& viSession, CVirtualInstrument** vInst);
	int select_dmm(ViSession defaultRM, char *pcCommand, ViSession& viSession, CVirtualInstrument** vInst);
	int select_rrt(ViSession defaultRM, char *pcCommand, ViSession& viSession, CVirtualInstrument** vInst);
	// -------- Fox ---------
};

#endif // !defined(AFX_GPIBDEVICE_H__FB9ACC39_0BAD_443D_BD7F_E18B822F4490__INCLUDED_)
