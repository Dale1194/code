#ifndef _MOTECH1201_H
#define _MOTECH1201_H

#include "visa_ExportApi.h"
#include "ReturnType.h"
#include "GlobalVar.h"
#include "VirtualFunction.h"
#include "CommonAPI.h"

class CMotech1201 : public CVirtualInstrument
{
public:
	CMotech1201();
	virtual ~CMotech1201();

public:	
	HINSTANCE				m_hDLL;
	CHAR					m_szDLLFile[MAX_PATH];
	CHAR					m_szCommand[256];
	CHAR					m_szReadBuffer[1024];

	ViSession				m_viSession;

	pf_viOpen_t				viOpen;
	pf_viScanf_t			viScanf;
	pf_viClose_t			viClose;
	pf_viPrintf_t			viPrintf;
	pf_viOpenDefaultRM_t	viOpenDefaultRM;
	pf_viQueryf_t			viQueryf;
	pf_viClear_t			viClear;
	pf_viSetAttribute_t		viSetAttribute;

public:
	INT	Write(CONST CHAR *cpcCommand);
	INT	Query(CONST CHAR *cpcCommand, CHAR *pcReturnValue);

public:
	// Virtual Function
	INT	VISA32_SET_VI_SESSION(DWORD vi);

	INT	PPS_SET_VOLTAGE(double dVoltage);
	INT	PPS_SET_VOLTAGE_CH2(double dVoltage);
	INT	PPS_SET_CURRENT(double dCurrentLimit);
	INT	PPS_SET_CURRENT_CH2(double dCurrentLimit);
	INT	PPS_SET_POWER_ON(VOID);
	INT	PPS_SET_POWER_ON_CH2(VOID);
	INT	PPS_SET_POWER_OFF(VOID);
	INT	PPS_SET_POWER_OFF_CH2(VOID);
	INT PPS_GET_CURRENT(double *pdCurrent);
	INT PPS_GET_CURRENT_CH2(double *pdCurrent);
	INT PPS_GET_VOLTAGE(double *pdVoltage);
	INT PPS_GET_VOLTAGE_CH2(double *pdVoltage);
};

#endif