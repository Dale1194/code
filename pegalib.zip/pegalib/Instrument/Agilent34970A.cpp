﻿// CAgilent34970A.cpp: implementation of the CAgilent34970A class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Agilent34970A.h"

//#ifdef _DEBUG
//#undef THIS_FILE
//static char THIS_FILE[]=__FILE__;
//#define new DEBUG_NEW
//#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAgilent34970A::CAgilent34970A()
{
	m_hDLL = NULL;
	m_iDeviceBrand = 0; // (0=Agilent/HP, 1=GWinstek)

	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	//m_hDLL = ::LoadLibraryEx(m_szDLLFile, NULL, DONT_RESOLVE_DLL_REFERENCES);
	if (NULL == m_hDLL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
	}
	else
	{
		viOpenDefaultRM = (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL, "viOpenDefaultRM");
		viOpen = (pf_viOpen_t)::GetProcAddress(m_hDLL, "viOpen");
		viPrintf = (pf_viPrintf_t)::GetProcAddress(m_hDLL, "viPrintf");
		viScanf = (pf_viScanf_t)::GetProcAddress(m_hDLL, "viScanf");
		viClose = (pf_viClose_t)::GetProcAddress(m_hDLL, "viClose");
		viQueryf = (pf_viQueryf_t)::GetProcAddress(m_hDLL, "viQueryf");
		viClear = (pf_viClear_t)::GetProcAddress(m_hDLL, "viClear");
		viSetAttribute = (pf_viSetAttribute_t)::GetProcAddress(m_hDLL, "viSetAttribute");
	}
}

CAgilent34970A::~CAgilent34970A()
{
	if (m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
}
//***************************************************************************
// Description	: Send GPIB command to Device via Visa
//***************************************************************************
INT CAgilent34970A::Write(CONST CHAR *pcCommand)
{
	ViStatus		status;
	CHAR			GPIBLog[1024] = { 0x00 };

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog), "WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viPrintf(m_viSession, m_szCommand);

	if (VI_SUCCESS != status)
	{
		return GPIB_WRITE_FAIL;
	}

	return GPIB_SUCCESS;
}

//***************************************************************************
// Description	: Execute Query command & get value from Device via Visa
//***************************************************************************
INT CAgilent34970A::Query(CONST CHAR *pcCommand, CHAR *pcReturnValue)
{
	ViStatus		status;
	CHAR			GPIBLog[1024] = { 0x00 };

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog), "WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viQueryf(m_viSession, m_szCommand, "%t", pcReturnValue);

	if (VI_SUCCESS != status)
	{
		return GPIB_QUERY_FAIL;
	}

	if (m_bGPIB_Log_Enable == TRUE)
	{
		memset(GPIBLog, 0x00, sizeof(GPIBLog));
		sprintf_s(GPIBLog, sizeof(GPIBLog), "RE: %s", pcReturnValue);
		GPIBTrace(GPIBLog);
	}

	return GPIB_SUCCESS;
}
//***************************************************************************
// Description: Virtual Function
//***************************************************************************
INT	CAgilent34970A::VISA32_SET_VI_SESSION(DWORD vi)
{
	m_viSession = (ViSession)vi;
	return GPIB_SUCCESS;
}

INT	CAgilent34970A::VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable)
{
	m_bGPIB_Log_Enable = bGPIBLog_Enable;
	GPIBTrace("##########		34970A Test Start		##########");
	return GPIB_SUCCESS;
}

INT CAgilent34970A::GPIB_WRITE(const char* command)
{
	return this->Write(command);
}

INT CAgilent34970A::GPIB_QUERY(const char* command, char* returnVal)
{
	return this->Query(command, returnVal);
}

INT CAgilent34970A::SET_DEVICE_BRAND(INT iBrand) // dale add 02/07/2025 function to set device brand
{
	m_iDeviceBrand = iBrand;
	return GPIB_SUCCESS;
}

INT CAgilent34970A::ROUTE_OPEN(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "ROUT:Open (@%d)", iCH);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_ROUT_OPEN_FAIL;
	}
	return iGPIBRet;
}

INT CAgilent34970A::ROUTE_CLOSE(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "ROUT:Close (@%d)", iCH);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_ROUT_CLOSE_FAIL;
	}
	return iGPIBRet;
}

INT CAgilent34970A::ROUTE_OPEN_2CH(INT iCH1, INT iCH2)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "ROUT:Open (@%d,%d)", iCH1, iCH2);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_ROUT_OPEN_FAIL;
	}
	return iGPIBRet;
}

INT CAgilent34970A::ROUTE_CLOSE_2CH(INT iCH1, INT iCH2)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "ROUT:Close (@%d,%d)", iCH1, iCH2);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_ROUT_CLOSE_FAIL;
	}
	return iGPIBRet;
}

INT CAgilent34970A::ROUTE_SCAN(INT iCH)
{
#if 0
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "ROUT:SCAN (@%d)", iCH);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_ROUT_SCAN_FAIL;
	}
	return iGPIBRet;
#endif
	return GPIB_SUCCESS;
}

INT CAgilent34970A::SET_DC_CURRENT(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	// Set measurement type
	m_iCurrMeasType = DMM_TYPE_DC_CURR;

	// Kiểm tra brand thiết bị để sử dụng command phù hợp
	if (m_iDeviceBrand == 1) // GWinstek GDM9061
	{
		// GDM9061 sử dụng command đơn giản hơn
		sprintf_s(m_szCommand, "CONF:CURR:DC;*OPC?");
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		}
	}
	else // Agilent/HP 34970A (mặc định)
	{
		//2011/04/13, Modified to set the range & resolution in INI file.
		//sprintf_s(m_szCommand, "CONF:CURRent:DC MAX,(@%d)", iCH);

		sprintf_s(m_szCommand, "CONF:CURR:DC %s,DEF,(@%d);*OPC?", m_DMMMeasPara.szRange, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		}

		if (GPIB_SUCCESS == iGPIBRet)
		{
			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
			sprintf_s(m_szCommand, "SENS:CURR:DC:NPLC %s,(@%d);*OPC?", m_DMMMeasPara.szIntegrationTime, iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
			else
			{
				if (1 != atoi(m_szReadBuffer))
					iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
			}
		}
	}
	return iGPIBRet;
}

INT CAgilent34970A::SET_DC_CURRENT_1A(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	//20060908 suggest by Apple
	//sprintf_s(m_szCommand,"CONF:CURRent:DC MAX,(@%d)",iCH);
	sprintf_s(m_szCommand, "CONF:CURRent:DC MAX, 1E-6,(@%d)", iCH);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
	}
	return iGPIBRet;
}

INT CAgilent34970A::SET_DC_CURRENT_uA(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "CONF:CURRent:DC 1mA, (@%d)", iCH);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
	}
	return iGPIBRet;
}

INT CAgilent34970A::SET_AC_CURRENT(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	// Set measurement type
	m_iCurrMeasType = DMM_TYPE_AC_CURR;

	// Kiểm tra brand thiết bị để sử dụng command phù hợp
	if (m_iDeviceBrand == 1) // GWinstek GDM9061
	{
		// GDM9061 sử dụng command đơn giản hơn
		sprintf_s(m_szCommand, "CONF:CURR:AC;*OPC?");
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
		}
	}
	else // Agilent/HP 34970A (mặc định)
	{
		sprintf_s(m_szCommand, "CONF:CURR:AC %s,%s,(@%d);*OPC?", m_DMMMeasPara.szRange, m_DMMMeasPara.szResolution, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
		}

		//Set Low Frequency Filter --> Only available when AC measurement
		if (GPIB_SUCCESS == iGPIBRet)
		{
			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
			sprintf_s(m_szCommand, "SENS:CURR:AC:BAND %s,(@%d);*OPC?", m_DMMMeasPara.szLFF, iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			else
			{
				if (1 != atoi(m_szReadBuffer))
					iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			}
		}
	}
	return iGPIBRet;
}

INT CAgilent34970A::SET_DC_VOLTAGE(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	// Set measurement type
	m_iCurrMeasType = DMM_TYPE_DC_VOLT;

	// Kiểm tra brand thiết bị để sử dụng command phù hợp
	if (m_iDeviceBrand == 1) // GWinstek GDM9061
	{
		// GWinstek GDM9061 sử dụng command đơn giản hơn
		sprintf_s(m_szCommand, "CONF:VOLT:DC;*OPC?");
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_DC_VOLTAGE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_DC_VOLTAGE_FAIL;
		}
	}
	else // Agilent/HP 34970A (mặc định)
	{
		//sprintf_s(m_szCommand, "CONF:VOLT:DC %s,DEF,(@%d);*OPC?", m_DMMMeasPara.szRange, iCH);
		sprintf_s(m_szCommand, "CONF:VOLT:DC %s,DEF,(@%d);*OPC?", m_DMMMeasPara.szRange, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_DC_VOLTAGE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_DC_VOLTAGE_FAIL;
		}

		if (GPIB_SUCCESS == iGPIBRet)
		{
			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
			sprintf_s(m_szCommand, "SENS:VOLT:DC:NPLC %s,(@%d);*OPC?", m_DMMMeasPara.szIntegrationTime, iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
			else
			{
				if (1 != atoi(m_szReadBuffer))
					iGPIBRet = GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
			}
		}
	}
	return iGPIBRet;
}

INT CAgilent34970A::SET_AC_VOLTAGE(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	// Set measurement type
	m_iCurrMeasType = DMM_TYPE_AC_VOLT;

	// Kiểm tra brand thiết bị để sử dụng command phù hợp
	if (m_iDeviceBrand == 1) // GWinstek GDM9061
	{
		// GDM9061 sử dụng command đơn giản hơn
		sprintf_s(m_szCommand, "CONF:VOLT:AC;*OPC?");
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_AC_VOLTAGE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_VOLTAGE_FAIL;
		}
	}
	else // Agilent/HP 34970A (mặc định)
	{
		sprintf_s(m_szCommand, "CONF:VOLT:AC %s,%s,(@%d);*OPC?", m_DMMMeasPara.szRange, m_DMMMeasPara.szResolution, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_AC_VOLTAGE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_VOLTAGE_FAIL;
		}

		//Set Low Frequency Filter --> Only available when AC measurement
		if (GPIB_SUCCESS == iGPIBRet)
		{
			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
			sprintf_s(m_szCommand, "SENS:CURR:AC:BAND %s,(@%d);*OPC?", m_DMMMeasPara.szLFF, iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			else
			{
				if (1 != atoi(m_szReadBuffer))
					iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			}
		}
	}
	return iGPIBRet;
}

//***************************************************************************
// Function	: READ_DC_VOLTAGE
// Purpose	: Measurement voltage 
// Input	: iStableTime -- wait time for stable, the unit is ms
//			: iFetchTime  -- repeat time for Fetch testing value
//			: iCH -- 34970A's channel number
// Output	: pdDCVolt -- the testing result 
//***************************************************************************
INT CAgilent34970A::READ_DC_VOLTAGE(INT iCH, double *pdDCVolt, FLOAT fIntervalTime, INT iFetchCount)
{
	INT iGPIBRet = GPIB_SUCCESS;
	iGPIBRet = ROUTE_SCAN(iCH);
	if (GPIB_SUCCESS == iGPIBRet)
	{
		iGPIBRet = SET_DC_VOLTAGE(iCH);
		if (GPIB_SUCCESS == iGPIBRet)
		{
			iGPIBRet = READ_VALUE(iCH, pdDCVolt, (float)m_DMMMeasPara.dCHDelay, m_DMMMeasPara.iAvgCount);
		}
	}
	return iGPIBRet;
}

//***************************************************************************
// Function	: READ_AC_VOLTAGE
// Purpose	: Measurement voltage 
// Input	: iStableTime -- wait time for stable, the unit is ms
//			: iFetchTime  -- repeat time for Fetch testing value
//			: iCH -- 34970A's channel number
// Output	: pdDCVolt -- the testing result 
//***************************************************************************
INT CAgilent34970A::READ_AC_VOLTAGE(INT iCH, double *pdDCVolt, FLOAT fIntervalTime, INT iFetchCount)
{
	INT iGPIBRet = GPIB_SUCCESS;

	iGPIBRet = ROUTE_SCAN(iCH);
	if (GPIB_SUCCESS == iGPIBRet)
	{
		iGPIBRet = SET_AC_VOLTAGE(iCH);
		if (GPIB_SUCCESS == iGPIBRet)
		{
			iGPIBRet = READ_VALUE(iCH, pdDCVolt, (float)m_DMMMeasPara.dCHDelay, m_DMMMeasPara.iAvgCount);
		}
	}
	return iGPIBRet;
}

//***************************************************************************
// Function	: READ_FREQUENCY
// Purpose	: Measurement frequency
// Input	: iStableTime -- wait time for stable, the unit is ms
//			: iFetchTime  -- repeat time for Fetch testing value
//			: iCH -- 34970A's channel number
// Output	: pdFreq -- the testing result 
//***************************************************************************
INT CAgilent34970A::READ_FREQUENCY(INT iCH, double *pdFreq, FLOAT fIntervalTime, INT iFetchCount)
{
	INT iGPIBRet = GPIB_SUCCESS;
	iGPIBRet = ROUTE_SCAN(iCH);
	::Sleep(GPIB_CMD_DELAY);
	if (GPIB_SUCCESS == iGPIBRet)
	{
		iGPIBRet = SET_FREQUENCY(iCH);
		::Sleep(GPIB_CMD_DELAY);
		if (GPIB_SUCCESS == iGPIBRet)
		{
			iGPIBRet = READ_VALUE(iCH, pdFreq, fIntervalTime, iFetchCount);
		}
	}
	return iGPIBRet;
}

//***************************************************************************
// Function	: SET_RESISTANCE
// Purpose	: Set to measure resistance 
// Input	: iCH -- 34970A's channel number
//			: iBaseOHM -- 34970A's data mode, default value is DABend
// Output	: VOID
//***************************************************************************
INT CAgilent34970A::SET_RESISTANCE(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	// Set measurement type
	m_iCurrMeasType = DMM_TYPE_OHM;

	// Kiểm tra brand thiết bị để sử dụng command phù hợp
	if (m_iDeviceBrand == 1) // GWinstek GDM9061
	{
		// GDM9061 sử dụng command đơn giản hơn
		sprintf_s(m_szCommand, "CONF:RES;*OPC?");
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		}
	}
	else // Agilent/HP 34970A (mặc định)
	{
		//Set Range & Resolution
		sprintf_s(m_szCommand, "CONF:RES %s,DEF,(@%d);*OPC?", m_DMMMeasPara.szRange, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		}

		//Set Integration Time
		if (GPIB_SUCCESS == iGPIBRet)
		{
			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
			sprintf_s(m_szCommand, "SENS:RES:NPLC %s,(@%d);*OPC?", m_DMMMeasPara.szIntegrationTime, iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			else
			{
				if (1 != atoi(m_szReadBuffer))
					iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			}
		}

		//Set Offset Compensation, Only available at 100/1K/10K
		if (GPIB_SUCCESS == iGPIBRet)
		{
			if (0 == strcmp(m_DMMMeasPara.szRange, "100") || 0 == strcmp(m_DMMMeasPara.szRange, "1K") ||
				0 != strcmp(m_DMMMeasPara.szRange, "10K"))
			{
				memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
				sprintf_s(m_szCommand, "SENS:RES:OCOM %s,(@%d);*OPC?", m_DMMMeasPara.szO_COMP, iCH);
				iGPIBRet = Query(m_szCommand, m_szReadBuffer);
				if (GPIB_SUCCESS != iGPIBRet)
					iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
				else
				{
					if (1 != atoi(m_szReadBuffer))
						iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
				}
			}
		}
	}

	return iGPIBRet;
}

INT CAgilent34970A::SET_RESISTANCE_4W(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	// Set measurement type
	m_iCurrMeasType = DMM_TYPE_OHM_4W;

	// Kiểm tra brand thiết bị để sử dụng command phù hợp
	if (m_iDeviceBrand == 1) // GWinstek GDM9061
	{
		// GDM9061 sử dụng command đơn giản hơn
		sprintf_s(m_szCommand, "CONF:FRES;*OPC?");
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		}
	}
	else // Agilent/HP 34970A (mặc định)
	{
		//Set Range & Resolution
		sprintf_s(m_szCommand, "CONF:FRES %s,DEF,(@%d);*OPC?", m_DMMMeasPara.szRange, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				iGPIBRet = GPIB_34970_SET_MEASURE_RESISTANCE_FAIL;
		}

		//Set Integration Time
		if (GPIB_SUCCESS == iGPIBRet)
		{
			memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
			sprintf_s(m_szCommand, "SENS:FRES:NPLC %s,(@%d);*OPC?", m_DMMMeasPara.szIntegrationTime, iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			else
			{
				if (1 != atoi(m_szReadBuffer))
					iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
			}
		}

		//Set Offset Compensation
		if (GPIB_SUCCESS == iGPIBRet)
		{
			if (0 == strcmp(m_DMMMeasPara.szRange, "100") || 0 == strcmp(m_DMMMeasPara.szRange, "1K") ||
				0 != strcmp(m_DMMMeasPara.szRange, "10K"))
			{
				memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
				sprintf_s(m_szCommand, "SENS:FRES:OCOM %s,(@%d);*OPC?", m_DMMMeasPara.szO_COMP, iCH);
				iGPIBRet = Query(m_szCommand, m_szReadBuffer);
				if (GPIB_SUCCESS != iGPIBRet)
					iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
				else
				{
					if (1 != atoi(m_szReadBuffer))
						iGPIBRet = GPIB_34970_SET_MEASURE_AC_CURRENT_FAIL;
				}
			}
		}
	}

	return iGPIBRet;
}

//***************************************************************************
// Function	: SET_FREQUENCY
// Purpose	: Set to measure resistance 
// Input	: iCH -- 34970A's channel number
// Output	: VOID
//***************************************************************************
INT CAgilent34970A::SET_FREQUENCY(INT iCH)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "CONF:FREQ (@%d)", iCH);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		iGPIBRet = GPIB_34970_SET_MEASURE_FREQUENCY_FAIL;
	}
	return iGPIBRet;
}

//***************************************************************************
// Function	: READ_RESISTANCE
// Purpose	: Measurement resistance 
// Input	: fIntervalTime -- wait time for stable, the unit is ms
//			: iFetchTime  -- repeat time for Fetch testing value
//			: iCH -- 34970A's channel number
// Output	: pdDCVolt -- the testing result 
//***************************************************************************
INT CAgilent34970A::READ_RESISTANCE(INT iCH, double *pdDCVolt, FLOAT fIntervalTime, INT iFetchCount)
{
	INT iGPIBRet = GPIB_SUCCESS;

	iGPIBRet = ROUTE_SCAN(iCH);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		iGPIBRet = SET_RESISTANCE(iCH);
		if (iGPIBRet == GPIB_SUCCESS)
		{
			iGPIBRet = READ_VALUE(iCH, pdDCVolt, (float)m_DMMMeasPara.dCHDelay, m_DMMMeasPara.iAvgCount);
		}
	}
	return iGPIBRet;
}

INT CAgilent34970A::READ_RESISTANCE_4W(INT iCH, double *pdDCVolt, FLOAT fIntervalTime, INT iFetchCount)
{
	INT iGPIBRet = GPIB_SUCCESS;
	iGPIBRet = ROUTE_SCAN(iCH);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		iGPIBRet = SET_RESISTANCE_4W(iCH);
		if (iGPIBRet == GPIB_SUCCESS)
		{
			iGPIBRet = READ_VALUE(iCH, pdDCVolt, (float)m_DMMMeasPara.dCHDelay, m_DMMMeasPara.iAvgCount);
		}
	}
	return iGPIBRet;
}

INT CAgilent34970A::READ_LAST_VALUE(INT iCH, double *pdVale, INT iLastNumCount)
{
	INT		iGPIBRet = GPIB_SUCCESS;
	CHAR	*pReadBuffer = NULL;
	INT		iReadCount = 0;
	double	*pdValue = NULL;

	*pdVale = 0;
	sprintf_s(m_szCommand, "DATA:LAST? %d,(@%d)", iLastNumCount, iCH);
	iGPIBRet = Query(m_szCommand, m_szReadBuffer);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		return GPIB_34970_READ_VALUE_AVER_AVER_FAIL;
	}
	else
	{
		*pdVale = strtod(m_szReadBuffer, NULL);
	}
	return iGPIBRet;
}

INT CAgilent34970A::READ_VALUE(INT iCH, double *pdVale, FLOAT fIntervalTime, INT iFetchCount)
{
	INT		iGPIBRet = GPIB_SUCCESS;
	CHAR	*pReadBuffer = NULL;
	INT		iReadCount = 0;
	double	*pdValue = NULL;

	memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));

	*pdVale = 0;

	// Kiểm tra brand thiết bị để sử dụng command phù hợp
	if (m_iDeviceBrand == 1) // GWinstek GDM9061
	{
		// GDM9061 sử dụng command đơn giản dựa theo loại đo hiện tại
		switch (m_iCurrMeasType)
		{
		case DMM_TYPE_DC_VOLT:
			sprintf_s(m_szCommand, "MEAS:VOLT:DC?");
			break;
		case DMM_TYPE_AC_VOLT:
			sprintf_s(m_szCommand, "MEAS:VOLT:AC?");
			break;
		case DMM_TYPE_DC_CURR:
			sprintf_s(m_szCommand, "MEAS:CURR:DC?");
			break;
		case DMM_TYPE_AC_CURR:
			sprintf_s(m_szCommand, "MEAS:CURR:AC?");
			break;
		case DMM_TYPE_OHM:
			sprintf_s(m_szCommand, "MEAS:RES?");
			break;
		case DMM_TYPE_OHM_4W:
			sprintf_s(m_szCommand, "MEAS:FRES?");
			break;
		default:
			sprintf_s(m_szCommand, "MEAS:VOLT:DC?");
			break;
		}
		
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			return GPIB_34970_READ_VALUE_AVER_AVER_FAIL;
		else
			*pdVale = strtod(m_szReadBuffer, NULL);
	}
	else // Agilent/HP 34970A (mặc định)
	{
		if (fIntervalTime == -999.0)
			sprintf_s(m_szCommand, "ROUTe:CHANnel:DELay:AUTO ON,(@%d);*OPC?", iCH);
		else
			sprintf_s(m_szCommand, "ROUTe:CHANnel:DELay %f,(@%d);*OPC?", fIntervalTime, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			return GPIB_34970_READ_VALUE_CHANNEL_DELAY_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				return GPIB_34970_READ_VALUE_CHANNEL_DELAY_FAIL;
		}

		memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
		sprintf_s(m_szCommand, "TRIG:COUNT %d;*OPC?", iFetchCount);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			return GPIB_34970_READ_VALUE_CHANNEL_DELAY_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				return GPIB_34970_READ_VALUE_CHANNEL_DELAY_FAIL;
		}

		//Set Autozero flag
		memset(m_szReadBuffer, 0x00, sizeof(m_szReadBuffer));
		sprintf_s(m_szCommand, "SENS:ZERO:AUTO %s,(@%d);*OPC?", m_DMMMeasPara.szAutozero, iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
			return GPIB_34970_READ_VALUE_CHANNEL_DELAY_FAIL;
		else
		{
			if (1 != atoi(m_szReadBuffer))
				return GPIB_34970_READ_VALUE_CHANNEL_DELAY_FAIL;
		}

		iGPIBRet = Write("INITiate");
		if (GPIB_SUCCESS != iGPIBRet)
			return GPIB_34970_READ_VALUE_INITIAL_FAIL;

		DWORD dwCurrTime = ::GetTickCount();
		DWORD dwExpectTime = dwCurrTime + 60000;

		do
		{	//while loop for wait the FetchCount
			sprintf_s(m_szCommand, "CALC:AVER:COUNT? (@%d)", iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				return GPIB_34970_READ_VALUE_AVER_COUNT_FAIL;
			else
			{
				iReadCount = (INT)strtod(m_szReadBuffer, NULL);
				::Sleep(GPIB_CMD_DELAY);
			}
			dwCurrTime = ::GetTickCount();
		} while ((iReadCount < iFetchCount) && (dwCurrTime < dwExpectTime));

		if (iReadCount != iFetchCount)
			return GPIB_34970_READ_VALUE_AVER_AVER_FAIL;
		else
		{
			sprintf_s(m_szCommand, "CALC:AVER:AVER? (@%d)", iCH);
			iGPIBRet = Query(m_szCommand, m_szReadBuffer);
			if (GPIB_SUCCESS != iGPIBRet)
				return GPIB_34970_READ_VALUE_AVER_AVER_FAIL;
			else
				*pdVale = strtod(m_szReadBuffer, NULL);
		}
	}

	return iGPIBRet;
}

INT CAgilent34970A::READ_VALUE_MIN(INT iCH, double *pdVale, FLOAT fIntervalTime, INT iFetchCount)
{
	INT		iGPIBRet = GPIB_SUCCESS;
	CHAR	*pReadBuffer = NULL;
	INT		iReadCount = 0;
	double	*pdValue = NULL;

	*pdVale = 0;
	sprintf_s(m_szCommand, "ROUTe:CHANnel:DELay %f,(@%d)", fIntervalTime, iCH);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		return GPIB_34970_READ_VALUE_CHANNEL_DELAY_FAIL;
	}
	::Sleep(GPIB_CMD_DELAY);

	sprintf_s(m_szCommand, "TRIG:COUNT %d", iFetchCount);
	iGPIBRet = Write(m_szCommand);
	if (GPIB_SUCCESS != iGPIBRet)
	{
		return GPIB_34970_READ_VALUE_TRIG_COUNT_FAIL;
	}
	::Sleep(GPIB_CMD_DELAY);

	iGPIBRet = Write("INITiate");
	if (GPIB_SUCCESS != iGPIBRet)
	{
		return GPIB_34970_READ_VALUE_INITIAL_FAIL;
	}
	::Sleep(GPIB_CMD_DELAY * 20);

	DWORD	dwCurrTime = ::GetTickCount();
	DWORD	dwExpectTime = dwCurrTime + 5000;

	do { //while loop for wait the FetchCount
		sprintf_s(m_szCommand, "CALC:AVER:COUNT? (@%d)", iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
		{
			return GPIB_34970_READ_VALUE_AVER_COUNT_FAIL;
		}
		else
		{
			iReadCount = (INT)strtod(m_szReadBuffer, NULL);
			::Sleep(GPIB_CMD_DELAY);
			if (CHARGE_FREQ_PIN == iCH)
			{
				::Sleep(GPIB_CMD_DELAY * 10);
			}
		}
		dwCurrTime = ::GetTickCount();
	} while ((iReadCount<iFetchCount) && (dwCurrTime < dwExpectTime));

	if (iReadCount != iFetchCount)
	{
		return GPIB_34970_READ_VALUE_AVER_AVER_FAIL;
	}
	else
	{
		sprintf_s(m_szCommand, "CALC:AVER:MIN? (@%d)", iCH);
		iGPIBRet = Query(m_szCommand, m_szReadBuffer);
		if (GPIB_SUCCESS != iGPIBRet)
		{
			return GPIB_34970_READ_VALUE_AVER_AVER_FAIL;
		}
		else
		{
			*pdVale = strtod(m_szReadBuffer, NULL);
		}
	}

	return iGPIBRet;
}
//***************************************************************************
// Description	: Preset and Clear 34970
//***************************************************************************
INT CAgilent34970A::PRESET(VOID)
{
	INT iGPIBRet = GPIB_SUCCESS;

	iGPIBRet = Write("*CLS");
	if (GPIB_SUCCESS != iGPIBRet)
	{
		return GPIB_34970_PRERESET_CLEAR_FAIL;
	}
	// Factory Reset
	iGPIBRet = Write("*RST");
	if (GPIB_SUCCESS != iGPIBRet)
	{
		return GPIB_34970_PRERESET_CLEAR_FAIL;
	}
	// Instrument Preset
	iGPIBRet = Write("SYSTem:PRESet");
	if (GPIB_SUCCESS != iGPIBRet)
	{
		return GPIB_34970_PRERESET_CLEAR_FAIL;
	}
	/*
	// Card Reset
	iGPIBRet = Write("SYSTem:CPON");
	if(GPIB_SUCCESS != iGPIBRet)
	{
	return GPIB_34970_PRERESET_CLEAR_FAIL;
	}
	*/
	return iGPIBRet;
}
//***************************************************************************
// Function	: READ_DC_CURRENT
// Purpose	: Measurement currnt 
// Input	: iStableTime -- wait time for stable, the unit is ms
//			: iFetchTime  -- repeat time for Fetch testing value
//			: iCH -- 34970A's channel number
// Output	: pdDCVolt -- the testing result 
//***************************************************************************
INT CAgilent34970A::READ_DC_CURRENT(INT iCH, double *pdDCVolt, FLOAT fIntervalTime, INT iFetchCount)
{
	INT iGPIBRet = GPIB_SUCCESS;
	iGPIBRet = ROUTE_SCAN(iCH);

	if (GPIB_SUCCESS == iGPIBRet)
	{
		iGPIBRet = SET_DC_CURRENT(iCH);
		if (GPIB_SUCCESS == iGPIBRet)
		{
			iGPIBRet = READ_VALUE(iCH, pdDCVolt, (float)m_DMMMeasPara.dCHDelay, m_DMMMeasPara.iAvgCount);
		}
	}
	return iGPIBRet;
}
//***************************************************************************
// Function	: READ_DC_CURRENT
// Purpose	: Measurement currnt 
// Input	: iStableTime -- wait time for stable, the unit is ms
//			: iFetchTime  -- repeat time for Fetch testing value
//			: iCH -- 34970A's channel number
// Output	: pdDCVolt -- the testing result 
//***************************************************************************
INT CAgilent34970A::READ_AC_CURRENT(INT iCH, double *pdDCVolt, FLOAT fIntervalTime, INT iFetchCount)
{
	INT iGPIBRet = GPIB_SUCCESS;
	iGPIBRet = ROUTE_SCAN(iCH);
	if (GPIB_SUCCESS == iGPIBRet)
	{
		iGPIBRet = SET_AC_CURRENT(iCH);
		if (GPIB_SUCCESS == iGPIBRet)
		{
			iGPIBRet = READ_VALUE(iCH, pdDCVolt, (float)m_DMMMeasPara.dCHDelay, m_DMMMeasPara.iAvgCount);
		}
	}
	return iGPIBRet;
}

INT CAgilent34970A::SET_DMM_MEAS_PARA(INT iMeasType, CHAR* cRange, CHAR* cResolution, CHAR* cIntegrationTime, CHAR* cLFF, CHAR* cO_COMP, CHAR* cAutozero, double dCHDelay, INT iAvgCount)
{


	INT iGPIBRet = GPIB_SUCCESS;

	//Channel delay, -999.0 means using AUTO channel delay
	if (dCHDelay == -999.0)
		m_DMMMeasPara.dCHDelay = -999.0;
	else if (dCHDelay < 0)
		m_DMMMeasPara.dCHDelay = 0;
	else if (dCHDelay > 60)
		m_DMMMeasPara.dCHDelay = 60;
	else
		m_DMMMeasPara.dCHDelay = dCHDelay;

	//Avg Count
	if (iAvgCount <= 1)
		m_DMMMeasPara.iAvgCount = 1;
	else
		m_DMMMeasPara.iAvgCount = iAvgCount;

	//Assign measurement type
	m_iCurrMeasType = iMeasType;

	switch (iMeasType)
	{
	case DMM_TYPE_DC_CURR:
	case DMM_TYPE_AC_CURR:
		//Range
		if (0 != strcmp(cRange, "AUTO") && 0 != strcmp(cRange, "1") && 0 != strcmp(cRange, "0.1") &&
			0 != strcmp(cRange, "0.01"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szRange, "%s", cRange);

		//Resolution
		if (0 != strcmp(cResolution, "MAX") && 0 != strcmp(cResolution, "MIN") && 0 != strcmp(cResolution, "4") &&
			0 != strcmp(cResolution, "5") && 0 != strcmp(cResolution, "6"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
		{
			if (0 == strcmp(cResolution, "MAX") || 0 == strcmp(cResolution, "MIN"))
				sprintf_s(m_DMMMeasPara.szResolution, "%s", cResolution);
			else
			{
				if (0 == strcmp(cRange, "AUTO"))
					sprintf_s(m_DMMMeasPara.szResolution, "DEF");
				else if (0 == strcmp(cRange, "1"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-4");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-5");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-6");
				}
				else if (0 == strcmp(cRange, "0.1"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-5");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-6");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-7");
				}
				else if (0 == strcmp(cRange, "0.01"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-6");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-7");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-8");
				}
			}
		}

		//Integration Time
		if (0 != strcmp(cIntegrationTime, "0.02") && 0 != strcmp(cIntegrationTime, "0.2") &&
			0 != strcmp(cIntegrationTime, "1") && 0 != strcmp(cIntegrationTime, "2") &&
			0 != strcmp(cIntegrationTime, "10") && 0 != strcmp(cIntegrationTime, "20") &&
			0 != strcmp(cIntegrationTime, "100") && 0 != strcmp(cIntegrationTime, "200"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szIntegrationTime, "%s", cIntegrationTime);

		//Low Freq Filter --> Only available on AC measurement
		if (iMeasType != DMM_TYPE_AC_CURR)
			sprintf_s(m_DMMMeasPara.szLFF, "NONE");
		else
		{
			if (0 != strcmp(cLFF, "NONE") && 0 != strcmp(cLFF, "3") && 0 != strcmp(cLFF, "20") && 0 != strcmp(cLFF, "200"))
				return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
			else
			{
				if (0 == strcmp(cLFF, "NONE") || 0 == strcmp(cLFF, "20"))
					sprintf_s(m_DMMMeasPara.szLFF, "20");
				else
					sprintf_s(m_DMMMeasPara.szLFF, "%s", cLFF);
			}
		}

		//Autozero
		if (0 != strcmp(cAutozero, "ON") && 0 != strcmp(cAutozero, "OFF") && 0 != strcmp(cAutozero, "ONCE"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szAutozero, "%s", cAutozero);
		break;

	case DMM_TYPE_DC_VOLT:
	case DMM_TYPE_AC_VOLT:
		//Range
		if (0 != strcmp(cRange, "AUTO") && 0 != strcmp(cRange, "0.1") && 0 != strcmp(cRange, "1") &&
			0 != strcmp(cRange, "10") && 0 != strcmp(cRange, "100") && 0 != strcmp(cRange, "300"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szRange, "%s", cRange);

		//Resolution
		if (0 != strcmp(cResolution, "MAX") && 0 != strcmp(cResolution, "MIN") && 0 != strcmp(cResolution, "4") &&
			0 != strcmp(cResolution, "5") && 0 != strcmp(cResolution, "6"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
		{
			if (0 == strcmp(cResolution, "MAX") || 0 == strcmp(cResolution, "MIN"))
				sprintf_s(m_DMMMeasPara.szResolution, "%s", cResolution);
			else
			{
				if (0 == strcmp(cRange, "AUTO"))
					sprintf_s(m_DMMMeasPara.szResolution, "DEF");
				else if (0 == strcmp(cRange, "0.1"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-5");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-6");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-7");
				}
				else if (0 == strcmp(cRange, "1"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-4");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-5");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-6");
				}
				else if (0 == strcmp(cRange, "10"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-3");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-4");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-5");
				}
				else if (0 == strcmp(cRange, "100"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-2");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-3");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-4");
				}
				else if (0 == strcmp(cRange, "300"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "3E-2");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "3E-3");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "3E-4");
				}
			}
		}

		//Integration Time
		if (0 != strcmp(cIntegrationTime, "0.02") && 0 != strcmp(cIntegrationTime, "0.2") &&
			0 != strcmp(cIntegrationTime, "1") && 0 != strcmp(cIntegrationTime, "2") &&
			0 != strcmp(cIntegrationTime, "10") && 0 != strcmp(cIntegrationTime, "20") &&
			0 != strcmp(cIntegrationTime, "100") && 0 != strcmp(cIntegrationTime, "200"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szIntegrationTime, "%s", cIntegrationTime);

		//Low Freq Filter --> Only available on AC measurement
		if (iMeasType != DMM_TYPE_AC_VOLT)
			sprintf_s(m_DMMMeasPara.szLFF, "NONE");
		else
		{
			if (0 != strcmp(cLFF, "NONE") && 0 != strcmp(cLFF, "3") && 0 != strcmp(cLFF, "20") && 0 != strcmp(cLFF, "200"))
				return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
			else
			{
				if (0 == strcmp(cLFF, "NONE") || 0 == strcmp(cLFF, "20"))
					sprintf_s(m_DMMMeasPara.szLFF, "20");
				else
					sprintf_s(m_DMMMeasPara.szLFF, "%s", cLFF);
			}
		}

		//Autozero
		if (0 != strcmp(cAutozero, "ON") && 0 != strcmp(cAutozero, "OFF") && 0 != strcmp(cAutozero, "ONCE"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szAutozero, "%s", cAutozero);
		break;

	case DMM_TYPE_OHM:
	case DMM_TYPE_OHM_4W:
		//Range
		if (0 != strcmp(cRange, "AUTO") && 0 != strcmp(cRange, "100") && 0 != strcmp(cRange, "1K") &&
			0 != strcmp(cRange, "10K") && 0 != strcmp(cRange, "100K") && 0 != strcmp(cRange, "1M") &&
			0 != strcmp(cRange, "10M") && 0 != strcmp(cRange, "100M"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
		{
			if (0 == strcmp(cRange, "AUTO"))
				sprintf_s(m_DMMMeasPara.szRange, "AUTO");
			else if (0 == strcmp(cRange, "100"))
				sprintf_s(m_DMMMeasPara.szRange, "1E2");
			else if (0 == strcmp(cRange, "1K"))
				sprintf_s(m_DMMMeasPara.szRange, "1E3");
			else if (0 == strcmp(cRange, "10K"))
				sprintf_s(m_DMMMeasPara.szRange, "1E4");
			else if (0 == strcmp(cRange, "100K"))
				sprintf_s(m_DMMMeasPara.szRange, "1E5");
			else if (0 == strcmp(cRange, "1M"))
				sprintf_s(m_DMMMeasPara.szRange, "1E6");
			else if (0 == strcmp(cRange, "10M"))
				sprintf_s(m_DMMMeasPara.szRange, "1E7");
			else if (0 == strcmp(cRange, "100M"))
				sprintf_s(m_DMMMeasPara.szRange, "1E8");
		}

		//Resolution
		if (0 != strcmp(cResolution, "MAX") && 0 != strcmp(cResolution, "MIN") && 0 != strcmp(cResolution, "4") &&
			0 != strcmp(cResolution, "5") && 0 != strcmp(cResolution, "6"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
		{
			if (0 == strcmp(cResolution, "MAX") || 0 == strcmp(cResolution, "MIN"))
				sprintf_s(m_DMMMeasPara.szResolution, "%s", cResolution);
			else
			{
				if (0 == strcmp(cRange, "AUTO"))
					sprintf_s(m_DMMMeasPara.szResolution, "DEF");
				else if (0 == strcmp(cRange, "100"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-2");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-3");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-4");
				}
				else if (0 == strcmp(cRange, "1K"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-1");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-2");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-3");
				}
				else if (0 == strcmp(cRange, "10K"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-1");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-2");
				}
				else if (0 == strcmp(cRange, "100K"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "10");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E-1");
				}
				else if (0 == strcmp(cRange, "1M"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E2");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "10");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1");
				}
				else if (0 == strcmp(cRange, "10M"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E3");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E2");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "10");
				}
				else if (0 == strcmp(cRange, "100M"))
				{
					if (0 == strcmp(cResolution, "4"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E4");
					else if (0 == strcmp(cResolution, "5"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E3");
					else if (0 == strcmp(cResolution, "6"))
						sprintf_s(m_DMMMeasPara.szResolution, "1E2");
				}
			}
		}

		//Integration Time
		if (0 != strcmp(cIntegrationTime, "0.02") && 0 != strcmp(cIntegrationTime, "0.2") &&
			0 != strcmp(cIntegrationTime, "1") && 0 != strcmp(cIntegrationTime, "2") &&
			0 != strcmp(cIntegrationTime, "10") && 0 != strcmp(cIntegrationTime, "20") &&
			0 != strcmp(cIntegrationTime, "100") && 0 != strcmp(cIntegrationTime, "200"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szIntegrationTime, "%s", cIntegrationTime);

		//Autozero
		if (0 != strcmp(cAutozero, "ON") && 0 != strcmp(cAutozero, "OFF") && 0 != strcmp(cAutozero, "ONCE"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
			sprintf_s(m_DMMMeasPara.szAutozero, "%s", cAutozero);

		//Offset compensation
		if (0 != strcmp(cO_COMP, "ON") && 0 != strcmp(cO_COMP, "OFF") && 0 != strcmp(cO_COMP, "NONE"))
			return GPIB_34970_SET_MEASURE_DC_CURRENT_FAIL;
		else
		{
			if (0 == strcmp(cO_COMP, "OFF") || 0 == strcmp(cO_COMP, "NONE"))
				sprintf_s(m_DMMMeasPara.szO_COMP, "OFF");
			else
				sprintf_s(m_DMMMeasPara.szO_COMP, "ON");
		}
		break;

	default:
		iGPIBRet = GPIB_34970_ROUT_SCAN_FAIL;
		break;
	}

	return iGPIBRet;
}
//***************************************************************************
// Description: End
//***************************************************************************