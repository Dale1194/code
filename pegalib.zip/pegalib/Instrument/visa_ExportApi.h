/*******************************************************************************
 *  Copyright Statement:
 *  --------------------
 *  BU3 ATS Team Engineer
 *  BU3-SW Div.-ATS
 *  PEGATRON Corporation (C) 2008-2010
 ******************************************************************************/

/*******************************************************************************
 *==============================================================================
 * Filename:
 * ---------
 *  visa_ExportApi.h
 *
 * Description:
 * ------------
 *  NI visa32 Program Access Interface.
 *
 * Author:
 * -------
 *	Tomy Chen (PEGATRON#LA0801572)
 *
 *	Rev 1.0.0	Dec 24 2009		Version base on NI-488.2 V2.5, Visa32.dll V4.1.0.49152
 *==============================================================================
 *******************************************************************************/
#ifndef _VISA_EXPORTAPI_H
#define _VISA_EXPORTAPI_H
#include "visa.h"

#ifdef          __cplusplus
extern "C" {
#endif

#define         _VISA_EXPORT_DLL
#ifdef          _VISA_EXPORT_DLL
#define         VISA_EXPORT          __declspec(dllexport)
#else
#define         VISA_EXPORT          __declspec(dllimport)
#endif

typedef  ViStatus (_VI_FUNC *pf_viOpenDefaultRM_t)(ViPSession vi);
typedef	 ViStatus (_VI_FUNC *pf_viOpen_t)(ViSession sesn, ViRsrc name, ViAccessMode mode, ViUInt32 timeout, ViPSession vi);
typedef	 ViStatus (_VI_FUNCC *pf_viPrintf_t)(ViSession vi, ViString writeFmt, ...);
typedef	 ViStatus (_VI_FUNCC *pf_viScanf_t)(ViSession vi, ViString readFmt, ...);
typedef	 ViStatus (_VI_FUNC *pf_viClose_t)(ViObject vi);
typedef	 ViStatus (_VI_FUNCC *pf_viQueryf_t)(ViSession vi, ViString writeFmt, ViString readFmt, ...);
typedef	 ViStatus (_VI_FUNC  *pf_viClear_t)(ViSession vi);
typedef	 ViStatus (_VI_FUNC  *pf_viSetAttribute_t)(ViObject vi, ViAttr attrName, ViAttrState attrValue);
typedef	 ViStatus (_VI_FUNC  *pf_viWrite_t)(ViSession vi, ViBuf  buf, ViUInt32 cnt, ViPUInt32 retCnt);
typedef  ViStatus (_VI_FUNC  *pf_viGpibControlREN_t)(ViSession vi, ViUInt16 mode);

#ifdef          __cplusplus
}
#endif

#endif // End of _VISA_EXPORTAPI_H_