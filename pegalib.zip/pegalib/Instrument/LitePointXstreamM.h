#ifndef _LITEPOINTIQXSTREAMM_H
#define _LITEPOINTIQXSTREAMM_H

#include "visa_ExportApi.h"
#include "ReturnType.h"
#include "GlobalVar.h"
#include "VirtualFunction.h"
#include "CommonAPI.h"


class CLitePointIQxtreamM : public CVirtualInstrument
{
public:
	CLitePointIQxtreamM();
	virtual ~CLitePointIQxtreamM();
	
public:
	HINSTANCE				m_hDLL;
	CHAR					m_szDLLFile[MAX_PATH];
	CHAR					m_szCommand[256];
	CHAR					m_szReadBuffer[1024];

	ViSession				m_viSession;

	pf_viOpen_t				viOpen;
	pf_viScanf_t			viScanf;
	pf_viClose_t			viClose;
	pf_viPrintf_t			viPrintf;
	pf_viOpenDefaultRM_t	viOpenDefaultRM;
	pf_viQueryf_t			viQueryf;
	pf_viClear_t			viClear;
	pf_viSetAttribute_t		viSetAttribute;

	BOOL					m_bGPIB_Log_Enable;

	INT	Write(CONST CHAR *pcCommand);
	INT	Query(CONST CHAR *pcCommand, CHAR *pcReturnValue);

	INT VISA32_SET_VI_SESSION(DWORD vi);
	INT	VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable);
	INT GPIB_WRITE(const char* command);
	INT GPIB_QUERY(const char* command, char* returnVal);

};


#endif /* #pragma once */