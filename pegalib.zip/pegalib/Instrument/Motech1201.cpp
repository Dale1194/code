// Motech1201.cpp: implementation of the CMotech1201 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Motech1201.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMotech1201::CMotech1201()
{
	m_hDLL	= NULL;

	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	//m_hDLL = ::LoadLibraryEx(m_szDLLFile, NULL, DONT_RESOLVE_DLL_REFERENCES);
	if(NULL == m_hDLL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
	}
	else
	{
		viOpenDefaultRM	= (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL,"viOpenDefaultRM");
		viOpen			= (pf_viOpen_t)::GetProcAddress(m_hDLL,"viOpen");
		viPrintf		= (pf_viPrintf_t)::GetProcAddress(m_hDLL,"viPrintf");
		viScanf			= (pf_viScanf_t)::GetProcAddress(m_hDLL,"viScanf");
		viClose			= (pf_viClose_t)::GetProcAddress(m_hDLL,"viClose");
		viQueryf		= (pf_viQueryf_t)::GetProcAddress(m_hDLL,"viQueryf");
		viClear			= (pf_viClear_t)::GetProcAddress(m_hDLL,"viClear");
		viSetAttribute	= (pf_viSetAttribute_t)::GetProcAddress(m_hDLL,"viSetAttribute");
	}
}
CMotech1201::~CMotech1201()
{
	if(m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
}

//***************************************************************************
// Description: Send GPIB command to Device via Visa
//***************************************************************************
INT CMotech1201::Write(CONST CHAR *pcCommand)
{
	ViStatus status;

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	GPIBTrace(m_szCommand);

	status = viPrintf(m_viSession, m_szCommand);
	if (status != VI_SUCCESS)
	{
		return GPIB_WRITE_FAIL;
	}
	return GPIB_SUCCESS;
}

//***************************************************************************
// Description: Execute Query command & get value from Device via Visa
//***************************************************************************
INT CMotech1201::Query(CONST CHAR *pcCommand, CHAR *pcReturnValue)
{
	ViStatus status;

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	GPIBTrace(m_szCommand);

	status = viQueryf(m_viSession, m_szCommand, "%t", pcReturnValue);
	if (status != VI_SUCCESS)
	{
		return GPIB_QUERY_FAIL;
	}
	return GPIB_SUCCESS;
}
//***************************************************************************
// Description: Virtual Function
//***************************************************************************
INT	CMotech1201::VISA32_SET_VI_SESSION(DWORD vi)
{
	m_viSession = (ViSession)vi;
	return GPIB_SUCCESS;
}

INT	CMotech1201::PPS_SET_VOLTAGE(double dVoltage)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "VSET1 %2.2f",dVoltage);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CMotech1201::PPS_SET_VOLTAGE_CH2(double dVoltage)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "VSET2 %2.2f",dVoltage);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CMotech1201::PPS_SET_CURRENT(double dCurrLimit)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "ISET1 %2.1f",dCurrLimit);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CMotech1201::PPS_SET_CURRENT_CH2(double dCurrLimit)
{
	INT iGPIBRet = GPIB_SUCCESS;
	sprintf_s(m_szCommand, "ISET2 %2.1f",dCurrLimit);
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CMotech1201::PPS_SET_POWER_ON(VOID)
{
    sprintf_s(m_szCommand, "BEEP 3");
	INT iGPIBRet = Write(m_szCommand);
	memset(m_szCommand,0x00,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "OUT1 1");
    iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CMotech1201::PPS_SET_POWER_ON_CH2(VOID)
{
	sprintf_s(m_szCommand, "BEEP 3");
	INT iGPIBRet = Write(m_szCommand);
	memset(m_szCommand,0x00,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "OUT2 1");
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CMotech1201::PPS_SET_POWER_OFF(VOID)
{
	sprintf_s(m_szCommand, "BEEP 3");
	INT iGPIBRet = Write(m_szCommand);
	memset(m_szCommand,0x00,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "OUT1 0");
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CMotech1201::PPS_SET_POWER_OFF_CH2(VOID)
{
	sprintf_s(m_szCommand, "BEEP 3");
	INT iGPIBRet = Write(m_szCommand);
	memset(m_szCommand,0x00,sizeof(m_szCommand));
	sprintf_s(m_szCommand, "OUT2 0");
	iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}
INT	CMotech1201::PPS_GET_CURRENT(double *pdCurrent)
{
	*pdCurrent = 0;
	INT iGPIBRet = Query("IOUT1?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdCurrent = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}
INT	CMotech1201::PPS_GET_CURRENT_CH2(double *pdCurrent)
{
	*pdCurrent = 0;
	INT iGPIBRet = Query("IOUT2?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdCurrent = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}
INT	CMotech1201::PPS_GET_VOLTAGE(double *pdVoltage)
{
	*pdVoltage = 0;
	INT iGPIBRet = Query("VOUT1?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdVoltage = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}
INT	CMotech1201::PPS_GET_VOLTAGE_CH2(double *pdVoltage)
{
	*pdVoltage = 0;
	INT iGPIBRet = Query("VOUT2?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdVoltage = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}
//***************************************************************************
// Description: End
//***************************************************************************