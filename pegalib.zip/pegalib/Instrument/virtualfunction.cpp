#include "stdafx.h"
#include <algorithm>
#include "virtualfunction.h"



using namespace std;


void CVirtualInstrument::AddOutput(COutputDebug* output)
{
	this->m_dbgmsg.AddOutput(output);
}

void CVirtualInstrument::RemoveOutput(COutputDebug* output)
{
	this->m_dbgmsg.RemoveOutput(output);
}

void CVirtualInstrument::OutputLog(const char* str)
{
	this->m_dbgmsg.Output(str);
}

void CVirtualInstrument::OutputfLog(const char* fmt, ...)
{
	int buf_cnt = 512;
	char* buffer = NULL;
	va_list	list;
	int vsn = -1;

	va_start(list, fmt);

	do{
		delete[] buffer;
		buf_cnt *= 2;
		buffer = new char[buf_cnt];
		vsn = vsnprintf_s(buffer, buf_cnt, _TRUNCATE, fmt, list);
	} while (vsn == -1);

	va_end(list);

	OutputLog(buffer);
	delete[] buffer;
}

void CVirtualInstrument::OutputLog(const string& str)
{
	this->m_dbgmsg.Output(str);
}


