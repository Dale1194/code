// GPIBDevice.cpp: implementation of the CGPIBDevice class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GPIBDevice.h"
#include <stdio.h>
#include "CommonApi.h"
#include "Config.h"


//#ifdef _DEBUG
//#undef THIS_FILE
//static char THIS_FILE[]=__FILE__;
//#define new DEBUG_NEW
//#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGPIBDevice::CGPIBDevice()
{
	m_PPSObj = NULL;
	m_PPS2Obj = NULL;
	m_RRTObj = NULL;
	m_DMMObj = NULL;
	m_DMM2Obj = NULL;
	m_DMM3Obj = NULL;
	m_FREObj = NULL;                 //53131
	m_FRE2Obj = NULL;
	m_FRE3Obj = NULL;
	m_FRE4Obj = NULL;
	m_hDLL = NULL;
	m_viSession_PPS = 0;
	m_viOpenDefaultRM_PPS = 0;
	m_viSession_PPS2 = 0;
	m_viOpenDefaultRM_PPS2 = 0;
	m_viSession_RRT = 0;
	m_viOpenDefaultRM_RRT = 0;
	m_viSession_DMM = 0;
	m_viOpenDefaultRM_DMM2 = 0;
	m_viSession_DMM2 = 0;
	m_viOpenDefaultRM_DMM2 = 0;
	m_viSession_DMM3 = 0;
	m_viOpenDefaultRM_DMM3 = 0;
	m_viSession_FRE = 0;
	m_viOpenDefaultRM_FRE = 0;
	m_viSession_FRE2 = 0;
	m_viOpenDefaultRM_FRE2 = 0;
	m_viSession_FRE3 = 0;
	m_viOpenDefaultRM_FRE3 = 0;
	m_viSession_FRE4 = 0;
	m_viOpenDefaultRM_FRE4 = 0;
	m_iRRTBrandType = -1;
	m_i8820Type = -1;

	m_isPPS1_DualCH = TRUE;
	m_isPPS2_DualCH = TRUE;
}

CGPIBDevice::~CGPIBDevice()
{
	CLOSE_ALL_SESSION();

	if(m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
}
INT CGPIBDevice::DETECT_DEVICE(DEVICE_CONTROL stDevice)
{
	INT iStatus = GPIB_SUCCESS;

	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	if(INVALID_FILE_ATTRIBUTES == ::GetFileAttributesA(m_szDLLFile)) return LOAD_DLL_FAIL;

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	//m_hDLL = ::LoadLibraryEx(m_szDLLFile, NULL, DONT_RESOLVE_DLL_REFERENCES);
	if(m_hDLL == NULL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
		return GPIB_INIT_FAIL;
	}
	else
	{		
		viOpenDefaultRM		= (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL,"viOpenDefaultRM");
		viOpen				= (pf_viOpen_t)::GetProcAddress(m_hDLL,"viOpen");
		viPrintf			= (pf_viPrintf_t)::GetProcAddress(m_hDLL,"viPrintf");
		viScanf				= (pf_viScanf_t)::GetProcAddress(m_hDLL,"viScanf");
		viClose				= (pf_viClose_t)::GetProcAddress(m_hDLL,"viClose");
		viQueryf			= (pf_viQueryf_t)::GetProcAddress(m_hDLL,"viQueryf");
		viClear				= (pf_viClear_t)::GetProcAddress(m_hDLL,"viClear");
		viSetAttribute		= (pf_viSetAttribute_t)::GetProcAddress(m_hDLL,"viSetAttribute");
		viWrite				= (pf_viWrite_t)::GetProcAddress(m_hDLL, "viWrite");
		viGpibControlREN	= (pf_viGpibControlREN_t)::GetProcAddress(m_hDLL, "viGpibControlREN");

	}

	if( !viOpenDefaultRM || !viOpen || !viPrintf || !viScanf || !viClose || 
		!viQueryf || !viClear || !viSetAttribute || !viWrite || !viGpibControlREN)
	{
		::FreeLibrary(m_hDLL);
		::MessageBoxA(NULL, "Load visa32.dll Function Point Fail.", NULL, NULL);
		return LOAD_DLL_FAIL; 
	}

	/************************************************************************/
	/* Find Power Supply Device                                             */
	/************************************************************************/
	if(TRUE == stDevice.bPPSEnable && 0 == m_viSession_PPS)
	{
		m_bPPSExist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_PPS);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iPPSAddress);

		iStatus = SELECT_PPS(m_viOpenDefaultRM_PPS, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bPPSExist)
		{
			viClose(m_viOpenDefaultRM_PPS);
			return GPIB_PPS_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_PPS, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_PPS_DETECT_FAIL;
		}
		m_PPSObj->VISA32_SET_VI_SESSION(m_viSession_PPS);
		m_PPSObj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}

	/************************************************************************/
	/* Find Power Supply Device2                                            */
	/************************************************************************/
	if(TRUE == stDevice.bPPS2Enable && 0 == m_viSession_PPS2)
	{
		m_bPPS2Exist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_PPS2);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iPPS2Address);

		iStatus = SELECT_PPS2(m_viOpenDefaultRM_PPS2, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bPPS2Exist)
		{
			viClose(m_viOpenDefaultRM_PPS2);
			return GPIB_PPS_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_PPS2, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_PPS_DETECT_FAIL;
		}
		m_PPS2Obj->VISA32_SET_VI_SESSION(m_viSession_PPS2);
		m_PPS2Obj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}

	/************************************************************************/
	/* Find Measurement Instrument Device                                   */
	/************************************************************************/
	if(TRUE == stDevice.bRRTEnable && 0 == m_viSession_RRT)
	{
		m_bRRTExist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_RRT);

		//sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iRRTAddress);
		//sprintf_s(m_szCommand, "TCPIP0::172.17.75.1::inst0::INSTR", stDevice.iGPIBBoard, stDevice.iRRTAddress);

		if(strstr(stDevice.szTCPIPRRTAddress,"172.17"))
		{
			sprintf_s(m_szCommand, "TCPIP0::%s::inst0::INSTR", stDevice.szTCPIPRRTAddress);

		}
		else
		{
			sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iRRTAddress);

		}

		iStatus = SELECT_RRT(m_viOpenDefaultRM_RRT, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bRRTExist)
		{
			viClose(m_viOpenDefaultRM_RRT);
			return GPIB_RRT_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_RRT, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_RRT_DETECT_FAIL;
		}
		m_RRTObj->VISA32_SET_VI_SESSION(m_viSession_RRT);
		m_RRTObj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}
	/************************************************************************/
	/* Find 34970 Instrument Device											*/
	/************************************************************************/
	if(TRUE == stDevice.bDMMEnable && 0 == m_viSession_DMM)
	{
		GPIBTrace("##########		Find 34970 Instrument Device		##########");
		m_bRRTExist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_DMM);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iDMMAddress);

		iStatus = SELECT_DMM(m_viOpenDefaultRM_DMM, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bDMMExist)
		{
			viClose(m_viOpenDefaultRM_DMM);
			return GPIB_DMM_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_DMM, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
		m_DMMObj->VISA32_SET_VI_SESSION(m_viSession_DMM);
		m_DMMObj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}

	/************************************************************************/
	/* Find 34970 Instrument Device	2										*/
	/************************************************************************/
	if(TRUE == stDevice.bDMM2Enable && 0 == m_viSession_DMM2)
	{
		m_bRRTExist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_DMM2);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iDMM2Address);

		iStatus = SELECT_DMM2(m_viOpenDefaultRM_DMM2, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bDMM2Exist)
		{
			viClose(m_viOpenDefaultRM_DMM2);
			return GPIB_DMM_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_DMM2, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
		m_DMM2Obj->VISA32_SET_VI_SESSION(m_viSession_DMM2);
		m_DMM2Obj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}

	/************************************************************************/
	/* Find 3458A Instrument Device											*/
	/************************************************************************/
	if(TRUE == stDevice.bDMM3Enable && 0 == m_viSession_DMM3)
	{
		GPIBTrace("##########		Find 3458A Instrument Device		##########");
		m_bRRTExist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_DMM3);
		// GPIBx::y::INSTR, where x is the board index number (usually 0) and y is the primary address of the instrument.
		sprintf_s(m_szCommand, "GPIB%d::%d::INSTR", stDevice.iGPIBBoard, stDevice.iDMM3Address);	// Get Device name		

		iStatus = SELECT_DMM3(m_viOpenDefaultRM_DMM3, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bDMM3Exist)
		{
			viClose(m_viOpenDefaultRM_DMM3);
			return GPIB_DMM_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_DMM3, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
		m_DMM3Obj->VISA32_SET_VI_SESSION(m_viSession_DMM3);
		m_DMM3Obj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}

	/************************************************************************/
	/* Find 53131 Instrument Device											*/
	/************************************************************************/
	if(TRUE == stDevice.bFREEnable && 0 == m_viSession_FRE)
	{
		m_bFREExist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_FRE);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iFREAddress);

		iStatus = SELECT_FRE(m_viOpenDefaultRM_FRE, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bFREExist)
		{
			viClose(m_viOpenDefaultRM_FRE);
			return GPIB_DMM_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_FRE, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
		m_FREObj->VISA32_SET_VI_SESSION(m_viSession_FRE);
		m_FREObj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}


	/************************************************************************/
	/* Find 53131-2 Instrument Device											*/
	/************************************************************************/
	if(TRUE == stDevice.bFRE2Enable && 0 == m_viSession_FRE2)
	{
		m_bFRE2Exist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_FRE2);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iFRE2Address);

		iStatus = SELECT_FRE2(m_viOpenDefaultRM_FRE2, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bFRE2Exist)
		{
			viClose(m_viOpenDefaultRM_FRE2);
			return GPIB_DMM_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_FRE2, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
		m_FRE2Obj->VISA32_SET_VI_SESSION(m_viSession_FRE2);
		m_FRE2Obj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}

	/************************************************************************/
	/* Find 53131-3 Instrument Device											*/
	/************************************************************************/
	if(TRUE == stDevice.bFRE3Enable && 0 == m_viSession_FRE3)
	{
		m_bFRE2Exist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_FRE3);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iFRE3Address);

		iStatus = SELECT_FRE3(m_viOpenDefaultRM_FRE3, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bFRE3Exist)
		{
			viClose(m_viOpenDefaultRM_FRE3);
			return GPIB_DMM_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_FRE3, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
		m_FRE3Obj->VISA32_SET_VI_SESSION(m_viSession_FRE3);
		m_FRE3Obj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}

	/************************************************************************/
	/* Find 53131-3 Instrument Device											*/
	/************************************************************************/
	if(TRUE == stDevice.bFRE4Enable && 0 == m_viSession_FRE4)
	{
		m_bFRE2Exist = FALSE;
		viOpenDefaultRM(&m_viOpenDefaultRM_FRE4);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", stDevice.iGPIBBoard, stDevice.iFRE4Address);

		iStatus = SELECT_FRE4(m_viOpenDefaultRM_FRE4, m_szCommand);
		if(ERROR_SUCCESS != iStatus || TRUE != m_bFRE4Exist)
		{
			viClose(m_viOpenDefaultRM_FRE4);
			return GPIB_DMM_DETECT_FAIL;
		}
		if(VI_SUCCESS != viSetAttribute(m_viSession_FRE4, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
		m_FRE4Obj->VISA32_SET_VI_SESSION(m_viSession_FRE4);
		m_FRE4Obj->VISA32_SET_GPIBLOG_ENABLE(stDevice.bGPIBLogEnable);
	}
	return iStatus;
}

//***************************************************************************
// Description: RRT => Programmable Power Supply
//***************************************************************************
INT CGPIBDevice::SELECT_PPS(ViSession defaultRM, CHAR *pcCommand)
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]			= {	"HEWLETT-PACKARD", "PRESERVE","E3631","NULL"};
	CONST CHAR	*szAnritsu[]	= {	"ANRITSU", "PRESERVE", "NONE", "NULL"};
	CONST CHAR	*szRS[]			= {	"Rohde&Schwarz", "PRESERVE", "NONE", "NULL"};
	CONST CHAR	*szKeithley[]	= {	"KEITHLEY INSTRUMENTS INC.", "KI", "MODEL 230", "NULL"};
	CONST CHAR	*szAgilent[]	= {	"Agilent Technologies", "PRESERVE", "663","E3646A", "E3631", "NULL"};
	CONST CHAR	*szMotech[]	    = {	"PPS-1201GSM"};
	
	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;

	// viOpen Session
	iStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != iStatus) 
	{
		return iStatus;
	}
	iStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	iStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	iStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != iStatus) 
	{
        iStatus = viQueryf(viSession, "MODEL?\n", "%t", &m_szGetDeviceName);
		if(VI_SUCCESS != iStatus) 
		{
			viClose(viSession);
			return iStatus;
		}
	}
	m_viSession_PPS = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szAgilent[0], strlen(szAgilent[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szAgilent[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szAgilent[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szAgilent[i], strlen(szAgilent[i])))
			{
				if(0 == _stricmp(szAgilent[i], "E3646A")) /* Special PPS */
				{
					m_bPPSExist = TRUE;
					m_PPSObj = new CAgilentE3646A;
				}
				else
				{
					m_bPPSExist = TRUE;
					m_PPSObj = new CAgilent663x;
				}
				break;
			}
		}
	}
	else if(0 == _strnicmp(m_szGetDeviceName, szKeithley[0], strlen(szKeithley[0])) ||
			0 == _strnicmp(m_szGetDeviceName, szKeithley[1], strlen(szKeithley[1])))
	{
		pcBrand = m_szGetDeviceName + strlen(szKeithley[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szKeithley[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szKeithley[i], strlen(szKeithley[i])))
			{
				m_bPPSExist = TRUE;
				m_PPSObj = new CKeithley230x;

				if (NULL != strstr(m_szGetDeviceName, "2303"))
					m_isPPS1_DualCH = FALSE;
				break;
			}
		}
	}
	else if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bPPSExist = TRUE;
				m_PPSObj = new CAgilent663x;
				break;
			}
		}
	}
	else if(0 == _strnicmp(m_szGetDeviceName, szMotech[0], strlen(szMotech[0])))/* Motech */
	{
		m_bPPSExist = TRUE;
		m_PPSObj = new CMotech1201;
	}
	else
	{
		//...
	}

	return iStatus;
}
//***************************************************************************
// Description: RRT => Programmable Power Supply
//***************************************************************************
INT CGPIBDevice::SELECT_PPS2(ViSession defaultRM, CHAR *pcCommand)
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]			= {	"HEWLETT-PACKARD", "PRESERVE","E3631","NULL"};
	CONST CHAR	*szAnritsu[]	= {	"ANRITSU", "PRESERVE", "NONE", "NULL"};
	CONST CHAR	*szRS[]			= {	"Rohde&Schwarz", "PRESERVE", "NONE", "NULL"};
	CONST CHAR	*szKeithley[]	= {	"KEITHLEY INSTRUMENTS INC.", "KI", "MODEL 230", "NULL"};
	CONST CHAR	*szAgilent[]	= {	"Agilent Technologies", "PRESERVE", "663","E3646A", "E3631", "NULL"};
	CONST CHAR	*szMotech[]	    = {	"PPS"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;

	// viOpen Session
	iStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != iStatus) 
	{
		return iStatus;
	}
	iStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	iStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	iStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != iStatus) 
	{
		iStatus = viQueryf(viSession, "MODEL?\n", "%t", &m_szGetDeviceName);
		if(VI_SUCCESS != iStatus) 
		{
			viClose(viSession);
			return iStatus;
		}
	}
	m_viSession_PPS2 = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szAgilent[0], strlen(szAgilent[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szAgilent[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szAgilent[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szAgilent[i], strlen(szAgilent[i])))
			{
				if(0 == _stricmp(szAgilent[i], "E3646A")) /* Special PPS */
				{
					m_bPPS2Exist = TRUE;
					m_PPS2Obj = new CAgilentE3646A;
				}
				else
				{
					m_bPPS2Exist = TRUE;
					m_PPS2Obj = new CAgilent663x;
				}
				break;
			}
		}
	}
	else if(0 == _strnicmp(m_szGetDeviceName, szKeithley[0], strlen(szKeithley[0])) ||
		0 == _strnicmp(m_szGetDeviceName, szKeithley[1], strlen(szKeithley[1])))
	{
		pcBrand = m_szGetDeviceName + strlen(szKeithley[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szKeithley[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szKeithley[i], strlen(szKeithley[i])))
			{
				m_bPPS2Exist = TRUE;
				m_PPS2Obj = new CKeithley230x;

				if (NULL != strstr(m_szGetDeviceName, "2303"))
					m_isPPS2_DualCH = FALSE;
				break;
			}
		}
	}
	else if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bPPS2Exist = TRUE;
				m_PPS2Obj = new CAgilent663x;
				break;
			}
		}
	}
	else if(0 == _strnicmp(m_szGetDeviceName, szMotech[0], strlen(szMotech[0])))/* Motech */
	{
		m_bPPS2Exist = TRUE;
		m_PPS2Obj = new CMotech1201;
	}
	else
	{
		//...
	}

	return iStatus;
}
//***************************************************************************
// Description: RRT => Remote RF Test
//***************************************************************************
INT CGPIBDevice::SELECT_RRT(ViSession defaultRM, CHAR *pcCommand) 
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szAnritsu[]	= {	"ANRITSU", "PRESERVE", "MT8820A", "MT8815A", "MT8820B", "MT8815B", "NULL"};
	CONST CHAR	*szRS[]			= {	"Rohde&Schwarz", "PRESERVE", "CMU 200", "FSP", "NULL"};	//	Rohde&Schwarz,FSP-7,100196/007,3.40
	CONST CHAR	*szAgilent[]	= {	"Agilent Technologies", "PRESERVE", "8960", "E6601", "NULL"};
	CONST CHAR	*szAdvanTest[]	= {	"Advantest", "PRESERVE", "R3131A","U3751","NULL"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;
	
	//-----------------------------------------------//
	// viOpen Session
	iStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != iStatus)
	{
		return iStatus;
	}
	iStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	iStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	iStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != iStatus) 
	{
		viClose(viSession);
		return iStatus;
	}
	m_viSession_RRT = viSession;

	// sprintf_s(m_szGetDeviceName,"FSP-3");	// for test Brighd

	// Agilent device ?
	if(0 == _strnicmp(m_szGetDeviceName, szAgilent[0], strlen(szAgilent[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szAgilent[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szAgilent[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if((0 == _strnicmp(pcBrand, szAgilent[i], strlen(szAgilent[i]))) && (i == 2))
			{
				m_bRRTExist = TRUE;
//fox				m_RRTObj = new C8960;
				m_iRRTBrandType = RRT_AG8960;
				break;
			}
			else if((0 == _strnicmp(pcBrand, szAgilent[i], strlen(szAgilent[i]))) && (i == 3))
			{
				m_bRRTExist = TRUE;
//fox				m_RRTObj = new E6601A;
				m_iRRTBrandType = RRT_AG6601;
				break;
			}
		}
	}
	//	for Anritsu device
	else if(0 == _strnicmp(m_szGetDeviceName, szAnritsu[0], strlen(szAnritsu[0])))
	{
		/*pcBrand = m_szGetDeviceName + strlen(szAnritsu[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szAnritsu[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szAnritsu[i], strlen(szAnritsu[i])))
			{
				m_bRRTExist = TRUE;
				m_RRTObj = new C8820;
				m_iRRTBrandType = RRT_AN8820;
				if ((i == 2) || (i == 3))
					m_i8820Type = RRT_AN8820A;
				else if ((i == 4) || (i == 5))
					m_i8820Type = RRT_AN8820B;
				else		//Default as 8820B
					m_i8820Type = RRT_AN8820B;
				break;
			}
		}*/

		m_bRRTExist = TRUE;
//fox		m_RRTObj = new Anritsu;

	}
	//	for RS device
	// else if(0 == _strnicmp(m_szGetDeviceName, szRS[0], strlen(szRS[0])))
	else if(NULL != strstr(m_szGetDeviceName, szRS[3]) || strstr(m_szGetDeviceName, "Rohde&Schwarz"))
	{
		/*pcBrand = m_szGetDeviceName + strlen(szRS[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szRS[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if((0 == _strnicmp(pcBrand, szRS[i], strlen(szRS[i]))) && (i == 2))
			{
				m_bRRTExist = TRUE;
				m_RRTObj = new CCMU200;
				m_iRRTBrandType = RRT_RSCMU;
				break;
			}
			// else if((0 == _strnicmp(pcBrand, szRS[i], strlen(szRS[i]))) && (i == 3))
			else if(NULL != strstr(m_szGetDeviceName, szRS[3]) || strstr(m_szGetDeviceName, "Rohde&Schwarz"))
			{
				m_bRRTExist = TRUE;
				m_RRTObj = new CROHDE_FSP;
				m_iRRTBrandType = RRT_RSFSP;
				break;
			}
		}*/

		m_bRRTExist = TRUE;
//fox		m_RRTObj = new CROHDE_FSP;
		m_iRRTBrandType = RRT_RSFSP;

		memset(m_RRTObj->m_szInstrumentName,0,sizeof(m_RRTObj->m_szInstrumentName));
		sprintf_s(m_RRTObj->m_szInstrumentName,"%s",m_szGetDeviceName);

	}
	//	for Advantest R3131A		spectrum	//
	else if(0 == _strnicmp(m_szGetDeviceName, szAdvanTest[0], strlen(szAdvanTest[0])))
	{
		//pcBrand = m_szGetDeviceName + strlen(szAdvanTest[0]) + 1; // (+1) => Token ","
		//for(int i=2; (0 != _stricmp(szAdvanTest[i], "NULL")); i++) // Set i=2 to Find Model
		//{
			//if(0 == _strnicmp(pcBrand, szAdvanTest[i], strlen(szAdvanTest[i])))
			//{
				m_bRRTExist = TRUE;
//fox				m_RRTObj = new CATR3131A;
				m_iRRTBrandType = RRT_ATR3131A;
				//break;
			//}
		//}
	}
	else
	{
		//...
	}
	return iStatus;
}
//***************************************************************************
// Description: DMM => Digital Multimeter
//***************************************************************************
INT CGPIBDevice::SELECT_DMM(ViSession defaultRM, CHAR *pcCommand) 
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]	= {	"HEWLETT-PACKARD", "PRESERVE", "34970A", "NULL"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != viStatus) 
	{
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	// viStatus = viQueryf(viSession, "ID?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != viStatus) 
	{
		viClose(viSession);
		return viStatus;
	}

	m_viSession_DMM = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bDMMExist = TRUE;
				m_DMMObj = new CAgilent34970A();
				break;
			}
		}
	}
	return iStatus;
}
//***************************************************************************
// Description: DMM => Digital Multimeter
//***************************************************************************
INT CGPIBDevice::SELECT_DMM2(ViSession defaultRM, CHAR *pcCommand) 
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]	= {	"HEWLETT-PACKARD", "PRESERVE", "34970A", "NULL"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != viStatus) 
	{
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != viStatus) 
	{
		viClose(viSession);
		return viStatus;
	}

	m_viSession_DMM2 = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bDMM2Exist = TRUE;
				m_DMM2Obj = new CAgilent34970A();
				break;
			}
		}
	}
	return iStatus;
}
//***************************************************************************
// Description: DMM3 => Digital Multimeter
//***************************************************************************
INT CGPIBDevice::SELECT_DMM3(ViSession defaultRM, CHAR *pcCommand) 
{
	INT			iStatus = ERROR_SUCCESS;	
	/* String Format => { Model } */ 
	CONST CHAR	szHP[10] = {"HP3458A"};	
	ViSession	viSession;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != viStatus)
		return viStatus;

	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	//	The END command enables or disables the GPIB End Or Identify (EOI) function.
	viStatus = viPrintf(viSession, "END ALWAYS\n");						// page 176
	// to preset
	viStatus = viPrintf(viSession, "PRESET NORM\n");					// page 217
	// to clear the status register
	viStatus = viPrintf(viSession, "CSB\n");							// page 167
	// Get Device Name or Model	
	// viStatus = viQueryf(viSession, "ID?\n", "%t", &m_szGetDeviceName);	// page 186
	viStatus = viQueryf(viSession, "ID?\n", "%t", &m_szGetDeviceName);	// page 186

	if(VI_SUCCESS != viStatus)
	{
		viClose(viSession);
		return viStatus;
	}

	m_viSession_DMM3 = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szHP, strlen(szHP)))
	{
		m_bDMM3Exist = TRUE;
//fox		m_DMM3Obj = new CAgilent3458A;
	}
	return iStatus;
}
//***************************************************************************
// Description: FRE => Digital Multimeter
//***************************************************************************
INT CGPIBDevice::SELECT_FRE(ViSession defaultRM, CHAR *pcCommand) 
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]	= {	"HEWLETT-PACKARD", "PRESERVE", "53131A","53181A","NULL"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != viStatus) 
	{
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != viStatus) 
	{
		viClose(viSession);
		return viStatus;
	}

	m_viSession_FRE = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bFREExist = TRUE;
//fox				m_FREObj = new CAgilent53131A;
				break;
			}
		}
	}
	return iStatus;
}
//***************************************************************************
// Description: FRE => Digital Multimeter
//***************************************************************************
INT CGPIBDevice::SELECT_FRE2(ViSession defaultRM, CHAR *pcCommand) 
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]	= {	"HEWLETT-PACKARD", "PRESERVE", "53131A","53181A","NULL"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != viStatus) 
	{
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != viStatus) 
	{
		viClose(viSession);
		return viStatus;
	}

	m_viSession_FRE2 = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bFRE2Exist = TRUE;
//fox				m_FRE2Obj = new CAgilent53131A;
				break;
			}
		}
	}
	return iStatus;
}
//***************************************************************************
// Description: FRE => Digital Multimeter
//***************************************************************************
INT CGPIBDevice::SELECT_FRE3(ViSession defaultRM, CHAR *pcCommand) 
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]	= {	"HEWLETT-PACKARD", "PRESERVE", "53131A","53181A","NULL"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != viStatus) 
	{
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != viStatus) 
	{
		viClose(viSession);
		return viStatus;
	}

	m_viSession_FRE3 = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bFRE3Exist = TRUE;
//fox				m_FRE3Obj = new CAgilent53131A;
				break;
			}
		}
	}
	return iStatus;
}
//***************************************************************************
// Description: FRE => Digital Multimeter
//***************************************************************************
INT CGPIBDevice::SELECT_FRE4(ViSession defaultRM, CHAR *pcCommand) 
{
	/* String Format => { Brand, Preserve, Model , NULL } */ 
	CONST CHAR	*szHP[]	= {	"HEWLETT-PACKARD", "PRESERVE", "53131A","53181A","NULL"};

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;
	ViSession	viSession;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if(VI_SUCCESS != viStatus) 
	{
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if(VI_SUCCESS != viStatus) 
	{
		viClose(viSession);
		return viStatus;
	}

	m_viSession_FRE4 = viSession;

	if(0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for(int i=2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if(0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				m_bFRE4Exist = TRUE;
//fox				m_FRE4Obj = new CAgilent53131A;
				break;
			}
		}
	}
	return iStatus;
}
//***************************************************************************
//Description: Clear and Close Session
//***************************************************************************
INT CGPIBDevice::CLOSE_PPS_SESSION(VOID)
{
	::Sleep(10); /* Wait for Device Response */
	if (TRUE == m_bPPSExist)
	{
		viClear(m_viSession_PPS);
		viGpibControlREN(m_viSession_PPS, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_PPS);
		viClose(m_viOpenDefaultRM_PPS);
		m_viOpenDefaultRM_PPS = 0;
		m_viSession_PPS = 0;
		m_bPPSExist = FALSE;
	}
	if (TRUE == m_bPPS2Exist)
	{
		viClear(m_viSession_PPS2);
		viGpibControlREN(m_viSession_PPS2, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_PPS2);
		viClose(m_viOpenDefaultRM_PPS2);
		m_viOpenDefaultRM_PPS2 = 0;
		m_viSession_PPS2 = 0;
		m_bPPSExist = FALSE;
	}
	if (NULL != m_PPSObj)
	{
		delete m_PPSObj;
		m_PPSObj = NULL;
	}
	else if (NULL != m_PPS2Obj)
	{
		delete m_PPS2Obj;
		m_PPS2Obj = NULL;
	}
	return GPIB_SUCCESS;
}
INT CGPIBDevice::CLOSE_RRT_SESSION(VOID)
{
	::Sleep(10); /* Wait for Device Response */
	if (TRUE == m_bRRTExist)
	{
		viClear(m_viSession_RRT);
		viGpibControlREN(m_viSession_RRT, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_RRT);
		viClose(m_viOpenDefaultRM_RRT);
		m_viOpenDefaultRM_RRT = 0;
		m_viSession_RRT = 0;
		m_bRRTExist = FALSE;
	}
	if (NULL != m_RRTObj)
	{
		delete m_RRTObj;
		m_RRTObj = NULL;
	}
	return GPIB_SUCCESS;
}
INT CGPIBDevice::CLOSE_DMM_SESSION(VOID)
{
	::Sleep(10); /* Wait for Device Response */
	if (TRUE == m_bDMMExist)
	{
		viClear(m_viSession_DMM);
		viGpibControlREN(m_viSession_DMM, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_DMM);
		viClose(m_viOpenDefaultRM_DMM);
		m_viOpenDefaultRM_DMM = 0;
		m_viSession_DMM = 0;
		m_bDMMExist = FALSE;
	}
	if (TRUE == m_bDMM2Exist)
	{
		viClear(m_viSession_DMM2);
		viGpibControlREN(m_viSession_DMM2, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_DMM2);
		viClose(m_viOpenDefaultRM_DMM2);
		m_viOpenDefaultRM_DMM2 = 0;
		m_viSession_DMM2 = 0;
		m_bDMMExist = FALSE;
	}
	if (NULL != m_DMMObj)
	{
		delete m_DMMObj;
		m_DMMObj = NULL;
	}
	else if (NULL != m_DMM2Obj)
	{
		delete m_DMM2Obj;
		m_DMM2Obj = NULL;
	}
	return GPIB_SUCCESS;
}
INT CGPIBDevice::CLOSE_FRE_SESSION(VOID)
{
	::Sleep(10); /* Wait for Device Response */
	if (TRUE == m_bFREExist)
	{
		viClear(m_viSession_FRE);
		viGpibControlREN(m_viSession_FRE, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_FRE);
		viClose(m_viOpenDefaultRM_FRE);
		m_viOpenDefaultRM_FRE = 0;
		m_viSession_FRE = 0;
		m_bDMMExist = FALSE;
	}
	if (TRUE == m_bFRE2Exist)
	{
		viClear(m_viSession_FRE2);
		viGpibControlREN(m_viSession_FRE2, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_FRE2);
		viClose(m_viOpenDefaultRM_FRE2);
		m_viOpenDefaultRM_FRE2 = 0;
		m_viSession_FRE2 = 0;
		m_bDMMExist = FALSE;
	}
	if (TRUE == m_bFRE3Exist)
	{
		viClear(m_viSession_FRE3);
		viGpibControlREN(m_viSession_FRE3, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_FRE3);
		viClose(m_viOpenDefaultRM_FRE3);
		m_viOpenDefaultRM_FRE3 = 0;
		m_viSession_FRE3 = 0;
		m_bDMMExist = FALSE;
	}
	if (TRUE == m_bFRE4Exist)
	{
		viClear(m_viSession_FRE4);
		viGpibControlREN(m_viSession_FRE4, VI_GPIB_REN_ADDRESS_GTL);
		viClose(m_viSession_FRE4);
		viClose(m_viOpenDefaultRM_FRE4);
		m_viOpenDefaultRM_FRE4 = 0;
		m_viSession_FRE4 = 0;
		m_bDMMExist = FALSE;
	}
	if (NULL != m_FREObj)
	{
		delete m_FREObj;
		m_FREObj = NULL;
	}
	else if (NULL != m_FRE2Obj)
	{
		delete m_FRE2Obj;
		m_FRE2Obj = NULL;
	}
	else if (NULL != m_FRE3Obj)
	{
		delete m_FRE3Obj;
		m_FRE3Obj = NULL;
	}
	else if (NULL != m_FRE4Obj)
	{
		delete m_FRE4Obj;
		m_FRE4Obj = NULL;
	}

	return GPIB_SUCCESS;
}
INT CGPIBDevice::CLOSE_ALL_SESSION(VOID)
{
	if (NULL != m_PPSObj)
		CLOSE_PPS_SESSION();

	if (NULL != m_RRTObj)
		CLOSE_RRT_SESSION();

	if (NULL != m_DMMObj)
 		CLOSE_DMM_SESSION();

	if (NULL != m_FREObj)
		CLOSE_FRE_SESSION();

	for (map<string, VIRESOURCE*>::iterator it = m_vi.begin(); it != m_vi.end(); it++)
	{
		::Sleep(10);
		viClear(it->second->viSession);
		viGpibControlREN(it->second->viSession, VI_GPIB_REN_ADDRESS_GTL);
		viClose(it->second->viSession);
		viClose(it->second->viDefaultRM);
		delete it->second->vInst;
		delete it->second;
	}

	if (NULL != m_hDLL)
		UNLOAD_DLL();

	return GPIB_SUCCESS;
}
INT CGPIBDevice::UNLOAD_DLL(VOID)
{
	if (NULL != m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
	return GPIB_SUCCESS;
}




INT CGPIBDevice::LoadDll(void)
{
	if (m_hDLL != NULL)
		return GPIB_SUCCESS;

	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	if (INVALID_FILE_ATTRIBUTES == ::GetFileAttributesA(m_szDLLFile)) return LOAD_DLL_FAIL;

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	if (m_hDLL == NULL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
		return GPIB_INIT_FAIL;
	}
	else
	{
		viOpenDefaultRM = (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL, "viOpenDefaultRM");
		viOpen = (pf_viOpen_t)::GetProcAddress(m_hDLL, "viOpen");
		viPrintf = (pf_viPrintf_t)::GetProcAddress(m_hDLL, "viPrintf");
		viScanf = (pf_viScanf_t)::GetProcAddress(m_hDLL, "viScanf");
		viClose = (pf_viClose_t)::GetProcAddress(m_hDLL, "viClose");
		viQueryf = (pf_viQueryf_t)::GetProcAddress(m_hDLL, "viQueryf");
		viClear = (pf_viClear_t)::GetProcAddress(m_hDLL, "viClear");
		viSetAttribute = (pf_viSetAttribute_t)::GetProcAddress(m_hDLL, "viSetAttribute");
		viWrite = (pf_viWrite_t)::GetProcAddress(m_hDLL, "viWrite");
		viGpibControlREN = (pf_viGpibControlREN_t)::GetProcAddress(m_hDLL, "viGpibControlREN");

	}

	if (!viOpenDefaultRM || !viOpen || !viPrintf || !viScanf || !viClose ||
		!viQueryf || !viClear || !viSetAttribute || !viWrite || !viGpibControlREN)
	{
		::FreeLibrary(m_hDLL);
		::MessageBoxA(NULL, "Load visa32.dll Function Point Fail.", NULL, NULL);
		return LOAD_DLL_FAIL;
	}

	return GPIB_SUCCESS;
}

void CGPIBDevice::AddOutput(COutputDebug* output)
{
	this->m_dbgmsg.AddOutput(output);
}

int CGPIBDevice::Init(const char* alias_name, const char* gpib_ins, const char* vesa_res_name, int gpib_board, int bpib_addr)
{
	INT iStatus = GPIB_SUCCESS;
	VIRESOURCE*			viResource;
	ViSession			viDefaultRM = 0;
	ViSession			viSession = 0;
	CVirtualInstrument* vInst = NULL;

	if (m_vi.find(alias_name) != m_vi.end())
		return iStatus;

	if (LoadDll() != GPIB_SUCCESS)
		return LOAD_DLL_FAIL;

	viOpenDefaultRM(&viDefaultRM);
	if (strlen(vesa_res_name) != 0)
		strcpy_s(m_szCommand, vesa_res_name);
	else
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", gpib_board, bpib_addr);

	m_dbgmsg.Outputf("GPIB source name:%s\n", m_szCommand);

	if (strcmp(gpib_ins, "DMM") == 0)
	{
		/*viOpenDefaultRM(&viDefaultRM);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", gpib_board, bpib_addr);*/

		iStatus = select_dmm(viDefaultRM, m_szCommand, viSession, &vInst);
		if (ERROR_SUCCESS != iStatus/* || TRUE != m_bDMMExist*/)
		{
			viClose(viDefaultRM);
			return GPIB_DMM_DETECT_FAIL;
		}
		if (VI_SUCCESS != viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_DMM_DETECT_FAIL;
		}
	}
	else if (strcmp(gpib_ins, "PPS") == 0)
	{
		/*viOpenDefaultRM(&viDefaultRM);
		sprintf_s(m_szCommand, "GPIB%d::%d::0::INSTR", gpib_board, bpib_addr);*/

		iStatus = select_pps(viDefaultRM, m_szCommand, viSession, &vInst);
		if (ERROR_SUCCESS != iStatus/* || TRUE != m_bPPSExist*/)
		{
			viClose(viDefaultRM);
			return GPIB_PPS_DETECT_FAIL;
		}
		if (VI_SUCCESS != viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_PPS_DETECT_FAIL;
		}
	}
	else if (strcmp(gpib_ins, "RRT") == 0)
	{
		iStatus = select_rrt(viDefaultRM, m_szCommand, viSession, &vInst);
		if (ERROR_SUCCESS != iStatus/* || TRUE != m_bPPSExist*/)
		{
			viClose(viDefaultRM);
			return GPIB_PPS_DETECT_FAIL;
		}
		if (VI_SUCCESS != viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000))
		{
			return GPIB_PPS_DETECT_FAIL;
		}
	}

	vInst->VISA32_SET_VI_SESSION(viSession);
	vInst->VISA32_SET_GPIBLOG_ENABLE(CConfig::getInstance()->cfg_enable_gpib_log ? TRUE : FALSE);
	viResource = new VIRESOURCE();
	viResource->viDefaultRM = viDefaultRM;
	viResource->viSession = viSession;
	viResource->vInst = vInst;
	m_vi[alias_name] = viResource;

	return 0;
}

bool CGPIBDevice::HaveInit(const char* alias_name)
{
	return (m_vi.find(alias_name) != m_vi.end());
}

CVirtualInstrument* CGPIBDevice::use(const char* alias_name)
{
	if (m_vi.find(alias_name) == m_vi.end())
		::MessageBoxA(NULL, "can not find the alias of instrument!", "GPIBDevice", MB_OK);

	return m_vi[alias_name]->vInst;
}

int CGPIBDevice::select_pps(ViSession defaultRM, char *pcCommand, ViSession& viSession, CVirtualInstrument** vInst)
{
	/* String Format => { Brand, Preserve, Model , NULL } */
	CONST CHAR	*szHP[] = { "HEWLETT-PACKARD", "PRESERVE", "E3631", "NULL" };
	CONST CHAR	*szAnritsu[] = { "ANRITSU", "PRESERVE", "NONE", "NULL" };
	CONST CHAR	*szRS[] = { "Rohde&Schwarz", "PRESERVE", "NONE", "NULL" };
	CONST CHAR	*szKeithley[] = { "KEITHLEY INSTRUMENTS INC.", "KI", "MODEL 230", "NULL" };
	CONST CHAR	*szAgilent[] = { "Agilent Technologies", "PRESERVE", "663", "E3646A", "E3631", "NULL" };
	CONST CHAR	*szMotech[] = { "PPS-1201GSM" };
	CONST CHAR	*szInstek[] = { "GW INSTEK", "PRESERVE", "PPH1503", "NULL" };

	INT			iStatus = ERROR_SUCCESS;
	CHAR		*pcBrand = NULL;

	// viOpen Session
	iStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if (VI_SUCCESS != iStatus)
	{
		m_dbgmsg.Outputf("Failed to viOpen. Err:%d", iStatus);
		return iStatus;
	}
	iStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	iStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	iStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if (VI_SUCCESS != iStatus)
	{
		iStatus = viQueryf(viSession, "MODEL?\n", "%t", &m_szGetDeviceName);
		if (VI_SUCCESS != iStatus)
		{
			m_dbgmsg.Outputf("Failed to viQueryf(*IDN? or MODEL?). Err:%d", iStatus);
			viClose(viSession);
			return iStatus;
		}
	}

	if (0 == _strnicmp(m_szGetDeviceName, szAgilent[0], strlen(szAgilent[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szAgilent[0]) + 1; // (+1) => Token ","
		for (int i = 2; (0 != _stricmp(szAgilent[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if (0 == _strnicmp(pcBrand, szAgilent[i], strlen(szAgilent[i])))
			{
				if (0 == _stricmp(szAgilent[i], "E3646A")) /* Special PPS */
				{
					*vInst = new CAgilentE3646A;
				}
				else
				{
					*vInst = new CAgilent663x;
				}
				break;
			}
		}
	}
	else if (0 == _strnicmp(m_szGetDeviceName, szKeithley[0], strlen(szKeithley[0])) ||
		0 == _strnicmp(m_szGetDeviceName, szKeithley[1], strlen(szKeithley[1])))
	{
		pcBrand = m_szGetDeviceName + strlen(szKeithley[0]) + 1; // (+1) => Token ","
		for (int i = 2; (0 != _stricmp(szKeithley[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if (0 == _strnicmp(pcBrand, szKeithley[i], strlen(szKeithley[i])))
			{
				*vInst = new CKeithley230x;

				if (NULL != strstr(m_szGetDeviceName, "2303"))
					m_isPPS1_DualCH = FALSE;	//???????????????????????????????????? fox
				break;
			}
		}
	}
	else if (0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for (int i = 2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if (0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				*vInst = new CAgilent663x;
				break;
			}
		}
	}
	else if (0 == _strnicmp(m_szGetDeviceName, szInstek[0], strlen(szInstek[0]))) /// Hai add 22/08/05
	{
		pcBrand = m_szGetDeviceName + strlen(szInstek[0]) + 1; // (+1) => Token ","
		for (int i = 2; (0 != _stricmp(szInstek[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if (0 == _strnicmp(pcBrand, szInstek[i], strlen(szInstek[i])))
			{
				*vInst = new CAgilent663x;
				break;
			}
		}
	}
	else if (0 == _strnicmp(m_szGetDeviceName, szMotech[0], strlen(szMotech[0])))/* Motech */
	{
		*vInst = new CMotech1201;
	}
	else
	{
		//...
	}
	if (*vInst == NULL) /// Hai add 22/08/04
		iStatus = 1000;
	return iStatus;
}

int CGPIBDevice::select_dmm(ViSession defaultRM, char *pcCommand, ViSession& viSession, CVirtualInstrument** vInst)
{
	/* String Format => { Brand, Preserve, Model , NULL } */
	CONST CHAR	*szHP[] = { "HEWLETT-PACKARD", "PRESERVE", "34970A", "34410A", "34401A", "NULL" };
	CONST CHAR	*szGWinstek[] = { "GWInstek", "PRESERVE", "GDM9061", "NULL" };
	CHAR		*pcBrand = NULL;
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if (VI_SUCCESS != viStatus)
	{
		m_dbgmsg.Outputf("Failed to viOpen. Err:%d", viStatus);
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if (VI_SUCCESS != viStatus)
	{
		m_dbgmsg.Outputf("Failed to viQueryf(*IDN?). Err:%d", viStatus);
		viClose(viSession);
		return viStatus;
	}
	
	if (0 == _strnicmp(m_szGetDeviceName, szHP[0], strlen(szHP[0])))
	{
		pcBrand = m_szGetDeviceName + strlen(szHP[0]) + 1; // (+1) => Token ","
		for (int i = 2; (0 != _stricmp(szHP[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if (0 == _strnicmp(pcBrand, szHP[i], strlen(szHP[i])))
			{
				*vInst = new CAgilent34970A();
				break;
			}
		}
	}
	else if (0 == _strnicmp(m_szGetDeviceName, szGWinstek[0], strlen(szGWinstek[0]))) // dale add 02/07/2025 insert model GDM9061
	{
		pcBrand = m_szGetDeviceName + strlen(szGWinstek[0]) + 1; // (+1) => Token ","
		for (int i = 2; (0 != _stricmp(szGWinstek[i], "NULL")); i++) // Set i=2 to Find Model
		{
			if (0 == _strnicmp(pcBrand, szGWinstek[i], strlen(szGWinstek[i])))
			{
				// Tạm thời s�?dụng CAgilent34970A cho GDM9061 - cần tạo class riêng sau n?y
				*vInst = new CAgilent34970A();
				// Set brand ?�?s�?dụng GWinstek commands
				((CAgilent34970A*)*vInst)->SET_DEVICE_BRAND(1); // set brand ==1 for send and read command
				break;
			}
		}
	}
	return viStatus;
}

int CGPIBDevice::select_rrt(ViSession defaultRM, char *pcCommand, ViSession& viSession, CVirtualInstrument** vInst)
{
	ViStatus	viStatus;

	// viOpen Session
	viStatus = viOpen(defaultRM, pcCommand, VI_NULL, VI_NULL, &viSession);
	if (VI_SUCCESS != viStatus)
	{
		m_dbgmsg.Outputf("Failed to viOpen. Err:%d", viStatus);
		return viStatus;
	}
	viStatus = viSetAttribute(viSession, VI_ATTR_TMO_VALUE, 5000);
	viStatus = viSetAttribute(viSession, VI_ATTR_TERMCHAR, '\n');
	viStatus = viSetAttribute(viSession, VI_ATTR_TERMCHAR_EN, VI_TRUE);
	viStatus = viPrintf(viSession, "*CLS\n");
	// Get Device Name or Model
	viStatus = viQueryf(viSession, "*IDN?\n", "%t", &m_szGetDeviceName);
	if (VI_SUCCESS != viStatus)
	{
		m_dbgmsg.Outputf("Failed to viQueryf(*IDN?). Err:%d", viStatus);
		viClose(viSession);
		return viStatus;
	}

	if (0 == _strnicmp(m_szGetDeviceName, "LitePoint,IQxstream-M", strlen("LitePoint,IQxstream-M")))
	{
		*vInst = new CLitePointIQxtreamM();
	}

	return viStatus;
}





