#ifndef _AGILENTE3643A_H
#define _AGILENTE3643A_H

#include "visa_ExportApi.h"
#include "ReturnType.h"
#include "GlobalVar.h"
#include "VirtualFunction.h"
#include "CommonAPI.h"

class CAgilentE3646A : public CVirtualInstrument
{
public:
	CAgilentE3646A();
	virtual ~CAgilentE3646A();

public:	
	HINSTANCE				m_hDLL;
	CHAR					m_szDLLFile[MAX_PATH];
	CHAR					m_szCommand[256];
	CHAR					m_szReadBuffer[1024];

	ViSession				m_viSession;

	pf_viOpen_t				viOpen;
	pf_viScanf_t			viScanf;
	pf_viClose_t			viClose;
	pf_viPrintf_t			viPrintf;
	pf_viOpenDefaultRM_t	viOpenDefaultRM;
	pf_viQueryf_t			viQueryf;
	pf_viClear_t			viClear;
	pf_viSetAttribute_t		viSetAttribute;

	//Tomy Chen, 2009/03/31, Flag to indicate to save GPIB log or not.
	BOOL					m_bGPIB_Log_Enable;

public:
	INT	Write(CONST CHAR *cpcCommand);
	INT	Query(CONST CHAR *cpcCommand, CHAR *pcReturnValue);

public:
	// Virtual Function
	INT	VISA32_SET_VI_SESSION(DWORD vi);
	INT	VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable);

	INT	PPS_SET_VOLTAGE(double dVoltage);
	INT	PPS_SET_VOLTAGE_CH2(double dVoltage);
	INT	PPS_SET_CURRENT(double dCurrentLimit);
	INT	PPS_SET_CURRENT_CH2(double dCurrentLimit);
	INT	PPS_SET_POWER_ON(VOID);
	INT	PPS_SET_POWER_ON_CH2(VOID);
	INT	PPS_SET_POWER_OFF(VOID);
	INT	PPS_SET_POWER_OFF_CH2(VOID);
};

#endif // !defined(AFX_AGILENT663X_H__604FE59E_F54D_4C24_898B_DF8909594B74__INCLUDED_)
