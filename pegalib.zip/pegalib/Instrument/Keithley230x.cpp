// Keithley230x.cpp: implementation of the CKeithley230x class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Keithley230x.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CKeithley230x::CKeithley230x()
{
	m_hDLL	= NULL;

	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	//m_hDLL = ::LoadLibraryEx(m_szDLLFile, NULL, DONT_RESOLVE_DLL_REFERENCES);
	if(NULL == m_hDLL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
	}
	else
	{
		viOpenDefaultRM	= (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL,"viOpenDefaultRM");
		viOpen			= (pf_viOpen_t)::GetProcAddress(m_hDLL,"viOpen");
		viPrintf		= (pf_viPrintf_t)::GetProcAddress(m_hDLL,"viPrintf");
		viScanf			= (pf_viScanf_t)::GetProcAddress(m_hDLL,"viScanf");
		viClose			= (pf_viClose_t)::GetProcAddress(m_hDLL,"viClose");
		viQueryf		= (pf_viQueryf_t)::GetProcAddress(m_hDLL,"viQueryf");
		viClear			= (pf_viClear_t)::GetProcAddress(m_hDLL,"viClear");
		viSetAttribute	= (pf_viSetAttribute_t)::GetProcAddress(m_hDLL,"viSetAttribute");
	}
}
CKeithley230x::~CKeithley230x()
{
	if(m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
}

//***************************************************************************
// Description: Send GPIB command to Device via Visa
//***************************************************************************
INT CKeithley230x::Write(CONST CHAR *pcCommand)
{
	ViStatus		status;
	CHAR			GPIBLog[1024] = {0x00};

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog), "WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viPrintf(m_viSession, m_szCommand);
	if (status != VI_SUCCESS)
	{
		return GPIB_WRITE_FAIL;
	}
	return GPIB_SUCCESS;
}

//***************************************************************************
// Description: Execute Query command & get value from Device via Visa
//***************************************************************************
INT CKeithley230x::Query(CONST CHAR *pcCommand, CHAR *pcReturnValue)
{
	ViStatus		status;
	CHAR			GPIBLog[1024] = {0x00};

	if (m_bGPIB_Log_Enable == TRUE)
	{
		sprintf_s(GPIBLog, sizeof(GPIBLog), "WR: %s", pcCommand);
		GPIBTrace(GPIBLog);
	}
	
	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viQueryf(m_viSession, m_szCommand, "%t", pcReturnValue);
	if (status != VI_SUCCESS)
	{
		return GPIB_QUERY_FAIL;
	}

	if (m_bGPIB_Log_Enable == TRUE)
	{
		memset(GPIBLog, 0x00, sizeof(GPIBLog));
		sprintf_s(GPIBLog, sizeof(GPIBLog), "RE: %s", pcReturnValue);
		GPIBTrace(GPIBLog);
	}

	return GPIB_SUCCESS;
}
//***************************************************************************
// Description: Virtual Function
//***************************************************************************
INT	CKeithley230x::VISA32_SET_VI_SESSION(DWORD vi)
{
	m_viSession = (ViSession)vi;
	return GPIB_SUCCESS;
}

INT	CKeithley230x::VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable)
{
	m_bGPIB_Log_Enable = bGPIBLog_Enable;
	GPIBTrace("##########		Keithley 230X Test Start		##########");
	return GPIB_SUCCESS;
}

INT	CKeithley230x::PPS_SET_VOLTAGE(double dVoltage)
{
	sprintf_s(m_szCommand, "VOLTage %2.2f",dVoltage);
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_SET_VOLTAGE_CH2(double dVoltage)
{
	sprintf_s(m_szCommand, "SOURce2:VOLTage %2.2f",dVoltage);
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_SET_CURRENT(double dCurrLimit)
{
	sprintf_s(m_szCommand, "CURRent %2.1f",dCurrLimit);
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_SET_CURRENT_CH2(double dCurrLimit)
{
	sprintf_s(m_szCommand, "SOURce2:CURRent %2.1f",dCurrLimit);
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_GET_CURRENT(double *pdCurrent)
{
	*pdCurrent = 0;
	INT iGPIBRet = Query("meas:curr?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdCurrent = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}

INT	CKeithley230x::PPS_GET_CURRENT_CH2(double *pdCurrent)
{
	*pdCurrent = 0;
	INT iGPIBRet = Query("MEASure2:curr?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdCurrent = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}

INT	CKeithley230x::PPS_SET_POWER_ON(VOID)
{
	sprintf_s(m_szCommand, "OUTPUT ON");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_SET_POWER_ON_CH2(VOID)
{
	sprintf_s(m_szCommand, "OUTPut2 ON");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_SET_POWER_OFF(VOID)
{
	sprintf_s(m_szCommand, "OUTPUT OFF");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_SET_POWER_OFF_CH2(VOID)
{
	sprintf_s(m_szCommand, "OUTPut2 OFF");
	INT iGPIBRet = Write(m_szCommand);
	return iGPIBRet;
}

INT	CKeithley230x::PPS_GET_VOLTAGE(double *pdVoltage)
{
	*pdVoltage = 0;
	INT iGPIBRet = Query("MEASure:VOLT?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdVoltage = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}

INT	CKeithley230x::PPS_GET_VOLTAGE_CH2(double *pdVoltage)
{
	*pdVoltage = 0;
	INT iGPIBRet = Query("MEASure2:VOLT?", m_szReadBuffer);
	if (iGPIBRet == GPIB_SUCCESS)
	{
		*pdVoltage = strtod(m_szReadBuffer, NULL);
	}
	else
	{
		iGPIBRet = GPIB_QUERY_FAIL;
	}
	return iGPIBRet;
}
//***************************************************************************
// Description: End
//***************************************************************************