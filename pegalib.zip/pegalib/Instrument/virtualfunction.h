#ifndef VIRTUALFUNCTION_H
#define VIRTUALFUNCTION_H

//#include "CmdRecord.h"
#include "ReturnType.h"
//#include "qlib_defines.h"
#include "GlobalVar.h"
#include <vector>
#include "..\modules\outputlog\OutputDebug.h"
#include "..\modules\outputlog\DebugMessage.h"

using namespace std;

// Communicate with DUT (input/output)
typedef struct _DUT_INTERFACE {
	IN	CHAR	szRapiDLL[256];
	IN	CHAR	szRapiFunction[256];
	IN	DWORD	dwTestType;
	IN	UCHAR	ucImage[256];
	IN	UCHAR	ucCommandLine[256];
	IN	DWORD	iTimeout;
	OUT	DWORD	dwValue;
	OUT CHAR	szMessage[256];
} DUT_INTERFACE, *LPDUT_INTERFACE;

typedef struct _TEST_VALUE {
	IN	CHAR	szISN[32];
	IN	CHAR	szTestItem[64];
	IN	CHAR	szUpLimit[64];
	IN	CHAR	szLowLimit[64];	
	OUT	CHAR	szTestValue[4096];
	OUT	INT		iTestStatus;
}TEST_VALUE, *LPTEST_VALUE;

typedef struct _DEVICE_CONTROL {
	IN	CHAR	szPPSEnable[8];
	IN	CHAR	szPPS2Enable[8];
	IN	CHAR	szRRTEnable[8];
	IN	CHAR	szDMMEnable[8];
	IN	CHAR	szDMM2Enable[8];
	IN	CHAR	szDMM3Enable[8];	// 2012/12/12 0505/PM Brighd for new DMM 3458A
	IN	CHAR	szBTTEnable[8];	
	IN	CHAR	szFREEnable[8];
	IN	CHAR	szFRE2Enable[8];
	IN	CHAR	szFRE3Enable[8];
	IN	CHAR	szFRE4Enable[8];
	IN	INT		iPPSAddress;
	IN	INT		iPPS2Address;
	IN	INT		iRRTAddress;
	IN	INT		iDMMAddress;
	IN	INT		iDMM2Address;
	IN	INT		iDMM3Address;		// 2012/12/12 0505/PM Brighd for new DMM 3458A
	IN	INT		iBTTAddress;	
	IN	INT		iFREAddress;
	IN	INT		iFRE2Address;
	IN	INT		iFRE3Address;
	IN	INT		iFRE4Address;
	IN	BOOL	bPPSEnable;
	IN	BOOL	bPPS2Enable;
	IN	BOOL	bRRTEnable;
	IN	BOOL	bDMMEnable;
	IN	BOOL	bDMM2Enable;
	IN	BOOL	bDMM3Enable;		// 2012/12/12 0505/PM Brighd for new DMM 3458A
	IN	BOOL	bBTTEnable;	
	IN	BOOL	bFREEnable;
	IN	BOOL	bFRE2Enable;
	IN	BOOL	bFRE3Enable;
	IN	BOOL	bFRE4Enable;
	IN  INT     iGPIBBoard;
	IN	CHAR	szGPIBLogEnable[8];
	IN	BOOL	bGPIBLogEnable;
	IN	char    szTCPIPRRTAddress[100];
}DEVICE_CONTROL, *LPDEVICE_CONTROL;

typedef struct _NI_CONTROL {
	IN	CHAR	sz6518Enable[8];
	IN	CHAR	sz6281Enable[8];
	IN	BOOL	b6518Enable;
	IN	BOOL	b6281Enable;
	IN	CHAR	sz6518Type[32];
	IN	CHAR	sz6281Type[32];
}NI_CONTROL, *LPNI_CONTROL;

typedef struct _RRT_PARAMETERS {
	//Instrument parameters
	IN	CHAR	cAppName[SIZE_16_LENGTH];
	IN	INT		iOperationMode;
	IN	INT		iNCCCode;
	IN	INT		iBCCCode;
	IN	INT		iCCHBand;
	IN	INT		iCCH_Arfcn;
	IN	double	dBsPower;
	IN	INT		iTCHBand;
	IN	INT		iTCH_Arfcn;
	IN	INT		iPCL;
	IN	double	dExpectedPower;
	IN	INT		iDL_Arfcn;
	IN	CHAR	cEPSK_ConnType[SIZE_16_LENGTH];
	IN	CHAR	cWB_LoopMode[SIZE_16_LENGTH];
	IN	INT		iSignal_Flag;
	IN	INT		iEPSK_CodeScheme;
	IN	INT		iHandOverTarget;
	IN	INT		iDelay_After_BandIndicator;
	IN	CHAR	cSignalingCH[SIZE_32_LENGTH];

	//Measurement setting parameters
	IN	INT		iMeasCounter;
	IN	INT		iMeasTimeoutS;
	IN	BOOL	bMeasContinuous;
	IN	CHAR	cMeasPvTOffsets[SIZE_512_LENGTH];
	IN	CHAR	cMeasPvTSyncMode[SIZE_16_LENGTH];
	IN	CHAR	cMeasORFSSw[SIZE_512_LENGTH];
	IN	CHAR	cMeasORFSMod[SIZE_512_LENGTH];
	IN	INT		iMeasORFSModCounter;
	IN	INT		iMeasORFSSwCounter;
	IN	CHAR	cWB_SEM_DetectMode[SIZE_16_LENGTH];
	IN	BOOL	bWB_ACLR_P5On;
	IN	BOOL	bWB_ACLR_N5On;
	IN	BOOL	bWB_ACLR_P10On;
	IN	BOOL	bWB_ACLR_N10On;
	IN	CHAR	cWB_ILPC_Segment[SIZE_16_LENGTH];
	IN	INT		iWB_ILPC_StartSlot;
	IN	INT		iWB_ILPC_EndSlot;
	IN	double	dWB_ILPC_StartPwr;
	IN	double	dWB_ILPC_EndPwr;
	IN	INT		iWB_ILPC_MeasSlotNumber;
	IN	BOOL	bWB_FastPowerMeas;

	//WB Parameters
	IN	CHAR	cDPCH_ChannelType[SIZE_16_LENGTH];
	IN	INT		iDPCH_ChannelCode;
	IN	INT		iDPCH_ChannelSACode;
	IN	CHAR	cTPC_Pattern[SIZE_16_LENGTH];
	IN	INT		iTPC_ALG;
	IN	INT		iTPC_StepSize;
	IN	CHAR	cWBTriggerSource[SIZE_16_LENGTH];
	IN	double	dTriggetDelayMS;

	//Polar loop calibration
	IN	INT		iPCAL_Duration;
	IN	INT		iPCAL_Period;
	IN	INT		iPCAL_StepLength;
	IN	INT		iPCAL_TriggerOffset;
	IN	INT		iPCAL_FreqEstiLimit;

	//WCDMA TX Sweep Calibration
	IN	INT		iWBSweep_TimeInterval;
	IN	INT		iWBSweep_Counter;
	IN	INT		iWBSweep_Timeout;
	IN	INT		iWBSweep_PALoop;

	//WCDMA BetaC, BetaD
	IN	INT		iWB_BetaC;
	IN	INT		iWB_BetaD;

	//HSDPA Parameters
	IN INT		iDPA_Channel_Coding;//mzlin 20090702
	IN INT		iDPA_Registration_Mode;//mzlin 20090702
	IN INT		iDPA_Hshset;//mzlin 20090702
	IN INT		iDPA_DeltaACK;//mzlin 20090702
	IN INT		iDPA_DeltaNACK;//mzlin 20090702
	IN INT		iDPA_DeltaCQI;//mzlin 20090702
	IN INT		iDPA_AckNack_Repetition_Factor;//mzlin 20090702
	IN INT		iDPA_CQI_Feedback_Cycle;//mzlin 20090702
	IN INT		iDPA_CQI_Repetition_Factor;//mzlin 20090702
	IN INT		iDPA_SubTest;//mzlin 20091204

	//TDSCDMA Parameters
	IN INT		iTDSCDMA_Conf;//mzlin 20090702
	IN CHAR		cTDSCDMA_Data_Rate[SIZE_32_LENGTH];//mzlin 20090702

}RRT_PARAMETERS, *LPRRT_PARAMETERS;
using namespace std;

// by Project(Braves...) -> by Station(GSM..) -> by Test Item(WRITE_ISN...)
//class CVirtualProject
//{
//
//private:
//	DWORD dwResult;
//
//public:
//	CVirtualProject(){};
//	virtual ~CVirtualProject(){};
//
//	virtual INT	INIT_OBJECT(CONST CHAR *pcFile, CONST CHAR *pcStation) { return dwResult; }
//	virtual INT	UNINIT_OBJECT(CONST CHAR *pcTestItemParam = NULL) { return dwResult; }
//	virtual INT BOARD_MMI_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT BOARD_GPS_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT BOARD_GSM_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT BOARD_GSM_CAL_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT BOARD_WCDMA_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT BOARD_WCDMA_CAL_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT BOARD_WIFI_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT BOARD_OTP_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }             //Add by Alice 20091028 for Diesel OTP
//	virtual INT SYSTEM_ALS_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; } 
//	
//
//	virtual INT PACKING_CONFIG_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_OTA_CURRENT_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_GSENSOR_XYZ(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT SYSTEM_AUDIO_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_CAMERA_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_WCDMA_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_GSM_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT PACKING_AOI_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_WIFI_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_GSENSOR_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_ECOMPASS_TEST_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_OS_DOWNLOAD_STATION(CMD_INDEX_TAG index, CONST CHAR *pcTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SYSTEM_LOG_UPLOAD_STATION(CMD_INDEX_TAG index, CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//};

//class CVirtualTestItem
//{
//
//private:
//	DWORD dwResult;
//
//public:
//
//	CVirtualTestItem(){};
//	virtual ~CVirtualTestItem(){};
//
//	// Common
//	virtual INT	INIT_OBJECT(CONST CHAR *pcFile, CONST CHAR *pcStation) { return dwResult; }
//	virtual INT	UNINIT_OBJECT(CONST CHAR *pcTestItemParam = NULL) { return dwResult; }
//	// Show MessageBox() and then detect power supply current
//	virtual INT	MESSAGE_DETECT_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	IF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	ELSE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	ELSE_IF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	END_IF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_DELTA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	// WinCE
//	virtual INT WINCE_SET_ACTIVESYNC_USB(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WINCE_INIT_RAPI_EX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WINCE_UNINIT_RAPI(VOID) { return dwResult; }
//	virtual INT WINCE_COPY_FILE_TO_DUT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WINCE_DELETE_DUT_FILE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WINCE_SET_SECURITY_POLICIES(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WINCE_GET_FILE_FROM_DUT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WINCE_TAKE_PHOTOS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SHOW_MESSAGE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	// Socket
//	virtual INT SOCKET_PREPARE_APP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SOCKET_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT SOCKET_UNINIT(VOID) { return dwResult; }
//	virtual INT SOCKET_CLOSE(VOID) { return dwResult; }
//	virtual INT SOCKET_CLOSE_APP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	// RS232
//	virtual INT RS232_OPEN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT RS232_CLOSE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT RS232_READ(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT RS232_WRITE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	// MMI Test Item
//	virtual INT TEST_WRITE_ISN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_WRITE_IMEI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_WRITE_WIFI_ADDRESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_WRITE_BT_ADDRESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_WRITE_CUSTOMER_ESN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_WRITE_MAP_UNLOCK_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_WRITE_NATIONAL_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_WRITE_REGISTRATION_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_ISN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_MODEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_FW_VERSION_MLB(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ALS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ACCEL_G(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_FIXTURE(CONST CHAR *pTestItemParam,TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_FIXTURE2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	OPEN_COM_PORT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	CLOSE_COM_PORT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT LUX_METER_LUX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT LUX_METER_LUX_T_10A(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_WAIT_START_UP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WHITE_CSV_AND_UI_ITEM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_REL_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult;}
//	virtual INT TEST_WRITE_DUT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }//by yunchen
//	virtual INT TEST_PREPARE_BURNIN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_APPEND_BURNIN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SCAN_ISN_CARRIER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	virtual INT STATION_MAC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT FIXTURE_ID(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_MLB_CONFIG(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_AVERAGE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT USB_SWITCH_SET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_OS_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_ATS_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_QCN_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_RADIO_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_MODEM_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_BOOT_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_APPBOOT_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_RECOVERY_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_SYSTEM_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_GPS_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_BT_ADDRESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_WIFI_ADDRESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_IMEI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_CUSTOMER_ESN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_GPI_INFO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_PRODUCT_INFO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_NATIONAL_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_PRODUCT_DOMAIN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_READ_REGISTRATION_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_READ_MAP_UNLOCK_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_READ_CAMERA_INFO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_CLEAR_MAP_UNLOCK_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_CHECK_BT_ADDRESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_CHECK_IMEI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_CHECK_CUSTOMER_ESN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_CHECK_MAP_UNLOCK_CODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_READ_CHECKSUM_FILE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_BT_MODULE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//    virtual INT TEST_FM_MODULE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_WIFI_MODULE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_MODULE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_CPU(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_FLASH(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SDRAM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_MOTION_SENSOR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_BACKLIGHT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SUSPEND_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_CHARGING_CURR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_RTC_CLOCK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_RTC_OFFSET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_VBAT_ADC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_VBAT_HOST(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_VIBRATOR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_KEYPAD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_CAMERA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SPEAKER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_RECEIVER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_MICROPHONE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_HEADSET_EARPHONE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_HEADSET_MIC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_MIC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_STANDBY_CURR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_KEYPAD_LED(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ONBOARD_LED(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_PHONE_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_WAKEUP_CURR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GET_STORAGE_CARD_ID(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_DETECT_USB(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SIM_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SIM_LOCK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_PLAY_PC_WAV(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_STOP_PC_WAV(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_PLAY_DUT_WAV(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_STOP_DUT_WAV(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_PLAY_DUT_WAV_SPK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_STOP_DUT_WAV_SPK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_PLAY_DUT_WAV_REC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_STOP_DUT_WAV_REC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_PLAY_DUT_WAV_MIC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_STOP_DUT_WAV_MIC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_BMIC_RECORD_WAV(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_LED_OFF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_RF_TEMPERATURE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_REBOOT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_REBOOT_DUT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GET_SYSTEM_INFO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_READ_XML_FILE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SET_GPS_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_DL_FW(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SIM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_MODEM_MODULE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GET_HEADSET_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_GET_HOOKKEY_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_SET_AUDIO_PATH(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_SET_AUDIO_LOOPBACK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_BMIC_TO_SPEAKER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_BMIC_TO_RECEIVER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_HMIC_TO_HEADSET_L(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_HMIC_TO_HEADSET_R(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_HMIC_PCM_RECEIVER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_HMIC_TO_SPEAKER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_HMIC_TO_RECEIVER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BMIC_TO_HEADSET_L(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BMIC_TO_HEADSET_R(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_HEADSET_L(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_HEADSET_R(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BMIC_WAV_SPEAKER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BMIC_WAV_RECEIVER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_FM_TO_SPEAKER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_FM_RADIO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_FM_TO_HEADSET_L(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_FM_TO_HEADSET_R(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_SET_FM_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_INIT_SETTING(VOID){ return dwResult; }
//	virtual	INT TEST_CAMERA_READ_IMAGE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_GET_POSITION_POINT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_COLOR_DELTAE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_MACRO_MTF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_NORMAL_MTF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_INFINITE_MTF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_CONTRAST(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_LUMINANCE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_LENS_SHADING(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_COLOR_SHADING(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_DARK_PIXELS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_WHITE_PIXELS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_ROTATE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_BLEMISH_PIXELS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CAMERA_DEFECT_PIXELS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT DISABLE_CHARGING(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT DELTA_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }	
//	virtual	INT ENABLE_CHARGING(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }	
//
//	virtual	INT TEST_LENS_SHADING(CAMERA_PARAMETERS &stCameraParam){ return dwResult; }
//	virtual	INT TEST_COLOR_SHADING(CAMERA_PARAMETERS &stCameraParam){ return dwResult; }
//	virtual	INT TEST_AUTO_WHITE_BALANCE(CAMERA_PARAMETERS &stCameraParam){ return dwResult; }
//	virtual	INT TEST_BLEMISH_DETECT(CAMERA_PARAMETERS &stCameraParam){ return dwResult; }
//	virtual	INT TEST_DEFECT_DETECT(CAMERA_PARAMETERS &stCameraParam){ return dwResult; }
//	virtual	INT TEST_COLOR_DELTAE(CAMERA_PARAMETERS &stCameraParam){ return dwResult; }
//	virtual	INT TEST_ROTATE_IMAGE(CAMERA_PARAMETERS &stCameraParam){ return dwResult; }
//
//	virtual	INT TEST_LIGHT_SENSOR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_RESETFTM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_READ_GPS_MESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_SYSTEM_SUSPEND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//    virtual	INT TEST_CHARGE_ENABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BT_MODULE_MOUNT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_WIFI_MODULE_MOUNT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_READ_BATTERY_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_READ_BATTERY_CAPACITY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_KEYPAD_BACKLIGHT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_ONBOARD_LED_RED(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_ONBOARD_LED_GREEN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_ONBOARD_LED_BLUE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BACKLIGHT_ON(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BACKLIGHT_OFF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_GSENSOR_ID(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT GSENSOR_CALIBRATION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_GSENSOR_XYZ(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_BTMACADDRESS_ID(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_BOOT_VER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_MODEMIMAGE_VER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_POWER_ON_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT CHANG_WIRELESS_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_BACKUP_QCN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	//GPS Test Item
//	virtual INT TEST_GPS_OPEN_COM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CLOSE_COM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_DET_BAUDRATE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_NMEA_To_BINARY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_INIT_DATA_SOURCE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_SWICTH_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_PARSER_SIRF_BINARY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_SATELLITE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_PERIOD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_CN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_CLOCK_DRIFT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_CLOCK_OFFSET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_1KHZ(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_I_SIGNAL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_Q_SIGNAL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; } 
//	virtual INT TEST_GPS_CHECK_PHASE_ERROR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_CHECK_RTC_FREQUENCY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_FACTORY_RESET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SDCARD_DETECT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_SDCARD_SELFTEST(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_DUT_RESET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GPS_DC_TURN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	
//	// for G-Sensor and E-Compass
//	virtual INT TEST_GSENSOR_ENABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GSENSOR_DISABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GSENSOR_CAL_ENABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GSENSOR_CAL_DISABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GSENSOR_READ_VALUE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GSENSOR_READ_RAW_DATA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_GSENSOR_READ_INFO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_ENABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_DISABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_CAL_ENABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_CAL_DISABLE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_READ_VALUE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_READ_RAW_DATA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_READ_HEADING(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT TEST_ECOMPASS_READ_INFO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	// for example (FTM or Factory Test Mode)
//	// TEST_FACTORY_TEST_MODE	WRITE, 1
//	// TEST_FACTORY_TEST_MODE	READ
//	virtual INT TEST_FACTORY_TEST_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_INSTALL_FILE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_UNINSTALL_FILE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SEND_COMMAND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_COMMAND_WRITE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT TEST_ITEM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT TEST_READ_DELTA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SEND_COMMAND_WIFI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SEND_AND_CHECK_COMMAND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }	
//	virtual INT TEST_SEND_COMMAND_DOS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT COMPORT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }	
//	virtual INT TEST_READ_PEAK_POWER_AVERAGE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT TEST_SEND_COMMAND_DOS1(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SEND_COMMAND_DOS2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_6LOWPAN_NETWORK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//    virtual INT DUT_BLE_WRITE_CAL_VALUE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT DUT_BLE_READ_CAL_VALUE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	// for example
//	// TEST_CLEAR	ANDROID
//	// TEST_CLEAR	XXX_FILE	
//	virtual INT TEST_CLEAR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_WRITE_NVRAM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SET_CHARGER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_COPY_FILE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SET_FAKE_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_SENSOR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_READ_ZIGBEE_ADDRESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_DOWNLOAD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_TEMPERATURE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_HUMIDITY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_APPEND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TEST_GET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT CHECK_BATTERY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	// PPS, Calibration and RF Test Item
//	virtual INT	TEST_CHANGE_STATION_ID(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_INIT_CH2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_VOLTAGE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_ON(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_OFF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_ON_CH2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	PPS_OFF_CH2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	RRT_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	RRT_SET_CALL_PARAMETERS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_RRT_CLEAR_CALLSTATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT MAKE_PHONE_CALL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	
//	//Calibration
//	virtual INT DUT_CHECK_CONN(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	DUT_SET_ONLINE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	DUT_SET_TEST_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	GSM_CAL_RX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT GSM_CAL_THERMISTOR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	GSM_CAL_ALL_ITEM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	RF_WRITE_NV_DATA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	CHECK_LED_ON(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	virtual INT GSM_CAL_CARRIER_SUPPRESSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WCDMA_CAL_RX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WCDMA_CAL_AUTO_DC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT GSM_CAL_PHASE_DELAY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT RF_RELOAD_NV_ITEM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	GSM_CAL_TX_POLAR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult;}
//	virtual INT	WCDMA_CAL_TX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult;}
//	virtual INT	GSM_CAL_VCO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult;}
//
//	virtual INT GSM_RRT_CAL_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT WCDMA_RRT_CAL_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	virtual	INT WCDMA_CAL_TXRX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	WRITE_NV_TO_PHONE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//    //CURRENT TEST
//	virtual INT TEST_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	//WCDMA RF non-signaling test
//	virtual INT WBT_RELEASE_FASTCALL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	START_WCDMA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_RRT_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_MAX_OUTPUT_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_CHANGE_BAND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_SETUP_RRT_DEVICE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_MIN_OUTPUT_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_OPEN_LOOP_POWER_CONTROL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_INNER_LOOP_POWER_CONTROL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_SPECTRUM_EMISSION_MASK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_ACLR_POWER_RATIO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_OBW(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_SPURIOUS_EMISSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_CHANGE_TX_CHANNEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_MODULATION_ACCURACY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_CPICHRSCP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_REFERENCE_SENSITIVITY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_MAX_INPUT_LEVEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	WCDMA_SETTING_CHANNEL_by_BAND(E_BAND iBand){ return dwResult; }
//	virtual INT WBT_JudgeChannelString(E_BAND iBand, int iChannel){ return dwResult; }
//	virtual INT WBT_SETUP_FASTCALL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WBT_PCDE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	
//	//HSDPA RF signaling test by mzlin 20090702 start
//	virtual INT DPA_SETUP_FASTCALL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT START_HSDPA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_SETUP_RRT_DEVICE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_MAX_OUTPUT_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_SPECTRUM_EMISSION_MASK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_ACLR_POWER_RATIO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_OBW(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_EVM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_RCDPA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_REFERENCE_SENSITIVITY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_MAX_INPUT_LEVEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DPA_CHANGE_TX_CHANNEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT DPA_CHANGE_HSHSET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT DPA_RRT_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	//mzlin 20090702 end
//
//	//TDSCDMA RF signaling test by mzlin 20090702 start
//	virtual INT TDSCDMA_CHANGE_BAND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_CHANGE_CHANNEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT	START_TDSCDMA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_SETUP_RRT_DEVICE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT TDSCDMA_SWP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_CONF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_MAX_OUTPUT_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_SPECTRUM_EMISSION_MASK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_ACLR_POWER_RATIO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	TDSCDMA_OBW(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	TDSCDMA_TRANSMIT_ON_OFF_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	TDSCDMA_EVM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	TDSCDMA_PCDE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_MIN_OUTPUT_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_REFERENCE_SENSITIVITY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_FREQERR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_MAX_INPUT_LEVEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_CLOSED_LOOP_POWER_CONTROL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual INT TDSCDMA_HSDPA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TDSCDMA_TPUT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	//mzlin 20090702 end
//	virtual INT	ADB_CMD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	//GSM RF non-signaling test
//	virtual INT RFTEST_INIT_INSTRUMENT(VOID){ return dwResult; }
//	virtual INT START_GSM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT ParseRFTestINIFile(VOID){ return dwResult; }
//	virtual INT ParseSpecFile(VOID){ return dwResult; }
//	virtual INT ParseDviFile(VOID){ return dwResult; }
//	virtual INT EG_JudgeSystemType(char* cSysType){ return dwResult; }
//	virtual INT Round(double input_DAC){ return dwResult; }
//	virtual INT GSM_SETUP_FASTCALL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT GSM_RELEASE_FASTCALL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DUT_GSM_SET_CONNECT_FAST_CALL(FTM_GSM_BER_Band_Enum nNewMode){ return dwResult; }
//
//	virtual INT BSPOWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT GSM850_B(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT GSM850_T(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT EGSM_B(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT EGSM_T(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DCS_B(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT DCS_T(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT PCS_B(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT PCS_T(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT CHANNEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT CHANNEL_B(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT TXLEVEL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT WAITING(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT Test_TXP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	RFTest_Check_TXP(VOID){ return dwResult; }
//	virtual INT	RFTest_TXP(VOID){ return dwResult; }
//	virtual INT Test_PVT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT RFTest_PVT(VOID){ return dwResult; }
//	virtual INT RFTest_Check_PVT(VOID){ return dwResult; }
//	virtual INT Test_ORFS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT RFTest_ORFS(VOID){ return dwResult; }
//	virtual INT RFTest_Check_ORFS(VOID){ return dwResult; }
//	virtual INT Test_PFER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT RFTest_PFER(VOID){ return dwResult; }
//	virtual INT RFTest_Check_PFER(VOID){ return dwResult; }
//	virtual INT Test_FBER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT RFTest_FBER(VOID){ return dwResult; }
//	virtual INT RFTest_Check_FBER(VOID){ return dwResult; }
//	virtual INT Test_RSSI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	RFTest_Check_RSSI(VOID){ return dwResult; }
//	virtual INT DUT_HANDOVER(FTM_GSM_BER_Band_Enum nNewMode){ return dwResult; }
//	virtual INT CalculateOFRSindBm(VOID){ return dwResult; }
//
//	virtual INT	RFTest_SaveTXPLog(VOID){ return dwResult; }
//	virtual INT	RFTest_SavePVTLog(VOID){ return dwResult; }
//	virtual INT	RFTest_SaveORFSLog(VOID){ return dwResult; }
//	virtual INT	RFTest_SavePFERLog(VOID){ return dwResult; }
//	virtual INT	RFTest_SaveFBERLog(BOOL b_FBERPASS){ return dwResult; }
//	virtual INT	RFTest_SaveRSSILog(VOID){ return dwResult; }
//
//	//************************* for EDGE *****************************//
//	virtual INT RFTEST_INIT_INSTRUMENT_EDGE(VOID){ return dwResult; }
//	virtual INT DUT_EDGE_SET_CONNECT_FAST_CALL(FTM_GSM_BER_Band_Enum nNewMode){ return dwResult; }
//	virtual INT Test_ETXP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	RFTest_Check_ETXP(VOID){ return dwResult; }
//	virtual INT Test_EPVT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	RFTest_Check_EPVT(VOID){ return dwResult; }
//	virtual INT Test_EMAC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	RFTest_EMAC(VOID){ return dwResult; }
//	virtual INT	RFTest_Check_EMAC(VOID){ return dwResult; }
//	virtual INT Test_EORFS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual INT	RFTest_Check_EORFS(VOID){ return dwResult; }
//
//	virtual INT	RFTest_SaveETXPLog(VOID){ return dwResult; }
//	virtual INT	RFTest_SaveEPVTLog(VOID){ return dwResult; }
//	virtual INT	RFTest_SaveEMACLog(VOID){ return dwResult; }
//	virtual INT	RFTest_SaveEORFSLog(VOID){ return dwResult; }
//
//	virtual INT TEST_HANDOVER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	//NI 6518 & NI 6281
//	virtual INT	TEST_NI_INIT_DEVICE(VOID) { return dwResult; }
//	virtual INT	TEST_NI_UNINIT_DEVICE(VOID) { return dwResult; }
//	virtual INT	TEST_6518_LOAD_DUT(VOID) { return dwResult; }
//	virtual INT	TEST_6518_UNLOAD_DUT(VOID) { return dwResult; }
//	virtual INT	TEST_6518_ASCEND_MIC(VOID) { return dwResult; }
//	virtual INT	TEST_6518_DESCEND_MIC(VOID) { return dwResult; }
//	virtual INT	TEST_6518_LOAD_10_CM_MTF(VOID) { return dwResult; }
//	virtual INT	TEST_6518_LOAD_COLLIMATE(VOID) { return dwResult; }
//	virtual INT	TEST_6518_LOAD_WHITE_BOARD(VOID) { return dwResult; }
//	virtual INT	TEST_6518_LOAD_BLACK_BOARD(VOID) { return dwResult; }
//	virtual INT	TEST_6281_STEPPED_SWEEP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_1K(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_MOUTH_PLAY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_MIC_RECEIVE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_ANALYSIS_TDMS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_MIC_RECEIVE_SPK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_ANALYSIS_TDMS_SPK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_MIC_RECEIVE_REC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_ANALYSIS_TDMS_REC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_MIC_RECEIVE_MIC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_6281_ANALYSIS_TDMS_MIC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	/**********		Start -- GPS FTM Virtual Functions		**********/
//	virtual	INT	TEST_GPS_EFS_DELETE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	/**********		End -- GPS FTM Virtual Functions		**********/
//	//For Diesel OTP
//    virtual	INT TEST_OTP_ACTIVE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_OTP_READ_ID(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_OTP_INACTIVE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_WAIT_FOR_JACKET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_WRITE_DATA(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	
//	//QUALCOMM QLIB API
//	virtual INT	TEST_QCOM_SET_LIB_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_GET_PHONE_PORT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_CONNECT_SERVER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_CHANGE_SYS_STATE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_FTM_AUDIO_SET_PATH(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_FTM_AUDIO_SET_VOLUME(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_FTM_AUDIO_TONES_PLAY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_FTM_AUDIO_TONES_STOP(VOID) { return dwResult; }
//	virtual INT	TEST_QCOM_PLAY_DUT_TONE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_DUT_RECORD_TONE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//	virtual INT	TEST_QCOM_TAKE_PICTURE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest) { return dwResult; }
//
//	//For Diesel 
//    virtual	INT TEST_TOUCH(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_CHECK_SPI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_CHECK_PCM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_ENTER_SLEEP_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_READ_SNOR_VER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_FM_ANT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_LED(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_CAMIF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_MODIF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_SET_FM_FREQ(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_READ_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_DUT_BATTERY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_CONNECT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_POWER_ONOFF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//    virtual	INT TEST_PHONE_VER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_EBI2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_USB_VBUS_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_VBUS_VOLTAGE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_READ_VER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_CHECK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_CHECK_CONNECTION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_FTM_AUDIO_PATH(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_SET_SD_STATUS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_VBAT_MODU(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_VCC_MODIF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT TEST_READ_POWER_OFF_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual INT DUT_CHECK_ONLINE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	
//	//For Fish
//   
//	virtual	INT CHECK_BOOT_READY(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	virtual	INT SEND_CMD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT QERY_CMD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT QERY_UART_BP(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT MEAS_DMM_1(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT MEAS_DMM_2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	virtual	INT MEAS_FRQ_1(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT MEAS_FRQ_2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT MEAS_FRQ_3(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT MEAS_FRQ_4(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_PPS_1(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_PPS_2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_34903_1(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_34903_2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT WRITE_FROM_UI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT CMP_UI(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT CMP_SFIS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT ZIGBEE_DOWNLOAD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//    virtual	INT CHECK_CURRENT_RESULT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT ENTER_UBOOT_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT VOLT_PIEZO_SOUNDER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT CURR_S2R(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_SET_RESULT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_READ_FACTORY_CONFIG(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT GET_CONFIG_FROM_SFIS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//
//	virtual	INT QERY_CMD_AND_CHECK_RANGE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT ADC_PIR(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT GET_PPS_1(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT GET_PPS_2(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT QERY_UART_HU(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_PPS_1_OFF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_PPS_2_OFF(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_BOOT_INFO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT RECEIVE_CMD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_PPS_1_VOLT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_PPS_2_VOLT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT CACULATE_CURRENT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT WRITE_CB(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	//virtual	INT MEAS_DMM_I_1(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	virtual	INT TEST_READ_WIFI_MAC(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	//virtual	INT TEST_APPEND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	//virtual	INT TEST_CHECK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	//virtual	INT TEST_READ_ZIGBEE_ADDRESS(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	virtual	INT TEST_READ_VERSION(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	virtual	INT COM_COMMAND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	virtual	INT GET_PPS_VALUE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//
//	//FISH_CUR   
//	virtual	INT TEST_QUERY_COMMAND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT INIT_SPECTRUM(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT DUT_SET_WIFI_TEST_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_RRT_CENTER_FREQ(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT DUT_SET_WIFI_CH(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT DUT_SET_WIFI_TX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT DUT_SET_WIFI_TX_SUSPEND(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT READ_PEAK_POWER(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT DUT_SET_ZIGBEE_TEST_MODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT DUT_SET_ZIGBEE_CH(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT DUT_SET_ZIGBEE_TX(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_RRT_SWEET_TIME (CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT SET_RRT_REFERENCE_OFFSET (CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}	
//	
//	//For Sensor
//	virtual	INT SENSOR_TEST(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT GET_DUT_LOG(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT TEST_ADB_INIT(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT FIXTURE_CAL(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//
//	/**********		Start -- AOI  Virtual Functions	,Added By Eve Lee , 2009/04/06	**********/
//	virtual	INT	TEST_CAPTURE_IMAGEDEVICE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT	TEST_AOI_KEYPAD(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//    virtual	INT	TEST_AOI_TOP_LOGO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT	TEST_AOI_BOTTOM_LOGO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	/**********		End -- AOI  Virtual Functions		********/
//
//	virtual	INT TEST_WIFI_TESTMODE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT DUT_SET_ZIGBEE_RESET(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT DUT_READ_ZIGBEE_CHIP_ID(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT DUT_READ_ZIGBEE_COEX_GPIO(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT DUT_SET_CLK_OUT_TO_ZIGBEE_CLK_MON(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT DUT_SET_ZIGBEE_TRANSMIT_ON(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }	
//	virtual	INT DUT_SET_ZIGBEE_TRANSMIT_TONE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//
//	virtual	INT PIR_WIFI_ON_PEAK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT PIR_ZIGBEE_ON_PEAK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//	virtual	INT PIR_ON_PEAK(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){return dwResult;}
//
//	// BQ Accel Motor
//	virtual	INT TEST_MOTOR_HOME(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//	virtual	INT TEST_MONITOR_VN100(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
//};

class CVirtualInstrument
{

private:
	DWORD dwResult;
	CDebugMessage m_dbgmsg;

public:

	CVirtualInstrument(){};
	virtual ~CVirtualInstrument(){};

	// Common for PPS and RRT
	virtual INT	VISA32_SET_VI_SESSION(DWORD vi) { return dwResult; }
	virtual INT	VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable) { return dwResult; }
	virtual INT GPIB_WRITE(const char* command) { return dwResult; }
	virtual INT GPIB_QUERY(const char* command, char* returnVal) { return dwResult; }
	void AddOutput(COutputDebug* output);
	void RemoveOutput(COutputDebug* output);
	void OutputLog(const char* str);
	void OutputfLog(const char* fmt, ...);
	void OutputLog(const string& str);

	char                    m_szInstrumentName[100];
	
public: 
	virtual INT	PPS_SET_VOLTAGE(double dVoltage) { return dwResult; }
	virtual INT	PPS_SET_VOLTAGE_CH2(double dVoltage) { return dwResult; }
	virtual INT	PPS_SET_CURRENT(double dCurrentLimit) { return dwResult; }
	virtual INT	PPS_SET_CURRENT_CH2(double dCurrentLimit) { return dwResult; }
	virtual INT	PPS_GET_CURRENT(double *pdCurrent) { return dwResult; }
	virtual INT	PPS_GET_CURRENT_CH2(double *pdCurrent) { return dwResult; }
	virtual INT	PPS_SET_POWER_ON(VOID) { return dwResult; }
	virtual INT	PPS_SET_POWER_ON_CH2(VOID) { return dwResult; }
	virtual INT	PPS_SET_POWER_OFF(VOID) { return dwResult; }
	virtual INT	PPS_SET_POWER_OFF_CH2(VOID) { return dwResult; }
	virtual INT	PPS_GET_VOLTAGE(double *pdVoltage) { return dwResult; }
	virtual INT	PPS_GET_VOLTAGE_CH2(double *pdVoltage) { return dwResult; }
	
public:
	virtual INT	ROUTE_OPEN(INT iCH) { return dwResult; }
	virtual INT	ROUTE_CLOSE(INT iCH) { return dwResult; }

public:
	virtual INT SEND_RESET(VOID) { return dwResult; }
	virtual INT	SWITCH_FAST_SCREEN(BOOL bFast) { return dwResult; }

	virtual INT SELECT_VIEW(char* czView) { return dwResult; } 
	virtual INT END_CALL() { return dwResult; } 
	virtual INT SEND_OPC( int iRetryCount, int iRetryIdle ) { return dwResult; } 
	virtual INT QUERY_STD(char* czQueryResult) { return dwResult; } 
	virtual INT SET_CALL_PROCESSING_MODE( bool bStatus ) { return dwResult; } 

	virtual INT SET_RF_OUTPUT_SIGNAL_STATUS( bool bStatus ) { return dwResult; } 
	virtual INT SET_OUTPUT_MOD_SIGNAL_STATUS( bool bStatus ) { return dwResult; } 
	virtual INT GSM_OUTPUT_SIGNAL_PATTERN(const char* czPattern) { return dwResult; } 
	virtual INT GSM_SET_MEASUREMENT_STATUS(const char* czMeasurement, bool bStatus) { return dwResult; } 
	virtual INT SET_MEASUREMENT_MODE( bool bStatus ) { return dwResult; } 
	virtual INT GSM_SET_BIT_OFFSET(float fBitOfs) { return dwResult; } 
	virtual INT SET_SCREEN_DISPLAY( bool bStatus ) { return dwResult; } 
	virtual INT GSM_SET_POWER_MEASUREMENT_COUNT( int nCount ) { return dwResult; } 
	virtual INT GSM_SET_TRAINING_SEQUENCE( int nPattern ) { return dwResult; } 
	virtual INT GSM_SET_OPERATING_MODE( const char* czMode ) { return dwResult; } 
	virtual INT GSM_SET_MEASURMENT_OBJECT( const char* czObject ) { return dwResult; } 
	virtual INT GSM_SET_CABLE_LOSS( float fLoss, int iBand ) { return dwResult; } 
	virtual INT GSM_SET_CABLE_LOSS_STATUS( bool bStatus ) { return dwResult; } 
	//virtual INT GSM_SET_INPUT_LEVEL( float fInputLevel ) { return dwResult; } 
	virtual INT GSM_PREDISTQ_MEASURE( int nDuration, int iPeriods, int iStepLength ) { return dwResult; } 
	virtual INT GSM_PREDISTQ_MEASURE( int nDuration, int iPeriods, double fRatio ){ return dwResult; } 
	virtual INT GSM_PREDISTQ_GET_STATUS( char* pStatus ) { return dwResult; } 
	virtual INT GSM_PREDISTQ_GET_POWER( int iPeriods, char* pResult ) { return dwResult; } 

	virtual INT WCDMA_SET_OUTPUT_LEVEL_STATUS( bool bStatus ) { return dwResult; } 
	virtual INT WCDMA_SET_AWGN_OUTPUT_STATUS( bool bStatus ) { return dwResult; } 
	virtual INT SET_MEASUREMENT_STATUS(const char* czMeasurement, bool bStatus) { return dwResult; } 
	virtual INT WCDMA_SET_POWER_MEASUREMENT_AVERAGE_COUNT( int nCount ) { return dwResult; } 
	virtual INT WCDMA_SET_RF_SIGNAL_OUTPUT_CONNECTOR_TYPE( const char* czConnectorType ) { return dwResult; } 
	virtual INT WCDMA_SET_DL_FREQUENCY( double dFreq ) { return dwResult; } 
	virtual INT WCDMA_SET_OUTPUT_LEVEL( double dPower ) { return dwResult; } 
	virtual INT WCDMA_SET_AUX_CABLE_LOSS( double dLoss ) { return dwResult; } 
	virtual INT WCDMA_SET_AUX_CABLE_LOSS_STATUS( bool bStatus ) { return dwResult; } 
	virtual INT WCDMA_SET_DL_CABLE_LOSS( double dLoss ) { return dwResult; } 
	virtual INT WCDMA_SET_DL_CABLE_LOSS_STATUS( bool bStatus ) { return dwResult; } 
//	virtual INT GSM_SET_OUTPUT_LEVEL_STATUS( bool bStatus ) { return dwResult; } 
	virtual INT GSM_SET_OUTPUT_MOD_SIGNAL_STATUS( bool bStatus ) { return dwResult; } 
//	virtual INT GSM_OUTPUT_SIGNAL_PATTERN(const char* czPattern) { return dwResult; } 
	virtual INT WCDMA_SET_AM_STATUS(bool bStatus) { return dwResult; } ; 
	virtual INT WCDMA_CLOSE_ALL_MEASUREMENT(VOID)	{ return dwResult; } ;
	virtual INT SET_EXTERNAL_LOSS_TABLE(CHAR *cStandard, double dFrequency[], double dCableLoss[], INT num){ return dwResult; }

	virtual INT RESET(VOID) { return dwResult; }
	virtual INT QUERY_SW_VERSION(const int iStandardNumber, char* szSWVersion){ return dwResult; }
	virtual INT SET_POWER_COUNT(const int iPowerCount){ return dwResult; }
	virtual INT SET_INSTRUMENT_MODE(const char* szBand,/*const char* szMeasureObj,*/bool bUSFBlockERR ){ return dwResult; }
	virtual INT SET_CODE_SCHEME(const char* szCodeSchemeType, const int iCodeScheme){ return dwResult; } //MF
	virtual INT SET_RF_OUTPUT(const int iOutputConnector){ return dwResult; } 
	virtual INT SET_BIT_OFFSET( const int iBitOffsetType){ return dwResult; }
	virtual INT SET_ORFS_COUNT(const int iORFSMode, const int iCount){ return dwResult; }
	virtual INT SET_EXTURNAL_CABLE_LOSS(const int iDLULSelect, const int iBand, const int iCableLoss){ return dwResult; } 
	virtual INT EXT_LOSS_SWITCH(const bool bLossSwitch){ return dwResult; }
	//virtual INT SET_STD_SELECT(const char* szStd){ return dwResult; }
	virtual INT SCREEN_SWITCH(const bool bScreenSwitch){ return dwResult; }
	virtual INT SET_TRAINING_SEQUENCE(INT iTSC){ return dwResult; }
	virtual INT SET_INPUT_POWER_LEL( double fIL){ return dwResult; }
	virtual INT SET_SYNCHRONOUS_SINGLE_SWEEP(VOID){ return dwResult; }
	virtual INT QUERY_SWP_STATUS(char* szSWPstatus){ return dwResult; } 

	virtual INT QUERY_MEASUREMENT_STATUS(const int iQuaryRFPath, char* szRFStatus){ return dwResult; }
	virtual INT QUERY_ALL_MEASURE_RESULT(const char* szQueryItem, char* szQueryResult){ return dwResult; } 
	virtual INT	GSM_CAL_INIT(VOID) { return dwResult; }
	virtual INT	GSM_CAL_RX_INIT(VOID) { return dwResult; }
	virtual INT GSM_CAL_SET_BAND(int iBand) { return dwResult; }
	virtual INT GSM_CAL_SET_CH(int iCCH, int iTCH) { return dwResult; }
	virtual INT GSM_CAL_SET_FREQ(int isel, double dFreq) { return dwResult; }
	virtual INT GSM_CAL_IM2_INIT(VOID) { return dwResult; }
	virtual INT GSM_CAL_IM2_UNINIT(VOID) { return dwResult; }
	virtual INT GSM_SET_LEVEL(int isel, double level) { return dwResult; }
	virtual INT GSM_SET_POWER_LEVEL(int isel, double level) { return dwResult; }
	virtual INT GSM_CAL_SYNC_SINGLE_MODE(int iDuration,int iNum, double dRatio) { return dwResult; }
	virtual INT GSM_CAL_PREDISTQ_POWER(char *cPower,int iPREDISTQ_No) { return dwResult; }
	virtual INT GSM_CAL_PREDISTQ_PHASE(char *cPhase,int iPREDISTQ_No) { return dwResult; }
	virtual INT GSM_CAL_PRESET_DEVICE(VOID) { return dwResult; }
	virtual INT GSM_CAL_POLAR_INIT(VOID){ return dwResult;}
	virtual INT GSM_CAL_CS_INIT(VOID){ return dwResult;}
	virtual INT GSM_CAL_PHASEDELAY_INIT(const int iCount){ return dwResult;}
	virtual INT WCDMA_CAL_RX_INIT(VOID){ return dwResult;}
	virtual INT	GSM_SET_EXTERNAL_LOSS_TABLE(double dFrequency[], double dCableLoss[], INT num){ return dwResult; }
	virtual INT CLOSE_ALL_MEASUREMENT(VOID){ return dwResult; }
	virtual INT SET_STANDARD_SELECT(CHAR *cStandard){ return dwResult; }
	virtual INT WB_ANT8820_RESET(VOID){ return dwResult; }
	virtual INT WCDMA_MEAS_AVG_PWR(double dILVL, double *dPower){ return dwResult; }
	virtual INT WCDMA_SET_CABLE_LOSS_STATUS(char *cSTATUS){ return dwResult; }
	virtual INT WCDMA_SET_UL_CHAN(int iCH){ return dwResult; }
	virtual INT	WCDMA_GET_SWP_PWR(int iSTEP,char *cPower){ return dwResult; }
	virtual INT WCDMA_MEAS_SWP_PWR(void){ return dwResult; }
	virtual INT WCDMA_SWP_PWR_SET(int iSTEP, int iNUM, int iTimeout){ return dwResult; }
	virtual INT GSM_CAL_FREQ_EOR_AVG(char *szBuf){ return dwResult; }
	virtual INT GSM_CAL_VCO_INIT(VOID){ return dwResult; }
	virtual INT WB_SET_INPUT_LEVEL(double fPower){ return dwResult; }
	virtual INT BAND_CALIBRATION(VOID){ return dwResult; }

	//add to 53131 command by Allen
	virtual INT READ_FREQUENCY_MHz(INT iCH, double *dMin, double *dMax, double *dAve, double *dSDev, INT iCount, double dGateTime = 0.1, INT iSleepTime = 1000){ return dwResult; }
	virtual INT READ_FREQUENCY_MHz_WITH_FILTER(INT iCH, double *dMin, double *dMax, double *dAve, double *dSDev, INT iCount, double dGateTime = 0.1, INT iSleepTime = 1000){ return dwResult; }

	//add to 34970 command by Allen
	virtual INT READ_VALUE(INT iCH, double *pdVale, FLOAT fIntervalTime=0.01, INT iFetchCount=10){ return dwResult; }
	virtual INT READ_VALUE_MIN(INT iCH, double *pdVale, FLOAT fIntervalTime=0.01, INT iFetchCount=10){ return dwResult; }
	virtual INT READ_LAST_VALUE(INT iCH, double *pdVale, INT iLastNumCount){ return dwResult; }
	virtual INT READ_RESISTANCE(INT iCH, double *pdRes, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	virtual INT READ_RESISTANCE_4W(INT iCH, double *pdRes, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	virtual INT READ_DC_VOLTAGE(INT iCH, double *pdDCVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	virtual INT READ_AC_VOLTAGE(INT iCH, double *pdACVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	virtual INT READ_DC_CURRENT(INT iCH, double *pdDCVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	virtual INT READ_AC_CURRENT(INT iCH, double *pdACVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	virtual INT READ_FREQUENCY(INT iCH, double *pdFreq, FLOAT fIntervalTime=0.01, INT iFetchCount=1){ return dwResult; }
	virtual INT PRESET(VOID){ return dwResult; }
	virtual INT SET_DMM_MEAS_PARA(INT iMeasType, CHAR* cRange, CHAR* cResolution, CHAR* cIntegrationTime, CHAR* cLFF, CHAR* cO_COMP, CHAR* cAutozero, double dCHDelay=0.001, INT iAvgCount=5){ return dwResult; }
	


	//add to 3458A command by Allen
	// virtual INT READ_DC_VOLTAGE(double *pdDCVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	// virtual INT READ_AC_VOLTAGE(double *pdACVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	// virtual INT READ_DC_CURRENT(double *pdDCVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	// virtual INT READ_AC_CURRENT(double *pdACVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50){ return dwResult; }
	// virtual INT SET_DMM_MEAS_PARA_3(INT iMeasType, CHAR* cRange, CHAR* cResolution, CHAR* cIntegrationTime, CHAR* cLFF, CHAR* cO_COMP, CHAR* cAutozero, double dCHDelay=0.001, INT iAvgCount=5){ return dwResult; }

	//WCDMA RF non-signaling test
	virtual INT SendOPC(VOID){ return dwResult; }
	virtual INT WB_SET_OUTPUT_LEVEL(double dPower){ return dwResult; }
	virtual INT WB_SET_CHANNEL(INT nDownlink, INT nUplink){ return dwResult; }
	virtual INT WB_SET_DOWNLINK_SCRAMBLING_CODES( INT nPrimary, INT nDPCHSecondary ){ return dwResult; }
	virtual INT WB_SET_TPC_PATTERN( char *cPatternType) { return dwResult; }
	virtual INT WB_SET_PHYSICAL_CHANNEL( char *eChannel, INT nChannelisationCode, INT nSymbolRate, INT nTimingOffset ){ return dwResult; }
	virtual INT SET_ALL_FUNDAMENTAL_MEASUREMENT_ITEMS_OFF(VOID){ return dwResult; }
	virtual INT Reset_Cable_Loss(VOID){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_POWER(CHAR *cAvgPower){ return dwResult; }
	virtual INT WB_SET_INSTRUMENT_MODE(CONST CHAR *in_psMode){ return dwResult; }
	virtual INT Set_Power_Measurement_Count(INT nCount){ return dwResult; }
	virtual INT WB_SET_FUNDAMENTAL_MEASUREMENT(char *selectScr){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_SEM(CHAR *cSEM){ return dwResult; }
	virtual INT WB_GET_FILTER_MEASUREMENT_POWER(CHAR *cAvgPower){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_ACLR(CHAR *cLow_5_MHZ,CHAR *cLow_10_MHZ,CHAR *cUp_5_MHZ,CHAR *cUp_10_MHZ){ return dwResult; }
	virtual INT WCDMA_SET_MEASUREMENT_CONDITION(const char* czMeasurement, bool bStatus, int avgcount){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_BER(CHAR *cPercent){ return dwResult; }
	virtual INT WB_SET_TRANSMISSION_POWER_CONTROL(CHAR *cPattern, INT nStepSize, INT nAlgorithm ){ return dwResult; }
	virtual INT WB_Setup_Call_Condition(int ChannelizationCode){ return dwResult; }
	virtual INT WB_SET_DATA_PATTERN(CHAR *eDTCHPattern){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_EVM(CHAR *cEVM){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_FREQUENCY_ERROR(CHAR *cFreqErr){ return dwResult; }
	virtual INT WB_GET_MEASURED_IQ_ERROR(double *pdOffset, double *pdImbalance){ return dwResult; }
	virtual INT WB_SET_SLOT_POWER_MEASUREMENT(double dTimeSpan, INT nStartSlotList, INT nEndSlotList, double dThreshold_Level){ return dwResult; }
	virtual INT WB_SET_TRIGGER(CHAR *cMode, double dDelay){ return dwResult; }
	virtual INT WB_GET_SLOT_POWER(double *pdPowerArray, INT nNumberOfSlots){ return dwResult; }
	virtual INT WB_SET_TRIGGER_START_AND_DURATION(double SLOT_START_TIME, double SLOT_DURATION_TIME){ return dwResult; }
	virtual INT WB_SET_MEASUREMENT_INNER_LOOP_POWER(const char* csSegment, int Number_ofSlots,int TPC_Step, double Start_Power,double Stop_Power, int Algorithm){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_OBW(CHAR *cAvgPower){ return dwResult; }
	virtual INT WB_SET_ILPC_CONDITION_ON(VOID){ return dwResult; }
	virtual INT WB_GET_MEASUREMENT_INNER_LOOP_POWER(CHAR *slot_list){ return dwResult; }

	//GSM RF non-signaling test
	virtual INT SET_POWER(INT nCount, INT nTimeOut){ return dwResult; }
	virtual INT SET_PVT(INT nCount, INT nTimeOut){ return dwResult; }
	virtual INT SET_PFER(INT nCount, INT nTimeOut){ return dwResult; }
	virtual INT SET_FBER(INT nCount, INT nTimeOut){ return dwResult; }
	virtual INT SET_ORFS(INT iModCount, INT iSWCount, INT nTimeOut){ return dwResult; }
	virtual INT EG_SET_INSTRUMENT_MODE(INT iOperateMode){ return dwResult; }
	virtual INT SET_SYSTEM_COMBINATION(CONST CHAR *cSyscmb){ return dwResult; }
	virtual INT SET_BCH_ARFCn(UINT arfcn){ return dwResult; }
	virtual INT SET_TCH_BAND( CONST CHAR in_sBand[]){ return dwResult; }
	virtual INT SET_TCH_ARFCn(const UINT in_uiARFCn){ return dwResult; }
	virtual INT SET_EXP_POWER_LEVEL(INT iPowerLevel, E_BAND iBand){ return dwResult; }
	virtual INT SET_TCH_TIME_SLOT(UINT timeslot){ return dwResult; }
	virtual INT AFC_Fetch_Freq_Error(CHAR *cReturn){ return dwResult; }
	virtual INT SET_CELL_POWER(double fPower){ return dwResult; }
	virtual INT FETCH_POWER_INIT_DONE(char *out_psResult){ return dwResult; }
	virtual INT FETCH_POWER( CHAR *out_psResult){ return dwResult; }
	virtual INT SET_END_ETXP(VOID){ return dwResult; }
	virtual INT INIT_TX_POWER(VOID){ return dwResult; }
	virtual INT SET_END_TXP(VOID){ return dwResult; }
	virtual INT SET_PDTCH_BAND(const char in_sBand[]){ return dwResult; }
	virtual INT SET_PDTCH_CHANNEL(UINT arfcn){ return dwResult; }
	virtual INT SET_PDTCH_MS_TX_LEVEL(const UINT Device_in_uiTxLevel){ return dwResult; }
	virtual INT SET_PCS_PVT(VOID){ return dwResult; }
	//virtual INT INIT_PVT(VOID){ return dwResult; }
	virtual INT PVT_MEASUREMENT(BOOL &bMaskOK, CHAR *cPVT_Result, CHAR *cPvtTimeOffset){ return dwResult; }
	virtual INT SET_END_PVT(VOID){ return dwResult; }
	virtual INT INIT_ORFS(VOID){ return dwResult; }
	virtual INT RFTest_Check_ORFS(VOID){ return dwResult; }
	virtual INT ORFS_MEASUREMENT(CHAR *cSW_Result, CHAR *cMOD_Result, CHAR *cOrfsSwFreqOffset, CHAR *cOrfsModFreqOffset){ return dwResult; }
	virtual INT FETCH_ORFS_30KHz_BW_POWER(CHAR *out_psResult){ return dwResult; }
	virtual INT SET_END_ORFS(VOID){ return dwResult; }
	virtual INT FETCH_PFER( CHAR *out_psResult){ return dwResult; }
	virtual INT FETCH_PEAKPH( CHAR *out_psResult){ return dwResult; }
	virtual INT FETCH_RMSPH( CHAR *out_psResult){ return dwResult; }
	virtual INT SET_END_PFER(VOID){ return dwResult; }
	virtual INT SET_END_EMAC(VOID){ return dwResult; }
	virtual INT INIT_FREQ_ERROR(VOID){ return dwResult; }
	virtual INT INIT_EMAC(VOID){ return dwResult; }
	virtual INT SET_INIT_FBER(VOID){ return dwResult; }
	virtual INT FETCH_FBER( CHAR *out_psResult){ return dwResult; }
	virtual INT SET_END_FBER(VOID){return dwResult; }
	virtual INT FETCH_RSSI(CHAR *out_psRxQ, CHAR *out_psRxL){return dwResult; }

	//******************* EDGE non-signaling test ******************
	virtual INT SET_EDGE_CODE_SCHEME(char *in_pSchemeSetting){return dwResult; }
	virtual INT SET_PVT_TIME_OFFSET(char *cPvtTimeOffset){return dwResult; }
	virtual INT SET_ORFS_MOD_FREQ_OFFSET(char *cOrfsFreqOffset){return dwResult; }
	virtual INT SET_ORFS_SWIT_FREQ_OFFSET(char *cOrfsFreqOffset){return dwResult; }
	virtual INT SET_ETXP(int nCount, int nTimeOut){return dwResult; }
	virtual INT SET_EMAC(int nCount, int nTimeOut){return dwResult; }
	//virtual INT SET_ORFS(int iModCount, int iSWCount, int nTimeOut){return dwResult; }
	virtual INT SET_BLER(INT nCount, INT nTimeOut){return dwResult; }
	virtual INT SET_CELL_POWER_STATE_OFF(VOID){return dwResult; }
	virtual INT SET_CeELL_POWER_STATE_ON(VOID){return dwResult; }

	virtual INT INIT_ETXP(VOID){return dwResult; }
	virtual INT FETCH_ETXP(char *out_psResult){return dwResult; }
	virtual INT CALL_TEST_FETCH(const char* in_psCommand, char *out_psResult){return dwResult; }
	//virtual INT SET_END_ETXP(VOID){return dwResult; }
	virtual INT INIT_PVT(VOID){return dwResult; }
	virtual INT FETCH_PEAK_EVM(CHAR *out_psResult){return dwResult; }
	virtual INT FETCH_RMS_EVM(CHAR *out_psResult){return dwResult; }
	virtual INT FETCH_95th_EVM(CHAR *out_psResult){return dwResult; }


	virtual INT WAIT_for_MEASUREMENT_COMPLETE(char *cTestItem){return dwResult; }
	virtual INT INSTRUMENT_CALIBRATION(VOID){ return dwResult; }

	/**********		Start -- RRT Virtual Functions		**********/
	//	Common Functions
	virtual INT RRT_RESET(VOID){ return dwResult; }
	virtual INT RRT_FULL_CALIBRATION(VOID){ return dwResult; }
	virtual INT RRT_BAND_CALIBRATION(VOID){ return dwResult; }
	virtual	INT RRT_QUERY_CALIB_DATE(CHAR* cValue){ return dwResult; }
	virtual	INT RRT_SET_CALIB_DATE(VOID){ return dwResult; }
	virtual	INT RRT_QUERY_SYS_DATE(CHAR* cValue){ return dwResult; }
	virtual	INT RRT_QUERY_SYS_TIME(CHAR* cValue){ return dwResult; }
	virtual	INT RRT_SET_SYS_DATE(VOID){ return dwResult; }
	virtual	INT RRT_SET_SYS_TIME(VOID){ return dwResult; }
	virtual	INT RRT_SWITCH_FAST_SCREEN(BOOL bFastScreenOn){ return dwResult; }
	virtual	INT RRT_GPIB_LOG_ON(BOOL bLogOn){ return dwResult; }
	virtual	INT RRT_SEND_OPC(VOID){ return dwResult; }
	virtual	INT RRT_RESET_CABLELOSS(VOID){ return dwResult; }
	virtual	INT RRT_SET_CABLELOSS(double dLossFreq[], double dLossGain[], INT iLossCount){ return dwResult; }
	virtual	INT RRT_SET_CABLELOSS_STATE(CHAR* cState){ return dwResult; }
	virtual	INT RRT_SET_RF_CONNECTOR(INT iRFConnector){ return dwResult; }
	virtual	INT RRT_QUERY_CURR_APP(CHAR* cValue){ return dwResult; }
	virtual	INT RRT_SET_APP_SECADDR(INT iAddr, INT iOptIndex){ return dwResult; }
	virtual	INT RRT_QUERY_APP_SECADDR(CHAR *cAPPList){ return dwResult; }
	virtual	INT RRT_SELECT_APPLICATION(CHAR* cAppName){ return dwResult; }
	virtual	INT RRT_SELECT_SCREEN(CHAR* cScreenName){ return dwResult; }
	virtual	INT RRT_QUERY_SCREEN(CHAR* cValue){ return dwResult; }
	virtual	INT RRT_SET_MOCALL(VOID){ return dwResult; }
	virtual	INT RRT_SET_ENDCALL(VOID){ return dwResult; }
	virtual	INT RRT_QUERY_CALLSTATUS(CHAR* cStatus){ return dwResult; }
	virtual	INT RRT_SET_WB_SERVICE_TYPE(CHAR* cType){ return dwResult; }
	virtual	INT RRT_SET_WB_TESTLOOPMODE(CHAR* cMode){ return dwResult; }
	virtual	INT RRT_3GPP_PRESET(VOID){ return dwResult; }
	virtual INT	RRT_SET_HANDOVER_TARGET(INT iBandIndex){ return dwResult; }
	virtual INT RRT_SET_HANDOVER(VOID){ return dwResult; }
	virtual INT RRT_SET_HANDOVER_ALERT_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_HANDOVER_WAIT_ON(BOOL bMode){ return dwResult; }
	virtual	INT RRT_CLEAR_STATUS(VOID){ return dwResult; }
	virtual INT RRT_SET_NCC(INT iCode){ return dwResult; }
	virtual INT RRT_SET_BCC(INT iCode){ return dwResult; }
	virtual INT RRT_SET_LOOPBACK_ON(BOOL bLoopOn){ return dwResult; }
	virtual INT RRT_SET_LOOPBACK_TYPE(INT iLoopType){ return dwResult; }
	virtual INT RRT_SET_TIMESLOT(INT iSlotNumber){ return dwResult; }
	virtual INT RRT_SET_BITOFFSET(INT iBitOffsetType){ return dwResult; }
	virtual INT RRT_SET_FAST_MEASURE_MODE(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_RF_CONNECTOR_TYPE(CHAR* cType){ return dwResult; }
	virtual	INT RRT_QUERY_CALLSTATUS_V2(CHAR* cMode, INT iQueryType){ return dwResult; }

	//Add for Agilent E6601A
	virtual	INT RRT_QUERY_RFG_CALIB_DATE(CHAR* cValue){ return dwResult; }
	//	Setting Functions
	virtual INT RRT_SET_ALL_MEASURE_OFF(VOID){ return dwResult; }
	virtual INT RRT_SET_CALLPROCESS_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_MODULATION_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_OPERATION_MODE(INT iOpeMode){ return dwResult; }
	virtual INT RRT_SET_TSC(INT iTSC){ return dwResult; }
	virtual INT RRT_SET_BCH_BAND(INT iBandIndex){ return dwResult; }
	virtual INT RRT_SET_TCH_BAND(INT iBandIndex){ return dwResult; }
	virtual INT RRT_SET_BCH_ARFCN(INT iArfcn){ return dwResult; }
	virtual INT RRT_SET_TCH_ARFCN(INT iArfcn){ return dwResult; }
	virtual INT RRT_SET_BSPOWER(double dPowerLev){ return dwResult; }
	virtual	INT RRT_SET_BSPOWER_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_AUTO_EXPECTED_POWER(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_EXPECTED_POWER(INT iSlot, double dPowerLev){ return dwResult; }
	virtual INT RRT_SET_EXPECTED_POWER_LEVEL(INT iSlot, INT iPCL){ return dwResult; }
	virtual INT RRT_SET_SPEECH_SOURCE(CHAR* cSourceStr){ return dwResult; }
	virtual INT RRT_SET_CODE_SCHEME(CHAR* cCodeScheme){ return dwResult; }
	virtual INT RRT_SET_MODULATION_CONTROL_AUTO(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_MULTISLOT_CONFIG(INT iUpSlot, INT iDownSlot){ return dwResult; }
	virtual INT RRT_SET_MEASURE_OBJECT(INT iSlot, CHAR* cMeasObj){ return dwResult; }
	virtual INT RRT_SET_OUTPUT_PATTERN(CHAR* cPattern){ return dwResult; }
	virtual INT RRT_SET_RFG_FREQ_AUTO(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_RFG_FREQ(double dFreqMHz){ return dwResult; }
	virtual INT RRT_SET_RFG_BURSTTYPE(CHAR *cType){ return dwResult; }
	virtual INT RRT_SET_RFAN_FREQ_AUTO(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_RFAN_FREQ(double dFreqMHz){ return dwResult; }
	virtual INT RRT_SET_RFAN_ATTENUATION(INT iType){ return dwResult; }
	virtual INT RRT_SET_TPC_TYPE(INT iIndex, CHAR* cPattern){ return dwResult; }
	virtual INT RRT_SET_WB_TPC_PATTERN(CHAR* cPattern){ return dwResult; }
	virtual INT RRT_SET_WB_TPC_STEPSIZE(INT iStepsize){ return dwResult; }
	virtual INT RRT_SET_WB_TPC_ALGORITHM(INT iALG){ return dwResult; }
	virtual INT RRT_SET_WB_ACTIVATE_TPC_PATTERN(VOID){ return dwResult; }
	virtual INT RRT_SET_WB_CHANNEL(INT iDLChannel, INT iUPChannel){ return dwResult; }
	virtual INT RRT_SET_SPECTRUM_MONITOR_TRIGGER(CHAR* cMode){ return dwResult; }
	virtual INT RRT_SET_TDMEAS_TRIGGER(CHAR* cMode){ return dwResult; }
	virtual INT RRT_SET_TRIGGER(CHAR* cMode, CHAR *cSlope, double dThreshold){ return dwResult; }
	virtual INT RRT_SET_SPECTRUM_MONITOR_TRIGGER_DELAY(double dDelay_ms){ return dwResult; }
	virtual INT RRT_SET_TDMEAS_TRIGGER_DELAY(double dDelay_ms){ return dwResult; }
	virtual INT RRT_SET_TRIGGER_DELAY(double dDelay_ms){ return dwResult; }
	virtual INT RRT_SET_SLOTPOWER_STARTTIME(double dTime_us){ return dwResult; }
	virtual INT RRT_SET_SLOTPOWER_DURATION(double dTimeperiod_us){ return dwResult; }
	virtual INT RRT_SET_FASTPOWER_MEAS_MODE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_SLOTPOWER_MEAS_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_SLOTPOWER_MEASSLOT(INT iStartslot, INT iEndslot){ return dwResult; }
	virtual INT RRT_SET_SLOTPOWER_DEL_SLOT(INT iStartslot, INT iEndslot){ return dwResult; }
	virtual INT RRT_SET_SLOTPOWER_THRESHOLD(double dLevel){ return dwResult; }
	virtual INT RRT_SET_TDMEAS_TIMESPAN(double dTimespan_ms){return dwResult; }
	virtual INT RRT_SET_TDMEAS_RRC_FILTER_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_VIDEO_FILTER_LENGTH(double dLength_us){ return dwResult; }
	virtual INT RRT_SET_WB_DTCH_DATATYPE(CHAR* cType){ return dwResult; }
	virtual INT RRT_SET_WB_PRIMARY_SCRAMBING_CODE(INT iCode){ return dwResult; }
	virtual INT RRT_SET_WB_CPICH_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_CPICH_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_PRIMARY_CCPC_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_PRIMARY_CCPC_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_SECONDARY_CCPCH_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_SECONDARY_CCPCH_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_SCH_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_SCH_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_PICH_CODE(INT iCode){ return dwResult; }
	virtual INT RRT_SET_WB_PICH_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_PICH_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_DPCH_CHANNEL_TYPE(CHAR* cType){ return dwResult; }
	virtual INT RRT_SET_WB_DPCH_CODE(INT iCode){ return dwResult; }
	virtual INT RRT_SET_WB_DPCH_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_DPCH_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_DPCH_SACODE(INT iCode){ return dwResult; }
	virtual INT RRT_SET_WB_DPCH_DOWNLINK_SEC_SCRAMBLING_CODE(INT iCode){ return dwResult; }
	virtual INT RRT_SET_WB_DPCH_UPLINK_SCRAMBLING_CODE(INT iCode){ return dwResult; }
	virtual INT RRT_SET_WB_AICH_CODE(INT iCode){ return dwResult; }
	virtual INT RRT_SET_WB_AICH_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_AICH_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_UL_GAIN_FACTOR(INT iBetaC, INT iBetaD){ return dwResult; }
	virtual INT RRT_SET_WB_ULDPCH_GAIN_MODE(BOOL bIsAuto){ return dwResult; }
	virtual INT RRT_SET_DATA_CONNECTION_TYPE(CHAR* cType){ return dwResult; }
	virtual INT RRT_SET_WB_AUTH_KEY(CHAR* cKey){ return dwResult; }
	virtual INT RRT_SET_WB_MS_IMSI(CHAR* cIMSI){ return dwResult; }
	virtual INT RRT_SET_WB_AUTH_STATE_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_CELL_OFF(VOID){ return dwResult; }
	virtual INT RRT_SET_ACTIVE_SLOTPOWER_WINDOW(VOID){ return dwResult; }
	virtual INT RRT_SET_WB_ILPC_TPC_STEP(CHAR* cStep){ return dwResult; }
	virtual INT RRT_SET_WB_ILPC_TPC_COMMAND_LENGTH(CHAR *cStep, INT iLength){ return dwResult; }
	virtual INT RRT_SET_WB_ILPC_MAX_THRESHOLD(BOOL bAutoModeOn, double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_ILPC_MIN_THRESHOLD(BOOL bAutoModeOn, double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_AWGN_STATE_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_WB_AWGN_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_WB_AM_SIGNAL_ON(BOOL bModeON){ return dwResult; }
	virtual INT RRT_SET_EG_MS_IMSI(CHAR* cIMSI){ return dwResult; }
	virtual INT RRT_SET_EG_BAND_INDICATOR(BOOL bIsDCSIndicator){ return dwResult; }
	virtual INT RRT_QUERY_EG_BAND_INDICATOR(CHAR* cStatus){ return dwResult; }
	virtual INT RRT_QUERY_EG_REG_STATUS(VOID){ return dwResult; }
	virtual INT RRT_SET_WB_FREQ(BOOL bIsULFreq, double dFreqMHz){ return dwResult; }
	virtual	INT RRT_SET_WB_REG_TXRX_FREQ(INT iSeqNum, CHAR *cFreqstr){ return dwResult; }
	virtual INT RRT_SET_WB_REG_RX_PWR(CHAR *cRXPWr){ return dwResult; }
	virtual INT RRT_SET_WB_REG_TX_PWR(CHAR *cTXPWr){ return dwResult; }
	virtual INT RRT_SET_BSPOWER_CONTINUOUS(BOOL bContOn){ return dwResult; }
	virtual INT RRT_SET_UE_MEAS_REPORT_ON(BOOL bModeOn){ return dwResult; }

	//HSDPA start //mzlin 20090702
	virtual INT RRT_SET_DPA_CHANNEL_CODING(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_REGISTRATION_MODE(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_HSHSET(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_DPCH_OFFSET(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_FDD_TEST_DPCH_LEVEL(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_PHYSICAL_CHANNEL_LEVEL(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_DELTA_ACK(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_DELTA_NACK(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_DELTA_CQI(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_ACKNACK_REPETITION_FACTOR(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_CQI_FEEDBACK_CYCLE(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_CQI_REPETITION_FACTOR(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_BetaC_BetaD(INT iBetaC, INT iBetaD){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_DPA_MEASURE_OBJECT(CHAR* cMeasObj){ return dwResult; }//mzlin 20091204
	virtual INT RRT_SET_DPA_HSMA_ITEM(CHAR* cMeasItem){ return dwResult; }//mzlin 20091204

	virtual INT RRT_SET_DPA_CHANNEL(INT iDLChannel, INT iUPChannel){ return dwResult; }//mzlin 20091204
	virtual INT RRT_SET_DPA_8960_TCR_HANDOVER(VOID){ return dwResult; }//mzlin 20091204
	//HSDPA end //mzlin 20090702

	//TDSCDMA start //mzlin 20090702
	virtual INT RRT_SET_TDSCDMA_CHANNEL(INT iChannel){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_TDSCDMA_SWP(VOID){ return dwResult; }//mzlin 20090702
	virtual INT RRT_SET_TDSCDMA_CONF(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702

	virtual INT RRT_FETCH_TDSCDMA_ACLR(CHAR* cValueN16, CHAR* cValueN32, CHAR* cValueP16, CHAR* cValueP32){ return dwResult; }
	virtual INT RRT_FETCH_TDSCDMA_Transmit_OnOff_Power(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_TDSCDMA_PCDE(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_TDSCDMA_FREQ_ERR(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_TDSCDMA_CLPC(CHAR* cValueStep_B, CHAR* cValueStep_C, CHAR* cValueStep_D, CHAR* cValueStep_E, CHAR* cValueStep_F, CHAR* cValueStep_G){ return dwResult; }

	virtual INT RRT_SET_TDSCDMA_HS_DATA_RATE(RRT_PARAMETERS &stParameter){ return dwResult; }//mzlin 20090702
	virtual INT RRT_FETCH_TDSCDMA_TPUT(CHAR* cValue){ return dwResult; }
	//TDSCDMA end //mzlin 20090702

	//	Measurement Functions
	virtual INT RRT_SET_POWER_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_POWER_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_POWER_CONTINUOUS_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_INIT_TXP(VOID){ return dwResult; }
	virtual INT RRT_FETCH_TXP(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_TXP(VOID){ return dwResult; }
	virtual INT RRT_SET_PVT_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_PVT_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_PVT_CONTINUOUS_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_PVT_TIMEOFFSET(CHAR* cTimeoffset){ return dwResult; }
	virtual	INT RRT_SET_PVT_PCS_LIMIT(CHAR* cLimitMode){ return dwResult; }
	virtual	INT RRT_SET_PVT_BURST_SYNC_MODE(CHAR* cSyncMode){ return dwResult; }
	virtual INT RRT_SET_INIT_PVT(VOID){ return dwResult; }
	virtual INT RRT_FETCH_PVT(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_PVT(VOID){ return dwResult; }
	virtual INT RRT_SET_PFER_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_PFER_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_PFER_CONTINUOUS_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_INIT_PFER(VOID){ return dwResult; }
	virtual INT RRT_FETCH_FREQ_ERR(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_PEAK_PHASE_ERR(CHAR* cValue){return dwResult; }
	virtual INT RRT_FETCH_RMS_PHASE_ERR(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_PEAK_EVM(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_RMS_EVM(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_95TH(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_ORIGIN_OFFSET(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_PFER(VOID){ return dwResult; }
	virtual INT RRT_SET_ORFS_COUNT(INT iMod_Count, INT iSw_Count){ return dwResult; }
	virtual INT RRT_SET_ORFS_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_ORFS_CONTINUOUS_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_ORFS_FREQOFFSET(CHAR* cMod_Freq, CHAR* cSw_Freq){ return dwResult; }
	virtual INT RRT_SET_ORFS_FILTER_TYPE(CHAR* cType){ return dwResult; }
	virtual INT RRT_QUERY_ORFS_FILTER_TYPE(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_INIT_ORFS(VOID){ return dwResult; }
	virtual INT RRT_FETCH_ORFS(CHAR* cModResult, CHAR* cSwResult){ return dwResult; }
	virtual INT RRT_SET_END_ORFS(VOID){ return dwResult; }
	virtual INT RRT_FETCH_ORFS_30KHZ_BW_POWER(CHAR* cPower){ return dwResult; }
	virtual INT RRT_SET_FBER_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_FBER_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_FBER_CONTINUOUS_ON(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_INIT_FBER(VOID){ return dwResult; }
	virtual INT RRT_FETCH_FBER(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_FBER(VOID){ return dwResult; }
	virtual INT RRT_FBER_TEST_SETUP(INT iTestIndex){ return dwResult; }
	virtual INT RRT_SET_FBER_TCH_LEVEL(double dLevel){ return dwResult; }
	virtual INT RRT_SET_FBER_CLOSELOOP_DELAY(INT iDelayms){ return dwResult; }
	virtual INT RRT_SET_WB_FBER_UL_TFCI_AUTO_CONTROL(BOOL bModeOn){ return dwResult; }
	virtual INT RRT_SET_WB_FBER_DL_TFCI(CHAR* cCode){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_MAXTXP(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_MAXTXP(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_WB_MAXTXP(VOID){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_MINTXP(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_MINTXP(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_WB_MINTXP(VOID){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_OPENLOOP_POWER(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_OPENLOOP_POWER(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_WB_OPENLOOP_POWER(VOID){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_SLOTPOWER(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_SLOTPOWER(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_WB_SLOTPOWER(VOID){ return dwResult; }
	virtual INT RRT_SET_WB_SEM_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_WB_SEM_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_WB_SEM_COUTINUOUS_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_SEM_DETECTMODE(CHAR* cMode){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_SEM(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_SEM(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_WB_SEM(VOID){ return dwResult; }
	virtual INT RRT_SET_WB_ACLR_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_WB_ACLR_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_WB_ACLR_COUTINUOUS_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_WB_ACLR_QUERY_STATUS(BOOL bN10On, BOOL bN5On, BOOL bP5On, BOOL bP10On){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_ACLR(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_ACLR(CHAR* cValueN5, CHAR* cValueN10, CHAR* cValueP5, CHAR* cValueP10){ return dwResult; }
	virtual INT RRT_SET_END_WB_ACLR(VOID){ return dwResult; }
	virtual INT RRT_GET_VALUE_FROM_STRING_LIST(CHAR* pSource, int iNumber, CHAR* out_pResult){ return dwResult; }
	virtual INT RRT_SET_WB_OBW_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_WB_OBW_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_WB_OBW_COUTINUOUS_ON(BOOL bMode){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_OBW(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_OBW(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_WB_OBW(VOID){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_ILPC(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_ILPC(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_WB_ILPC_TESTED_SLOT(CHAR* cValue){ return dwResult; }
	virtual INT RRT_SET_END_WB_ILPC(VOID){ return dwResult; }
	virtual INT RRT_SET_PCAL_FILTER_TYPE(CHAR* cType){ return dwResult; }
	virtual INT RRT_SET_PCAL_WAVEFORM_TYPE(CHAR* cType){ return dwResult; }
	virtual INT RRT_SET_PCAL_TRIGGER_SOURCE(CHAR* cType){ return dwResult; }
	virtual INT RRT_SET_PCAL_TRIGGER_THRESHOLD(double dValue){ return dwResult; }
	virtual INT RRT_SET_PCAL_RESULT_TYPE(CHAR* cType){ return dwResult; }
	virtual INT RRT_SET_PCAL_STEP_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_PCAL_STEP_CENTER(double dValueS){ return dwResult; }
	virtual INT RRT_SET_PCAL_STEP_WIDTH(INT iValueMS){ return dwResult; }
	virtual INT RRT_SET_PCAL_TIMEOUT(INT iTimeoutS){ return dwResult; }
	virtual INT RRT_SET_INIT_PCAL(INT iDuration = 0.0, INT iPeriodNumber = 0, double dRatio = 0.0, INT iType = 0){ return dwResult; }
	virtual INT RRT_SET_WB_MULTIPOWER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_MULTIPOWER(VOID){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_TXRX_FREQ_MEASUREMENT(INT iSegment, INT iSequence){ return dwResult; }
	virtual INT RRT_SET_WB_PCDE_COUNT(INT iCount){ return dwResult; }
	virtual INT RRT_SET_WB_PCDE(BOOL bControl){ return dwResult; }
	virtual INT RRT_SET_INIT_WB_PCDE(VOID){ return dwResult; }
	virtual INT RRT_SET_END_WB_PCDE(VOID){ return dwResult; }
	virtual INT RRT_SET_WB_THROUGHPUT(BOOL bControl){ return dwResult; }
	virtual INT RRT_SET_WB_THROUGHPUT_SAMPLE_NUMBER(INT iCount){ return dwResult; }

	virtual INT RRT_SET_ETXP_TRIGGER_DELAY(double dDelay){ return dwResult; }
	virtual INT RRT_SET_PFER_TRIGGER_SOURCE(CHAR* cSource){ return dwResult; }
	virtual INT RRT_SET_PFER_SYNC(CHAR* cSync){ return dwResult; }
	
	//=========================  Set function end  =========================

	//=========================  Query function start  =========================
//	virtual INT RRT_QUERY_CALLSTATUS(CHAR* cStatus){ return dwResult; }
	virtual INT RRT_QUERY_MEASUREMENT_STATUS(INT *iMSTAT_Staus){ return dwResult; }
	virtual INT RRT_QUERY_TX_MEASUREMENT_STATUS(CHAR *szRFStatus){ return dwResult; }
	virtual INT RRT_QUERY_RX_MEASUREMENT_STATUS(CHAR *szRFStatus){ return dwResult; }
	virtual INT RRT_SEND_OPC(INT iRetryCount, INT iRetryIdle){ return dwResult; }
//	virtual INT RRT_QUERY_CALIB_DATE(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_QUERY_SYS_DATE(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_QUERY_SYS_TIME(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_QUERY_CURR_APP(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_QUERY_APP_SECADDR(CHAR *cAPPList){ return dwResult; }
//	virtual INT RRT_QUERY_SCREEN(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_QUERY_EG_BAND_INDICATOR(CHAR* cStatus){ return dwResult; }
	virtual INT RRT_QUERY_EG_REG_STATUS(INT iMode){ return dwResult; }	

	//Measure query or fetch function
	virtual INT RRT_QUERY_HSDPCCH_RESULT(CHAR *cHSDPCCH){ return dwResult; }

//	virtual INT RRT_FETCH_TDSCDMA_ACLR(CHAR* cValueN16, CHAR* cValueN32, CHAR* cValueP16, CHAR* cValueP32){ return dwResult; }
//	virtual INT RRT_FETCH_TDSCDMA_Transmit_OnOff_Power(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_TDSCDMA_PCDE(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_TDSCDMA_FREQ_ERR(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_TDSCDMA_CLPC(CHAR* cValueStep_B, CHAR* cValueStep_C, CHAR* cValueStep_D, CHAR* cValueStep_E, CHAR* cValueStep_F, CHAR* cValueStep_G){ return dwResult; }
//	virtual INT RRT_FETCH_TDSCDMA_TPUT(CHAR* cValue){ return dwResult; }

//	virtual INT RRT_FETCH_TXP(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_PVT(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_FREQ_ERR(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_PEAK_PHASE_ERR(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_RMS_PHASE_ERR(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_PEAK_EVM(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_PEAK_EVM_ATT(CHAR* cValue){ return dwResult; }//mzlin 20100125 AT&T
//	virtual INT RRT_FETCH_RMS_EVM(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_95TH(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_ORIGIN_OFFSET(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_QUERY_ORFS_FILTER_TYPE(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_ORFS(CHAR* cModResult, CHAR* cSwResult){ return dwResult; }
//	virtual INT RRT_FETCH_ORFS_30KHZ_BW_POWER(CHAR* cPower){ return dwResult; }
//	virtual INT RRT_FETCH_FBER(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_WB_MAXTXP(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_WB_MINTXP(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_WB_OPENLOOP_POWER(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_WB_SLOTPOWER(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_WB_SEM(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_WB_SEM_RESULT(CHAR *cSEM){ return dwResult; }
//	virtual INT RRT_FETCH_WB_ACLR(CHAR* cValueN5, CHAR* cValueN10, CHAR* cValueP5, CHAR* cValueP10){ return dwResult; }
//	virtual INT RRT_FETCH_WB_OBW(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_WB_ILPC(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_FETCH_WB_ILPC_TESTED_SLOT(CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_PCAL_MEAS_COMPLETE(VOID){ return dwResult; }
	virtual INT RRT_FETCH_PCAL_POWER(INT iSampleCount, CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_PCAL_PHASE(INT iSampleCount, CHAR* cValue){ return dwResult; }
//	virtual	INT RRT_SET_WB_MULTIPOWER(RRT_PARAMETERS &stParameter){ return dwResult; }
//	virtual	INT RRT_SET_INIT_WB_MULTIPOWER(VOID){ return dwResult; }
	virtual	INT RRT_FETCH_WB_MULTIPOWER(INT iStepNumber, CHAR* cValue){ return dwResult; }
	virtual INT RRT_FETCH_RSSI(CHAR *out_psRxQ, CHAR *out_psRxL){ return dwResult; }
//	virtual INT RRT_SET_INIT_WB_TXRX_FREQ_MEASUREMENT(INT iSegment, INT iSequence){ return dwResult; }
	virtual INT RRT_FETCH_WB_TXRX_FREQ_MEASUREMENT(CHAR *cValue){ return dwResult; }
	virtual INT RRT_FETCH_UE_CPICH_RSCP(CHAR *cValue){ return dwResult; }
//	virtual INT RRT_SET_WB_PCDE_COUNT(INT iCount){ return dwResult; }
//	virtual INT RRT_SET_INIT_WB_PCDE(VOID){ return dwResult; }
	virtual INT RRT_FETCH_WB_PCDE(CHAR* cValue){ return dwResult; }
//	virtual INT RRT_SET_END_WB_PCDE(VOID){ return dwResult; }

	//	Combined RRT test functions
	virtual INT RRT_CX_INSTRUMENT_RESET(VOID){ return dwResult; }
	virtual INT RRT_CX_INSTRUMENT_CALIBRATION(VOID){ return dwResult; }
	virtual	INT RRT_CX_SET_INSTRUMENT_CABLELOSS(CHAR *cState, double dLossFreq[], double dLossGain[], INT iLossCount){ return dwResult; }
	virtual INT RRT_CX_SET_INSTRUMENT_MODE(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_EG_POWER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_EG_PVT(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_EG_PFER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_EG_ORFS(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_EG_FBER(RRT_PARAMETERS &stParameter){ return dwResult; }

	virtual INT RRT_CX_SET_WB_DPCH_PARAMETER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_SET_WB_POWER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_SET_WB_SEM(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_SET_WB_ACLR(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_SET_WB_OBW(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_SET_WB_BER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_WB_TRANSMISSION_POWER_CONTROL(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_WB_TRIGGER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_WB_ILPC(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual INT RRT_CX_SET_WB_PCDE(RRT_PARAMETERS &stParameter){ return dwResult; }

	//	Combined RRT calibration functions
	virtual	INT RRT_CX_QCOMM_GSM_CAL_INIT(VOID){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_WB_CAL_INIT(VOID){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_GSM_RX_CAL_INIT(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_GSM_POLAR_CAL_INIT(VOID){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_SET_GSM_POLAR_MEAS_INIT(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_SET_GSM_PHASEDELAY_INIT(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_SET_GSM_VCO_INIT(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_NSCALL_HANDOVER(RRT_PARAMETERS &stParameter){ return dwResult; }
	virtual	INT RRT_CX_QCOMM_SIGCALL_HANDOVER(RRT_PARAMETERS &stParameter){ return dwResult; }
	//	NI I/O control, NI measurement functions
	virtual INT NI_LOAD_DLL(VOID) { return dwResult; }
	virtual INT	NI_UNLOAD_DLL(VOID) { return dwResult; }

	virtual INT	NI_6518_LOAD_DUT(VOID) { return dwResult; }
	virtual INT	NI_6518_UNLOAD_DUT(INT iLEDStatus) { return dwResult; }
	virtual INT	NI_6518_ASCEND_MIC(VOID) { return dwResult; }
	virtual INT	NI_6518_DESCEND_MIC(VOID) { return dwResult; }
	virtual INT	NI_6518_LOAD_10_CM_MTF(VOID) { return dwResult; }
	virtual INT	NI_6518_LOAD_COLLIMATE(VOID) { return dwResult; }
	virtual INT	NI_6518_LOAD_WHITE_BOARD(VOID) { return dwResult; }
	virtual INT	NI_6518_LOAD_BLACK_BOARD(VOID) { return dwResult; }
	virtual INT	NI_6281_MICRxTDMS(double aiChannel, double TimeToRecordTheDataSec, double sampleRate) { return dwResult; }
	virtual INT	NI_6281_ANALYSIS_TDMS(double Count, double StdCriteria, double ToneNum, double Start, double Duration, double NextInterval, double Sensitivity) { return dwResult; }
	virtual INT	NI_6281_1K_TEST(double aiChannel, double *aidBSPL, double *aiFreq, double *aiVrms, double aoChannel, double aoFreq, double aoVrms, double Sensitivity) { return dwResult; }

	//Add for Advatest R3131A	2012_0307 Brighd
	
	virtual INT PRESET_SPECTRUM(VOID){ return dwResult; }
	virtual INT SET_CENTER_FREQUENCE(double dCenterFreqMHz){ return dwResult; }
	virtual INT SET_RBW(double dRBWkHz){ return dwResult; }
	virtual INT SET_VBW(double dVBWkHz){ return dwResult; }

	virtual INT SET_RBW(char* szRBWkHz){ return dwResult; }
	virtual INT SET_VBW(char* szVBWkHz){ return dwResult; }

	virtual INT SET_SPAN(char* szSpanType){ return dwResult; }
	virtual INT SET_SPAN(INT iSpanMode){ return dwResult; }
	virtual INT SET_SPAN_VALUE(INT iSpanValue){ return dwResult; }

	virtual INT SET_TRIG(char* szTrig){ return dwResult; }
	virtual INT SET_TRIG(INT iTrigMode){ return dwResult; }
	virtual INT SET_TRIG_LEVEL(char* szTrigLevel){ return dwResult; }
	virtual INT SET_LEVEL_UNIT(INT iDisplayLevelUnit){ return dwResult; }
	virtual INT SET_LEVEL_REFERENCE(double dRefLevel){ return dwResult; }
	virtual INT SET_LEVEL_REFERENCE(char* szRefLevel){ return dwResult; }	

	virtual INT SET_REFERENCE_OFFSET(double dRefLevel){ return dwResult; }

	virtual INT SET_TRACE_WRITE(){ return dwResult; }
	virtual INT SET_TRACE_DETECTOR(){ return dwResult; }
	virtual INT SET_TRACE(char cTraceSelect, INT iTraceMode){ return dwResult; }
	virtual INT SET_TRACE(char* szTraceMode){ return dwResult; }

	virtual INT PEAK_SEARCH(void){ return dwResult; }
	virtual INT GET_MARKER_LEVEL(double *dMarkerLevel){ return dwResult; }
	virtual INT SET_SWEEP_TIME(char* szSweepTime){ return dwResult; }
	
	
//	virtual	INT SET_REFERENCE_OFFSET_VALUE(CONST CHAR *pTestItemParam, TEST_VALUE &stTest){ return dwResult; }
};

#endif /* !VIRTUALFUNCTION_H */
