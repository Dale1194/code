#if !defined _GLOBALVAR_H
#define _GLOBALVAR_H

// for SFIS On/Off Line, 0:Off Line test; 1:On Line test
#define		ONLINE_TEST					1

#define		YES							"YES"
#define		NO							"NO"
#define		NA							"N/A"

// for TEST STATION
//Board Level
#define		BRD							"BRD"
#define		BOD							"BOD"
#define		BMT							"BMT"
#define		BGK							"BGK"
#define		BGT							"BGT"
#define		BGN							"BGN"
#define		BGP							"BGP"
#define		BWK							"BWK"
#define		BWT							"BWT"
#define		BWN							"BWN"
#define		BWF						"BWF"

//System Level
#define		SWT							"SWT"
#define		SHT                         "SHT"
#define		LTT                         "LTT"
#define		SMT                         "SMT"
#define		SAT                         "SAT"
#define		SCT                         "SCT"
#define		SGT                         "SGT"
#define		SBT                         "SBT"
#define		SWF                         "SWF"
#define		SGP                         "SGP"
#define		SFM                         "SFM"
#define		CUR							"CUR"
#define		SRT							"SRT"
#define		LTS							"LTS"
#define		OTA							"OTA"
#define		ALS							"ALS"
#define     ACCEL                       "ACCEL"
//Packing Level
#define		REF							"REF"
#define		CFG							"CFG"
#define		CFW							"CFW"
#define		CFC							"CFC"
#define		AOI							"AOI"
#define		GSR							"GSR"
#define		ECS							"ECS"

//For Kevin SAT, SCT using.
#define		ABILITY						"ABILITY"
#define		SEMCO						"SEMCO"


#define		TDMS_FILE					"c:\\TDMS.tdms"
#define		SPEAKER_BACKUP_TDMS			"c:\\TDMS_SPEAKER.tdms"
#define		SPEAKER_BACKUP_TDMSdBSPL	"c:\\TDMSdBspl_SPEAKER.txt"
#define		RECEIVER_BACKUP_TDMS		"c:\\TDMS_RECEIVER.tdms"
#define		RECEIVER_BACKUP_TDMSdBSPL	"c:\\TDMSdBspl_RECEIVER.txt"
#define		MICROPHONE_BACKUP_TDMS		"c:\\TDMS_MICROPHONE.tdms"
#define		MICROPHONE_BACKUP_TDMSdBSPL	"c:\\TDMSdBspl_MICROPHONE.txt"

#define		BLACK_BACKUP_IMAGE			".\\IMAGE\\Image_Black.jpg"
#define		NORMAL_BACKUP_IMAGE			".\\IMAGE\\Image_Normal.jpg"
#define		WHITE_BACKUP_IMAGE			".\\IMAGE\\Image_White.jpg"

//For Qualcomm platform sendsync command file name
#define		QCOM_SENDSYNC				".\\QCOM_SendSync.ini"

// ...
#define		MAX_CLIENT					8
#define		INFO_SIZE					0x000A
#define		GPIB_CMD_DELAY				10

//Keypad Define
#define		KEYPAD_RELEASE				0
#define		KEYPAD_PLAY					1
#define		KEYPAD_VOLUP				2
#define		KEYPAD_VOLDOWN				3
#define		KEYPAD_PREVIOUS				4
#define		KEYPAD_NEXT					5
#define		KEYPAD_ON_SHUF				6
#define		KEYPAD_ON_CON				7
#define		KEYPAD_OFF_SHUF				8
#define		KEYPAD_OFF_CON				9
#define		N98_PLUGIN					10
#define		N98_PULL					11
#define		REMIND_KEYPAD_ON_SHUFFLE	12
#define		REMIND_KEYPAD_ON_CONTINUE	13
#define		REMIND_KEYPAD_OFF_SHUFFLE	14
#define		REMIND_KEYPAD_OFF_CONTINUE	15
#define		CLEAR_UI_MSG				16

// for Fingerprint Test
#define		MPKID_FINGERPRINT_UP		0x0207
#define		MPKID_FINGERPRINT_DOWN		0x0208
#define		MPKID_FINGERPRINT_LEFT		0x0209
#define		MPKID_FINGERPRINT_RIGHT		0x020A
#define		MPKID_FINGERPRINT_ENTER		0x020B

// Idle Current (A)
#define		IDLE_CURRENT				0.02

//For GSM, EDGE Test Constant
#define		SIZE_16_LENGTH					16
#define		SIZE_32_LENGTH					32
#define		SIZE_256_LENGTH					256
#define		SIZE_512_LENGTH					512
#define		SIZE_1024_LENGTH				1024
#define		SIZE_2048_LENGTH				2048
#define		MAX_RFLOSS_COUNT				20
#define		GMSK_LOW_BAND_POWER_STEP		15
#define		GMSK_HIGH_BAND_POWER_STEP		16
#define		EPSK_LOW_BAND_POWER_STEP		12
#define		EPSK_HIGH_BAND_POWER_STEP		14
#define		MAX_LOSS_COUNT					20
#define		MAX_PVT_NUMBER					12
#define		MAX_ORFS_NUMBER					22
#define		MAX_PVT_OFFSET_COUNT			12
#define		MAX_ORFS_MOD_COUNT				22
#define		MAX_ORFS_SW_COUNT				8

//For Command issued to DUT max retry count
#define		MAX_CMD_RETRY_COUNT				10

enum CONNECT_TYPE
{
	CONN_TYPE_RS232 = 0,
	CONN_TYPE_RAPI = 1,
	CONN_TYPE_SOCKET = 2,
};

enum PPS_CHANNEL_ON_OFF 
{
	CHANNEL1_ON,
	CHANNEL1_OFF,
	CHANNEL2_ON,
	CHANNEL2_OFF,
};
enum PPS_CHANNEL 
{
	CHANNEL1=1,
	CHANNEL2=2,
};

enum RRT_MODE 
{
	GMSK_MODE		= 0,
	GPRS_MODE		= 1,
	EPSK_MODE		= 2,
	WCDMA_MODE		= 3,
	CW_MODE			= 4,
	OFF_MODE		= 5,			//For 8960 to set Cell parameters using.
	HSDPA_MODE		= 6,		//mzlin 20090702 WCDMA HSDPA
	TDSCDMA_MODE	= 7,		//mzlin 20090702 TDSCDMA
	TD_HSDPA_MODE	= 8,		//mzlin 20090702 TDSCDMA HSDPA
};

enum REGISTRATION_MODE//mzlin 20090702
{
	AUTO			= 0,//8960 ABSent
	CS				= 1,
	CSPS			= 2,
	COMBINED		= 3,//8960 PRESent
};

enum CHANNEL_CODING//mzlin 20090702
{
	REFERENCE_MEASUERMENT_CHANNEL	= 0,//8960 RMC12
	VOICE							= 1,
	FIXED_REFERENCE_CHANNEL			= 2,//8960 HSDP12
	E_DCH_RF_TEST					= 3,
};

enum H_SET//mzlin 20090702
{
	HSET1_QPSK		= 0,//534 kbps
	HSET1_16QAM		= 1,//777 kbps
	HSET2_QPSK		= 2,//801 kbps
	HSET2_16QAM		= 3,//1166 kbps
	HSET3_QPSK		= 4,//1601 kbps
	HSET3_16QAM		= 5,//2332 kbps
	HSET4_QPSK		= 6,//534 kbps
	HSET5_QPSK		= 7,//801 kbps
	HSET6_QPSK		= 8,//3219 kbps
	HSET6_16QAM		= 9,//4689 kbps
	HSET8_64QAM		= 10,//13245 kbps
	CAT6_MAX		= 21,//3649 kbps
	CAT8_MAX		= 31,//7205.5 kbps
	CAT10_MAX		= 41,//13976 kbps
	CAT14_MAX		= 51,//21098 kbps
	ERROR_HSHSET	= 999,//command fail
};

enum TDSCDMA_CONF_TYPE//mzlin 20090702
{
	NORMAL			= 0,
	CALL_MAXPWR		= 1,
	CALL_OFFPWR		= 2,
	CALL_20DBM		= 3,
	CALL_MINPWR		= 4,
	CALL_BERSENS	= 5,
	CALL_BERMAX		= 6,
	CALL_CLPC		= 7,
	ERROR_CONF		= 999,//command fail
};

typedef enum RRT_CALLPROCESS_MODE
{
	CALLPROCESS_ON	= 0,
	CALLPROCESS_OFF	= 1,
};

typedef enum RRT_MODULATION_MODE
{
	MODULATION_ON	= 0,
	MODULATION_OFF	= 1,
};

typedef enum RRT_OUTPUT_PATTERN
{
	PATTERN_BCH		= 0,
	PATTERN_TCH		= 1,
	PATTERN_BCHTCH	= 2,
};

typedef enum RRT_SIGNAL_MODE
{
	SIGNAL_MODE		= 0,
	N0N_SIGNAL_MODE	= 1,
};

typedef enum RRT_EPSK_LOOPBACK_TYPE
{
	TESTMODE_A		= 0,
	TESTMODE_B_ACK	= 1,
	TESTMODE_B_UACK	= 2,
	BLER			= 3,
	SRB				= 4,
};

typedef enum RRT_GMSK_LOOPBACK_TYPE
{
	LBT_TYPEA			= 0,
	LBT_TYPEB			= 1,
	LBT_TYPEC			= 2,
	LBT_TYPEII			= 3,
	LBT_OFF				= 4,
};

typedef enum RRT_BRAND_TYPE
{
	RRT_AG8960			= 0,
	RRT_AN8820			= 1,
	RRT_RSCMU			= 2,
	RRT_AN8820A			= 3,
	RRT_AN8820B			= 4,
	RRT_AG6601			= 5,
	RRT_ATR3131A		= 6,
	RRT_RSFSP			= 7,
};

typedef enum RRT_CALLSTATUS_TYPE
{
	CS_IDLE				= 0,
	CS_ATTACHED			= 1,
	CS_CONNECTED		= 2,
	CS_TRANSFERRING		= 3,
	CS_ALERTING			= 4,
	CS_REGISTERED		= 5,
};

#ifdef DVT_VERSION
enum ATE1JIGPinNumber{
	VDD3V0_PIN				=	101, //testing vdd 3.0
	VDD_1V2_PIN				=	102, //testing vdd 1.2v
	VDD_RTC_PIN				=	103, //testing vdd rtc
	VDD_CLASSD_PIN			=	104, //testing vdd classd
	VDD_POWER_SOURCE_PIN	=	105, //testing vdd classd
	REGA_VDD2				=	106,
	DVDD					=	107,
	VBUS_PIN				=	108,
	USB_INT_PIN				=	109,
	USB_RVP_INT				=	110,
	D_PLUS_VOLT_PIN			=	110,
	VBATT					=	111,
	DETECT_ON_OFF_VOLT_PIN	=	111,
	NTC_VOLTAGE_CHANNEL		=	112,
	NTC_RESISTOR_CHANNEL	=	112, //testing the NTC resistor
	VTHM_CHANNEL			=	113,
	CHARGE_FREQ_PIN			=	114,
	LED_BATT_G_PIN			=	115,
	LED_BATT_R_PIN			=	116,
	LED_STAT_G_PIN			=	117,
	LED_STAT_O_PIN			=	118,
	AUDIO_R_PIN				=	119,
	AUDIO_L_PIN				=	120,
	USB_CURRENT_PIN			=	121,// for measure usb current
	BATTERY_CURRENT_PIN		=	122,// for measure BATTERY current

	BATTERY_STEERING_PIN	=	201,
	ACC_TO_POD				=	202,
	HP_DETECT_PIN			=	203,
	VOL_UP_PIN				=	204,
	VOL_DOWN_PIN			=	205,
	PREVIOUS_PIN			=	206,
	NEXT_PIN				=	207,
	PLAY_PIN				=	208,
	OFF_PIN					=	209,
	//modified by bunny 2006/8/26--start
	/* old:
	ON_PIN				=	210,-> sw_shut/cont
	SHUF_PIN			=	211,->usb 5v
	*/
	SHUF_PIN				=	210,

	//ON_PIN				=	210,
	USB_PUR_PIN		     	=	211,//VBUS GND
	//modified by bunny 2006/8/26--end
	NTC_TEMPTURE_HIGH_PIN	=	212,
	NTC_TEMPTURE_LOW_PIN	=	213,
	FAIL_STATE				=	214,
	PASS_STATE				=	215,
	//modified by bunny 2006/8/26--start
	/* old:
	USB_MODE_PIN		=	216,//yellow 
	*/
	YELLOW_LIGHT_PIN		=	216,//yellow 
	//modified by bunny 2006/8/26--end
	//added by bunny 2006/9/17--start
	USB_MODE_PIN			=   217,//D+D-
	AUDIO_3V0_PIN			=   218,
	ENABLE_DIVIDER_PIN		=   218,
	AUDIO_PIN               =   219,
	ENABLE_SUSPEND_PIN      =   219,
	//added by bunny 2006/9/17--end
};
#else
enum ATE1JIGPinNumber{
	VDD3V0_PIN=101, //testing vdd 3.0
	VDD_1V2_PIN=102, //testing vdd 1.2v
	VDD_RTC_PIN=103, //testing vdd rtc
	VDD_CLASSD_PIN=104, //testing vdd classd
	VDD_POWER_SOURCE_PIN=105, //testing vdd classd
	VBUS_PIN=108,
	USB_INT_PIN=109,
	VTHM_CHANNEL=110,
	NTC_VOLTAGE_CHANNEL=115,
	NTC_RESISTOR_CHANNEL=115, //testing the NTC resistor
	CHARGE_FREQ_PIN=116,
	AUDIO_L_PIN=119,
	AUDIO_R_PIN=118,
	BATTERY_CURRENT_PIN=122,// for measure BATTERY current
	USB_CURRENT_PIN=121,// for measure usb current
	VOL_UP_PIN=201,
	VOL_DOWN_PIN=202,
	PREVIOUS_PIN=203,
	NEXT_PIN=204,
	PLAY_PIN=205,
	ON_OFF_PIN=206,
	CON_SHUT_PIN=207,
	USB_MODE_PIN=208,
	HP_DETECT_PIN=209,
	BATTERY_STEERING_PIN=210,
	NTC_TEMPTURE_LOW_PIN=211,
	NTC_TEMPTURE_HIGH_PIN=212,	
};
#endif

enum A34970_CH
{
	//Head
	VCC_MAIN_CH			= 101,
	VDD1_CORE_CH		= 102,
	VDD2_CORE_CH		= 103,
    VIO_1V8_CH			= 104,
    TWL_RTC_CH			= 105,
    VDD_PLL1_CH			= 106,
	VMMC1_CH			= 107,
	VINDIG_OUT_CH		= 108,
	VINTANA1_CH			= 109,
	VINTANA2_CH			= 110,
	LCD_2V8_CH			= 111,
	VDD_ZIGBEE_CH		= 112,
    VUSB_3P1_CH			= 113,
    VUSB_1P8_CH			= 114,
	VUSB_1P5_CH			= 115,
    VIO_1V8_WLAN_OSC_CH = 116,
	F32K_OUT_CH			= 117,
	LCD_VOTAGE_CH       = 118,
	PIEZO_CH			= 119,
	LCD_CURRENT_CH      = 121,
	VBAT_CURRENT_CH     = 122,
	BACKPLATE_4V5_CUEENT_CH = 221,
	USB_CHARGING_CURRENT_CH = 222,
	VBAT_VOLTAGE_CH     = 204,

	CHARGING_CURRRENT_CH= 221,
	USB_CHARGING_CH     = 312,
	BATT_DISCONNECT_CH  = 301,

	LED_RED_CH          = 201,
	LED_GREEN_CH        = 202,
	VCC_MAIN_INT_CH     = 205,
	BACKPLATE_4V5_VOLTAGE_CH = 206,
	USB_VBUS_VOLTAGE_CH = 207,
	HU_DETEC_CH         = 305,    

	//Back
	BACKPLATE_4V5_CH		= 101,
	BACKPLATE_3V0_CH		= 102,
	MCU_VCORE_CH			= 103,
	MCU_AVCC_CH				= 104,
	BUCK_INPUT_CH			= 105,
	LTC_VIN_CH				= 106,
    TEMP_VCC_CH				= 107,
	RH_W1_CH				= 108,
	RH_W1_RE_CH		        = 109,
    RH_AUX_CH				= 110,
    RH_AUX_RE_CH            = 111,
    RC_Y1_CH				= 112,
	RC_Y1_RE_CH				= 113,
	RC_G_CH					= 114,
	RC_OB_CH				= 115,
	HUM1_HUM2_CH			= 116,
	DEHUM1_DEHUM2_CH		= 117,
	RC_OB_RE_CH             = 118,
    RC_G_RE_CH              = 119,
    POWER_VOTAGE_CH			= 119,
	OFN_DVDD_CH             = 120,
	POWER_CURRRENT_CH       = 121,
	BSDISABLE_CURRRENT_CH   = 222,
	RESTST_RH_W1_CH         = 109,
	RESTST_RH_AUX_CH        = 111,
	RESTST_RC_Y1_CH         = 113,
	RESTST_RC_G_CH          = 119,
	RESTST_RC_OB_CH         = 118,

	//349702
    BSDISABLE_CURRRENT_Y1_CH  = 121,
	BSDISABLE_CURRRENT_W1_CH  = 122,
	VCC_MAIN_CUR_CH           = 121,

	//SWITCH
	BACKPLATE4V5_USBVBUS_CH    = 201,
	RESIST_100K_CH             = 301,
	RESIST_40K_CH              = 302,
	RESIST_350K_CH             = 303,
	HU_POWER_ON_CH             = 205,
	BP_RESET_CH                = 206,
    HW_RESET_CH                = 207,
	HW_ON_CH                   = 208,


	SWITCH_G_CH          = 303,
	SWITCH_OB_CH         = 309,
	SWITCH_AUX_CH        = 308,
	SWITCH_RH_CH         = 306,
	SWITCH_W1_CH         = 305,
	SWITCH_C_CH          = 310,
	SWITCH_Y1_CH         = 304,
	SWITCH_RC_CH         = 307,
    BP_DETEC_CH          = 301,        
	//SWITCH_1_CH          = 201,

	LED_CH_HEAD_UP    = 201,
	LED_CH_HEAD_BACK  = 202,
	
	VBAT_CH           = 233,
	 
	OSK_3V3_CH        = 245,
	FTDI_1V8_CH       = 246,
	BACKPLATE_3V3_CH  = 247,
	
	
	PMIC_CH           = 250,
	SYS_XTALOUT_CH    = 251,
	WLAN_CLK_CH       = 252,
	LCD_CH            = 253,

	//Back
	LED_CH_BACK      = 203,
    HVAC_RH_CH       = 204,
	HVAC_RC_CH       = 205,
	HVAC_HUM_CH      = 206,
	HVAC_DEHUM_CH    = 207,
	
	
	XTAL_32K_OUT_CH  = 209,
	DRIVE_PWM_P_CH   = 210,
	DRIVE_PWM_N_CH   = 211,
	CLOCK_MONITOR_CH = 212,
	
	GPS_CH			= 213,

};

typedef enum _BAND {
	Band_GSM400     = 0, 
	Band_GSM850		= 1,
	Band_GSM		= 2,
	Band_DCS		= 3,
	Band_PCS		= 4,
	Band_WCDMA1		= 5,
	Band_WCDMA2		= 6,
	Band_WCDMA3		= 7,
	Band_WCDMA4		= 8,
	Band_WCDMA5		= 9,
	Band_WCDMA6		= 10,
	Band_WCDMA7		= 11,
	Band_WCDMA8		= 12,
	Band_WCDMA9		= 13,
	Band_TDSCDMA_A	= 14,//freq 1880-1920
	Band_TDSCDMA_B	= 15,//freq 2010-2025
	Band_TDSCDMA_C	= 16,//freq 2300-2400
} E_BAND;

typedef enum _PHYSICAL_CHANNEL {
	// State 
	imNONE				= -1, 
	imOFF				= 0, 
	imON				= 1,
	
	// Physical channels
	imCPICH				= 1000, 
	imSCH				= 1002, 
	imP_CCPCH			= 1004, 
	imS_CCPCH			= 1005, 
	imPICH				= 1006, 
	imAICH				= 1008, 
	imD_DPCH			= 1011,
	imD_DPCCH			= 1012, 
	imD_DPDCH			= 1013, 
	imPRACH				= 1150, 
	imU_DPCH			= 1160, 
	imOCNS				= 1200, 
	imAWGN				= 1201,
	// Radio Meassurement Channel(RMC) setting
	imVOICE_CHANNEL		= 100, 
	imRMC_12_2_KBPS		= 101, 
	imRMC_64_KBPS		= 102, 
	imRMC_144_KBPS		= 103, 
	imRMC_384_KBPS		= 104,
	// Data pattern
	imALL_ZERO			= 110, 
	imALL_ONE			= 111, 
	imPN9				= 112, 
	imPN15				= 113, 
	imECHO				= 114, 
	imNO_DATA			= 115,
} E_PHYSICAL_CHANNEL, *LPE_PHYSICAL_CHANNEL;


typedef enum TestTypeTag
{
	E_READ_ISN,
	E_VIBRATOR_TEST,
	E_LED_TEST,
	E_SET_GPS_MODE,
	E_GPS_MODULE_TEST,
	E_BT_MODULE_TEST,
	E_WIFI_MODULE_TEST,
	E_SIM_TEST,
	E_MODEM_MODULE_TEST,
	E_GET_HEADSET_STATUS,
	E_GET_HOOKKEY_STATUS,
	E_SET_AUDIO_PATH,
	E_SET_AUDIO_LOOP_BACK,
	E_SET_FM_STATUS,
	E_PLAY_DUT_WAV,
	E_STOP_DUT_WAV,
	E_BMIC_RECORD_WAV,
	E_TAKE_PICTURE,
	E_RELED_TEST,
	E_RESETFTM_TEST,
	E_WRITE_ISN,
	E_READ_GPS_MESS,
	E_SYSTEM_SUSPEND,
	E_CHARGE_ENABLE,
	E_BT_MODULE_MOUNT,
	E_WIFI_MODULE_MOUNT,
	E_READ_BATTERY_VER,
	E_SET_KEYPAD,
	E_READ_OS_VER,
	E_SET_BACKLIGHT_STATUS,
	E_SET_BACKLIGHT_LEVEL,
	E_SET_LIGHT_SENSOR_STATUS,
	E_GET_LIGHT_SENSOR_VALUE,
	E_WRITE_IMEI,
	E_READ_IMEI,
	E_WRITE_WIFI_ADDRESS,
	E_READ_WIFI_ADDRESS,
	E_WRITE_BT_ADDRESS,
	E_READ_BT_ADDRESS,
	E_READ_GSENSOR_VALUE,
	E_READ_GSENSOR_OFFSET,
	E_GSENSOR_CALIBRATION,
	E_READ_BTMAC_ID,
	E_READ_BOOT_VER,
	E_READ_RADIO_VERSION,
	E_BACKLIGHT_TEST,
	E_CHANGE_STATUS,
	E_REBOOT_DUT,
	E_SEND_VIRTUAL_KEY,
	E_READ_BATTERY_LIFE,
	E_SET_USB_MODE,
	E_DELETE_EPHEMERIS,
}Test_Type;

enum AUDIO_PATH 
{
	HMIC_TO_SPEAKER,
	HMIC_TO_RECEIVER,
	HMIC_TO_HEADSET,
	HMIC_TO_PCM_TO_RECEIVER,
	BMIC_TO_SPEAKER,
	BMIC_TO_RECEIVER,
	BMIC_TO_HEADSET,
	FM_TO_SPEAKER,
	FM_TO_HEADSET,
	SPEAKER_OUT,
	RECEIVER_OUT,
	BMIC_RECORD,
	HMIC_RECORD,
	PATH_CLOSE,
};

enum NI_6518_IO_OUT_SENSOR_Def
{
	DAQ_6518_AUDIO_DO_MIC_UP			= 0,
	DAQ_6518_AUDIO_DO_MIC_DOWN			= 1,
	DAQ_6518_AUDIO_DO_DUT_LOAD			= 0,
	DAQ_6518_AUDIO_DO_DUT_UNLOAD		= 2,

	DAQ_6518_AUDIO_DO_LED_OFF			= 0,
	DAQ_6518_AUDIO_DO_LED_RED_ON		= 8,
	DAQ_6518_AUDIO_DO_LED_YELLOW_ON		= 16,
	DAQ_6518_AUDIO_DO_LED_GREEN_ON		= 32,

	DAQ_6518_AUDIO_SENSOR_EMS_ON		= 0,
	DAQ_6518_AUDIO_SENSOR_EMS_OFF		= 2,
	DAQ_6518_AUDIO_SENSOR_MIC_UP		= 16,
	DAQ_6518_AUDIO_SENSOR_MIC_DOWN		= 8,
	DAQ_6518_AUDIO_SENSOR_DUT_LOAD		= 32,
	DAQ_6518_AUDIO_SENSOR_DUT_UNLOAD	= 64,

	DAQ_6518_CAMERA_DO_LIGHT_UNLOAD			= 0,
	DAQ_6518_CAMERA_DO_LIGHT_LOAD			= 1,
	DAQ_6518_CAMERA_DO_BLACK_UNLOAD			= 0,
	DAQ_6518_CAMERA_DO_BLACK_LOAD			= 2,
	DAQ_6518_CAMERA_DO_DUT_LOAD				= 0,
	DAQ_6518_CAMERA_DO_DUT_UNLOAD			= 4,
	DAQ_6518_CAMERA_DO_COLLIMATOR_UNLOAD	= 0,
	DAQ_6518_CAMERA_DO_COLLIMATOR_LOAD		= 64,

	DAQ_6518_CAMERA_DO_LED_OFF				= 0,
	DAQ_6518_CAMERA_DO_LED_RED_ON			= 8,
	DAQ_6518_CAMERA_DO_LED_YELLOW_ON		= 16,
	DAQ_6518_CAMERA_DO_LED_GREEN_ON			= 32,

	DAQ_6518_CAMERA_SENSOR_EMS_ON				= 0,
	DAQ_6518_CAMERA_SENSOR_EMS_OFF				= 2,
	DAQ_6518_CAMERA_SENSOR_LIGHT_LOAD			= 8,
	DAQ_6518_CAMERA_SENSOR_LIGHT_UNLOAD			= 16,
	DAQ_6518_CAMERA_SENSOR_BLACK_LOAD			= 32,
	DAQ_6518_CAMERA_SENSOR_BLACK_UNLOAD			= 64,
	DAQ_6518_CAMERA_SENSOR_DUT_LOAD				= 128,
	DAQ_6518_CAMERA_SENSOR_DUT_UNLOAD			= 256,
	DAQ_6518_CAMERA_SENSOR_COLLIMATOR_UNLOAD	= 512,
	DAQ_6518_CAMERA_SENSOR_COLLIMATOR_LOAD		= 1024,
};

typedef enum DMM_MEAS_TYPE
{
	DMM_TYPE_DC_CURR			= 0,
	DMM_TYPE_AC_CURR			= 1,
	DMM_TYPE_DC_VOLT			= 2,
	DMM_TYPE_AC_VOLT			= 3,
	DMM_TYPE_OHM				= 4,
	DMM_TYPE_OHM_4W				= 5,
};

typedef struct _CORRECTION_VALUE {
	double		dwFreq[256];
	double		dwdBSPL[256];
} CORRECTION_VALUE;

typedef struct _SPEC_VALUE {
	double		dwFreq[256];
	double		dwLowerLimit[256];
	double		dwUpperLimit[256];
	double		dThd[256];
} SPEC_VALUE;

typedef struct _MEASUREMENT_VALUE {
	double	dwFreq[256];
	double	dwdBSPL[256];
	double	dThd[256];
} MEASUREMENT_VALUE;

typedef struct _VALUE_WITH_CORRECTION {
	double	dwFreq[256];
	double	dwdBSPL[256];
} VALUE_WITH_CORRECTION;

//typedef struct _CAMERA_SETTING_VALUE {
//	int nPosR;
//	int nPosG;
//	int nPosB;
//	int nPosDiff;
//	int nPosCluster;
//	CPoint ptPositionPoint[4];
//	CRect rtBoxs[10];
//	double dBA;
//	double dBB;
//	double dGA;
//	double dGB;
//	double dRA;
//	double dRB;
//	double dWA;
//	double dWB;
//
//	int c1_thd_low;
//	int c1_thd_up;
//	int c2_thd_low;
//	int c2_thd_up;
//
//	int dtc_b_nBorderWidth;
//	int dtc_b_nWidthFactor;
//	int dtc_b_nHeightFactor;
//	int dtc_b_nArea1Thrd;
//	int dtc_b_nArea2Thrd;
//
//	int dtc_w_nBorderWidth;
//	int dtc_w_nWidthFactor;
//	int dtc_w_nHeightFactor;
//	int dtc_w_nArea1Thrd;
//	int dtc_w_nArea2Thrd;
//
//	CRect ls_rtBoxs[5];
//	CRect cs_rtBoxs[5];
//} CAMERA_SETTING_VALUE;

enum COLOR_TYPE
{
	BlueColor = 0,
	GreenColor = 1,
	RedColor = 2,
	GrayLevelColor = 3,
	ColorType = 4,
};

enum SECTION_TYPE
{
	LT = 0,
	LB = 1,
	RB = 2,
	RT = 3,
	MM = 4,
	SectionType = 5,
};

typedef struct _STATISTICS_VALUE
{
	double d_MeanValue[ColorType];
	double d_StdDevValue[ColorType];
	INT i_Median[ColorType];
	INT i_Total_Pixels;
}STATISTICS_VALUE, *LPSTATISTICS_VALUE;

typedef struct _CAMERA_TEST_VALUE {
	// ----- Color ----
	OUT double dDeltaE;

	// ---- Auto White Balance ----
	OUT double d_AWB_R_G;
	OUT double d_AWB_B_G;

	//----- Blemish Pixel -----

	//---- Lens Shading ----
	OUT double d_Lens_LT_MM;
	OUT double d_Lens_LB_MM;
	OUT double d_Lens_RB_MM;
	OUT double d_Lens_RT_MM;

	//---- Color Shading ----
	OUT double d_CLens_R_G[SectionType];
	OUT double d_CLens_B_G[SectionType];

}CAMERA_TEST_VALUE, *LPCAMERA_TEST_VALUE;

typedef struct _CAMERA_SPEC_VALUE {
	// ----- Color ----
	IN double dBA;
	IN double dBB;
	IN double dGA;
	IN double dGB;
	IN double dRA;
	IN double dRB;
	IN double dColorThrd;

	// ---- Auto White Balance ----
	IN double dAWBThrd;

	//----- Blemish Pixel -----
	IN int iWidthFactor;
	IN int iHeightFactor;
	IN int iCenterRegion;

	IN double d_Center_Thrd;
	IN double d_Corner_Thrd;

	IN int iCenter_Num;
	IN int iCenter_LaNum;

	IN int iCorner_Num;
	IN int iCorner_LaNum;

	//---- Lens Shading ----
	IN double dLSThrd; 

	//---- Color Shading ----
	IN double dCSThrd;
}CAMERA_SPEC_VALUE, *LPCAMERA_SPEC_VALUE;

typedef struct _CAMERA_PARAMETERS {
	// ----- Position Point ----
	IN INT iPosR;
	IN INT iPosG;
	IN INT iPosB;
	IN INT iPosDiff;
	IN INT iPosCluster;

	//[ROTATE TIMES]
	IN INT i_Rotate_Times_Color;
	IN INT i_Rotate_Times_White;
	IN INT i_Rotate_Times_Black;
	IN CHAR szRotateType[32];

	IN	CAMERA_SPEC_VALUE stCameraSpecValue;
	OUT CAMERA_TEST_VALUE stCameraTestValue;
}CAMERA_PARAMETERS, *LPCAMERA_PARAMETERS;

typedef enum _WCDMA_Band_Type {
	_BC1			= 0,
	_BC2			= 1,
	_BC4			= 2,
	_BC5			= 3,
	_BC8			= 4,
} WCDMA_Band_Type;
#define D_FAIL					"FAIL"
#define D_ERROR					"ERROR"
#define D_NULL					"NULL"
#define D_SENSOR_PROX_1			1
#define D_SENSOR_PROX_2			2
#define D_SENSOR_ALS_VIS		3
#define D_SENSOR_ALS_IR			4
#define D_SENSOR_TEMP_BP		5
#define D_SENSOR_TEMP_HU		6
#define D_SENSOR_HUMIDITY_BP	7
#define D_SENSOR_HUMIDITY_HU	8
#define D_SENSOR_PIR			9
#define STEP_DOOR_IN			1
#define STEP_DOOR_OUT			2
#define STEP_PROX_ON			3
#define STEP_PROX_OFF			4
#define STEP_ALS_ON				5
#define STEP_ALS_OFF			6
#define STEP_ALS_LAMP_ON		7
#define STEP_ALS_LAMP_OFF		8
#define STEP_PIR_ON				9
#define STEP_PIR_OFF			10
#define STEP_PIR_LAMP_ON		11
#define STEP_PIR_LAMP_OFF		12
#define ATS_SH					"/pegatron/diags/bin/ats/ats"
#define ATS_DIR					"/pegatron/diags/bin/ats/"
#define DIAG_DIR				"/pegatron/diags/bin/"



//FISN
typedef struct _AP_SETTING {
	int iChangeChannelDelay;
	int iPingWait;
	char szIP[32];
	bool bAPConnected;
	bool bPipeCreate;
	int iTest_Wifi_Set_AP_Power;//mzlin 20110513
	int iTest_Zigbee_Set_AP_Power;//mzlin 20110513
	char szIP_CLASS[32];//mzlin 20110520
}AP_SETTING;

typedef struct _DUT_SETTING {
	char szMac[32];
	char szIP[32];
	char MAC[32];
	bool bDUTConnected;
	bool bInDiag;
	int iConnAPTimeout;
	int iConnSSHTimeout;
	bool bPipeCreate;
	bool bWriteNextIP;
}DUT_SETTING;

#endif /* #pragma once */