﻿#ifndef _AGILENT34970A_H
#define _AGILENT34970A_H

#include "visa_ExportApi.h"
#include "ReturnType.h"
#include "GlobalVar.h"
#include "VirtualFunction.h"
#include "CommonAPI.h"

typedef struct _DMM_MEAS_PARA
{
	CHAR	szRange[SIZE_256_LENGTH];
	CHAR	szResolution[SIZE_256_LENGTH];
	CHAR	szIntegrationTime[SIZE_256_LENGTH];
	CHAR	szAutozero[SIZE_32_LENGTH];
	CHAR	szLFF[SIZE_32_LENGTH];
	CHAR	szO_COMP[SIZE_32_LENGTH];
	double	dCHDelay;
	INT		iAvgCount;
}DMM_MEAS_PARA;

class CAgilent34970A : public CVirtualInstrument
{
public:
	CAgilent34970A();
	virtual ~CAgilent34970A();

public:
	HINSTANCE				m_hDLL;
	CHAR					m_szDLLFile[MAX_PATH];
	CHAR					m_szCommand[256];
	CHAR					m_szReadBuffer[1024];

	ViSession				m_viSession;

	DMM_MEAS_PARA			m_DMMMeasPara;
	INT						m_iCurrMeasType;

	pf_viOpen_t				viOpen;
	pf_viScanf_t			viScanf;
	pf_viClose_t			viClose;
	pf_viPrintf_t			viPrintf;
	pf_viOpenDefaultRM_t	viOpenDefaultRM;
	pf_viQueryf_t			viQueryf;
	pf_viClear_t			viClear;
	pf_viSetAttribute_t		viSetAttribute;

	//Tomy Chen, 2009/03/31, Flag to indicate to save GPIB log or not.
	BOOL					m_bGPIB_Log_Enable;

	// Variable to identify device brand (0=Agilent/HP, 1=GWinstek)
	INT						m_iDeviceBrand; // Dale add 02/07/2025 (0=Agilent/HP, 1=GWinstek)

	INT	Write(CONST CHAR *pcCommand);
	INT	Query(CONST CHAR *pcCommand, CHAR *pcReturnValue);

	INT VISA32_SET_VI_SESSION(DWORD vi);
	INT	VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable);
	INT GPIB_WRITE(const char* command);
	INT GPIB_QUERY(const char* command, char* returnVal);
	INT SET_DEVICE_BRAND(INT iBrand); // Dale add 02/07/2025 (0=Agilent/HP, 1=GWinstek) (function to set device brand)

	/*
	INT READ_VALUE(INT iCH, double *pdVale, FLOAT fIntervalTime=0.01, INT iFetchCount=10);
	INT READ_VALUE_MIN(INT iCH, double *pdVale, FLOAT fIntervalTime=0.01, INT iFetchCount=10);
	INT READ_LAST_VALUE(INT iCH, double *pdVale, INT iLastNumCount);
	INT READ_RESISTANCE(INT iCH, double *pdRes, FLOAT fIntervalTime=0.01, INT iFetchCount=50);
	INT READ_RESISTANCE_4W(INT iCH, double *pdRes, FLOAT fIntervalTime=0.01, INT iFetchCount=50);
	INT READ_DC_VOLTAGE(INT iCH, double *pdDCVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50);
	INT READ_AC_VOLTAGE(INT iCH, double *pdACVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50);
	INT READ_FREQUENCY(INT iCH, double *pdFreq, FLOAT fIntervalTime=0.01, INT iFetchCount=1);
	INT READ_DC_CURRENT(INT iCH, double *pdDCVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50);
	INT READ_AC_CURRENT(INT iCH, double *pdDCVolt, FLOAT fIntervalTime=0.01, INT iFetchCount=50);
	*/

	INT READ_VALUE(INT iCH, double *pdVale, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);
	INT READ_VALUE_MIN(INT iCH, double *pdVale, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);
	INT READ_LAST_VALUE(INT iCH, double *pdVale, INT iLastNumCount);
	INT READ_RESISTANCE(INT iCH, double *pdRes, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);
	INT READ_RESISTANCE_4W(INT iCH, double *pdRes, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);
	INT READ_DC_VOLTAGE(INT iCH, double *pdDCVolt, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);
	INT READ_AC_VOLTAGE(INT iCH, double *pdACVolt, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);
	INT READ_FREQUENCY(INT iCH, double *pdFreq, FLOAT fIntervalTime = 0.01, INT iFetchCount = 1);
	INT READ_DC_CURRENT(INT iCH, double *pdDCVolt, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);
	INT READ_AC_CURRENT(INT iCH, double *pdDCVolt, FLOAT fIntervalTime = 0.01, INT iFetchCount = 5);

	INT SET_RESISTANCE(INT iCH);
	INT SET_RESISTANCE_4W(INT iCH);
	INT SET_DC_CURRENT(INT iCH);
	INT SET_DC_CURRENT_1A(INT iCH);
	INT SET_DC_CURRENT_uA(INT iCH);
	INT SET_AC_CURRENT(INT iCH);
	INT SET_DC_VOLTAGE(INT iCH);
	INT SET_AC_VOLTAGE(INT iCH);
	INT SET_FREQUENCY(INT iCH);

	INT ROUTE_SCAN(INT iCH);
	INT ROUTE_OPEN(INT iCH);
	INT ROUTE_CLOSE(INT iCH);
	INT ROUTE_OPEN_2CH(INT iCH1, INT iCH2);
	INT ROUTE_CLOSE_2CH(INT iCH1, INT iCH2);

	INT PRESET(VOID);

	INT	SET_DMM_MEAS_PARA(INT iMeasType, CHAR* cRange, CHAR* cResolution, CHAR* cIntegrationTime, CHAR* cLFF, CHAR* cO_COMP, CHAR* cAutozero, double dCHDelay = 0.001, INT iAvgCount = 5);
};

#endif /* #pragma once */
