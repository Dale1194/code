
#include "stdafx.h"
#include "LitePointXstreamM.h"



CLitePointIQxtreamM::CLitePointIQxtreamM()
{
	m_hDLL = NULL;

	::GetSystemDirectoryA(m_szDLLFile, MAX_PATH);
	strcat_s(m_szDLLFile, "\\visa32.dll");

	m_hDLL = ::LoadLibraryA(m_szDLLFile);
	if (NULL == m_hDLL)
	{
		::MessageBoxA(NULL, ("LoadLibrary visa32.dll Fail."), NULL, NULL);
	}
	else
	{
		viOpenDefaultRM = (pf_viOpenDefaultRM_t)::GetProcAddress(m_hDLL, "viOpenDefaultRM");
		viOpen = (pf_viOpen_t)::GetProcAddress(m_hDLL, "viOpen");
		viPrintf = (pf_viPrintf_t)::GetProcAddress(m_hDLL, "viPrintf");
		viScanf = (pf_viScanf_t)::GetProcAddress(m_hDLL, "viScanf");
		viClose = (pf_viClose_t)::GetProcAddress(m_hDLL, "viClose");
		viQueryf = (pf_viQueryf_t)::GetProcAddress(m_hDLL, "viQueryf");
		viClear = (pf_viClear_t)::GetProcAddress(m_hDLL, "viClear");
		viSetAttribute = (pf_viSetAttribute_t)::GetProcAddress(m_hDLL, "viSetAttribute");
	}
}

CLitePointIQxtreamM::~CLitePointIQxtreamM()
{
	if (m_hDLL)
	{
		::FreeLibrary(m_hDLL);
		m_hDLL = NULL;
	}
}

//***************************************************************************
// Description	: Send GPIB command to Device via Visa
//***************************************************************************
INT CLitePointIQxtreamM::Write(CONST CHAR *pcCommand)
{
	ViStatus		status;

	if (m_bGPIB_Log_Enable == TRUE)
	{
		OutputfLog("Write: %s\n", pcCommand);
	}

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viPrintf(m_viSession, m_szCommand);

	if (VI_SUCCESS != status)
	{
		OutputfLog("Failed to viPrintf. Err:%d", status);
		return GPIB_WRITE_FAIL;
	}

	return GPIB_SUCCESS;
}

//***************************************************************************
// Description	: Execute Query command & get value from Device via Visa
//***************************************************************************
INT CLitePointIQxtreamM::Query(CONST CHAR *pcCommand, CHAR *pcReturnValue)
{
	ViStatus		status;

	if (m_bGPIB_Log_Enable == TRUE)
	{
		OutputfLog("Write: %s\n", pcCommand);
	}

	sprintf_s(m_szCommand, "%s\n", pcCommand);
	status = viQueryf(m_viSession, m_szCommand, "%t", pcReturnValue);

	if (VI_SUCCESS != status)
	{
		OutputfLog("Failed to viQueryf. Err:%d", status);
		return GPIB_QUERY_FAIL;
	}

	if (m_bGPIB_Log_Enable == TRUE)
	{
		OutputfLog("Read: %s\n", pcReturnValue);
	}

	return GPIB_SUCCESS;
}
//***************************************************************************
// Description: Virtual Function
//***************************************************************************
INT	CLitePointIQxtreamM::VISA32_SET_VI_SESSION(DWORD vi)
{
	m_viSession = (ViSession)vi;
	return GPIB_SUCCESS;
}

INT	CLitePointIQxtreamM::VISA32_SET_GPIBLOG_ENABLE(BOOL bGPIBLog_Enable)
{
	m_bGPIB_Log_Enable = bGPIBLog_Enable;
	OutputLog("##########		CLitePointIQxtreamM Test Start		##########");
	return GPIB_SUCCESS;
}


INT CLitePointIQxtreamM::GPIB_WRITE(const char* command)
{
	return this->Write(command);
}

INT CLitePointIQxtreamM::GPIB_QUERY(const char* command, char* returnVal)
{
	return this->Query(command, returnVal);
}



