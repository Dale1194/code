#pragma once

#include <string>
#include "CommonApi.h"
#include "include/json/json.h"



using namespace std;


class CScenario
{
public:
	CScenario(const char* name);
	virtual ~CScenario();

private:

public:

private:
	string m_filename;
};

