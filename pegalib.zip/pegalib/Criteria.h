
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include "CommonApi.h"


extern HWND	g_uiwnd;
using namespace std;

#pragma once

class CCriteria
{
public:
	enum Status {
		Pass = 0,
		Fail = 1,
		NotFound
	};
private:
	CCriteria(const char* name):m_file_name("") {
		if (name == NULL && m_file_name.empty())
			assert(!"Object Criteria not init yet!");
		m_file_name = name;

		size_t pos;
		string f = m_file_name;
		pos = f.rfind('.');
		f.erase(pos);
		pos = f.rfind('\\') + 1;
		m_name_ = f.substr(pos);		

		init(name);
	};
public:
	~CCriteria(void) {
	};
public:
	static CCriteria* Init(const char* name) {
		static auto_ptr<CCriteria> pObj(new CCriteria(name));
		return pObj.get();
	};

	static CCriteria* getInstance() {
		return Init(NULL);
	};

	void ReInit() {
		init(m_file_name.c_str());
	};

	struct CriteriaField {
		string item;
		string status;
		string value;
		string ul;
		string dl;
	};

private:
	void init(const char* name) {
		FILE				*stream;
		char*				pBuff = NULL;
		std::vector<string>	lines;
		CriteriaField		csv_record;
		std::vector<string>	fields;

		if( fopen_s( &stream, name, "rb" ) == 0 )
		{
			unsigned long pos = ftell(stream); //Get current position in stream
			fseek (stream, 0L, SEEK_END);
			pos = ftell(stream);
			fseek (stream, 0L, SEEK_SET);
			pBuff = new char[pos+1];
			pBuff[pos] = 0;
			fread(pBuff, sizeof(char), pos, stream);
			fclose( stream );
		}

		StringToken(pBuff, lines, "\r\n"); // split \r\n out to vector
		delete[] pBuff;
		pBuff = NULL;

		m_item_criteria.clear();
		for (std::vector<string>::iterator it=lines.begin()+1; it!=lines.end(); ++it)
		{
			std::size_t found = it->find("\"\"");
			if (found != string::npos)
				it->insert(found + 1, "_");
			StringToken(it->c_str(), fields, ",\"", REMOVE_EMPTY_ENTRIES);

			if (fields.size() == 5) {
				csv_record.item = fields[0];
				csv_record.status = fields[1];
				csv_record.value = fields[2];
				csv_record.ul = fields[3];
				csv_record.dl = fields[4];

				m_item_criteria[fields[0]] = csv_record;
			}
			else {
				::MessageBoxA(NULL, "Criteria data are wrong!", "Warning", MB_OK);
			}
		}

	};

public:
	void GetCriteriaFileName(string& name) {
		name = m_name_;
	};

	const char* GetCriteriaFileName(void) {
		return m_name_.c_str();
	};

	bool GetCriteriaByItem(const char* item, CriteriaField& criteria) {
		if (m_item_criteria.find(item) != m_item_criteria.end()) {
			criteria = m_item_criteria[item];
			return true;
		}
		return false;
	};

	int GetCriteriaResult(const char* item, const double value, CriteriaField* criteria = NULL) {
		char v[32];
		sprintf_s(v, "%f", value);
		return GetCriteriaResult(item, v, criteria);
	};

	int GetCriteriaResult(const char* item, const char* value, CriteriaField* criteria = NULL) {
		int real_stat = Fail;
		string ul, dl;
		if (m_item_criteria.find(item) != m_item_criteria.end()) {
			ul = m_item_criteria[item].ul;
			dl = m_item_criteria[item].dl;

			if (_stricmp(value, "fail") != 0) {
				if (_stricmp(ul.c_str(), dl.c_str()) == 0) {
					if (_stricmp(ul.c_str(), "N/A") == 0) {
						real_stat = Pass;
					}
					else if (is_digits(ul.c_str())) {
						if ((atof(value) <= atof(ul.c_str())) && (atof(value) >= atof(dl.c_str()))) {
							real_stat = Pass;
						}
					}
					else {
						std::vector<string>	values;
						StringToken(ul.c_str(), values, "|");
						for (std::vector<string>::iterator it = values.begin(); it != values.end(); ++it) {
							if (strcmp(value, it->c_str()) == 0) {
								real_stat = Pass;
								dl = value;
								ul = value;
								break;
							}
						}
					}
				}
				else {
					
					if (_stricmp(ul.c_str(), "N/A") != 0 && _stricmp(dl.c_str(), "N/A") != 0) {
						if (is_digits(ul) && is_digits(dl)) {
							if ((atof(value) <= atof(ul.c_str())) && (atof(value) >= atof(dl.c_str()))) {
								real_stat = Pass;
							}
						}
					}
					else if (_stricmp(ul.c_str(), "N/A") != 0) {
						if (is_digits(ul)){
							if (atof(value) <= atof(ul.c_str())) {
								real_stat = Pass;
							}
						}
					}
					else if (_stricmp(dl.c_str(), "N/A") != 0) {
						if (is_digits(dl)) {
							if (atof(value) >= atof(dl.c_str())) {
								real_stat = Pass;
							}
						}
					}
				}
			}
			if (criteria != NULL) {
				*criteria = m_item_criteria[item];
				criteria->value = value;
				criteria->status = real_stat == Pass ? "0" : "1";
			}
		}
		else {
			real_stat = NotFound;
		}
		return real_stat;
	};

	bool is_digits(const std::string &str) {
		if (str[0] == '-')
			return str.substr(1).find_first_not_of(".0123456789") == std::string::npos;
		return str.find_first_not_of(".0123456789") == std::string::npos;
	};

	
private:
	string							m_file_name;
	string							m_name_;
	std::map<string, CriteriaField>	m_item_criteria;

};
