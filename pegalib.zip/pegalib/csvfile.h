
#include <string>
#include <iostream>
#include <fstream>




using namespace std;

#pragma once

class CCSvFile
{

public:
	CCSvFile(const char* name, const char* dir) :m_full_name("") {
		m_file_name = name;
		strcpy_s(m_rdlog_dir, dir);
		m_full_name = dir;
		m_full_name = m_full_name + "\\" + m_file_name + ".csv";
	};

	virtual ~CCSvFile() {
	};

	void WriteLog(const char* buffer) {
		HANDLE handle;
		DWORD dwBytesToWrite = (DWORD)strlen(buffer);
		DWORD dwBytesWritten = 0;
		char temp[64];

		handle = CreateFileA(m_full_name.c_str(), FILE_APPEND_DATA, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (handle == INVALID_HANDLE_VALUE) {
			::OutputDebugStringA("[fox] failed to open log file");
			sprintf_s(temp, "err no:%d", ::GetLastError());
			::OutputDebugStringA(temp);
			::Sleep(5000);
			handle = CreateFileA(m_full_name.c_str(), FILE_APPEND_DATA, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		}
		if (handle != INVALID_HANDLE_VALUE) {
			SetFilePointer(handle, 0, NULL, FILE_END);
			WriteFile(handle, buffer, dwBytesToWrite, &dwBytesWritten, NULL);
			CloseHandle(handle);
		}
		else {
			::OutputDebugStringA("[fox] failed to open log file(2)");
			sprintf_s(temp, "err no:%d", ::GetLastError());
			::OutputDebugStringA(temp);
		}
	}
	
	void WriteLogf(const char *fmt, ...) {
		int buf_cnt = 1024;
		char* buffer = NULL;
		int vsn = -1;
		va_list	list;

		va_start(list, fmt);
		do{
			delete[] buffer;
			buf_cnt *= 2;
			buffer = new char[buf_cnt];
			vsn = vsnprintf_s(buffer, buf_cnt, _TRUNCATE, fmt, list);
		} while (vsn == -1);
		va_end(list);

		WriteLog(buffer);
		delete[] buffer;
	}
	
	void Rename(const char* name) {
		string file_name(m_rdlog_dir);

		file_name = file_name + "\\" + name + ".csv";
		if (rename(m_full_name.c_str(), file_name.c_str()) != 0) {
			errno_t err;
			_get_errno(&err);
			//WriteLogf("failed to rename. errorno is %d", err);
			DBGTRACE(("failed to rename. [%s]", m_full_name.c_str()));
		} else {
			m_file_name = name;
			m_full_name = file_name;
		}
	}

	bool IsFileExist(string& file_name) {
		ifstream infile(file_name.c_str(), ifstream::in);
		return infile.good();
	}

public:
	string m_file_name;
	string m_full_name;

protected:
	char m_rdlog_dir[512];
};