
#include <vector>

using namespace std;

#pragma once

const int WM_BUTTON_ENABLE		= WM_USER + 1;
const int WM_TIMER_UPDATE		= WM_USER + 2;
const int WM_ISN_UPDATE			= WM_USER + 3;
const int WM_STATUS_UPDATE		= WM_USER + 4;
const int WM_COUNT_UPDATE		= WM_USER + 5;
const int WM_PROGRESS_UPDATE	= WM_USER + 6;
const int WM_PROGRESS_RANGE		= WM_USER + 7;
const int WM_PROGRESS_MAX		= WM_USER + 8;
const int WM_PROGRESS_TEXT		= WM_USER + 9;
const int WM_SET_INFO			= WM_USER + 10;
const int WM_CLEAR_INFO			= WM_USER + 11;
const int WM_POPUP_INPUT_FORM	= WM_USER + 12;
const int WM_ZIP_FILE			= WM_USER + 13;
const int WM_PIC_MSG_FORM		= WM_USER + 14;
const int WM_COMPORT_DBG		= WM_USER + 15;
const int WM_PIC_MSG_FORM_CLOSE = WM_USER + 16; //susu add 20241004


typedef enum test_mode
{
	OnLine,
	OffLine,
	QTR
}TestMode;

typedef char InputData[8][128];

typedef struct ui_attr
{
	int no;
	char name[64];
	TestMode testMode;
	char scenarioFile[512];
	int repeatCount;
	InputData inputData;
}UI_ATTR;


bool resume_if_debug_when_fail(const char* name);

DWORD WINAPI start_test_thread(LPVOID param);

void proc_input_data(const char* in_data, UI_ATTR& ui_attr);

void get_criteria_file();

void create_directory(const char* d);

int make_dir(const char *dir);

void remove_all_files(const char* dir);

void get_files(const char* dir, vector<string>& files);

void connect_net_neighbor();

