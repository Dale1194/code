#include "stdafx.h"
#include "pegalib.h"
#include "Dut.h"
#include "CommonApi.h"
#include "Criteria.h"
#include "Config.h"
#include <direct.h>
#include "modules\mydutcollect\MyDutCollect.h"
#include "modules\robotarm\RobotArmCtrl.h"


extern HWND	g_uiwnd;


bool resume_if_debug_when_fail(const char* name)
{
	return MyDutCollect::getInstance()->ResumeTest(name);
}

DWORD WINAPI start_test_thread(LPVOID param)
{
	::OutputDebugStringA("start_test_thread()++");
	
	UI_ATTR* ui = (UI_ATTR*)param;
	int repeat_count;
	bool is_robotarm_enable = false;
	int ret = S_OK;

	is_robotarm_enable = RobotArmCtrl::is_robotarm_enable();
	if (is_robotarm_enable)
		ret = RobotArmCtrl::wait_for_dut_place(ui->name);

	if (ret == S_OK)
	{
		repeat_count = CConfig::getInstance()->cfg_auto_test_count;
		//for (int n = 0; n < repeat_count; n++)
		int n = 0;
		while (true)
		{
			ui->repeatCount = (repeat_count == 1) ? 0 : n + 1;
			CDut* dut = new CDut(ui);
			MyDutCollect::getInstance()->AddDut(ui->name, dut);
			dut->StartTest();
			delete dut;
			MyDutCollect::getInstance()->RemoveTest(ui->name);

			if (n < repeat_count - 1)
				::Sleep(500);

			if (is_robotarm_enable)
			{
				ret = RobotArmCtrl::wait_for_dut_place(ui->name);
				if (ret != S_OK)
					break;
			}
			else
			{
				n++;
				if (n >= repeat_count)
					break;
			}
		}
	}

	delete[] ui;
	::OutputDebugStringA("start_test_thread()--");
	return 0;
}

void proc_input_data(const char* in_data, UI_ATTR& ui_attr)
{
	char delim[] = { 0x7f, 0x00 };
	int idx = 0;
	char* token;
	char* next_token;
	CMemByteAlloc buffer;

	memset(ui_attr.inputData, 0, sizeof(ui_attr.inputData));

	if (strlen(in_data) == 0)
		return;

	buffer.AllocSize(sizeof(ui_attr.inputData));
	strcpy_s((char*)buffer.data, sizeof(ui_attr.inputData), in_data);
	
	token = strtok_s((char*)buffer.data, delim, &next_token);
	while (token != NULL)
	{
		strcpy_s(ui_attr.inputData[idx], token);
		token = strtok_s(NULL, delim, &next_token);
		idx++;
		
		if (idx == _countof(ui_attr.inputData))
			break;
	}
}

void get_criteria_file()
{
	char file_path[256];
	std::vector<string> files;
	string path;

	GetCurrentPath(path);
	sprintf_s(file_path, "%s\\Criteria_v*.csv", path.c_str());
	FindFiles(file_path, files);
	if (files.size() == 0)
	{
		::MessageBoxA(g_uiwnd, "Can not find any criterion file!!\nThe file format is Criteria_v<ddd>.csv.", "Warning!", MB_OK | MB_ICONWARNING);
		::PostMessage(g_uiwnd, WM_CLOSE, NULL, NULL);
	}
	else
	{
		sort(files.begin(), files.end());
		sprintf_s(file_path, "%s\\%s", path.c_str(), (files.end() - 1)->c_str());
		CCriteria::Init(file_path);
	}
}

void create_directory(const char* d)
{
	int ret = 0;
	string dir;
	std::vector<string> test_mode;

	dir = d;
	ret = make_dir(dir.c_str());

	if (ret == 0)
	{
		dir = dir + "\\" + CConfig::getInstance()->cfg_project_name;
		ret = make_dir(dir.c_str());
	}

	if (ret == 0)
	{
		dir = dir + "\\" + CConfig::getInstance()->cfg_run_stage;
		ret = make_dir(dir.c_str());
	}

	if (ret == 0)
	{
		dir = dir + "\\" + CConfig::getInstance()->cfg_station_id;
		ret = make_dir(dir.c_str());
	}

	if (ret == 0)
	{
		dir = dir + "\\" + CConfig::getInstance()->cfg_device_id;
		ret = make_dir(dir.c_str());
	}

	test_mode.push_back(PATH_ONLINE);
	test_mode.push_back(PATH_OFFLINE);
	test_mode.push_back(PATH_QTR);

	for each (string mode in test_mode)
	{
		string s = dir + "\\" + mode;
		ret = make_dir(s.c_str());

		s = dir + "\\" + mode + "\\PASS";
		ret = make_dir(s.c_str());

		s = dir + "\\" + mode + "\\FAIL";
		ret = make_dir(s.c_str());
	}
	
	if (ret != 0)
	{
		errno_t err;
		_get_errno(&err);
		string msg = "Folder \"" + dir + "\" was not created.";
		::MessageBoxA(NULL, msg.c_str(), "error", 0);
	}
}

int make_dir(const char *dir)
{
	int ret = _mkdir(dir);
	if (ret != 0)
	{
		errno_t err;
		_get_errno(&err);
		if (err == EEXIST)
			ret = 0;
	}
	return ret;
}

void remove_all_files(const char* dir)
{
	std::vector<std::string> files;

	get_files(dir, files);
	for (unsigned int i = 0; i<files.size(); i++)
	{
		if (remove(files[i].c_str()) != 0)
		{
			::OutputDebugStringA("Error deleting file");
		}
	}
}

void get_files(const char* dir, vector<string>& files)
{
	WIN32_FIND_DATAA find_data;
	HANDLE find_handle = INVALID_HANDLE_VALUE;
	string full_name = dir;

	files.clear();
	full_name += "\\*.*";
	find_handle = FindFirstFileA(full_name.c_str(), &find_data);
	if (find_handle != INVALID_HANDLE_VALUE)
	{
		if ((find_data.dwFileAttributes & (FILE_ATTRIBUTE_ARCHIVE | FILE_ATTRIBUTE_NORMAL)) != 0x00)
		{
			full_name = dir;
			full_name = full_name + "\\" + find_data.cFileName;
			files.push_back(full_name);
		}
		while (FindNextFileA(find_handle, &find_data) != 0)
		{
			if ((find_data.dwFileAttributes & (FILE_ATTRIBUTE_ARCHIVE | FILE_ATTRIBUTE_NORMAL)) != 0x00)
			{
				full_name = dir;
				full_name = full_name + "\\" + find_data.cFileName;
				files.push_back(full_name);
			}
		}
		FindClose(find_handle);
	}
	else
	{
		char temp[128];
		sprintf_s(temp, "Invalid file handle. Error is %u.\n", GetLastError());
		::OutputDebugStringA(temp);
	}
}

void connect_net_neighbor()
{
	int ret = S_FALSE;

	if ((CConfig::getInstance()->cfg_server_log.user_name != "") || (CConfig::getInstance()->cfg_server_log.user_pwd != ""))
	{
		ret = ConnectNetNeighbor(CConfig::getInstance()->cfg_server_log.directory.c_str(), CConfig::getInstance()->cfg_server_log.user_name.c_str(), CConfig::getInstance()->cfg_server_log.user_pwd.c_str());
		if (ret != NO_ERROR)
		{
			char errmsg[256];
			sprintf_s(errmsg, "Failed to connect net neighbor. Please check the remote path, id or password.\nError code:%d", ret);
			::MessageBoxA(NULL, errmsg, "MultiTest", MB_OK + MB_ICONWARNING);
		}
		return;
	}
}

