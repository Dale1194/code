#include "stdafx.h"
#include "UIReponse.h"
#include "pegalib.h"
#include "Config.h"


CUIReponse::CUIReponse(HWND hwnd, int id_no, const char* id_name) :m_hwnd(hwnd), m_id_no(id_no), m_id_name(id_name)
{
}


CUIReponse::~CUIReponse()
{
}


void CUIReponse::EnableButton(bool b)
{
	::PostMessageA(this->m_hwnd, WM_BUTTON_ENABLE, this->m_id_no, (b == true) ? 1 : 0);
}

void CUIReponse::UpdateTimer(const char* data)
{
	char* p = new char[12];
	strcpy_s(p, 12, data);
	::PostMessageA(this->m_hwnd, WM_TIMER_UPDATE, this->m_id_no, (LPARAM)p);
}

void CUIReponse::UpdateIsn(const char* data)
{
	char* p = new char[128];
	strcpy_s(p, 128, data); 
	::PostMessageA(this->m_hwnd, WM_ISN_UPDATE, this->m_id_no, (LPARAM)p);
}

void CUIReponse::UpdateStatus(const char* data)
{
	char* p = new char[32];
	strcpy_s(p, 32, data); 
	::PostMessageA(this->m_hwnd, WM_STATUS_UPDATE, this->m_id_no, (LPARAM)p);
}

void CUIReponse::UpdateCount(const char* data)
{
	char* p = new char[32];
	strcpy_s(p, 32, data);
	::PostMessageA(this->m_hwnd, WM_COUNT_UPDATE, this->m_id_no, (LPARAM)p);
}

void CUIReponse::UpdateProgress(int step)
{
	::PostMessageA(this->m_hwnd, WM_PROGRESS_UPDATE, this->m_id_no, (LPARAM)step);
}

void CUIReponse::SetRangeProgress(int range)
{
	::PostMessageA(this->m_hwnd, WM_PROGRESS_RANGE, this->m_id_no, (LPARAM)range);
}

void CUIReponse::SetMaxProgress()
{
	::PostMessageA(this->m_hwnd, WM_PROGRESS_MAX, this->m_id_no, 0);
}

void CUIReponse::SetTextProgress(const char* data)
{
	/*char* p = new char[64];
	strcpy_s(p, 64, data);
	::PostMessageA(this->m_hwnd, WM_PROGRESS_TEXT, this->m_id_no, (LPARAM)p);*/
}

void CUIReponse::SetInfo(const char* item, CSfisCsv::Status stat, const char* value, const char* uplimit, const char* downlimit)
{
	if (CConfig::getInstance()->cfg_show_detail == true)
	{
		int len = strlen(item) + strlen(value) + strlen(uplimit) + strlen(downlimit) + 10;
		char* p = new char[len];
		sprintf_s(p, len, "%s,%s,%s,%s,%s", item, (stat == CSfisCsv::Pass ? "0" : "1"), value, uplimit, downlimit);
		::PostMessageA(this->m_hwnd, WM_SET_INFO, this->m_id_no, (LPARAM)p);
	}
}

void CUIReponse::PopupInputForm(HANDLE handle, const char* title1, const char* reg1, const char* title2, const char* reg2, const char* title3, const char* reg3)
{
	char delim[] = { 0x7f, 0x00 };
	unsigned int len = strlen(title1) + strlen(reg1) + strlen(title2) + strlen(reg2) + strlen(title3) + strlen(reg3) + 10;
	char* p = new char[len];

	sprintf_s(p, len, "%d%s%s%s%s%s%s%s%s%s%s%s%s", this->m_id_no, delim, title1, delim, reg1, delim, title2, delim, reg2, delim, title3, delim, reg3);
	::PostMessageA(this->m_hwnd, WM_POPUP_INPUT_FORM, (WPARAM)handle, (LPARAM)p);
}

void CUIReponse::ClearInfo()
{
	::PostMessageA(this->m_hwnd, WM_CLEAR_INFO, this->m_id_no, 0);
}

void CUIReponse::ZipFile(HANDLE handle, const char* source_dir, const char* dest_zip_name)
{
	char delim[] = { 0x7f, 0x00 };
	unsigned int len = strlen(source_dir) + strlen(dest_zip_name) + 10;
	char* p = new char[len];

	sprintf_s(p, len, "%d%s%s%s%s", this->m_id_no, delim, source_dir, delim, dest_zip_name);
	::PostMessageA(this->m_hwnd, WM_ZIP_FILE, (WPARAM)handle, (LPARAM)p);
}

void CUIReponse::PopupPicMsgForm(HANDLE handle, const char* pic, const char* desc, const int btn_num)
{
	char delim[] = { 0x7f, 0x00 };
	unsigned int len = strlen(this->m_id_name.c_str()) + strlen(pic) + strlen(desc) + 20;
	char* p = new char[len];

	sprintf_s(p, len, "%d%s%s%s%s%s%s%s%d", this->m_id_no, delim, this->m_id_name.c_str(), delim, pic, delim, desc, delim, btn_num);
	::PostMessageA(this->m_hwnd, WM_PIC_MSG_FORM, (WPARAM)handle, (LPARAM)p);
}

//susu add 20241004
void CUIReponse::PopupPicMsgFormClose()
{
	char delim[] = { 0x7f, 0x00 };
	unsigned int len = strlen(this->m_id_name.c_str()) + 20;
	char* p = new char[len];

	sprintf_s(p, len, "%d%s%s", this->m_id_no, delim, this->m_id_name.c_str());
	::PostMessageA(this->m_hwnd, WM_PIC_MSG_FORM_CLOSE, NULL, (LPARAM)p);
}


