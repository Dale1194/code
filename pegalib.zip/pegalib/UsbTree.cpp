#include "stdafx.h"
#include "UsbTree.h"
#include "Config.h"
#include "CommonApi.h"
#include <regex>


CUsbTree::CUsbTree() :m_units_config(NULL)
{
}


CUsbTree::~CUsbTree()
{
}

int CUsbTree::GetAdbDeviceId(const char* usb_path, string& dev_id)
{
	int ret = -1;
	map<string, string> path_devid;

	if (get_port_chain_adb_devid_map(path_devid) == 0)
	{
		if (path_devid.find(usb_path) != path_devid.end())
		{
			dev_id = path_devid[usb_path];
			ret = 0;
		}
	}

	return ret;
}

int CUsbTree::get_port_chain_adb_devid_map(map<string, string>& path_devid)
{
	int ret = -1;
	char find_a[64];
	char find_b[64] = { "============== USB Port" };
	size_t p;
	size_t q;
	string dev_info;
	string dos_result;
	string data;

	string reg_rule = "iSerialNumber\\s*:\\s[\\w]*\\r\\n\\sLanguage\\s[\\w]*\\s*:\\s\"[\\w]*(?=\")";
	smatch reg_result;
	std::tr1::regex	rx;
	rx.assign(reg_rule, regex_constants::icase);

	if (m_units_config == NULL)
	{
		CConfig::getInstance()->GetUnitConfig(m_units_config);

		for (unsigned int i = 0; i < m_units_config.size(); i++)
		{
			if (m_units_config[i]["Enable"].asBool() == true)
			{
				m_dev_path.push_back(m_units_config[i]["DevicePath"].asString());
			}
		}
	}

	ret = m_dos.Send("UsbTreeView.exe /r:usbtree.txt", dos_result, 9000);

	if (ret == ERROR_SUCCESS)
	{
		ReadFileBin("usbtree.txt", data);

		for each (string chain in m_dev_path)
		{
			sprintf_s(find_a, "Port Chain               : %s\r\n", chain.c_str());
			p = data.find(find_a);
			if (p != string::npos)
			{
				q = data.find(find_b, p);
			}

			if ((p != string::npos) && (q != string::npos))
			{
				dev_info = data.substr(p, q - p);
				if (regex_search(dev_info, reg_result, rx) == true)
				{
					string s = reg_result[0].str();
					p = s.find('"');
					path_devid[chain] = s.substr(p + 1);
					ret = 0;
				}
			}
		}
	}
	else
		::OutputDebugStringA("[fox] failed to exec \"UsbTreeView.exe /r:usbtree.txt\"");

	return ret;
}

int CUsbTree::GetComPort(const char* usb_path, string& com_port)
{
	int ret = S_FALSE;
	char find_a[64];
	char find_b[64] = { "============== USB Port" };
	size_t p;
	size_t q;
	string dev_info;
	string dos_result;
	string data;
	
	string reg_rule = "COM-Port\\s+:\\s(COM\\d+)\\s";
	smatch reg_result;
	std::tr1::regex	rx;
	rx.assign(reg_rule, regex_constants::icase);

	ret = m_dos.Send("UsbTreeView.exe /r:usbtree.txt", dos_result, 9000);

	if (ret == ERROR_SUCCESS)
	{
		ret = S_FALSE;
		ReadFileBin("usbtree.txt", data);

		sprintf_s(find_a, "Port Chain               : %s\r\n", usb_path);
		p = data.find(find_a);
		if (p != string::npos)
		{
			q = data.find(find_b, p);
		}

		if ((p != string::npos) && (q != string::npos))
		{
			dev_info = data.substr(p, q - p);
			if (regex_search(dev_info, reg_result, rx) == true)
			{
				string s = reg_result[1].str();
				com_port = s;
				ret = S_OK;
			}
		}
	}
	else
		::OutputDebugStringA("[fox] failed to exec \"UsbTreeView.exe /r:usbtree.txt\"");

	return ret;
}

//int CUsbTree::GetComPort(const char* usb_path, string& com_port)
//{
//	int ret = S_FALSE;
//	map<string, string> path_comport;
//
//	if (get_port_chain_com_port_map(path_comport) == S_OK)
//	{
//		if (path_comport.find(usb_path) != path_comport.end())
//		{
//			com_port = path_comport[usb_path];
//			ret = S_OK;
//		}
//	}
//
//	return ret;
//}

int CUsbTree::get_port_chain_com_port_map(map<string, string>& path_comport)
{
	int ret = S_FALSE;
	char find_a[64];
	char find_b[64] = { "============== USB Port" };
	size_t p;
	size_t q;
	string dev_info;
	string dos_result;
	string data;

	string reg_rule = "COM-Port\\s+:\\s(COM\\d+)\\s";
	smatch reg_result;
	std::tr1::regex	rx;
	rx.assign(reg_rule, regex_constants::icase);

	if (m_units_config == NULL)
	{
		CConfig::getInstance()->GetUnitConfig(m_units_config);

		for (unsigned int i = 0; i < m_units_config.size(); i++)
		{
			if (m_units_config[i]["Enable"].asBool() == true)
			{
				m_dev_path.push_back(m_units_config[i]["DevicePath"].asString());
			}
		}
	}

	ret = m_dos.Send("UsbTreeView.exe /r:usbtree.txt", dos_result, 9000);

	if (ret == ERROR_SUCCESS)
	{
		ret = S_FALSE;
		ReadFileBin("usbtree.txt", data);

		for each (string chain in m_dev_path)
		{
			sprintf_s(find_a, "Port Chain               : %s\r\n", chain.c_str());
			p = data.find(find_a);
			if (p != string::npos)
			{
				q = data.find(find_b, p);
			}

			if ((p != string::npos) && (q != string::npos))
			{
				dev_info = data.substr(p, q - p);
				if (regex_search(dev_info, reg_result, rx) == true)
				{
					string s = reg_result[1].str();
					path_comport[chain] = s;
					ret = S_OK;
				}
			}
		}
	}
	else
		::OutputDebugStringA("[fox] failed to exec \"UsbTreeView.exe /r:usbtree.txt\"");

	return ret;
}
