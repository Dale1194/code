#include <string>
#include <iostream>
#include <fstream>
#include "csvfile.h"
#include "CommonApi.h"



using namespace std;

#pragma once

namespace Assembly
{
	static CCriticalSection g_assembly_cs;
};


class CAssemblyInfo
{
public:
	string manufacturer;
	string location;
	string work_order;
	string device_config;
	string parent_serial_number;
	string parent_gpn;
	string parent_mpn;
	string child_serial_number;
	string child_lot_number;
	string child_gpn;
	string child_mpn;
	string child_quantity;
	string child_location;
	string child_part_type;
	string station_name;
	string station_id;
	string station_type;
	string data_time;
	string build_phase;
};


class CAssembly : public CCSvFile
{
private:
	CAssembly() : CCSvFile("", "") {
	};

public:
	~CAssembly() {
	};

	static CAssembly* getInstance() {
		static auto_ptr<CAssembly> pObj(new CAssembly);
		return pObj.get();
	};

	void SetPathName(const char* name, const char* dir) {
		m_file_name = name;
		strcpy_s(m_rdlog_dir, dir);
		m_full_name = dir;
		m_full_name = m_full_name + "\\" + m_file_name + ".csv";
	}

	void WriteCAssembly(CAssemblyInfo& info, bool current_datatime = true) {
		char datetime[32];
		string data;
		string file;

		if (current_datatime == true) {
			GetDateTime(datetime, _countof(datetime));
			info.data_time = datetime;
		}

		data = info.manufacturer + "," + info.location + "," + info.work_order + "," + info.device_config + "," + info.parent_serial_number + ","
			+ info.parent_gpn + "," + info.parent_mpn + "," + info.child_serial_number + "," + info.child_lot_number + "," 
			+ info.child_gpn + "," + info.child_mpn + "," + info.child_quantity + "," + info.child_location + "," 
			+ info.child_part_type + "," + info.station_name + "," + info.station_id + "," + info.station_type + ","
			+ info.data_time + "," + info.build_phase + "\n";

		if (!IsFileExist(m_full_name)) {
			WriteLog("MANUFACTURER,LOCATION,WORK_ORDER,DEVICE_CONFIG,PARENT_SERIAL_NUMBER,PARENT_GPN,PARENT_MPN,CHILD_SERIAL_NUMBER,CHILD_LOT_NUMBER,CHILD_GPN,CHILD_MPN,CHILD_QUANTITY,CHILD_LOCATION,CHILD_PART_TYPE,STATION_NAME,STATION_ID,STATION_TYPE,DATE_TIME,BUILD_PHASE\n");
		}
		WriteLog(data.c_str());
	}
};