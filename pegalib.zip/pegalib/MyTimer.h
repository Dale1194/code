#include "MyEvent.h"
#include "UIReponse.h"
#include <string>

using namespace std;

#pragma once

class CMyTimer
{
public:
	CMyTimer(void);
	CMyTimer(CUIReponse* ui);
public:
	virtual ~CMyTimer(void);

public:
	void Start();
	void Stop();
	void Join(DWORD timeout = INFINITE);
	
private:
	bool is_running();
	static DWORD WINAPI start_thread(LPVOID);
	void start_imp();
	
private:
	CUIReponse* m_ui;
	HANDLE m_thread;
	CMyEvent m_terminate_event;
};
