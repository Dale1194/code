
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include "CommonApi.h"
#include "UIReponse.h"
#include "DOSCommand.h"
#include <Shlwapi.h>



using namespace std;

#pragma once

class CGucciZip
{
public:
	CGucciZip(CUIReponse* ui) {
		m_ui = ui;
	};
	
	virtual ~CGucciZip(void) {
	};

	void CreateSourceDir(const char* dir) {
		m_source_dir = dir;
		CreateFolder(dir);
		m_attachments_dir = dir + string("\\attachments");
		CreateFolder(m_attachments_dir.c_str());
	}

   /** 
	* was waived.
	* The zip file can not be unzip on linux.
    */
	/*int StartZip(const char* zip_name) {
		HANDLE event;

		event = CreateEvent(NULL, TRUE, FALSE, NULL);
		ResetEvent(event);

		m_dest_zip_name = zip_name;
		m_ui->ZipFile(event, m_source_dir.c_str(), m_dest_zip_name.c_str());

		WaitForSingleObject(event, INFINITE);
		CloseHandle(event);

		return 0;
	}*/

	int StartZip(const char* zip_name) {
		int ret = S_FALSE;
		CDOS dos;
		m_dest_zip_name = zip_name;
		string cmd = "7z.exe a " + m_dest_zip_name + " " + m_source_dir + "\\*";
		string result;

		dos.Send(cmd.c_str(), result, 20000);
		if (result.find("Everything is Ok") != string::npos)
			ret = S_OK;
		else
		{
			if (::PathFileExistsA(m_dest_zip_name.c_str()) && GetFileSize(m_dest_zip_name.c_str()) > 100)
				ret = S_OK;
		}

		return ret;
	}
		
private:
	CUIReponse* m_ui;
	string m_source_dir;
	string m_dest_zip_name;
	string m_attachments_dir;
};
