
#include <string>
#include <iostream>
#include <fstream>
#include "csvfile.h"
#include "CommonApi.h"



#define IMPORTANT(x) ((x)==true?"TRUE":"FALSE")
using namespace std;

#pragma once

class CGmeasurement : public CCSvFile
{
public:
	enum Status {
		Pass,
		Fail,
		Error,
		Timeout,
	};

private:
	map<Status, string> m_status;

public:
	CGmeasurement(const char* name, const char* dir) : CCSvFile(name, dir) {

		WriteLog("NAME,DESCRIPTION,IMPORTANT,STATUS,DATE_TIME,NUMERIC_VALUE,NUMERIC_MAX,NUMERIC_MIN,UNIT,TEXT_VALUE,EXPECTED_TEXT_VALUE,NUMERIC_VALUE_LIST,TEXT_VALUE_LIST\n");

		m_status[Pass] = "PASS";
		m_status[Fail] = "FAIL";
		m_status[Error] = "ERROR";
		m_status[Timeout] = "TIMEOUT";
	};

	~CGmeasurement() {
	};
	
	void WriteRow(const char* name, const char* description, bool important, Status status, double num_value, double num_max, double num_min, const char* unit) {
		WriteRow(name, description, important, status, num_value, num_max, num_min, unit, "", "", "\"\"", "\"\"");
	}

	void WriteRow(const char* name, const char* description, bool important, Status status, double num_value, double num_max, double num_min, const char* unit, const char *fmt, ...) {
		char buffer[2048];
		va_list	list;

		va_start(list, fmt);
		vsprintf_s(buffer, _countof(buffer), fmt, list);
		va_end(list);

		WriteRow(name, description, important, status, num_value, num_max, num_min, unit, "", "", buffer, "\"\"");
	}

	void WriteRow(const char* name, const char* description, bool important, Status status, double num_value, double num_max, double num_min, const char* unit, const char* text_value, const char* expected_text_value, const char* num_value_list, const char* text_value_list) {
		char datetime[32];

		GetSystemDateTime(datetime, _countof(datetime));
		WriteLogf("%s,%s,%s,%s,%s,%.4f,%.4f,%.4f,%s,%s,%s,%s,%s", name, description, IMPORTANT(important), m_status[status].c_str(), datetime, num_value, num_max, num_min, unit, text_value, expected_text_value, num_value_list, text_value_list);
	}

	void WriteRow(const char* name, const char* description, bool important, Status status, const char* text_value, const char* expected_text_value) {
		WriteRow(name, description, important, status, "", "", "", "", text_value, expected_text_value, "\"\"", "\"\"");
	}

	void WriteRow(const char* name, const char* description, bool important, Status status, const char* text_value, const char* expected_text_value, const char *fmt, ...) {
		char buffer[2048];
		va_list	list;

		va_start(list, fmt);
		vsprintf_s(buffer, _countof(buffer), fmt, list);
		va_end(list);

		WriteRow(name, description, important, status, "", "", "", "", text_value, expected_text_value, "\"\"", buffer);
	}

	void WriteRow(const char* name, const char* description, bool important, Status status, const char* num_value, const char* num_max, const char* num_min, const char* unit, const char* text_value, const char* expected_text_value, const char* num_value_list, const char* text_value_list) {
		char datetime[32];

		GetSystemDateTime(datetime, _countof(datetime));
		WriteLogf("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s", name, description, IMPORTANT(important), m_status[status].c_str(), datetime, num_value, num_max, num_min, unit, text_value, expected_text_value, num_value_list, text_value_list);
	}
};