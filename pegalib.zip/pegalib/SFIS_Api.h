#ifndef _SFIS_API_H
#define _SFIS_API_H

#include "SFIS_ExportApi.h"
#include "SfisCsv.h"
#include <memory>
#include <string>
#include "ErrorCode.h"
#include "CommonApi.h"

using namespace std;

class CSFIS_Api
{
private:
	CSFIS_Api();

public:
	virtual ~CSFIS_Api();
	
	static CSFIS_Api* getInstance() {
		static auto_ptr<CSFIS_Api> pObj(new CSFIS_Api);
		return pObj.get();
	};

public:
	// Member Function
	INT LOAD_DLL();
	INT UNLOAD_DLL(VOID);
    
	HINSTANCE               m_hDLL;   
    SFIS_CONNECT			m_pfnSFIS_Connect;
    SFIS_DISCONNECT			m_pfnSFIS_Disconnect;
    SFIS_LOGIN              m_pfnSFIS_Login;
    SFIS_CHECKROUTE         m_pfnSFIS_CheckRoute;
    SFIS_TESTRESULT         m_pfnSFIS_TestResult;
    SFIS_REPAIR             m_pfnSFIS_Repair;
    SFIS_GENERRORCODE       m_pfnSFIS_GenErrorCode;
	SFIS_GETVERSION			m_pfnSFIS_GetVersion;
	SFIS_GETI1394			m_pfnSFIS_GetI1394;
	SFIS_GETIMAC			m_pfnSFIS_GetIMAC;
	SFIS_LOADKEY			m_pfnSFIS_LoadKey;
	
	CHAR					m_szINIFile[MAX_PATH];
	CHAR                    m_szDLLFile[MAX_PATH];

public:
	SFIS_INTERFACE m_sfis_st;

	int Init(SFIS_INTERFACE& sfis_st);
	int CheckConnection();
	int Login(const char* user_id);
	int Logout();

	int GenerateErrorCode(const char* csv_file, string& error_code);
	int GenerateErrorCode(CSfisCsv* sfis_csv, string& err_code);
	void ListItemsWithoutErrorCode(CSfisCsv* sfis_csv, string& items);

private:
	void output_debug(char *fmt, ...);

	CErrorCode*		m_err_code;
};

#endif /* #pragma once */