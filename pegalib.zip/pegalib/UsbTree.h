#pragma once

#include "DOSCommand.h"
#include <memory>
#include <string>
#include <vector>
#include <map>
#include "include/json/json.h"

using namespace std;

class CUsbTree
{
private:
	CUsbTree();


public:
	static CUsbTree* getInstance() {
		static auto_ptr<CUsbTree> pObj(new CUsbTree);
		return pObj.get();
	};

	~CUsbTree();

	int GetAdbDeviceId(const char* usb_path, string& dev_id);
	int GetComPort(const char* usb_path, string& dev_id);


private:
	int get_port_chain_adb_devid_map(map<string, string>& path_devid);
	int get_port_chain_com_port_map(map<string, string>& path_devid);


private:
	CDOS			m_dos;
	Json::Value		m_units_config;
	vector<string>	m_dev_path;

};

