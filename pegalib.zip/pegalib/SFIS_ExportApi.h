/*******************************************************************************
 * Copyright Statement:
 * --------------------
 *  ATS Team Engineer, HHD ODM BU-ATS Dept.
 *  ASUSTek Computer Inc. (C) 2005-2008
 *  BU3-SW Div.-ATS Dept.-Sec.1
 *  PEGATRON Corporation (C) 2008-2011
 *******************************************************************************/

/*******************************************************************************
 *==============================================================================
 * Filename:
 * ---------
 *  SFIS_ExportApi.h
 *
 * Compiler:
 * --------
 *  Visual C++ 2005 / 2010
 *
 * Description:
 * ------------
 *  SFIS TEST Program Access Interface.
 *	SFIS Web Service with SOAP for Production Test
 *
 * Author:
 * -------
 *  Achigo Liu 	( Achigo_Liu@pegatroncorp.com )
 *
 *	[SFIS.dll]
 *	Rev 1.0.0	Nov 09 2005
 *	Rev 1.1.0	Nov 12 2005		Add CoInitialize for COM Object function.
 *	Rev 1.2.0	Nov 17 2005		Add Return Error Test Name if not find in ERROR.txt
 *	Rev 1.2.1	Nov 19 2005		Modify pAuth = &g_iUserAuth => *pAuth = g_iUserAuth
 *	Rev 1.3.0	Nov 19 2005		Modify Functions to get params from SFIS.ini and LoingID to strupr
 *	Rev 1.3.1	Jun 09 2006		Code Review for iPod
 *	Rev 2.0.0	Jun 15 2006		SFIS Class
 *	Rev 2.0.2	Sep 04 2006		Add SFIS_START parameter
 *	Rev 2.0.3	Oct 05 2006		For TY
 *	Rev 2.0.4	Nov 06 2006		For TY add SFIS_DevMO
 *	Rev 3.0.0	May 24 2007		Merge All SFIS.dll Version
 *	Rev 3.2.0	May 24 2007		Add AOILoc for 1 to 8 Panel
 *	Rev 4.0.0	Jan 24 2008		Modify INI [SFIS_SETTING]
 *	Rev 4.1.0	Jul 31 2008		Modify ::CoInitialize()
 *	Rev 4.2.0	Nov 01 2009		Add LoadKey Stored Procedure
 *	Rev 5.1.0	Jan 06 2011		Modify GetGUID to GetI1394 and add GetIMAC for Fish
 *
 *	[SFISWS.dll]
 *  Rev	1.0.0	2009/08/31
 *  Rev	1.0.1	2010/03/31		Add into Skeleton
 *  Rev	1.0.2	2011/05/04		Add GetIMAC and GetI1394
 *==============================================================================
 *******************************************************************************/
 
#ifndef _SFIS_EXPORTAPI_H
#define _SFIS_EXPORTAPI_H

namespace SFIS_EXPORTAPI
{

#define SP_LOGIN			"1"	// Login
#define SP_LOGOUT			"2"	// Logout
#define SP_LOGIN_ENFORCE	"3"	// Login Enforce (Not Support)
#define SP_LOGIN_QUERY		"4"	// Login Query
#define SP_LOGIN_CHECK		"5"	// Login Check


typedef struct _SFIS_INTERFACE
{
	CHAR	szINIFile[256];
	CHAR	szMessage[4096];
	CHAR	szISN[128];
	CHAR	szDeviceID[16];
	CHAR	szTSP[32];
	CHAR	szUserID[16];
	CHAR	szUserPassword[16];
	CHAR	szUserName[32];
	CHAR	szUserAuth[32];
	CHAR	szCheckFlag[128];
	CHAR	szCheckData[128];
	CHAR	szCheckData2[128];
	CHAR	szCheckRouteType[4];
	CHAR	szTestResultType[4];
	CHAR	szAutoRepairType[4];
	CHAR	szAOILoc[16];
	CHAR	szGetVersionType[32];
	CHAR	szGetVersion[4096];
	CHAR	szErrorCode[16];
	CHAR	szErrorCodeFile[256];
	CHAR	szErrorItem[256];
	CHAR	szLogFile[256];
	CHAR	szLogStreamData[32767];
	CHAR	szReturn[32];
	CHAR	szLoginMode[4];
	CHAR	szLoadKeyType[32];
	
} SFIS_INTERFACE, *LPSFIS_INTERFACE;

// SFIS Setting
typedef struct _SFIS_SETTING {
	IN	CHAR	szSFISCheckRouteCriticalEnable[8];
	IN	BOOL	bSFISCheckRouteCriticalEnable;
} SFIS_SETTING, *LPSFIS_SETTING;


typedef enum SFIS_RETURN_TAG
{
	SFIS_CONNECT_FAIL			= 0x9001,
	SFIS_INITIAL_FAIL			= 0x9002,
	SFIS_LOGIN_FAIL				= 0x9003,
	SFIS_CHANGE_PASSWORD_FAIL	= 0x9004,
	SFIS_CHECKROUTE_FAIL		= 0x9005,
	SFIS_TESTRESULT_FAIL		= 0x9006,
	SFIS_REPAIR_FAIL			= 0x9007,
	SFIS_DISCONNECT_FAIL		= 0x9008,
	SFIS_GETI1394_FAIL			= 0x9009,
	SFIS_GETVERSION_FAIL		= 0x9010,
	SFIS_GENERRORCODE_FAIL		= 0x9011,
	SFIS_CHECK_FILE_FAIL		= 0x9012,
	SFIS_LOADKEY_FAIL			= 0x9013,
	SFIS_GETIMAC_FAIL			= 0x9014,

} E_SFIS_RETURN_TAG;

}
using namespace SFIS_EXPORTAPI;

#ifdef          __cplusplus
extern "C" {
#endif

#define         _SFIS_EXPORT_DLL
#ifdef          _SFIS_EXPORT_DLL
#define         SFIS_EXPORT          __declspec(dllexport)
#else
#define         SFIS_EXPORT          __declspec(dllimport)
#endif

typedef INT(WINAPI *SFIS_CONNECT)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_Connect(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_DISCONNECT)(VOID);
SFIS_EXPORT INT WINAPI SFIS_Disconnect(VOID);

typedef INT(WINAPI *SFIS_LOGIN)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_Login(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_CHECKROUTE)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_CheckRoute(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_TESTRESULT)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_TestResult(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_REPAIR)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_Repair(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_GETVERSION)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_GetVersion(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_GENERRORCODE)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_GenErrorCode(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_LOADKEY)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_LoadKey(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_CHANGEPASSWORD)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_ChangePassword(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_GETI1394)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_GetI1394(SFIS_INTERFACE &stSFIS);

typedef INT(WINAPI *SFIS_GETIMAC)(SFIS_INTERFACE &stSFIS);
SFIS_EXPORT INT WINAPI SFIS_GetIMAC(SFIS_INTERFACE &stSFIS);


/*
typedef INT(WINAPI *SFIS_CHECKROUTE)(CONST CHAR *pcISN, CONST CHAR *pcFlag, CONST CHAR *pcData, CONST INT iType, CONST CHAR *pcAOILoc, CHAR *pcMsg);
SFIS_EXPORT INT WINAPI SFIS_CheckRoute(CONST CHAR *pcISN, CONST CHAR *pcFlag, CONST CHAR *pcData, CONST INT iType, CONST CHAR *pcAOILoc, CHAR *pcMsg);

typedef INT(WINAPI *SFIS_TESTRESULT)(CONST CHAR *pcISN, CONST CHAR *pcErrorCode, CONST CHAR *pcData, CONST INT iType, CONST CHAR *pcAOILoc, CHAR *pcMsg);
SFIS_EXPORT INT WINAPI SFIS_TestResult(CONST CHAR *pcISN, CONST CHAR *pcErrorCode, CONST CHAR *pcData, CONST INT iType, CONST CHAR *pcAOILoc, CHAR *pcMsg);

typedef INT(WINAPI *SFIS_REPAIR)(CONST CHAR *pcISN, CONST INT iType, CONST CHAR *pcAOILoc, CHAR *pcMsg);
SFIS_EXPORT INT WINAPI SFIS_Repair(CONST CHAR *pcISN, CONST INT iType, CONST CHAR *pcAOILoc, CHAR *pcMsg);

tpedef INT(WINAPI *SFIS_GENERRORCODE)(CONST CHAR  *pcLogPath, CONST CHAR  *pcErrorPath, CHAR *pcErrorCode, CHAR *pcData, CHAR *pcErrorItem);
SFIS_EXPORT INT WINAPI SFIS_GenErrorCode(CONST CHAR  *pcLogPath, CONST CHAR *pcErrorPath, CHAR *pcErrorCode, CHAR *pcData, CHAR *pcErrorItem);

typedef INT(WINAPI *SFIS_CHANGEPASSWORD)(CONST CHAR *pcUserID, CONST CHAR *pcNewPassword, CHAR *pcMsg);
SFIS_EXPORT INT WINAPI SFIS_ChangePassword(CONST CHAR *pcUserID, CONST CHAR *pcNewPassword, CHAR *pcMsg);

typedef INT(WINAPI *SFIS_GETVERSION)(CONST CHAR *pcISN, CONST CHAR *pcType, CHAR *pcVersion, CHAR *pcRetMsg);
SFIS_EXPORT INT WINAPI SFIS_GetVersion(CONST CHAR *pcISN, CONST CHAR *pcType, CHAR *pcVersion, CHAR *pcRetMsg);

typedef INT(WINAPI *SFIS_GETGUID)(CONST CHAR *pcISN, CHAR *pcRetMsg);
SFIS_EXPORT INT WINAPI SFIS_GetGUID(CONST CHAR *pcISN, CHAR *pcRetMsg);

*/
#ifdef          __cplusplus
}
#endif

#endif // End of _SFIS_EXPORTAPI_H_


/* SFIS�T��

[LOGSTP]ORA-01461: can bind a LONG value only for insert into a LONG column(TSP_TRESULT)
=>�]���פj��Fred������Message���סA�ҥH�ɭP�L�k�e�WSFIS

SFIS:ISN OK[W/ERROR[1]]!! (U)(SM) TEST DATA:SAVED!(TSP_TRESULT)
=>SFIS���\�T��

EC SFIS:WRONG STEP 3![REPAIR OF TEST ATE1](C_R)?[M](SM)(TSP_TRESULT)
=>�w�g�e�LSFIS�F

EC:[NULL]WRONG ISN:[NULL]LENGTH !(CHK_ISN)?[M](SM)(TSP_TRESULT)
=>�]��p_Error�S��Error Code�ҥH���ӥH""�W��SFIS�A���Χ�ѼƳ]�w��"NULL"

WRONG STEP 3![REPAIR OF TEST ATE1](C_R)CHK_ROUTE_STEP_NSTEP RUN OK!?(TSP_CHKROUTE)
WRONG STEP 3![REPAIR OF TEST ATE1](C_R)CHK_ROUTE_STEP_NSTEP RUN OK!? TYPE:1 (TSP_CHKROUTE)
WRONG STEP 3![REPAIR OF TEST ATE1](C_R)CHK_ROUTE_STEP_NSTEP RUN OK!?[LR#:1][LF#:4] TYPE:1 (TSP_CHKROUTE)
=>�w�g�e�LSFIS�F

CHECK ROUTE OK!@<>CHK_ROUTE_STEP_NSTEP RUN OK!?
CHECK ROUTE OK!@<>CHK_ROUTE_STEP_NSTEP RUN OK!?[#4][MODEL:WGM1310][LR#:5][LF#:4]
=>CheckRoute ���\ (SFIS_CheckRoute(cISN,NULL,NULL,cMessage))

CHECK ROUTE OK!@<>
=>CheckRoute ���\ (SFIS_CheckRoute(cISN,"SSN","SSN",cMessage))

WRONG STEP 4[BACK:TEST ATE3]![O][E](C/SR(C_R)(TSP_CHKROUTE)
=>CheckRoute ����

SN:WSZP59000200645 MO_D UPDATE ERROR_SPR3(SP_REPAIR)(TSP_REPAIR)
=>

INVALID NGRP [TT2] IN ROUTE [GKP5](TSP_REPAIR) 
=>���ܦb GKP5 ���ɨS�� TT2 �o�����]�w, �i��O���H���b�ק� routing �]�w�y����

*/