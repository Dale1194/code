#include "StdAfx.h"
#include "Config.h"
#include "CommonApi.h"



CConfig::CConfig(const char* name) :m_config_name(""), m_sfis_ini("\\SFIS.ini"), ext_full_path(""), ext_full_server_path("")
{
	string			path;
	string			data;
	Json::Reader	reader;
	Json::Value		root;

	if (name == NULL && m_config_name.empty())
		assert(!"Object Config not init yet!");
	m_config_name = name;

	size_t pos;
	string f = m_config_name;
	pos = f.rfind('.');
	f.erase(pos);
	pos = f.rfind('\\') + 1;
	m_name_ = f.substr(pos);

	GetCurrentPath(path);

	m_sfis_ini = path + "" + m_sfis_ini;
	/*m_config_name = path + "" + m_config_name;*/
	
	ReadFileBin(m_config_name, data);

	if (reader.parse(data, root, false))
	{
		cfg_project_name = root["Initial_Setting"]["PROJECT_NAME"].asString();
		cfg_run_stage = root["Initial_Setting"]["RUN_STAGE"].asString();
		cfg_station_id = root["Initial_Setting"]["STATION_ID"].asString();
		cfg_log_dir = root["Initial_Setting"]["LOG_DIRECTORY"].asString();
		cfg_enable_gpib_log = root["Initial_Setting"]["ENABLE_GPIB_LOG"].asBool();
		//cfg_sfis_testresult = root["Initial_Setting"]["UI_SFIS_TESTRESULT"].asBool();
		cfg_enable_repair = root["Initial_Setting"]["SFIS_ENABLE_REPAIR"].asBool();
		cfg_sfis_repair_count = root["Initial_Setting"]["SFIS_REPAIR_COUNT"].asInt();
		cfg_auto_test_count = root["Initial_Setting"]["AUTO_TEST_COUNT"].asInt();
		cfg_fixture_id = root["Initial_Setting"]["FIXTURE_ID"].asString();
		cfg_fixture_index = root["Initial_Setting"]["FIXTURE_INDEX"].asString();
		cfg_line_num = root["Initial_Setting"]["LINE_NUMBER"].asString();
		cfg_show_detail = root["Initial_Setting"]["SHOW_DETAIL"].asBool();
		cfg_sfis_write_result_n_times_when_fail = root["Initial_Setting"]["SFIS_WRITE_RESULT_N_TIMES_WHEN_FAIL"].asInt();
		cfg_sfis_route_rule = root["Initial_Setting"]["SFIS_ROUTE_RULE"].asString();

		/*cfg_sfis_url = root["SFIS_Setting"]["SFIS_WEB_SERVICE_URL"].asString();
		cfg_sfis_tsp = root["SFIS_Setting"]["SFIS_TSP"].asString();
		cfg_device_id = root["SFIS_Setting"]["SFIS_DEVICE_ID"].asString();
		cfg_sfis_checkroute_type = root["SFIS_Setting"]["SFIS_CHECKROUTE_TYPE"].asInt();
		cfg_sfis_testresult_type = root["SFIS_Setting"]["SFIS_TESTRESULT_TYPE"].asInt();
		cfg_sfis_autorepair_type = root["SFIS_Setting"]["SFIS_AUTOREPAIR_TYPE"].asInt();*/

		cfg_new_sfis_dll = root["Initial_Setting"]["NEW_SFIS_DLL"].asBool();
		cfg_warning_when_item_not_in_criteria = GetValueBool(root, "Initial_Setting", "WARNING_WHEN_ITEM_NOT_IN_CRITERIA", true);
		cfg_debug_when_fail = root["Initial_Setting"]["DEBUG_WHEN_FAIL"].asBool();
		cfg_crash_backup = root["Initial_Setting"]["CRASH_BACKUP"];

		cfg_server_log.enable_save = root["Initial_Setting"]["SERVER_LOG"]["EnableSave"].asBool();
		cfg_server_log.directory = root["Initial_Setting"]["SERVER_LOG"]["Directory"].asString();
		cfg_server_log.user_name = root["Initial_Setting"]["SERVER_LOG"]["UserName"].asString();
		cfg_server_log.user_pwd = root["Initial_Setting"]["SERVER_LOG"]["UserPwd"].asString();
		cfg_server_log.no_debug_log_when_pass = root["Initial_Setting"]["SERVER_LOG"]["NoDebugLogWhenPass"].asBool();

		cfg_iplas.enable = root["Initial_Setting"]["IPLAS"]["Enable"].asBool();
		cfg_iplas.attached = root["Initial_Setting"]["IPLAS"]["Attached"];

		cfg_ftp.server_name = root["Initial_Setting"]["SERVER_FTP"]["ServerName"].asString();
		cfg_ftp.user_name = root["Initial_Setting"]["SERVER_FTP"]["UserName"].asString();
		cfg_ftp.user_pwd = root["Initial_Setting"]["SERVER_FTP"]["UserPwd"].asString();
		cfg_ftp.enable_save = root["Initial_Setting"]["SERVER_FTP"]["EnableSave"].asBool();


		m_priority_error_item = root["PRIORITY_ERROR_ITEM"];
		m_units = root["Units"];
		m_ports = root["ComPort"];
		m_gpibs = root["GPIBInst"];
		m_remots = root["RemoteInst"];
		m_robotarm = root["RobotArmCtrl"];
	}

	cfg_device_id = get_profile_string("SFIS_SETTING", "SFIS_DEVICE_ID");


	/*ext_full_path = ext_full_path + cfg_log_dir + "\\" + cfg_project_name + "\\" + cfg_run_stage + "\\" + cfg_station_id + "\\" + cfg_device_id;
	ext_full_server_path = ext_full_server_path + cfg_file_server_dir + "\\" + cfg_project_name + "\\" + cfg_run_stage + "\\" + cfg_station_id + "\\" + cfg_device_id;*/
	
	/*if (cfg_on_line == true)
	{
		ext_full_path += "\\ON_LINE";
		ext_full_server_path += "\\ON_LINE";
	}
	else
	{
		ext_full_path += "\\OFF_LINE";
		ext_full_server_path += "\\OFF_LINE";
	}*/
}

CConfig::~CConfig(void)
{
	
}

void CConfig::GetConfigFileName(string& name)
{
	name = m_name_;
}

const char* CConfig::GetConfigFileName()
{
	return m_name_.c_str();
}

bool CConfig::GetValueBool(Json::Value& root, const char* section, const char* key, bool val_default)
{
	if (root[section].isMember(key))
		return root[section][key].asBool();
	return val_default;
}

void CConfig::GetUnitConfig(const char* name, Json::Value& config)
{
	for (unsigned int i = 0; i < m_units.size(); i++)
	{
		if (m_units[i]["Name"].asString().compare(name) == 0)
		{
			config = m_units[i];
			break;
		}
	}
}

void CConfig::GetUnitConfig(Json::Value& config)
{
	config = m_units;
}

int CConfig::GetPortByUnit(const char* unit_name, const char* port_name, string& real_portname)
{
	int ret = S_FALSE;
	Json::Value ports_map;
	string port_key;

	for (unsigned int i = 0; i < m_units.size(); i++)
	{
		if (m_units[i]["Name"].asString().compare(unit_name) == 0)
		{
			ports_map = m_units[i]["ComPort"];
			break;
		}
	}

	for (unsigned int i = 0; i < ports_map.size(); i++)
	{
		port_key = ports_map.getMemberNames()[i];
		if (port_key == port_name)
		{
			real_portname = ports_map[port_key].asString();
			ret = S_OK;
			break;
		}
	}

	return ret;
}

void CConfig::GetPorts(const char* name, Json::Value& port)
{
	for (unsigned int i = 0; i < m_ports.size(); i++)
	{
		if (m_ports[i]["Name"].asString().compare(name) == 0)
		{
			port = m_ports[i];
			break;
		}
	}
}

void CConfig::GetPorts(Json::Value& ports)
{
	ports = m_ports;
}

int CConfig::GetGPIBByUnit(const char* unit_name, const char* gpib_name, string& real_gpibname)
{
	int ret = S_FALSE;
	Json::Value gpibs_map;
	string port_key;

	for (unsigned int i = 0; i < m_units.size(); i++)
	{
		if (m_units[i]["Name"].asString().compare(unit_name) == 0)
		{
			//string str = m_units[i]["GPIBInst"].asString();
			gpibs_map = m_units[i]["GPIBInst"];
			break;
		}
	}

	for (unsigned int i = 0; i < gpibs_map.size(); i++)
	{
		port_key = gpibs_map.getMemberNames()[i];
		if (port_key == gpib_name)
		{
			real_gpibname = gpibs_map[port_key].asString();
			ret = S_OK;
			break;
		}
	}

	return ret;
}

void CConfig::GetGPIBs(const char* name, Json::Value& config)
{
	for (unsigned int i = 0; i < m_gpibs.size(); i++)
	{
		if (m_gpibs[i]["Name"].asString().compare(name) == 0)
		{
			config = m_gpibs[i];
			break;
		}
	}
}

void CConfig::GetGPIBs(Json::Value& config)
{
	config = m_gpibs;
}

void CConfig::GetRemots(const char* name, Json::Value& config)
{
	for (unsigned int i = 0; i < m_remots.size(); i++)
	{
		if (m_remots[i]["Name"].asString().compare(name) == 0)
		{
			config = m_remots[i];
			break;
		}
	}
}

void CConfig::GetRemots(Json::Value& config)
{
	config = m_remots;
}

void CConfig::GetRobotArmCtrl(Json::Value& config)
{
	config = m_robotarm;
}

int CConfig::GetPriorotyErrorCode(const char* items, string& err_item, string& err_code)
{
	int ret = -1;
	for each (string item in m_priority_error_item.getMemberNames())
	{
		if (strstr(items, item.c_str()))
		{
			err_item = item;
			err_code = m_priority_error_item[item].asString();
			ret = 0;
			break;
		}
	}

	return ret;
}

string CConfig::get_profile_string(const char* app_name, const char* key_name)
{
	char temp[MySize];
	GetPrivateProfileStringA(app_name, key_name, "", temp, MySize, m_sfis_ini.c_str());

	return string(temp);
}

