#pragma once

#include <memory>
#include <string>
#include <vector>
#include "include/json/json.h"

using namespace std;

class CConfig
{
	enum e_arraySize { MySize = 512, };

private:


public:
	string	cfg_project_name;
	string	cfg_run_stage;
	string	cfg_station_id;
	string	cfg_log_dir;
	bool	cfg_enable_gpib_log;
	//bool	cfg_on_line;
	//bool	cfg_sfis_testresult;
	bool	cfg_enable_repair;
	int		cfg_sfis_repair_count;
	int		cfg_auto_test_count;
	string	cfg_fixture_id;
	string	cfg_fixture_index;
	string	cfg_line_num;
	bool	cfg_show_detail;
	int		cfg_sfis_write_result_n_times_when_fail;
	string	cfg_sfis_route_rule;

	bool	cfg_auto_start_test;

	/*string	cfg_sfis_url;
	string	cfg_sfis_tsp;*/
	string	cfg_device_id;
	/*int		cfg_sfis_checkroute_type;
	int		cfg_sfis_testresult_type;
	int		cfg_sfis_autorepair_type;*/
	std::vector<string> cfg_priority_error_item;
	std::vector<string> cfg_priority_error_code;
	bool	cfg_new_sfis_dll;
	bool	cfg_warning_when_item_not_in_criteria;
	bool	cfg_debug_when_fail;
	Json::Value	cfg_crash_backup;

	struct struct_server_log {
		bool enable_save;
		string directory;
		string user_name;
		string user_pwd;
		bool no_debug_log_when_pass;
	}cfg_server_log;

	struct struct_iplas {
		bool enable;
		Json::Value attached;
	}cfg_iplas;

	struct struct_ftp {
		string server_name;
		string user_name;
		string user_pwd;
		bool enable_save;
	}cfg_ftp;



public:
	string	m_config_name;
	string	m_name_;
	string	m_sfis_ini;
	string	ext_full_path;
	string	ext_full_server_path;


private:
	Json::Value		m_priority_error_item;
	Json::Value		m_units;
	Json::Value		m_ports;
	Json::Value		m_gpibs;
	Json::Value		m_remots;
	Json::Value		m_robotarm;

private:
	CConfig(const char* name);
public:
	~CConfig(void);
public:
	static CConfig* getInstance() {
		return Init(NULL);
	};

	static CConfig* Init(const char* name) {
		static auto_ptr<CConfig> pObj(new CConfig(name));
		return pObj.get();
	};

	void GetConfigFileName(string& name);
	const char* GetConfigFileName();

	bool GetValueBool(Json::Value& root, const char* section, const char* key, bool val_default);
	void GetUnitConfig(const char* name, Json::Value& config);
	void GetUnitConfig(Json::Value& config);
	int GetPortByUnit(const char* unit_name, const char* port_name, string& real_portname);
	void GetPorts(const char* name, Json::Value& config);
	void GetPorts(Json::Value& config);
	int GetGPIBByUnit(const char* unit_name, const char* gpib_name, string& real_gpibname);
	void GetGPIBs(const char* name, Json::Value& config);
	void GetGPIBs(Json::Value& config);
	void GetRemots(const char* name, Json::Value& config);
	void GetRemots(Json::Value& config);
	void GetRobotArmCtrl(Json::Value& config);
	int GetPriorotyErrorCode(const char* items, string& err_item, string& err_code);

private:
	string get_profile_string(const char* app_name, const char* key_name);

};
