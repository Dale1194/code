#pragma once

#include <memory>
#include "include/json/json.h"

class CDataPool
{
private:
	CDataPool();

public:
	virtual ~CDataPool();

	static CDataPool* getInstance() {
		static std::auto_ptr<CDataPool> pObj(new CDataPool);
		return pObj.get();
	};

public:
	Json::Value m_datapool;
};

