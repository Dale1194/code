#include "stdafx.h"
#include "DataPool.h"
#include "CommonApi.h"

CCriticalSection g_datapool_cs;

CDataPool::CDataPool()
{
}


CDataPool::~CDataPool()
{
}
