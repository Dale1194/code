#pragma once

#include <string>
#include <winsock2.h>
#include <Ws2tcpip.h>
#include "..\outputlog\OutputDebug.h"
#include "..\outputlog\DebugMessage.h"

using namespace std;

class CMyTelnet
{
public:
	CMyTelnet();
	virtual ~CMyTelnet();
	char m_err_msg[256];

	char* GetErrMsg();
	int Connect(const char* addr, u_short port);
	void SkipInitScreen(string& src);
	int SendRecvStr(const char* send_str, std::string& recv_str, unsigned int timeout, const char* prompt);

	void AddOutput(COutputDebug* output);
	void RemoveOutput(COutputDebug* output);
	void OutputLog(const char* str);
	void OutputfLog(const char* fmt, ...);
	void OutputLog(const string& str);

private:
	void close_socket(SOCKET& socket);
	/*void timeout_for_recv(unsigned int timeout, SOCKET& socket);
	static DWORD WINAPI timeout_thread(LPVOID);
	void timeout_imp();
	bool exit_if_meet(const char* recv_str, const char* chk_str, bool use_regular);*/

private:
	bool m_socket_init;
	struct sockaddr_in m_sockaddr;

	SOCKET m_socket;
	unsigned int m_timeout;
	DWORD m_tick;

	CDebugMessage m_dbgmsg;
};

