#include "stdafx.h"
#include <vector>
#include "MyTelnet.h"
#include <regex>

#pragma comment(lib, "Ws2_32.lib")


CMyTelnet::CMyTelnet() : m_socket(INVALID_SOCKET), m_socket_init(false), m_tick(0)
{
	int result;
	WSADATA wsaData;

	result = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (result != NO_ERROR)
	{
		m_socket_init = false;
		sprintf_s(m_err_msg, "WSAStartup failed with error: %d\n", result);
		OutputfLog(" WSAStartup failed with error: %d\n", result);
	}
}


CMyTelnet::~CMyTelnet()
{
	close_socket(m_socket);
	WSACleanup();
}

char* CMyTelnet::GetErrMsg()
{
	return m_err_msg;
}

int CMyTelnet::Connect(const char* addr, u_short port)
{
	int ret = S_FALSE;
	int result;

	m_sockaddr.sin_family = AF_INET;
	m_sockaddr.sin_port = htons(port);
	int err_no = inet_pton(AF_INET, addr, &(m_sockaddr.sin_addr));
	if (err_no != 1)
	{
		sprintf_s(m_err_msg, "inet_pton failed with error: %s\n", addr);
		OutputfLog(" inet_pton failed with error: %s\n", addr);
		::MessageBoxA(NULL, m_err_msg, "RobotArm", MB_OK + MB_ICONERROR);
		return ret;
	}

	m_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_socket == INVALID_SOCKET) {
		sprintf_s(m_err_msg, "socket failed with error: %d\n", WSAGetLastError());
		OutputfLog(" socket failed with error: %d\n", WSAGetLastError());
		return ret;
	}

	result = connect(m_socket, (SOCKADDR*)&m_sockaddr, sizeof(m_sockaddr));
	if (result == SOCKET_ERROR) {
		sprintf_s(m_err_msg, "connect failed with error: %d\n", WSAGetLastError());
		OutputfLog(" connect failed with error: %d\n", WSAGetLastError());
		close_socket(m_socket);
		return ret;
	}

	return S_OK;

}

void CMyTelnet::SkipInitScreen(string& src)
{
	size_t pos;
	unsigned char header1[] = { 0xff, 0xfd, 0x01, 0xff, 0xfd, 0x1f, 0xff, 0xfb, 0x01, 0xff, 0xfb, 0x03, 0x0d, 0x00 };
	vector<char*> headers;
	headers.push_back((char*)header1);
	const char* a = src.c_str();

	for each (char* header in headers)
	{
		pos = src.find(header);
		if (pos != string::npos)
		{
			src = src.erase(pos, strlen(header));
			break;
		}
	}
}

int CMyTelnet::SendRecvStr(const char* send_str, std::string& recv_str, unsigned int timeout, const char* prompt)
{
	int ret = S_FALSE;
	int result;
	char recv_d[512] = { 0 };
	
	recv_str = "";
	result = send(m_socket, send_str, (int)strlen(send_str), 0);
	if (result == SOCKET_ERROR) {
		sprintf_s(m_err_msg, "send failed with error: %d\n", WSAGetLastError());
		OutputfLog(" send failed with error: %d\n", WSAGetLastError());
		close_socket(m_socket);
		return 1;
	}

	/*result = shutdown(m_socket, SD_SEND);
	if (result == SOCKET_ERROR) {
		sprintf_s(m_err_msg, "shutdown failed with error: %d\n", WSAGetLastError());
		close_socket(m_socket);
		return 1;
	}*/

	/*if (timeout != INFINITE)
		timeout_for_recv(timeout, m_socket);*/

	do {
		result = recv(m_socket, recv_d, sizeof(recv_d), 0);
		if (result > 0) {
			recv_str = recv_str + recv_d;
			//if (exit_if_meet(recv_str.c_str(), chk_str, use_regualr))			{
			if (recv_str.find(prompt) != string::npos) {
				ret = S_OK;
				break;
			}
			memset(recv_d, 0, sizeof(recv_d));
		}
		else {
			if ((m_tick != 0) && ((::GetTickCount() - m_tick) < 800))
				ret = WAIT_TIMEOUT;
			else
			{
				if (result == 0) {
					printf_s(m_err_msg, "Connection closed\n");
					OutputLog(" Connection closed\n");
				}
				else {
					sprintf_s(m_err_msg, "recv failed with error: %d\n", WSAGetLastError());
					OutputfLog(" recv failed with error: %d\n", WSAGetLastError());
				}
			}
		}
	} while (result > 0);
	
	return ret;
}

void CMyTelnet::close_socket(SOCKET& socket)
{
	if (socket != INVALID_SOCKET)
	{
		closesocket(socket);
		socket = INVALID_SOCKET;
	}
}

//void CMyTelnet::timeout_for_recv(unsigned int timeout, SOCKET& socket)
//{
//	m_timeout = timeout;
//	m_socket = socket;
//	m_tick = 0;
//	::CreateThread(NULL, 0, timeout_thread, this, 0, NULL);
//}
//
//DWORD WINAPI CMyTelnet::timeout_thread(LPVOID param)
//{
//	CMyTelnet *self = (CMyTelnet*)(param);
//	self->timeout_imp();
//	return 0;
//}
//
//void CMyTelnet::timeout_imp()
//{
//	::Sleep(m_timeout);
//	m_tick = ::GetTickCount();
//	close_socket(m_socket);
//}
//
//bool CMyTelnet::exit_if_meet(const char* recv_str, const char* chk_str, bool use_regular)
//{
//	if (chk_str == NULL)
//		return false;
//	else
//	{
//		if (use_regular == true)
//		{
//			std::tr1::regex	rx;
//			smatch reg_result;
//			rx.assign(chk_str, regex_constants::icase);
//			if (regex_search(string(recv_str), reg_result, rx) == true)
//				return true;
//			else
//				return false;
//		}
//		else
//		{
//			if (strstr(recv_str, chk_str) != NULL)
//				return true;
//			else
//				return false;
//		}
//	}
//}


void CMyTelnet::AddOutput(COutputDebug* output)
{
	this->m_dbgmsg.AddOutput(output);
}

void CMyTelnet::RemoveOutput(COutputDebug* output)
{
	this->m_dbgmsg.RemoveOutput(output);
}

void CMyTelnet::OutputLog(const char* str)
{
	this->m_dbgmsg.Output(str);
}

void CMyTelnet::OutputfLog(const char* fmt, ...)
{
	int buf_cnt = 512;
	char* buffer = NULL;
	va_list	list;
	int vsn = -1;

	va_start(list, fmt);

	do{
		delete[] buffer;
		buf_cnt *= 2;
		buffer = new char[buf_cnt];
		vsn = vsnprintf_s(buffer, buf_cnt, _TRUNCATE, fmt, list);
	} while (vsn == -1);

	va_end(list);

	OutputLog(buffer);
	delete[] buffer;
}

void CMyTelnet::OutputLog(const string& str)
{
	this->m_dbgmsg.Output(str);
}





