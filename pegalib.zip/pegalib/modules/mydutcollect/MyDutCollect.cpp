#include "stdafx.h"
#include "Dut.h"
#include "MyDutCollect.h"


MyDutCollect::MyDutCollect()
{
}


MyDutCollect::~MyDutCollect()
{
}

void MyDutCollect::AddDut(const char* name, CDut* dut)
{
	m_dut_collect[name] = dut;
}

void MyDutCollect::RemoveTest(const char* name)
{
	std::map<string, CDut*>::iterator it = m_dut_collect.find(name);;

	if (it != m_dut_collect.end())
		m_dut_collect.erase(it);
}

bool MyDutCollect::ResumeTest(const char* name)
{
	if (m_dut_collect.find(name) != m_dut_collect.end())
		if (m_dut_collect[name] != NULL)
		{
			m_dut_collect[name]->ResumeTest();
			return true;
		}

	return false;
}





