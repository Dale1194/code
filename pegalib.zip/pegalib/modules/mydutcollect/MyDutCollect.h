#pragma once

#include <memory>
#include <string>
#include <map>
#include <vector>
#include "MyEvent.h"

using namespace std;

class MyDutCollect
{
private:
	MyDutCollect();

public:
	static MyDutCollect* getInstance() {
		static auto_ptr<MyDutCollect> pObj(new MyDutCollect());
		return pObj.get();
	};

	virtual ~MyDutCollect();

	void AddDut(const char* name, CDut* dut);
	void RemoveTest(const char* name);
	bool ResumeTest(const char* name);


private:
	std::map<string, CDut*> m_dut_collect;
};

