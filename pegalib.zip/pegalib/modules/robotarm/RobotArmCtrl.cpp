#include "stdafx.h"
#include "Config.h"
#include "include/json/json.h"
#include "RobotArm.h"
#include "RobotArmCtrl.h"
#include "RobotCmdData.h"
#include "RobotActionDefine.h"


bool g_is_first = true;
bool g_is_robotarm_enable = false;
string g_remot_inst_name = "";


bool RobotArmCtrl::is_robotarm_enable()
{
	Json::Value robot_arm_ctrl;

	CConfig::getInstance()->GetRobotArmCtrl(robot_arm_ctrl);

	g_remot_inst_name = robot_arm_ctrl["RemotInstName"].asString();
	g_is_robotarm_enable = robot_arm_ctrl["Enable"].asBool();

	return g_is_robotarm_enable;
}

int RobotArmCtrl::wait_for_dut_place(const char* name)
{
	int ret = S_FALSE;
	CRobotCmdData rbt_cmd;
	CRobotArm robotarm(g_remot_inst_name.c_str());

	rbt_cmd.m_dut_name = name;

	if (g_is_first)
	{
		g_is_first = false;
		rbt_cmd.m_robot_scenario = RobotAction::RBT_WAIT_DUT;
	}
	else
	{
		rbt_cmd.DataPoolOut();
	}

	ret = robotarm.Notify(rbt_cmd);

	return ret;
}

