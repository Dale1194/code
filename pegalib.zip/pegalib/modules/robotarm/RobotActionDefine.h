#pragma once


namespace RobotAction {
	const char RBT_WAIT_DUT[] = "A";
	const char RBT_DUT_PASS[] = "B";
	const char RBT_DUT_FINAL_FAIL[] = "C";
	const char RBT_EXCEPTION[] = "D";
	const char RBT_DUT_AB_FAIL[] = "E";
	const char RBT_DUT_FINAL_FAIL_CONSECUTIVE_FAIL[] = "CF";
	const char RBT_DUT_AB_FAIL_CONSECUTIVE_FAIL[] = "EF";
	const char RBT_DUT_FINAL_FAIL_INCONSECUTIVE_FAIL[] = "CI";
	const char RBT_DUT_AB_FAIL_INCONSECUTIVE_FAIL[] = "EI";
}