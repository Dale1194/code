#pragma once

#include "../mysocket/MySocket.h"
#include "RobotCmdData.h"

class CRobotArm
{
public:
	CRobotArm(const char* name);
	virtual ~CRobotArm();

	int Notify(CRobotCmdData& cmd_data);


private:
	int parse_dut_name_no();

private:
	string m_arm_name;
	CMySocket m_socket;
	string m_dut_name;
	string m_dut_name_no;
};

