#pragma once
#include <string>

using namespace std;

class CRobotCmdData
{
public:
	CRobotCmdData();
	virtual ~CRobotCmdData();

	void ToCmdData(string& cmd);
	void DataPoolIn();
	void DataPoolOut(const char* dut_name = NULL);


public:
	string m_dut_name;
	string m_dut_name_no;
	string m_robot_scenario;
	string m_isn;
	string m_err_code;
};

