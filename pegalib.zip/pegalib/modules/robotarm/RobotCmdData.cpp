#include "stdafx.h"
#include "CommonApi.h"
#include "RobotCmdData.h"
#include "include/json/json.h"
#include "modules\datapool\DataPool.h"

extern CCriticalSection g_datapool_cs;

CRobotCmdData::CRobotCmdData() :m_isn("1111111111111111"), m_err_code("000000")
{
}


CRobotCmdData::~CRobotCmdData()
{
}

void CRobotCmdData::ToCmdData(string& cmd)
{
	cmd = m_dut_name_no;
	cmd += ",";
	cmd += m_robot_scenario;
	cmd += ",";
	cmd += m_isn;
	cmd += ",";
	cmd += m_err_code;
	cmd += "\r\n";
}

void CRobotCmdData::DataPoolIn()
{
	string key;
	Json::Value value;

	value["dut_name_no"] = m_dut_name_no;
	value["robot_scenario"] = m_robot_scenario;
	value["isn"] = m_isn;
	value["err_code"] = m_err_code;

	key = "dut_result_for_robot_" + m_dut_name;

	g_datapool_cs.Enter();
	CDataPool::getInstance()->m_datapool[key] = value;
	g_datapool_cs.Leave();
}

void CRobotCmdData::DataPoolOut(const char* dut_name)
{
	string key;
	Json::Value value;

	if (dut_name != NULL)
		m_dut_name = dut_name;

	key = "dut_result_for_robot_" + m_dut_name;

	g_datapool_cs.Enter();
	value = CDataPool::getInstance()->m_datapool[key];
	g_datapool_cs.Leave();
	
	m_dut_name_no = value["dut_name_no"].asString();
	m_robot_scenario = value["robot_scenario"].asString();
	m_isn = value["isn"].asString();
	m_err_code = value["err_code"].asString();
}

