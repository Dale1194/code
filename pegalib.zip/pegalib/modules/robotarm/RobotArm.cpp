#include "stdafx.h"
#include "Config.h"
#include "RobotArm.h"
#include <regex>
#include "include/json/json.h"


CRobotArm::CRobotArm(const char* name) :m_arm_name(name), m_dut_name("")
{
	Json::Value remote_inst_cfg;
	string r_ip;
	unsigned int r_port;

	CConfig::getInstance()->GetRemots(m_arm_name.c_str(), remote_inst_cfg);
	r_ip = remote_inst_cfg["IP"].asString();
	r_port = remote_inst_cfg["Port"].asUInt();

	m_socket.SetRemote(r_ip.c_str(), r_port);
}


CRobotArm::~CRobotArm()
{
}

int CRobotArm::Notify(CRobotCmdData& cmd_data)
{
	int ret = S_FALSE;
	string send_data;
	string recv_data;
	CRobotCmdData rbt_cmddata;
	
	int parse_ret;
	m_dut_name = cmd_data.m_dut_name;
	parse_ret = parse_dut_name_no();

	if (parse_ret == S_OK)
	{
		cmd_data.m_dut_name_no = m_dut_name_no;
		cmd_data.ToCmdData(send_data);

		ret = m_socket.SendRecvStr(send_data.c_str(), recv_data, INFINITE, "PASS");
		if (ret != S_OK)
		{
			string err_msg;
			err_msg = m_socket.GetErrMsg();
			::MessageBoxA(NULL, err_msg.c_str(), "MultiTest Tool", MB_OK + MB_ICONERROR);
		}
	}
	
	return ret;
}

int CRobotArm::parse_dut_name_no()
{
	std::tr1::regex	rx;
	smatch reg_result;

	rx.assign("\\d+", regex_constants::icase);
	if (regex_search(m_dut_name, reg_result, rx) == true)
		m_dut_name_no = reg_result[0].str();
	else
	{
		::MessageBoxA(NULL, "can not parse \"Unit name\"", "MultiTest Tool", MB_OK + MB_ICONERROR);
		return S_FALSE;
	}

	return S_OK;
}


