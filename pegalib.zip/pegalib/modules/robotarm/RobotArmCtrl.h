#pragma once
#include <string>

using namespace std;


namespace RobotArmCtrl
{
	bool is_robotarm_enable();
	int wait_for_dut_place(const char* name);
}