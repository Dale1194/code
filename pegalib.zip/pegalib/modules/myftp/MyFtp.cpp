#include "stdafx.h"
#include <string>
#include "Windows.h"
#include "MyFtp.h"

using namespace std;

#pragma comment(lib, "Wininet")

MyFtp::MyFtp() : m_hInternet(NULL), m_hConnect(NULL)
{
}



MyFtp::MyFtp(const char* server_name, const char* user, const char* pwd) : m_hInternet(NULL), m_hConnect(NULL)
{
	strcpy_s(m_server_name, server_name);
	strcpy_s(m_user_name, user);
	strcpy_s(m_user_pwd, pwd);
}


MyFtp::~MyFtp()
{
	if (m_hInternet != NULL) InternetCloseHandle(m_hInternet);
	if (m_hConnect != NULL) InternetCloseHandle(m_hConnect);
}


int MyFtp::Init()
{
	m_hInternet = InternetOpen(NULL, INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);
	if (m_hInternet == NULL) set_last_error("Failed to InternetOpen().");

	m_hConnect = InternetConnectA(m_hInternet, m_server_name, INTERNET_DEFAULT_FTP_PORT, m_user_name, m_user_pwd, INTERNET_SERVICE_FTP, 0, 0);
	if (m_hInternet == NULL) set_last_error("Failed to InternetConnect().");

	if ((m_hInternet == NULL) || (m_hConnect == NULL))
		return S_FALSE;

	return S_OK;
}

int MyFtp::Init(const char* server_name, const char* user, const char* pwd)
{
	strcpy_s(m_server_name, server_name);
	strcpy_s(m_user_name, user);
	strcpy_s(m_user_pwd, pwd);

	return Init();
}

int MyFtp::CreateFolder(const char* path)
{
	string netmsg;
	char szFolder[512];
	strcpy_s(szFolder, path);
	char *pStart = szFolder;
	char *pEnd = pStart + strlen(szFolder);
	char *p = pEnd;

	for (int i = 0; i < 20; i++)
	{
		BOOL bOK = ::FtpCreateDirectoryA(m_hConnect, szFolder);

		if (!bOK)
		{
			internet_err_msg(netmsg);
		}

		if ((!bOK) && (netmsg.find("550 The system cannot find the path specified.") != string::npos))
		{
			while (*p != '/')
			{
				if (p == pStart) return S_FALSE;
				p--;
			}
			*p = NULL;
		}
		else if (bOK || (netmsg.find("550 Cannot create a file when that file already exists.") != string::npos))
		{
			if (p == pEnd) return S_OK;
			*p = '/';
			while (*p) p++;
		}
		else
		{
			break;
		}
	}
	return S_FALSE;
}

int MyFtp::UploadFile(const char* local, const char* remote)
{
	BOOL bOK = ::FtpPutFileA(m_hConnect, local, remote, FTP_TRANSFER_TYPE_BINARY, 0);
	
	if (!bOK)
	{
		set_last_error("Failed to FtpPutFileA()");
		return S_FALSE;
	}

	return S_OK;
}

void MyFtp::set_last_error(const char* msg)
{
	DWORD err_code;
	char temp[12] = { 0 };

	err_code = ::GetLastError();
	sprintf_s(temp, "%d", err_code);

	m_err_msg = string(msg) + "\n The last error code is" + temp;
	::OutputDebugStringA(temp);
}

void MyFtp::internet_err_msg(string& netmsg)
{
	DWORD err = ::GetLastError();

	if (err == ERROR_INTERNET_EXTENDED_ERROR)
	{
		char errmsg[256];
		DWORD len = sizeof(errmsg);
		InternetGetLastResponseInfoA(&err, errmsg, &len);
		
		netmsg = errmsg;
		m_err_msg = errmsg;
	}
	else
		netmsg = "";
}


