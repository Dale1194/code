#pragma once
#include <wininet.h>

class MyFtp
{
public:
	MyFtp();
	MyFtp(const char* server_name, const char* user, const char* pwd);
	virtual ~MyFtp();
	
	int Init();
	int Init(const char* server_name, const char* user, const char* pwd);
	int CreateFolder(const char* path);
	int UploadFile(const char* local, const char* remote);


private:
	void set_last_error(const char* msg);
	void internet_err_msg(std::string& netmsg);

private:
	std::string		m_err_msg;
	HINTERNET		m_hInternet;
	HINTERNET		m_hConnect;
	char			m_server_name[64];
	char			m_user_name[32];
	char			m_user_pwd[32];
};

