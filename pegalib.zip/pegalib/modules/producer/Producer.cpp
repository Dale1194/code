#include "stdafx.h"
#include "SfisCsv.h"
#include <string>
#include <vector>
#include <map>
#include <regex>
#include "Producer.h"


using namespace std;

CCriticalSection g_producer_cs;

CProducer::CProducer(const char* device_id) : m_handle(NULL), m_get_version(NULL), m_initialize(NULL), m_set_topic(NULL), m_set_deviceid(NULL), m_send_msg(NULL)
{
	load_dll();

	if (device_id == NULL)
		assert(!"Object CProducer not init yet!");
	else
		init(device_id);
}


CProducer::~CProducer()
{
	if (m_handle == NULL)
	{
		FreeLibrary(m_handle);
		m_handle = NULL;
	}
}

int CProducer::load_dll()
{
	string dll_name;
	
	GetCurrentPath(dll_name);
	dll_name = dll_name + "\\iPLAS\\pega_producer.dll";

	m_handle = LoadLibraryA(dll_name.c_str());
	if (NULL == m_handle)
	{
		::MessageBox(NULL, L"Failed to load pega_producer.dll.", L"Error", MB_OK);
		return S_FALSE;
	}

	m_get_version = (GET_VERSION)GetProcAddress(m_handle, "get_version");
	m_initialize = (INITIALIZE)GetProcAddress(m_handle, "initialize");
	m_set_topic = (SET_TOPIC)GetProcAddress(m_handle, "set_topic");
	m_set_deviceid = (SET_DEVICEID)GetProcAddress(m_handle, "set_deviceid");
	m_send_msg = (SEND_MSG)GetProcAddress(m_handle, "send_msg");
	m_send_ts_msg = (SEND_TS_MSG)GetProcAddress(m_handle, "send_ts_msg");
	m_send_ts_data = (SEND_TS_DATA)GetProcAddress(m_handle, "send_ts_data");

	if (!m_get_version || !m_initialize || !m_set_topic || !m_set_deviceid || !m_send_msg || !m_send_ts_msg || !m_send_ts_data)
	{
		::FreeLibrary(m_handle);
		::MessageBoxA(NULL, "Load Function Point Fail.", NULL, NULL);
		return S_FALSE;
	}

	return S_OK;
}

int CProducer::init(const char* device_id)
{
	m_get_version(&m_producer_ver);
	if (m_set_deviceid(device_id) != ERR_OK)
		assert(!"Failed to init CProducer!");
	strcpy_s(m_device_id, device_id);
	return S_OK;
}

char* CProducer::GetProducerVer()
{
	return m_producer_ver;
}

int CProducer::SendMsg(const char* _message)
{
	return m_send_msg(_message, m_device_id);
}

int CProducer::SendTsMsg(const char* _message)
{
	return m_send_ts_msg(_message);
}

int CProducer::SendTsData(const char* _fullpath, const char* _message)
{
	return m_send_ts_data(_fullpath, _message);
}




ProducerCsv::ProducerCsv() : m_all_data("TEST,STATUS,VALUE,UCL,LCL,CYCLE\n")
{
	strcpy_s(m_status_to_str[0], "PASS");
	strcpy_s(m_status_to_str[1], "FAIL");

	m_replaced_key_words["FATP_ISN"] = "ISN";
	m_replaced_key_words["MLB_ISN"] = "ISN";
	m_replaced_key_words["FIXTURE_ID"] = "DeviceId";
	m_replaced_key_words["TEST_DATE_TIME"] = "Test Start Time";
	m_replaced_key_words["TEST_END_TIME"] = "Test end Time";
	m_replaced_key_words["STATION_NAME"] = "TSP";
	m_replaced_key_words["STATION_SW_VERSION"] = "ATS_Ver";

	m_remove_field_status["Test Start Time,PASS,"] = "Test Start Time,,";
	m_remove_field_status["TSP,PASS,"] = "TSP,,";
	m_remove_field_status["Test Start Time,PASS,"] = "Test Start Time,,";
	m_remove_field_status["ATS_Ver,PASS,"] = "ATS_Ver,,";
	m_remove_field_status["DeviceId,PASS,"] = "DeviceId,,";
	m_remove_field_status["ISN,PASS,"] = "ISN,,";
	m_remove_field_status["Test end Time,PASS,"] = "Test end Time,,";
	m_remove_field_status["Project,PASS,"] = "Project,,";
	m_remove_field_status["Model,PASS,"] = "Model,,";
	m_remove_field_status["Line,PASS,"] = "Line,,";
	m_remove_field_status["ProducerVersion,PASS,"] = "ProducerVersion,,";
	m_remove_field_status["Type,PASS,"] = "Type,,";
	m_remove_field_status["Test Status,PASS,"] = "Test Status,,";
	m_remove_field_status["ErrorCode,PASS,"] = "ErrorCode,,";
	m_remove_field_status["CallerSendTime,PASS,"] = "CallerSendTime,,";
	m_remove_field_status["Slot,PASS,"] = "Slot,,";
	m_remove_field_status["Build,PASS,"] = "Build,,";
	m_remove_field_status["SFIS message,PASS,"] = "SFIS message,,";
}

ProducerCsv::~ProducerCsv()
{

}

void ProducerCsv::AddCsv(const char* data)
{
	m_all_data = m_all_data + data;
}

void ProducerCsv::AddCsv(const char* item, CSfisCsv::Status stat, string& value, const char* u_limit, const char* l_limit, const char* cycle)
{
	AddCsv(item, stat, value.c_str(), u_limit, l_limit, cycle);
}

void ProducerCsv::AddCsv(const char* item, CSfisCsv::Status stat, const char* value, const char* u_limit, const char* l_limit, const char* cycle)
{
	int n = -1;
	int buf_cnt = 1024;
	char* buf = NULL;

	do
	{
		delete[] buf;
		buf_cnt *= 2;
		buf = new char[buf_cnt];
		n = _snprintf_s(buf, buf_cnt, _TRUNCATE, "%s,%s,%s,%s,%s,%s\n", item, m_status_to_str[stat], value, u_limit, l_limit, cycle);
	} while (n == -1);

	AddCsv(buf);

	delete[] buf;
}

void ProducerCsv::AddKeyWord(const char* key, const char* value)
{
	m_replaced_key_words[key] = value;
}

const char* ProducerCsv::GetAllData()
{
	post_processing();
	return m_all_data.c_str();
}

void ProducerCsv::post_processing()
{
	std::regex rule;
	for (map<string, string>::iterator it = m_replaced_key_words.begin(); it != m_replaced_key_words.end(); ++it)
	{
		rule.assign(it->first);
		m_all_data = std::regex_replace(m_all_data, rule, it->second);
	}

	for (map<string, string>::iterator it = m_remove_field_status.begin(); it != m_remove_field_status.end(); ++it)
	{
		rule.assign(it->first);
		m_all_data = std::regex_replace(m_all_data, rule, it->second);
	}
}






