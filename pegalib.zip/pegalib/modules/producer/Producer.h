
#include <string>
#include <memory>

#pragma once

class CProducer
{
private:
	CProducer(const char* device_id);

public:
	virtual ~CProducer();

	static CProducer* getInstance() {
		return Init(NULL);
	};

	static CProducer* Init(const char* device_id) {
		static std::auto_ptr<CProducer> pObj(new CProducer(device_id));
		return pObj.get();
	};

	typedef int(*SEND_MSG)(const char* _message, const char* _key);
	typedef int(*GET_VERSION)(char** _version);
	typedef int(*INITIALIZE)(bool is_test);
	typedef int(*SET_TOPIC)(const char* _topic);
	typedef int(*SET_DEVICEID)(const char* _id);
	typedef int(*SEND_TS_MSG)(const char* _test_csv);
	typedef int(*SEND_TS_DATA)(const char* _absolute_file_path, const char* _test_csv);

	enum Error_Code {
		ERR_OK = 0,
		ERR_FAIL = 10000,
		ERR_NOT_INIT = 10001,
		ERR_ILLEGAL_PARAM = 10002,
		ERR_BUSY = 10003,
		ERR_DISK_FULL = 10004,
		ERR_FILE = 10005,
		ERR_EXIT = 10006
	};

public:
	char* GetProducerVer();
	int SendMsg(const char* _message);
	int SendTsMsg(const char* _message);
	int SendTsData(const char* _fullpath, const char* _message);
	
private:
	int load_dll();
	int init(const char* device_id);


private:
	char* m_producer_ver;
	char m_device_id[8];
	
	HMODULE	m_handle;
	GET_VERSION m_get_version;
	INITIALIZE m_initialize;
	SET_TOPIC m_set_topic;
	SET_DEVICEID m_set_deviceid;
	SEND_MSG m_send_msg;
	SEND_TS_MSG m_send_ts_msg;
	SEND_TS_DATA m_send_ts_data;
};




class ProducerCsv
{
public:
	ProducerCsv();
	virtual ~ProducerCsv();

	void AddCsv(const char* data);
	void AddCsv(const char* item, CSfisCsv::Status stat, string& value, const char* u_limit, const char* l_limit, const char* cycle);
	void AddCsv(const char* item, CSfisCsv::Status stat, const char* value, const char* u_limit, const char* l_limit, const char* cycle);
	void AddKeyWord(const char* key, const char* value);
	const char* GetAllData();

private:
	void post_processing();

private:
	char m_status_to_str[2][5];
	string m_all_data;
	map<string, string> m_replaced_key_words;
	map<string, string> m_remove_field_status;
};