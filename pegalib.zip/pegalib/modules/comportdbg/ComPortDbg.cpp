#include "stdafx.h"
#include "ComPortDbg.h"
#include "pegalib.h"


CComPortDbg::CComPortDbg() :m_hwnd(NULL), m_thread(NULL), m_is_open_original_status(false)
{
}


CComPortDbg::~CComPortDbg()
{
}

void CComPortDbg::AddObjRs232(CRS232* rs232)
{
	this->m_comports[rs232->ComName()] = rs232;
}

int CComPortDbg::Init(const HWND hUIWnd, const char* com_name)
{
	int ret = S_FALSE;

	m_hwnd = hUIWnd;
	
	strcpy_s(m_com_name, com_name);
	CRS232* rs232 = UseCom(m_com_name);

	if (rs232 != NULL)
	{
		m_is_open_original_status = rs232->IsOpen();
		if (!m_is_open_original_status)
		{
			ret = rs232->Open();
		}
		else
			ret = S_OK;
	}

	if (ret == S_OK)
	{
		m_terminate_event.Reset();
		m_thread = ::CreateThread(NULL, 0, com_dbg_thread, (LPVOID)this, 0, NULL);
	}

	return ret;
}

int CComPortDbg::SendCommand(const char* cmd)
{
	int ret = S_FALSE;
	CRS232* rs232 = UseCom(m_com_name);
	
	if (rs232 != NULL)
		ret = rs232->WriteString(cmd);

	return ret;
}

int CComPortDbg::Uninit()
{
	int ret = S_FALSE;
	CRS232* rs232 = UseCom(m_com_name);

	m_terminate_event.Set();

	if ((rs232 != NULL) && (m_is_open_original_status == false))
		ret = rs232->Close();

	m_hwnd = NULL;

	return ret;
}

CRS232* CComPortDbg::UseCom(const char* com_name)
{
	return (m_comports.find(com_name) == m_comports.end()) ? NULL : m_comports[com_name];
}

DWORD WINAPI CComPortDbg::com_dbg_thread(LPVOID param)
{
	CComPortDbg *self = (CComPortDbg*)(param);
	self->com_dbg_imp();
	return 0;
}

void CComPortDbg::com_dbg_imp()
{
	char* p;
	int len;
	string read_data;
	CRS232* rs232 = UseCom(m_com_name);

	while (m_terminate_event.Unlook(100))
	{
		rs232->ReadString(read_data);

		if (!read_data.empty())
		{
			if (m_hwnd != NULL)
			{
				len = read_data.length() + 1;
				p = new char[len];
				strcpy_s(p, len, read_data.c_str());
				::PostMessageA(this->m_hwnd, WM_COMPORT_DBG, 0, (LPARAM)p);
			}
			else
			{
				read_data = string(m_com_name) + ":" + read_data;
				::OutputDebugStringA(read_data.c_str());
			}
		}
	}
}

