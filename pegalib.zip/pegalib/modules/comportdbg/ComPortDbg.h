#pragma once

#include <memory>
#include <string>
#include <map>
#include <vector>
#include "RS232.h"
#include "MyEvent.h"

using namespace std;

enum ComDbgActId
{
	INIT,
	SENDCMD,
	UINIT
};

class CComPortDbg
{
private:
	CComPortDbg();

public:
	static CComPortDbg* getInstance() {
		static auto_ptr<CComPortDbg> pObj(new CComPortDbg());
		return pObj.get();
	};

	virtual ~CComPortDbg();

	void AddObjRs232(CRS232* rs232);
	int Init(const HWND hUIWnd, const char* com_name);
	int SendCommand(const char* cmd);
	int Uninit();
	CRS232* UseCom(const char* com_name);


private:
	static DWORD WINAPI com_dbg_thread(LPVOID param);
	void com_dbg_imp();


private:
	HWND m_hwnd;
	HANDLE m_thread;
	char m_com_name[12];
	bool m_is_open_original_status;
	std::map<string, CRS232*> m_comports;
	CMyEvent m_terminate_event;
};

