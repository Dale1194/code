#pragma once

#include <string>
#include <winsock2.h>
#include <Ws2tcpip.h>

using namespace std;

class CMySocket
{
public:
	CMySocket();
	virtual ~CMySocket();
	char m_err_msg[256];

	char* GetErrMsg();
	int SetRemote(const char* addr, u_short port);
	int SendRecvStr(const char* send_str, std::string& recv_str, unsigned int timeout, const char* chk_str = NULL, bool use_regualr = false);

private:
	void timeout_for_recv(unsigned int timeout, SOCKET& socket);
	static DWORD WINAPI timeout_thread(LPVOID);
	void timeout_imp();
	bool exit_if_meet(const char* recv_str, const char* chk_str, bool use_regular);

private:
	bool m_socket_init;
	struct sockaddr_in m_sockaddr;

	SOCKET m_socket;
	unsigned int m_timeout;
	DWORD m_tick;
};

