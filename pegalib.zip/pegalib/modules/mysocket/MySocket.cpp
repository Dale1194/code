#include "stdafx.h"
#include "MySocket.h"
#include <regex>

#pragma comment(lib, "Ws2_32.lib")


CMySocket::CMySocket() :m_socket_init(true), m_tick(0)
{
	int result;
	WSADATA wsaData;

	result = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (result != NO_ERROR)
	{
		m_socket_init = false;
		sprintf_s(m_err_msg, "WSAStartup failed with error: %d", result);
	}
}


CMySocket::~CMySocket()
{
	WSACleanup();
}

char* CMySocket::GetErrMsg()
{
	return m_err_msg;
}

int CMySocket::SetRemote(const char* addr, u_short port)
{
	m_sockaddr.sin_family = AF_INET;
	m_sockaddr.sin_port = htons(port);
	int err_no = inet_pton(AF_INET, addr, &(m_sockaddr.sin_addr));
	if (err_no != 1)
	{
		sprintf_s(m_err_msg, "inet_pton failed with error: %s", addr);
		::MessageBoxA(NULL, m_err_msg, "RobotArm", MB_OK + MB_ICONERROR);
		return S_FALSE;
	}

	return 0;
}

int CMySocket::SendRecvStr(const char* send_str, std::string& recv_str, unsigned int timeout, const char* chk_str, bool use_regualr)
{
	int ret = S_FALSE;
	int result;
	SOCKET Connect_socket = INVALID_SOCKET;
	char recv_d[512] = { 0 };

	Connect_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (Connect_socket == INVALID_SOCKET) {
		sprintf_s(m_err_msg, "socket failed with error: %d\n", WSAGetLastError());
		return 1;
	}

	result = connect(Connect_socket, (SOCKADDR*)&m_sockaddr, sizeof(m_sockaddr));
	if (result == SOCKET_ERROR) {
		sprintf_s(m_err_msg, "connect failed with error: %d\n", WSAGetLastError());
		closesocket(Connect_socket);
		return 1;
	}

	result = send(Connect_socket, send_str, (int)strlen(send_str), 0);
	if (result == SOCKET_ERROR) {
		sprintf_s(m_err_msg, "send failed with error: %d\n", WSAGetLastError());
		closesocket(Connect_socket);
		return 1;
	}

	result = shutdown(Connect_socket, SD_SEND);
	if (result == SOCKET_ERROR) {
		sprintf_s(m_err_msg, "shutdown failed with error: %d\n", WSAGetLastError());
		closesocket(Connect_socket);
		return 1;
	}

	if (timeout != INFINITE)
		timeout_for_recv(timeout, Connect_socket);

	do {
		result = recv(Connect_socket, recv_d, sizeof(recv_d), 0);
		if (result > 0) {
			recv_str = recv_str + recv_d;
			if (exit_if_meet(recv_str.c_str(), chk_str, use_regualr))
			{
				ret = S_OK;
				break;
			}
			memset(recv_d, 0, sizeof(recv_d));
		}
		else {
			if ((m_tick != 0) && ((::GetTickCount() - m_tick) < 800))
				ret = WAIT_TIMEOUT;
			else
			{
				if (result == 0)
					printf_s(m_err_msg, "Connection closed\n");
				else
					sprintf_s(m_err_msg, "recv failed with error: %d\n", WSAGetLastError());
			}
		}
	} while (result > 0);

	closesocket(Connect_socket);

	return ret;
}

void CMySocket::timeout_for_recv(unsigned int timeout, SOCKET& socket)
{
	m_timeout = timeout;
	m_socket = socket;
	m_tick = 0;
	::CreateThread(NULL, 0, timeout_thread, this, 0, NULL);
}

DWORD WINAPI CMySocket::timeout_thread(LPVOID param)
{
	CMySocket *self = (CMySocket*)(param);
	self->timeout_imp();
	return 0;
}

void CMySocket::timeout_imp()
{
	::Sleep(m_timeout);
	m_tick = ::GetTickCount();
	closesocket(m_socket);
}

bool CMySocket::exit_if_meet(const char* recv_str, const char* chk_str, bool use_regular)
{
	if (chk_str == NULL)
		return false;
	else
	{
		if (use_regular == true)
		{
			std::tr1::regex	rx;
			smatch reg_result;
			rx.assign(chk_str, regex_constants::icase);
			if (regex_search(string(recv_str), reg_result, rx) == true)
				return true;
			else
				return false;
		}
		else
		{
			if (strstr(recv_str, chk_str) != NULL)
				return true;
			else
				return false;
		}
	}
}

