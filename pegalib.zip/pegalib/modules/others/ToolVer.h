#include "StdAfx.h"
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include "CommonApi.h"


extern HWND	g_uiwnd;
using namespace std;

#pragma once

class CToolVer
{
private:
	CToolVer(void) {
		get_package_ver(m_package_version);
		get_pegalib_ver(m_pegalib_version);
	};

public:
	~CToolVer(void) {
	};
	
public:
	static CToolVer* getInstance() {
		static auto_ptr<CToolVer> pObj(new CToolVer());
		return pObj.get();
	};
	
public:
	void GetPackageVer(string& ver) {
		ver = m_package_version;
	};

	const char* GetPackageVer(void) {
		return m_package_version.c_str();
	};

	void GetPegalibVer(string& ver) {
		ver = m_pegalib_version;
	};

	const char* GetPegalibVer(void) {
		return m_pegalib_version.c_str();
	};

private:
	void get_package_ver(string& ver) {
		string path;
		std::vector<string> files;

		GetCurrentPath(path);
		path = path + "\\*.pver";
		FindFiles(path.c_str(), files);
		
		if (files.size() != 1) {
			::MessageBoxA(g_uiwnd, "Get package version fail!!\nThere should have one and only one .pver file.", "Warning!", MB_OK | MB_ICONWARNING);
			ver = "unknown";
		} else {
			ver = files[0].substr(0, files[0].find_last_of('.'));
		}
	};

	void get_pegalib_ver(string& ver) {
		GetFileVersion(".\\pegalib.dll", ver);
	};
		
private:
	string	m_package_version;
	string	m_pegalib_version;
};
