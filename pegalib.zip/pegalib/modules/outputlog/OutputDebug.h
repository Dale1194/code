#pragma once


using namespace std;


class COutputDebug
{
public:
	COutputDebug();
	virtual ~COutputDebug();

	virtual void Output(const char* str){ return; }
	virtual void Output(const string& str){ return; }

private:
};

