#include "stdafx.h"
#include <string>
#include <vector>
#include "OutputDebug.h"


COutputDebug::COutputDebug()
{
}


COutputDebug::~COutputDebug()
{
}
