#include "stdafx.h"
#include <string>
#include <vector>
#include "OutputDebug.h"
#include "DebugMessage.h"


CDebugMessage::CDebugMessage()
{
}


CDebugMessage::~CDebugMessage()
{
}

void CDebugMessage::AddOutput(COutputDebug* output)
{
	this->m_output.push_back(output);
}

void CDebugMessage::RemoveOutput(COutputDebug* output)
{
	std::vector<COutputDebug*>::iterator it;
	it = std::find(this->m_output.begin(), this->m_output.end(), output);
	if (it != this->m_output.end())
		this->m_output.erase(it);
}

void CDebugMessage::Output(const char* str)
{
	for each (COutputDebug* output in this->m_output)
	{
		output->Output(str);
	}
}

void CDebugMessage::Output(const string& str)
{
	for each (COutputDebug* output in this->m_output)
	{
		output->Output(str);
	}
}

void CDebugMessage::Outputf(const char* fmt, ...)
{
	int buf_cnt = 512;
	char* buffer = NULL;
	va_list	list;
	int vsn = -1;

	va_start(list, fmt);

	do{
		delete[] buffer;
		buf_cnt *= 2;
		buffer = new char[buf_cnt];
		vsn = vsnprintf_s(buffer, buf_cnt, _TRUNCATE, fmt, list);
	} while (vsn == -1);

	va_end(list);

	Output(buffer);
	delete[] buffer;
}

