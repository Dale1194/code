#pragma once


using namespace std;


class CDebugMessage
{
public:
	CDebugMessage();
	virtual ~CDebugMessage();

	void AddOutput(COutputDebug* output);
	void RemoveOutput(COutputDebug* output);
	void Output(const char* str);
	void Output(const string& str);
	void Outputf(const char* fmt, ...);

private:
	vector<COutputDebug*> m_output;
};

