#include "StdAfx.h"
#include "MyTimer.h"
#include <cassert>

extern HWND	g_uiwnd;

CMyTimer::CMyTimer(void)
{
}

CMyTimer::CMyTimer(CUIReponse* ui) :m_ui(ui)
{
}

CMyTimer::~CMyTimer(void)
{
	Stop();
	Join();
	::CloseHandle(m_thread);
}

void CMyTimer::Start()
{
	bool is_run = is_running();
	if (!is_run)
	{
		m_terminate_event.Reset();
		m_thread = ::CreateThread(NULL, 0, &CMyTimer::start_thread, this, 0, NULL);
	}
	else
	{
		assert(!"MyTimer thread is running!");
	}
}

void CMyTimer::Stop()
{
	m_terminate_event.Set();
}

void CMyTimer::Join(DWORD timeout)
{
	::WaitForSingleObject(m_thread, timeout);
}

bool CMyTimer::is_running()
{
	return (::WaitForSingleObject(m_thread, 0) == WAIT_TIMEOUT) ? true : false;
}

DWORD WINAPI CMyTimer::start_thread(LPVOID param)
{
	CMyTimer *self = (CMyTimer*)(param);
	self->start_imp();
	return 0;
}

void CMyTimer::start_imp()
{
	DWORD tick = ::GetTickCount();
	char temp[12];

	while (m_terminate_event.Unlook(60))
	{
		sprintf_s(temp, "%4.1f", (::GetTickCount() - tick) / 1000.0);
		this->m_ui->UpdateTimer(temp);
	}
}

