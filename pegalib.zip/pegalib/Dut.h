
#include <string>
#include <map>
#include "UIReponse.h"
#include "MyTimer.h"
#include "SfisCsv.h"
#include "RdLog.h"
#include "pegalib.h"
#include "DOSCommand.h"
#include "RS232.h"
#include "GPIBDevice.h"
#include "include/json/json.h"
#include "MyResource.h"
#include "Glog.h"
#include "Gmetadata.h"
#include "Gmeasurements.h"
#include "Gucci_zip.h"
#include "md5wrapper.h"
#include <memory>
#include "projects\other_sub_dut.h"
#include "projects\OtherDut.h"
#include ".\modules\myftp\MyFtp.h"
#include ".\modules\mytelnet\MyTelnet.h"
#include ".\modules\producer\Producer.h"


using namespace std;

static const char PATH_ONLINE[] = { "ONLINE" };
static const char PATH_OFFLINE[] = { "OFFLINE" };
static const char PATH_QTR[] = { "QTR" };
static const char PATH_SPC[] = { "SPC" };

#define PARAM_N(x) (param[(x)].asInt())
#define PARAM_S(x) (param[(x)].asString())
#define PARAM_F(x) (param[(x)].asDouble())
#define PARAM_B(x) (param[(x)].asBool())

#pragma once

class CDut
{
public:
	CDut(UI_ATTR* ui_attr);
	virtual ~CDut(void);



public:
	void output_debug(const char *fmt, ...);
	int just_test(const char* item, const Json::Value& param);

	int StartTest();



private:
	int run_script_command(string& item_name, Json::Value& item_param);
	void replace_test_item_name(const Json::Value& item_param, string& item_nmae);
	void test_item_special_attribute_set(Json::Value& item_param);
	void test_item_special_attribute_restore();
	int run_sub_script_command(const Json::Value& test_items);
	int before_test();
	int after_test();
	void read_scenario_file(const char* file_name, Json::Value& test_items);
	void reset_ui();
	void create_temp();
	void backup_temp();
	void remove_temp(string& dir);
	void gen_zip(const char* zip_name, Json::Value& ext_name);
	void create_backup_path();
	int sfis_check_rule(int count);
	int sfis_check_route(string& msg);
	int sfis_auto_repair();

public:
	int sfis_get_version(const char* isn, const char* type, const char* data1, const char* data2, vector<string>& getver);
	int sfis_get_version(const char* isn, const char* deviceid, const char* type, const char* data1, const char* data2, vector<string>& getver);
	int sfis_get_imac(const char* isn, const char* status, const char* num, vector<string>& getver);
	int sfis_get_previous_result(const char* isn, vector<string>& getver);

private:
	int sfis_test_result();

public:
	int ParamInt(const Json::Value& param, const char* key, int v_default);
	double ParamDouble(const Json::Value& param, const char* key, double v_default);
	bool ParamBool(const Json::Value& param, const char* key, bool v_default);
	void ParamStr(const Json::Value& param, const char* key, string& out_str, const char* v_default);
	string toLowerCase(const std::string& str); //susu add
	vector<std::string> CDut::split(const std::string str, const string regex_ctr);
	string formatMAC(const std::string &mac); //susu add
	vector<char> ParamByte(const Json::Value& param, const char* key, const char* v_default);
	void set_info(const char* item, CSfisCsv::Status stat, const char* value);
	void set_info(const char* item, CSfisCsv::Status stat, double value);
	int log_sfis_save_item_and_set_info(const char* item, const char* value, bool write_really = true);
	int log_sfis_and_set_info(const char* item, const char* value, bool no_log_if_fail = true);
	int log_sfis_and_set_info(const char* item, double value);
	int log_sfis_and_set_info_no_judge(const char* item, CSfisCsv::Status stat, const char* value, bool no_log_if_fail = true);
	int log_sfis_and_set_info_no_judge(const char* item, CSfisCsv::Status stat, int value);
	int log_sfis_and_set_info_no_judge(const char* item, CSfisCsv::Status stat, double value);
	BOOL move_all_files_to(const char* dst, bool unless = false);
	void record_file_status_list(const char* file_name, int flag);
	void add_check_point(const char* name, const char* dir);
	void add_assembly(const char* name, const char* dir);
	void add_components(const char* name, const char* dir);
	int popup_input_form(const char*title1, const char* reg1, const char*title2, const char* reg2, const char*title3, const char* reg3, string& data1, string& data2, string& data3);

	int get_dutid(string& dutid);
	int get_dutid2(string& dutid);
	int get_dutcomport(string& comport);
	int get_usb_loc_info(const char* vid_pid, const char* sub, string& loc_info);
	int adb_command(const char* cmd, string& retval, int timeout = 3000);
	int adb_command(const char* cmd, string& retval, const char* tmnl, int wait, int timeout = 3000);
	int fastboot_command(const char* cmd, string& retval, int timeout = 3000);
	int fastboot_command(const char* cmd, string& retval, const char* tmnl, int wait, int timeout = 3000);
	int reset_usb_hub();
	int get_value_from_sysenv(const char* data, const char* name, char* value);
	int get_data_from_isn(const char* isn, int start, int len, char* data);
	int regular(string src, const Json::Value& param, string& out);
	int add_iplas_items();
	int upload_iplas(const char* zip_name);

	string adb_cmd_by_regex(const char* cmd, bool reg_enable, string reg_rule, int reg_catch);	// min add 20210122
	/// <summary>
	/// Hai add 19/07
	/// </summary>
	/// <param name="cmd"></param>
	/// <param name="reg_enable"></param>
	/// <param name="reg_rule"></param>
	/// <param name="reg_catch"></param>
	/// <returns></returns>
	string CDut::hai_cmd_by_regex(const string& cmd, bool reg_enable, string reg_rule, int reg_catch); //Hai add 22/07/18

	CRS232* use_comport(const char* friendlyname, RS232_CONFIG* _cfg = NULL);
	CMyTelnet* use_telnet(const char* friendlyname);
	CVirtualInstrument* use_gpibdev(const char* inst);
	CVirtualInstrument* use_gpibdev(const char* inst, int& slot); ///Hai add 22/08/03

	void SuspendTest();
	void ResumeTest();

private:
	int cmd_init(const char* item, const Json::Value& param);
	int cmd_wait(const char* item, const Json::Value& param);
	int cmd_message(const char* item, const Json::Value& param);
	int cmd_together(const char* item, const Json::Value& param);
	int cmd_only_one(const char* item, const Json::Value& param);
	int cmd_run_once(const char* item, const Json::Value& param);
	int cmd_end_test(const char* item, const Json::Value& param);
	int cmd_sfis_check_route(const char* item, const Json::Value& param);
	int cmd_sfis_get_previous_result(const char* item, const Json::Value& param);
	int cmd_sfis_get_config(const char* item, const Json::Value& param);
	int cmd_sfis_get_imac(const char* item, const Json::Value& param); //susu add
	int cmd_mac_addr(const char* item, const Json::Value& param);
	int cmd_get_isn_from_ui(const char* item, const Json::Value& param);
	int cmd_adb_devices(const char* item, const Json::Value& param);
	int cmd_fastboot_devices(const char* item, const Json::Value& param);
	int cmd_get_isn_fatp(const char* item, const Json::Value& param);
	int cmd_get_sysenv_info(const char* item, const Json::Value& param);
	int cmd_get_sysenv_info_mlb(const char* item, const Json::Value& param);
	int cmd_adb_command(const char* item, const Json::Value& param);
	int multi_adb_command(const char* item, const Json::Value& param); //  min add 20210125
	int cmd_fastboot_command(const char* item, const Json::Value& param);
	int cmd_fastboot_command2(const char* item, const Json::Value& param);
	int cmd_adb_wait_for_device(const char* item, const Json::Value& param);
	int cmd_fastboot_wait_for_device(const char* item, const Json::Value& param);
	int cmd_fastboot_flash(const char* item, const Json::Value& param);
	int cmd_fastboot_flash2(const char* item, const Json::Value& param);
	int cmd_fastboot_flash_unlock(const char* item, const Json::Value& param);
	int cmd_console_cmd(const char* item, const Json::Value& param);

	int cmd_self_comport(const char* item, const Json::Value& param);
	int cmd_open_serial(const char* item, const Json::Value& param);
	int cmd_serial_command(const char* item, const Json::Value& param);
	int cmd_close_serial(const char* item, const Json::Value& param);
		
	int cmd_get_sysenv_item(const char* item, const Json::Value& param);
	int cmd_set_sysenv_item(const char* item, const Json::Value& param);
	int cmd_upload_save_item(const char* item, const Json::Value& param);
	int cmd_input_data_ui(const char* item, const Json::Value& param);

	int cmd_telnet_open(const char* item, const Json::Value& param);
	int cmd_telnet_command(const char* item, const Json::Value& param);

	int cmd_read_qrcode(const char* item, const Json::Value& param);
	int cmd_check_qrcode(const char* item, const Json::Value& param);
	int cmd_compare_with_sfis(const char* item, const Json::Value& param);
	int cmd_compare_wifi_mac(const char* item, const Json::Value& param);
	int cmd_compare_15_4_mac(const char* item, const Json::Value& param);
	int cmd_check_sfis_info(const char* item, const Json::Value& param);
	int cmd_swdl_exclude_90pn(const char* item, const Json::Value& param);
	int cmd_swdl_sec_exclude_90pn(const char* item, const Json::Value& param);
	int cmd_ready_for_flash(const char* item, const Json::Value& param);
	int cmd_get_info_file_plist(const char* item, const Json::Value& param);
	int cmd_check_info(const char* item, const Json::Value& param);
	int cmd_check_info2(const char* item, const Json::Value& param);
	int cmd_check_info3(const char* item, const Json::Value& param);
	int cmd_90pn_map_image(const char* item, const Json::Value& param);
	int cmd_check_reboot(const char* item, const Json::Value& param);
	int cmd_get_isn_from_qrcode(const char* item, const Json::Value& param);

	int cmd_als_test(const char* item, const Json::Value& param);

	//DMM & PPS
	int pps_on(const char* item, const Json::Value& param);
	int pps_off(const char* item, const Json::Value& param);
	int pps_set_vol(const char* item, const Json::Value& param);
	int pps_set_curr(const char* item, const Json::Value& param);
	int pps_meas_curr(const char* item, const Json::Value& param);
	int route_open(const char* item, const Json::Value& param);
	int route_close(const char* item, const Json::Value& param);
	int meas_vol(const char* item, const Json::Value& param);
	int meas_curr(const char* item, const Json::Value& param);

	int cmd_checkpoint_Log(const char* item, const Json::Value& param);
	int cmd_assembly_Log(const char* item, const Json::Value& param);
	int cmd_components_log(const char* item, const Json::Value& param);

	// add by Vic
	char* utf8_to_ansi(const char* cptr_utf8);
	int cmd_message_pic_demo(const char* item, const Json::Value& param);
	int popup_pic_msg_form(const char* pic, const char* desc, const int btn_num);

	// add by Vic -- end --

	// add by Isaac
	int cmd_write_isn(const char* item, const Json::Value& param);
	int cmd_read_isn(const char* item, const Json::Value& param);


	int cmd_adb_command_mb(const char* item, const Json::Value& param);
	int cmd_adb_command_ex(const char* item, const Json::Value& param);
	// add by Isaac -- end --
	
	// add by Brighd -- start	20180130
	int cmd_when(const char* item, const Json::Value& param);
	// add by Brighd -- end		20180201
	int cmd_get_fatp_isn_via_ssn(const char* item, const Json::Value& param);
	string sfis_get_device_config();


	int check_button_cmd_adb_pic_have_timeout(const char* item, const Json::Value& param);// add by Min  20210104
	int CDut::check_ADD_PICTRUE_ITEMS(const char* item, const Json::Value& param); // add by Hai 20220716

private:
	typedef int (CDut::*FN_CMD)(const char* item, const Json::Value& param);
	std::map<string, CDut::FN_CMD> m_command;

	enum func_ret
	{
		RET_SUCCESS,
		RET_FAIL
	};

	enum{
		UI_RET_NONE,
		UI_RET_OK,
		UI_RET_CNACEL,
		UI_RET_ABORT,
		UI_RET_RETRY,
		UI_RET_IGNORE,
		UI_RET_YES,
		UI_RET_NO,
	};

public:
	int			m_id_no;
	string		m_id_name;
	TestMode	m_test_mode;
	int			m_repeat_count;
	InputData	m_input_data;
	string		m_scenario_name;
	string		m_scenario_ver;
	bool		m_check_route_pass;
	int			m_route_status;
	bool		m_upload_test_result_pass;

	string		m_dut_id;
	string		m_dut_comport;
	string		m_tag;
	bool		m_exit_test;
	bool		m_exit_test_and_no_sfis;
	string		m_temp_path;
	string		m_local_path;
	string		m_server_path;
	string		m_error_code;
	Json::Value	m_config;

	map<string, CRS232*> m_com;
	map<string, CMyTelnet*> m_telnet;
	CGPIBDevice	m_gpib_dev;

	string		m_isn;
	string		m_isn_fatp;
	string		m_isn_mlb;
	bool		m_is_rel;

	string		m_isn_ui; //min


	CUIReponse*	m_ui;
	CSfisCsv*	m_sfiscsv;
	CRdLog*		m_rdlog;
	CRdLog*		m_gpiblog;
	ProducerCsv m_producer;
	CCalcPeriod m_test_period;
	CDOS		m_dos;
	Json::Value	m_var;
	md5wrapper	m_md5;
	MyFtp*		m_myftp;

	
private:
	COtherDut	m_other_dut;
	CMyEvent m_suspend_event;

};


