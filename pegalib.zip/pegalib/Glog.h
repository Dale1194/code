
#include <string>
#include <iostream>
#include <fstream>
#include "csvfile.h"




using namespace std;

#pragma once

class CGlog : public CCSvFile
{
public:
	enum Severity {
		Info,
		Warning,
		Error,
		Fatal,
	};

private:
	map<Severity, string> m_severity;

public:
	CGlog(const char* name, const char* dir) : CCSvFile(name, dir)  {

		WriteLog("DATE_TIME,LOG_MESSAGE,SEVERITY\n");

		m_severity[Info] = "INFO";
		m_severity[Warning] = "WARNING";
		m_severity[Error] = "ERROR";
		m_severity[Fatal] = "FATAL";
	};

	~CGlog() {
	};
	
	void WriteRow(Severity severity, const char* buffer) {
		SYSTEMTIME sys_t;
		size_t size = strlen(buffer) + 64;
		char* p = NULL;

		p = new char[size];

		::GetSystemTime(&sys_t);
		sprintf_s(p, size, "%.4d-%.2d-%.2dT%.2d:%.2d:%.2dZ,%s,%s\n", sys_t.wYear, sys_t.wMonth, sys_t.wDay, sys_t.wHour, sys_t.wMinute, sys_t.wSecond, buffer, m_severity[severity].c_str());
		WriteLog(p);

		delete[] p;
	}

	void WriteRowf(Severity severity, const char *fmt, ...) {
		char buffer[4096];
		va_list	list;

		va_start(list, fmt);
		vsprintf_s(buffer, _countof(buffer), fmt, list);
		va_end(list);

		WriteRow(severity, buffer);
	}
	
};