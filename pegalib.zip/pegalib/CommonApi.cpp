#include "stdafx.h"
#include <Windows.h>
#include <VersionHelpers.h>
#include "CommonApi.h"
#include <string>
#include "Winnetwk.h"
#include <random>


#pragma comment(lib, "mpr.lib")


using namespace std;

#pragma once




CCriticalSection cs_dbg;


int ConnectNetNeighbor(const char* path, const char* id, const char* pwd)
{
	NETRESOURCEA nr;
	DWORD dwFlags = CONNECT_UPDATE_PROFILE;
	DWORD dwRetVal = S_FALSE;

	memset(&nr, 0, sizeof(NETRESOURCE));

	nr.dwType = RESOURCETYPE_ANY;
	nr.lpLocalName = NULL;
	nr.lpRemoteName = (LPSTR)path;
	nr.lpProvider = NULL;
	
	dwRetVal = WNetAddConnection2A(&nr, pwd, id, dwFlags);

	return dwRetVal;
}

long GetFileSize(const char* filename)
{
	struct stat stat_buf;
	int rc = stat(filename, &stat_buf);
	return rc == 0 ? stat_buf.st_size : -1;
}

void GetDateTimeFormatA(char* buffer, unsigned int len)
{
	SYSTEMTIME systime;
	GetLocalTime(&systime);
	sprintf_s(buffer, len, "%.4d-%.2d-%.2d %.2d:%.2d:%.2d", systime.wYear, systime.wMonth, systime.wDay, systime.wHour, systime.wMinute, systime.wSecond);
}

void GetSystemDateTimeFormatB(char* buffer, unsigned int len)
{
	SYSTEMTIME systime;
	GetSystemTime(&systime);
	sprintf_s(buffer, len, "%.4d%.2d%.2d%.2d%.2d%.2d", systime.wYear, systime.wMonth, systime.wDay, systime.wHour, systime.wMinute, systime.wSecond);
}

void GetWinVer(char* buffer, unsigned int len)
{
	if (::IsWindows8OrGreater())
		strcpy_s(buffer, len, "Win 10");
	else
		strcpy_s(buffer, len, "Win 7");
}

std::random_device rd;
std::default_random_engine ran_gen(rd());

float MyRandom(float min, float max)
{
	std::uniform_real_distribution<float> unif(min, max);
	return unif(ran_gen);
}





