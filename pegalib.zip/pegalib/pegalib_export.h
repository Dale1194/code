


#ifdef PEGALIB_EXPORTS
#define DLLEXPORT __declspec(dllexport)
#else
#define DLLEXPORT __declspec(dllimport)
#endif




extern "C"
{
	DLLEXPORT int __stdcall Lib_Init(const HWND hUIWnd, const char* script_file, const char* config_file, const char* criteria_file);
	DLLEXPORT int __stdcall Lib_StartTest(int id_no, const char* id_name, int test_mode, const char* input_data);
	DLLEXPORT int __stdcall Lib_SFISInit(const char* op_id);
	DLLEXPORT int __stdcall Lib_SFISLogin(const char* op_id);
	DLLEXPORT int __stdcall Lib_SFISLogout(VOID);
	DLLEXPORT int __stdcall Lib_FreeMem(LPVOID lp);
	DLLEXPORT int __stdcall Lib_SetEvent(LPVOID lp);
	DLLEXPORT int __stdcall Lib_BackFormData(const char* data1, const char* data2, const char* data3);
	DLLEXPORT int __stdcall Lib_UseComPort(const HWND hUIWnd, const char* com_name, int act_id, const char* cmd);
	DLLEXPORT int __stdcall just_test(const HWND hUIWnd);
}
