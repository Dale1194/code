// pegalib.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "pegalib_export.h"
#include "pegalib.h"
#include "Config.h"
#include "SFIS_Api.h"
#include "SFISLibApi.h"
#include "modules\comportdbg\ComPortDbg.h"
#include "modules\producer\Producer.h"
#include <string>
#include <direct.h>


using namespace std;


HWND	g_uiwnd = NULL;
string	g_data1, g_data2, g_data3;


string	g_script_file;
string	g_config_file;
string	g_criteria_file;



DLLEXPORT int __stdcall Lib_Init(const HWND hUIWnd, const char* script_file, const char* config_file, const char* criteria_file)
{
	::OutputDebugStringA("Lib_Init()++");

	g_uiwnd = hUIWnd;
	g_script_file = script_file;
	g_config_file = config_file;
	g_criteria_file = criteria_file;

	CCriteria::Init(g_criteria_file.c_str());
	CConfig::Init(g_config_file.c_str());

	if (CConfig::getInstance()->cfg_iplas.enable)
		CProducer::Init(CConfig::getInstance()->cfg_device_id.c_str());

	create_directory(CConfig::getInstance()->cfg_log_dir.c_str());
	if (CConfig::getInstance()->cfg_server_log.enable_save == true)
	{
		connect_net_neighbor();
		create_directory(CConfig::getInstance()->cfg_server_log.directory.c_str());
	}

	_mkdir("crash_backup");

	::OutputDebugStringA("Lib_Init()--");
	return 0;
}

DLLEXPORT int __stdcall Lib_StartTest(int id_no, const char* id_name, int test_mode, const char* input_data)
{
	::OutputDebugStringA("Lib_StartTest()++");
	
	UI_ATTR* ui = new UI_ATTR();
	ui->no = id_no;
	strcpy_s(ui->name, id_name);
	ui->testMode = (TestMode)test_mode;
	strcpy_s(ui->scenarioFile, g_script_file.c_str());
	proc_input_data(input_data, *ui);

	if (resume_if_debug_when_fail(id_name) == false)
		::CreateThread(NULL, 0, start_test_thread, (LPVOID)ui, 0, NULL);

	::OutputDebugStringA("Lib_StartTest()--");
	return 0;
}

DLLEXPORT int __stdcall Lib_SFISInit(const char* op_id)
{
	string			path;
	/// <summary>
	/// /////
	/// </summary>
	/// <param name="op_id"></param>
	/// <returns></returns>
	SFIS_INTERFACE	st;
	
	GetCurrentPath(path);

	memset(&st, 0, sizeof(st));
	strcpy_s(st.szUserID, op_id);
	sprintf_s(st.szINIFile, "%s\\SFIS.ini", path.c_str());
	sprintf_s(st.szErrorCodeFile, "%s\\ErrorCode.txt", path.c_str());
	strcpy_s(CSFIS_Api::getInstance()->m_sfis_st.szUserID, op_id);
	//CConfig::getInstance()->cfg_new_sfis_dll = false; // Hai add 22/07/30
	if (!CConfig::getInstance()->cfg_new_sfis_dll)
		CSFIS_Api::getInstance()->Init(st);
	else
		CSFISLibApi::getInstance()->Init(op_id);

	return 0;
}

DLLEXPORT int __stdcall Lib_SFISLogin(const char* op_id)
{
	::OutputDebugStringA("Lib_SFISLogin()++");

	int				ret = -1;
	string			result;
		
	if (!CConfig::getInstance()->cfg_new_sfis_dll)
		ret = CSFIS_Api::getInstance()->CheckConnection();
	else
		ret = CSFISLibApi::getInstance()->GetDbInfo(result);

	if (ret == ERROR_SUCCESS)
	{
		if (!CConfig::getInstance()->cfg_new_sfis_dll)
			ret = CSFIS_Api::getInstance()->Login(op_id);
		else
			ret = CSFISLibApi::getInstance()->Login(op_id, result);
	}

	if (ret != ERROR_SUCCESS)
	{
		if (!CConfig::getInstance()->cfg_new_sfis_dll)
			::MessageBoxA(g_uiwnd, CSFIS_Api::getInstance()->m_sfis_st.szMessage, "SFIS Info", MB_OK + MB_ICONERROR);
		else
		{
			CSFISLibApi::getInstance()->GetErrMsg(result);
			if (result.find("Login Twice") != string::npos)
				ret = ERROR_SUCCESS;
			else
				MessageBoxA(g_uiwnd, result.c_str(), "SFIS Info", MB_OK + MB_ICONERROR);
		}
	}

	::OutputDebugStringA("Lib_SFISLogin()--");
	return ret;
}

DLLEXPORT int __stdcall Lib_SFISLogout(VOID)
{
	::OutputDebugStringA("Lib_SFISLogout()++");

	if (!CConfig::getInstance()->cfg_new_sfis_dll)
	{
		CSFIS_Api::getInstance()->Logout();
		CSFIS_Api::getInstance()->m_pfnSFIS_Disconnect();
	}
	else
		CSFISLibApi::getInstance()->Logout();

	::OutputDebugStringA("Lib_SFISLogout()--");
	return 0;
}

DLLEXPORT int __stdcall Lib_FreeMem(LPVOID lp)
{
	//::OutputDebugStringA("Lib_FreeMem()++");
	
	delete[] lp;

	//::OutputDebugStringA("Lib_FreeMem()--");
	return 0;
}

DLLEXPORT int __stdcall Lib_SetEvent(LPVOID lp)
{
	::OutputDebugStringA("Lib_SetEvent()++");
	
	SetEvent((HANDLE)lp);

	::OutputDebugStringA("Lib_SetEvent()--");
	return 0;
}

DLLEXPORT int __stdcall Lib_BackFormData(const char* data1, const char* data2, const char* data3)
{
	::OutputDebugStringA("Lib_BackFormData()++");

	g_data1 = data1;
	g_data2 = data2;
	g_data3 = data3;

	::OutputDebugStringA("Lib_BackFormData()--");
	return 0;
}

DLLEXPORT int __stdcall Lib_UseComPort(const HWND hUIWnd, const char* com_name, int act_id, const char* cmd)
{
	int ret = S_FALSE;

	switch (act_id)
	{
	case ComDbgActId::INIT:
		ret = CComPortDbg::getInstance()->Init(hUIWnd, com_name);
			break;
	case ComDbgActId::SENDCMD:
		ret = CComPortDbg::getInstance()->SendCommand(cmd);
			break;
	case ComDbgActId::UINIT:
		ret = CComPortDbg::getInstance()->Uninit();
			break;
	}

	return ret;
}


DLLEXPORT int __stdcall just_test(const HWND hUIWnd)
{
	::OutputDebugStringA("just_test()++");

	g_uiwnd = hUIWnd;

	::OutputDebugStringA("just_test()--");
	return 0;
}


