

#pragma once

static const char SFISLOGIN[] = "1";
static const char SFISLOGOUT[] = "2";

#define ERRORCODE_OK		0
#define ERRORCODE_FAILED	1

struct SfisService
{
	virtual int WINAPI GetDatabaseInformation(std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI Loginout(const char* op, const char* device, const char* tsp, const char* status, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI ChkRoute(const char* isn, const char* device, const char* chkflag, const char* chkdata, const char* type, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI GetVersion(const char* isn, const char* device, const char* type, const char* chkdata, const char* chkdata2, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI Repair(const char* type, const char* isn, const char* device, const char* tsp, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI Result(const char* isn, const char* error, const char* device, const char* tsp, const char* data, const char* status, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI GetIMac(const char* device, const char* isn, const char* status, const char* num, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI GetI1394(const char* device, const char* isn, const char* status, const char* num, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI SendMail(const char* subject, const char* sendto, const char* sendtext, std::string& result) { return ERRORCODE_FAILED; };
	virtual int WINAPI SsdInputdata(const char* device, const char* data, const char* type, std::string& result) { return ERRORCODE_FAILED; };
	virtual void WINAPI GetErrorMsg(std::string& err_msg) { };
	virtual void WINAPI FreeResource(void) { };
};

typedef HRESULT(WINAPI *CREATE_SFISTESTSERVICE)(const char* sfis_url, SfisService*& sfis_service);

