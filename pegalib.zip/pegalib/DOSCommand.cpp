#include "stdafx.h"
#include "DOSCommand.h"
#include "CommonApi.h"
#include <cassert>

CDOS cdos;

enum en_ret
{
	TEST_SUCCESS,
	TEST_FAIL
};

CDOS::CDOS()
{

}
CDOS::~CDOS()
{

}

INT CDOS::InitConsole()
{
	SECURITY_ATTRIBUTES sa;
	HANDLE hInWrite, hInRead;
	HANDLE hOutWrite, hOutRead;

	sa.bInheritHandle = true;
	sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(sa);
	::CreatePipe(&hOutRead, &hOutWrite, &sa, 0);
	::DuplicateHandle(::GetCurrentProcess(), hOutRead, ::GetCurrentProcess(), &m_hOutReadData, 0, false, DUPLICATE_SAME_ACCESS);
	::CloseHandle(hOutRead);

	::CreatePipe(&hInRead, &hInWrite, &sa, 0);
	::DuplicateHandle(::GetCurrentProcess(), hInWrite, ::GetCurrentProcess(), &m_hInWriteData, 0, false, DUPLICATE_SAME_ACCESS);
	::CloseHandle(hInWrite);

	STARTUPINFOA si;
	::ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;
	si.hStdInput = hInRead;
	si.hStdOutput = hOutWrite;
	si.hStdError = ::GetStdHandle(STD_ERROR_HANDLE);

	PROCESS_INFORMATION pi;
	::ZeroMemory(&pi, sizeof(pi));
	if(::CreateProcessA(NULL, "cmd", NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		::CloseHandle(hInRead);
		::CloseHandle(hOutWrite);
		::CloseHandle(pi.hProcess);
		m_bEnableConsole = TRUE;

		m_hThread = ::CreateThread(NULL, 0, CDOS::Thread_Console, (LPVOID)this, CREATE_SUSPENDED, &m_dwThreadID);
		::SetThreadPriority(m_hThread, THREAD_PRIORITY_NORMAL);
		::ResumeThread(m_hThread);
	}
	else
	{
		return !ERROR_SUCCESS;
	}

	return ERROR_SUCCESS;
}

DWORD WINAPI CDOS::Thread_Console(LPVOID param)
{
	DWORD dwReadBytes = 0;
	CHAR szBuffer[4096] = {0x00};

	while(((CDOS*)param)->m_bEnableConsole)
	{
		memset(szBuffer, 0x00, sizeof(szBuffer));
		::ReadFile(((CDOS*)param)->m_hOutReadData, szBuffer, sizeof(szBuffer), &dwReadBytes, NULL);
		if(dwReadBytes)
		{
			memcpy(((CDOS*)param)->m_szMessage, szBuffer, dwReadBytes);
		}
	}
	return ERROR_SUCCESS;
}


INT CDOS::Send(CHAR *pcCommand, CHAR *pcMessage)
{
	// http://www.china-askpro.com/msg48/qa29.shtml
	// C:\Program Files\Borland\CBuilder6\Examples\WinTools

	INT iStatus = ERROR_SUCCESS;

	LPSECURITY_ATTRIBUTES lpsa = NULL;
	SECURITY_DESCRIPTOR sd;
	SECURITY_ATTRIBUTES sa;

	::ZeroMemory(&lpsa, sizeof(lpsa));
	::ZeroMemory(&sa, sizeof(sa));
	::ZeroMemory(&sd, sizeof(sd));

	::InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION);
	::SetSecurityDescriptorDacl(&sd, true, NULL, false);
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = true;
	sa.lpSecurityDescriptor = &sd;
	lpsa = &sa;

	HANDLE hReadPipe, hWritePipe;
	::CreatePipe(&hReadPipe, &hWritePipe, lpsa, 2500000);

	STARTUPINFOA si;
	::ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;	
	si.wShowWindow = SW_HIDE; 	//SW_MINIMIZE;
	si.hStdOutput = hWritePipe;	//GetStdHandle(STD_OUTPUT_HANDLE);
	si.hStdError = hWritePipe;	//GetStdHandle(STD_OUTPUT_HANDLE);

	PROCESS_INFORMATION pi;
	::ZeroMemory(&pi, sizeof(pi));
	if(::CreateProcessA(NULL, pcCommand, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	// if(::CreateProcess("test", pcCommand, NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
	{
		::CloseHandle(pi.hThread);
		::WaitForSingleObject(pi.hProcess, 10000);

		CHAR szBuffer[8192] = {0x00};
		char* p = szBuffer;
		DWORD dwReadBytes = 0;
		INT iCount = 0;
		BOOL bLoop = FALSE;
		while(!bLoop)
		{
			// Check pipe data exist or not
			::PeekNamedPipe(hReadPipe, p, 4096, &dwReadBytes, NULL, NULL);
			if (dwReadBytes > 0)
			{
				//memset(szBuffer, 0, sizeof(szBuffer));
				::ReadFile(hReadPipe, p, dwReadBytes, &dwReadBytes, NULL);
				p = p + dwReadBytes;
				assert((p - szBuffer) < (sizeof(szBuffer) - 1));
				// if(dwReadBytes < 1024) bLoop = TRUE;
				if(iCount > 300) bLoop = TRUE;
				iCount++;
				::Sleep(97);
			}
			else
			{
				break;
			}
		}
		strcpy_s(pcMessage, 1024, szBuffer);
	}
	else
	{
		strcpy_s(pcMessage, 64, "CreateProcess Fail!");
		iStatus = -1;
	}

	::CloseHandle(hReadPipe);
	::CloseHandle(hWritePipe);
	::CloseHandle(pi.hProcess);

	return iStatus;
}

int CDOS::Send(const char* command, string& result, unsigned int timeout, unsigned int wait, unsigned int timeout_noresponse)
{
	INT iStatus = ERROR_SUCCESS;
	CCalcPeriod period;

	result = "";

	LPSECURITY_ATTRIBUTES lpsa = NULL;
	SECURITY_DESCRIPTOR sd;
	SECURITY_ATTRIBUTES sa;

	::ZeroMemory(&lpsa, sizeof(lpsa));
	::ZeroMemory(&sa, sizeof(sa));
	::ZeroMemory(&sd, sizeof(sd));

	::InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION);
	::SetSecurityDescriptorDacl(&sd, true, NULL, false);
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = true;
	sa.lpSecurityDescriptor = &sd;
	lpsa = &sa;

	HANDLE hReadPipe, hWritePipe;
	::CreatePipe(&hReadPipe, &hWritePipe, lpsa, 2500000);

	STARTUPINFOA si;
	::ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE; 	//SW_MINIMIZE;
	si.hStdOutput = hWritePipe;	//GetStdHandle(STD_OUTPUT_HANDLE);
	si.hStdError = hWritePipe;	//GetStdHandle(STD_OUTPUT_HANDLE);

	PROCESS_INFORMATION pi;
	::ZeroMemory(&pi, sizeof(pi));
	if (::CreateProcessA(NULL, (char*)command, NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
		// if(::CreateProcess("test", pcCommand, NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
	{
		::CloseHandle(pi.hThread);
		::WaitForSingleObject(pi.hProcess, timeout_noresponse);

		CHAR szBuffer[8192] = { 0x00 };
		char* p = szBuffer;
		DWORD dwReadBytes = 0;
		unsigned int iCount = 0;

		period.GetTimeA();
		do
		{
			// Check pipe data exist or not
			::PeekNamedPipe(hReadPipe, p, 4096, &dwReadBytes, NULL, NULL);
			if (dwReadBytes > 0)
			{
				memset(szBuffer, 0, sizeof(szBuffer));
				::ReadFile(hReadPipe, szBuffer, dwReadBytes, &dwReadBytes, NULL);
				result = result + szBuffer;
				::Sleep(wait);
			}
			else
			{
				break;
			}
			period.GetTimeB();
		} while (period.GetDiff() < timeout);
	}
	else
	{
		result = "CreateProcess Fail!";
		iStatus = -1;
	}

	::CloseHandle(hReadPipe);
	::CloseHandle(hWritePipe);
	::CloseHandle(pi.hProcess);

	return iStatus;
}

int CDOS::Send(const char* command, string& result, const char* tmnl, unsigned int wait, unsigned int timeout)
{
	INT iStatus = ERROR_SUCCESS;
	CCalcPeriod period;

	result = "";

	LPSECURITY_ATTRIBUTES lpsa = NULL;
	SECURITY_DESCRIPTOR sd;
	SECURITY_ATTRIBUTES sa;

	::ZeroMemory(&lpsa, sizeof(lpsa));
	::ZeroMemory(&sa, sizeof(sa));
	::ZeroMemory(&sd, sizeof(sd));

	::InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION);
	::SetSecurityDescriptorDacl(&sd, true, NULL, false);
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = true;
	sa.lpSecurityDescriptor = &sd;
	lpsa = &sa;

	HANDLE hReadPipe, hWritePipe;
	::CreatePipe(&hReadPipe, &hWritePipe, lpsa, 2500000);

	STARTUPINFOA si;
	::ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE; 	//SW_MINIMIZE;
	si.hStdOutput = hWritePipe;	//GetStdHandle(STD_OUTPUT_HANDLE);
	si.hStdError = hWritePipe;	//GetStdHandle(STD_OUTPUT_HANDLE);

	PROCESS_INFORMATION pi;
	::ZeroMemory(&pi, sizeof(pi));
	if (::CreateProcessA(NULL, (char*)command, NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
		// if(::CreateProcess("test", pcCommand, NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
	{
		::CloseHandle(pi.hThread);
		::WaitForSingleObject(pi.hProcess, 10000);

		CHAR szBuffer[8192] = { 0x00 };
		char* p = szBuffer;
		DWORD dwReadBytes = 0;
		unsigned int iCount = 0;

		period.GetTimeA();
		do
		{
			// Check pipe data exist or not
			::PeekNamedPipe(hReadPipe, p, 4096, &dwReadBytes, NULL, NULL);
			if (dwReadBytes > 0)
			{
				memset(szBuffer, 0, sizeof(szBuffer));
				::ReadFile(hReadPipe, szBuffer, dwReadBytes, &dwReadBytes, NULL);
				result = result + szBuffer;

				if (strstr(szBuffer, tmnl) != NULL)
					break;

				::Sleep(wait);
			}
			period.GetTimeB();
		} while (period.GetDiff() < timeout);
	}
	else
	{
		result = "CreateProcess Fail!";
		iStatus = -1;
	}

	::CloseHandle(hReadPipe);
	::CloseHandle(hWritePipe);
	::CloseHandle(pi.hProcess);

	return iStatus;
}


//***************************************************************************
// Describtion�Gfor wifi resolve ip address
//***************************************************************************

INT CDOS::TerminalCommand(CHAR *pcCommand, CHAR *pcMessage)
{
	// http://www.china-askpro.com/msg48/qa29.shtml
	// C:\Program Files\Borland\CBuilder6\Examples\WinTools

	INT iStatus = ERROR_SUCCESS;
	/*
	LPSECURITY_ATTRIBUTES lpsa = NULL;
	SECURITY_DESCRIPTOR sd;
	SECURITY_ATTRIBUTES sa;

	::ZeroMemory(&lpsa, sizeof(lpsa));
	::ZeroMemory(&sa, sizeof(sa));
	::ZeroMemory(&sd, sizeof(sd));

	::InitializeSecurityDescriptor(&sd, SECURITY_DESCRIPTOR_REVISION);
	::SetSecurityDescriptorDacl(&sd, true, NULL, false);
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = true;
	sa.lpSecurityDescriptor = &sd;
	lpsa = &sa;
	*/
	//HANDLE hReadPipe, hWritePipe;
	//::CreatePipe(&hReadPipe, &hWritePipe, lpsa, 2500000);
	HANDLE hInWrite,hInRead,hInWriteTemp;
	HANDLE hOutWrite,hOutRead,hOutReadTemp;
	SECURITY_ATTRIBUTES sa;

	sa.bInheritHandle = true;
	sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(sa);

	/*
	BOOL WINAPI CreatePipe(
		__out     PHANDLE hReadPipe, // receives the read handle for the pipe.
		__out     PHANDLE hWritePipe, // receives the write handle for the pipe.
		__in_opt  LPSECURITY_ATTRIBUTES lpPipeAttributes,
		__in      DWORD nSize
	);
	*/
	::CreatePipe(&hOutRead, &hOutWrite, &sa, 0);
	::DuplicateHandle(::GetCurrentProcess(), hOutRead, ::GetCurrentProcess(), &hOutReadTemp, 0, false, DUPLICATE_SAME_ACCESS);
	::CloseHandle(hOutRead);

	::CreatePipe(&hInRead, &hInWrite, &sa, 0);
	::DuplicateHandle(::GetCurrentProcess(), hInWrite, ::GetCurrentProcess(), &hInWriteTemp, 0, false, DUPLICATE_SAME_ACCESS);
	::CloseHandle(hInWrite);

	STARTUPINFOA si;
	::ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;
	si.hStdInput = hInRead;
	si.hStdOutput = hOutWrite;
	si.hStdError = ::GetStdHandle(STD_ERROR_HANDLE);

	PROCESS_INFORMATION pi;
	::ZeroMemory(&pi, sizeof(pi));
	if(::CreateProcessA(NULL, pcCommand, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		::CloseHandle(hInRead);
		::CloseHandle(hOutWrite);

		CHAR szBuffer[4096] = {0x00};
		DWORD dwReadBytes = 0;

		while(::ReadFile(hOutReadTemp, szBuffer, sizeof(szBuffer), &dwReadBytes, NULL))
		{
			szBuffer[dwReadBytes] = '\n';
			//OUTPUT(szBuffer);
			if (::GetLastError() == ERROR_BROKEN_PIPE) break;
		}
		strcpy_s(pcMessage, 1024, szBuffer);
		::WaitForSingleObject(pi.hProcess, 500);
		::CloseHandle(hOutReadTemp);
		::CloseHandle(hInWriteTemp);
		::CloseHandle(pi.hProcess);
	}
	else
	{
		strcpy_s(pcMessage, 1024, "CreateProcess Fail!");
		iStatus = -1;
	}

	return iStatus;
}

INT CDOS::TerminalFileUpload(CHAR *pcCommand, INT iTimeOut, INT* iExeTime, char *pFile)
{
	INT iStatus = ERROR_SUCCESS;
	INT iTime = 0;
	bool bFind = false;

	HANDLE hInWrite,hInRead,hInWriteTemp;
	HANDLE hOutWrite,hOutRead,hOutReadTemp;
	SECURITY_ATTRIBUTES sa;

	sa.bInheritHandle = true;
	sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(sa);

	::CreatePipe(&hOutRead, &hOutWrite, &sa, 0);
	::DuplicateHandle(::GetCurrentProcess(), hOutRead, ::GetCurrentProcess(), &hOutReadTemp, 0, false, DUPLICATE_SAME_ACCESS);
	::CloseHandle(hOutRead);

	::CreatePipe(&hInRead, &hInWrite, &sa, 0);
	::DuplicateHandle(::GetCurrentProcess(), hInWrite, ::GetCurrentProcess(), &hInWriteTemp, 0, false, DUPLICATE_SAME_ACCESS);
	::CloseHandle(hInWrite);

	STARTUPINFOA si;
	::ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE;
	si.hStdInput = hInRead;
	si.hStdOutput = hOutWrite;
	si.hStdError = ::GetStdHandle(STD_ERROR_HANDLE);

	PROCESS_INFORMATION pi;
	::ZeroMemory(&pi, sizeof(pi));

	iTime = ::GetTickCount();
	if(::CreateProcessA(NULL, pcCommand, NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
	{
		::CloseHandle(hInRead);
		::CloseHandle(hOutWrite);

		CHAR szBuffer[1024] = {0x00};
		DWORD dwReadBytes = 0;

		int iTimeFindFile = ::GetTickCount() + iTimeOut;
		while((int)::GetTickCount() < iTimeFindFile)
		{
			FILE* fp;
			if (fopen_s(&fp, pFile, "r") == 0)
			{
				iTime = ::GetTickCount();
				fclose(fp);
				bFind = true;
				break;
			}
		}

		if(!bFind)
		{
			::CloseHandle(hOutReadTemp);
			::CloseHandle(hInWriteTemp);
			::CloseHandle(pi.hProcess);
			return WAIT_TIMEOUT;
		}

		if(WAIT_OBJECT_0 != ::WaitForSingleObject(pi.hProcess, iTimeOut))
		{
			iStatus = WAIT_TIMEOUT;
		}
		*iExeTime = ::GetTickCount() - iTime;
		::CloseHandle(hOutReadTemp);
		::CloseHandle(hInWriteTemp);
		::CloseHandle(pi.hProcess);
	}
	else
	{
		//strcpy(pcMessage, "CreateProcess Fail!");
		iStatus = TEST_FAIL;;
	}

	return iStatus;
}

INT CDOS::WifiMacFormat(CONST CHAR *pcInputWifiMac, CHAR *pcNewWifiMac)
{
	CHAR szWifiMac[32] = {0x00};
	INT i = 0;
	INT j = 0;

	for(i=0, j=0; i < (int)strlen(pcInputWifiMac); i++, j++)
	{
		szWifiMac[j] = pcInputWifiMac[i];
		if(i%2==1 && i!=11)
		{
			j++;
			szWifiMac[j] = '-';
		}
	}
	szWifiMac[j] = 0x00;
	//sprintf(pcNewWifiMac, "%s", szWifiMac);
	strcpy_s(pcNewWifiMac, 32, szWifiMac);

	return ERROR_SUCCESS;
}

INT CDOS::FindIPAddress(CHAR *pcCmdBuffer, CHAR *pcWifiMac, CHAR *pcIP)
{
	CHAR *p = NULL;
	CHAR szIP[32] = {0x00};

	_strlwr_s(pcWifiMac, 32);
	if(p = strstr(pcCmdBuffer, pcWifiMac))
	{
		for(int i=p-pcCmdBuffer-22, j=0; pcCmdBuffer[i] != 0x20; i++, j++)
		{
			szIP[j] = pcCmdBuffer[i];
		}
		if(strlen(szIP))
		{
			//sprintf(pcIP, "%s", szIP);
			strcpy_s(pcIP, 32, szIP);
		}
		else
		{
			sprintf_s(pcIP, 32, "FAIL:%s", szIP);
		}
	}
	else
	{
		sprintf_s(pcIP, 32, "FAIL: Can't find ip address from buffer.");
		return TEST_FAIL;
	}

	return ERROR_SUCCESS;
}
INT CDOS::ResolveIP(CONST CHAR *pcMacAddress, CHAR *pcIP)
{
	int iStatus = TEST_SUCCESS;
	// to MAC format
	CHAR szWifiMacFormat[32] = {0x00};
	WifiMacFormat(pcMacAddress, szWifiMacFormat);

	// Resolve MAC address
	CHAR szCmdBuffer[1024] = {0x00};
	TerminalCommand("arp -a", szCmdBuffer);

	// Find IP address
	CHAR szIP[64] = {0x00};
	iStatus = FindIPAddress(szCmdBuffer, szWifiMacFormat, szIP);

	//sprintf(pcIP, "%s", szIP);
	strcpy_s(pcIP, 64, szIP);

	return iStatus;
}
 

 