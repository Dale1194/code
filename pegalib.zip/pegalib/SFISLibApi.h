
#include <string>
#include <memory>
#include "SfisCsv.h"
#include "ErrorCode.h"
#include "ISfisTestSuites.h"

#pragma once

class CSFISLibApi
{
private:
	CSFISLibApi();

public:
	virtual ~CSFISLibApi();

	static CSFISLibApi* getInstance() {
		static std::auto_ptr<CSFISLibApi> pObj(new CSFISLibApi);
		return pObj.get();
	};


public:
	void Init(const char* userid);
	int GetDbInfo(string& result);
	int Login(const char* user_id, string& result);
	int Login(string& result);
	int Logout();
	int ChkRoute(const char* isn, string& result);
	int GetVersion(const char* isn, const char* ptype, const char* chkdata, const char* chkdata2, string& result);
	int GetVersion(const char* isn, const char* deviceid, const char* ptype, const char* chkdata, const char* chkdata2, string& result);
	int GetIMac(const char* isn, const char* status, const char* num, std::string& result);
	int Repair(const char* isn, string& result);
	int Result(const char* isn, const char* errcode, const char* data, string& result);
	int SsdInputdata(const char* data, const char* type, string& result);
	void GetErrMsg(string& errmsg);
	int GenerateErrorCode(CSfisCsv* sfis_csv, string& err_code);
	void ListItemsWithoutErrorCode(CSfisCsv* sfis_csv, string& items);
	const char* GetSfisResult();
	void GetSfisResult(vector<string>& result);
	const char* GetUserId();
	const char* GetDbInfo();
	const char* GetUserName();
	const char* GetStreamData();
	




private:
	int read_sfis_ini();
	int load_dll();
	int read_erro_code();


private:
	char m_sfis_web_vervice_url[256];
	char m_sfis_tsp[64];
	char m_sfis_device_id[12];
	char m_sfis_checkroute_type[8];
	char m_sfis_testresult_type[8];
	char m_sfis_autorepair_type[8];

	string m_user_id;
	string m_db_info;
	string m_user_name;
	string m_sfisws_result;
	string m_sfis_stream_data;
	string m_error_code;

	CErrorCode*		m_err_code;

	HMODULE	m_handle;
	CREATE_SFISTESTSERVICE m_create_sfis_test_service;
	SfisService* m_sfis_service;
};

