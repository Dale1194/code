﻿namespace MultiTest
{
    partial class ScenarioForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxScenario = new System.Windows.Forms.TextBox();
            this.comboBoxScenario = new System.Windows.Forms.ComboBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.textBoxIdTitle = new System.Windows.Forms.TextBox();
            this.textBoxId = new System.Windows.Forms.TextBox();
            this.btnOffline = new System.Windows.Forms.Button();
            this.textBoxConfig = new System.Windows.Forms.TextBox();
            this.textBoxCriteria = new System.Windows.Forms.TextBox();
            this.comboBoxConfig = new System.Windows.Forms.ComboBox();
            this.comboBoxCriteria = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // textBoxScenario
            // 
            this.textBoxScenario.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxScenario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxScenario.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxScenario.Location = new System.Drawing.Point(33, 133);
            this.textBoxScenario.Name = "textBoxScenario";
            this.textBoxScenario.ReadOnly = true;
            this.textBoxScenario.Size = new System.Drawing.Size(100, 26);
            this.textBoxScenario.TabIndex = 0;
            this.textBoxScenario.TabStop = false;
            this.textBoxScenario.Text = "Scenario:";
            // 
            // comboBoxScenario
            // 
            this.comboBoxScenario.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBoxScenario.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxScenario.FormattingEnabled = true;
            this.comboBoxScenario.Location = new System.Drawing.Point(128, 133);
            this.comboBoxScenario.Name = "comboBoxScenario";
            this.comboBoxScenario.Size = new System.Drawing.Size(492, 34);
            this.comboBoxScenario.TabIndex = 2;
            // 
            // btnOK
            // 
            this.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnOK.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(158, 266);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(98, 40);
            this.btnOK.TabIndex = 6;
            this.btnOK.Text = "On-line";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // textBoxIdTitle
            // 
            this.textBoxIdTitle.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxIdTitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxIdTitle.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIdTitle.Location = new System.Drawing.Point(33, 41);
            this.textBoxIdTitle.Name = "textBoxIdTitle";
            this.textBoxIdTitle.Size = new System.Drawing.Size(100, 26);
            this.textBoxIdTitle.TabIndex = 7;
            this.textBoxIdTitle.TabStop = false;
            this.textBoxIdTitle.Text = "ID:";
            // 
            // textBoxId
            // 
            this.textBoxId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxId.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxId.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxId.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBoxId.Location = new System.Drawing.Point(128, 41);
            this.textBoxId.Name = "textBoxId";
            this.textBoxId.Size = new System.Drawing.Size(245, 24);
            this.textBoxId.TabIndex = 4;
            this.textBoxId.TextChanged += new System.EventHandler(this.textBoxId_TextChanged);
            // 
            // btnOffline
            // 
            this.btnOffline.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOffline.Location = new System.Drawing.Point(304, 266);
            this.btnOffline.Name = "btnOffline";
            this.btnOffline.Size = new System.Drawing.Size(98, 40);
            this.btnOffline.TabIndex = 5;
            this.btnOffline.Text = "Off-line";
            this.btnOffline.UseVisualStyleBackColor = true;
            this.btnOffline.Click += new System.EventHandler(this.btnOffline_Click);
            // 
            // textBoxConfig
            // 
            this.textBoxConfig.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxConfig.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxConfig.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxConfig.Location = new System.Drawing.Point(33, 85);
            this.textBoxConfig.Name = "textBoxConfig";
            this.textBoxConfig.Size = new System.Drawing.Size(100, 26);
            this.textBoxConfig.TabIndex = 8;
            this.textBoxConfig.TabStop = false;
            this.textBoxConfig.Text = "Config:";
            // 
            // textBoxCriteria
            // 
            this.textBoxCriteria.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxCriteria.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCriteria.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCriteria.Location = new System.Drawing.Point(33, 181);
            this.textBoxCriteria.Name = "textBoxCriteria";
            this.textBoxCriteria.Size = new System.Drawing.Size(100, 26);
            this.textBoxCriteria.TabIndex = 9;
            this.textBoxCriteria.TabStop = false;
            this.textBoxCriteria.Text = "Criteria:";
            // 
            // comboBoxConfig
            // 
            this.comboBoxConfig.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBoxConfig.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxConfig.FormattingEnabled = true;
            this.comboBoxConfig.Location = new System.Drawing.Point(128, 85);
            this.comboBoxConfig.Name = "comboBoxConfig";
            this.comboBoxConfig.Size = new System.Drawing.Size(492, 34);
            this.comboBoxConfig.TabIndex = 1;
            this.comboBoxConfig.SelectedIndexChanged += new System.EventHandler(this.comboBoxConfig_SelectedIndexChanged);
            // 
            // comboBoxCriteria
            // 
            this.comboBoxCriteria.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBoxCriteria.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxCriteria.FormattingEnabled = true;
            this.comboBoxCriteria.Location = new System.Drawing.Point(128, 181);
            this.comboBoxCriteria.Name = "comboBoxCriteria";
            this.comboBoxCriteria.Size = new System.Drawing.Size(492, 34);
            this.comboBoxCriteria.TabIndex = 3;
            // 
            // ScenarioForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 318);
            this.Controls.Add(this.comboBoxCriteria);
            this.Controls.Add(this.comboBoxConfig);
            this.Controls.Add(this.textBoxCriteria);
            this.Controls.Add(this.textBoxConfig);
            this.Controls.Add(this.btnOffline);
            this.Controls.Add(this.textBoxId);
            this.Controls.Add(this.textBoxIdTitle);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.comboBoxScenario);
            this.Controls.Add(this.textBoxScenario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "ScenarioForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Scenario Select";
            this.Load += new System.EventHandler(this.ScenarioForm_Load);
            this.Shown += new System.EventHandler(this.ScenarioForm_Shown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxScenario;
        private System.Windows.Forms.ComboBox comboBoxScenario;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox textBoxIdTitle;
        private System.Windows.Forms.TextBox textBoxId;
        private System.Windows.Forms.Button btnOffline;
        private System.Windows.Forms.TextBox textBoxConfig;
        private System.Windows.Forms.TextBox textBoxCriteria;
        private System.Windows.Forms.ComboBox comboBoxConfig;
        private System.Windows.Forms.ComboBox comboBoxCriteria;
    }
}