﻿namespace MultiTest
{
    partial class InputForm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnStartTest = new System.Windows.Forms.Button();
            this.tb_loop_title = new System.Windows.Forms.TextBox();
            this.tb_wait_title = new System.Windows.Forms.TextBox();
            this.tb_loop_data = new System.Windows.Forms.TextBox();
            this.tb_wait_data = new System.Windows.Forms.TextBox();
            this.chkbox_one_panel = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(40, 45);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(330, 349);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // btnStartTest
            // 
            this.btnStartTest.Font = new System.Drawing.Font("Calibri", 14.1F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartTest.Location = new System.Drawing.Point(264, 435);
            this.btnStartTest.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStartTest.Name = "btnStartTest";
            this.btnStartTest.Size = new System.Drawing.Size(106, 58);
            this.btnStartTest.TabIndex = 1;
            this.btnStartTest.Text = "Test";
            this.btnStartTest.UseVisualStyleBackColor = true;
            this.btnStartTest.EnabledChanged += new System.EventHandler(this.btnStartTest_EnabledChanged);
            this.btnStartTest.Click += new System.EventHandler(this.btnStartTest_Click);
            // 
            // tb_loop_title
            // 
            this.tb_loop_title.BackColor = System.Drawing.SystemColors.Control;
            this.tb_loop_title.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_loop_title.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_loop_title.Location = new System.Drawing.Point(40, 445);
            this.tb_loop_title.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_loop_title.Name = "tb_loop_title";
            this.tb_loop_title.ReadOnly = true;
            this.tb_loop_title.Size = new System.Drawing.Size(58, 20);
            this.tb_loop_title.TabIndex = 2;
            this.tb_loop_title.TabStop = false;
            this.tb_loop_title.Text = "Loop:";
            // 
            // tb_wait_title
            // 
            this.tb_wait_title.BackColor = System.Drawing.SystemColors.Control;
            this.tb_wait_title.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_wait_title.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_wait_title.Location = new System.Drawing.Point(40, 473);
            this.tb_wait_title.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_wait_title.Name = "tb_wait_title";
            this.tb_wait_title.ReadOnly = true;
            this.tb_wait_title.Size = new System.Drawing.Size(58, 20);
            this.tb_wait_title.TabIndex = 3;
            this.tb_wait_title.TabStop = false;
            this.tb_wait_title.Text = "Wait:";
            // 
            // tb_loop_data
            // 
            this.tb_loop_data.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_loop_data.Location = new System.Drawing.Point(85, 442);
            this.tb_loop_data.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_loop_data.Name = "tb_loop_data";
            this.tb_loop_data.Size = new System.Drawing.Size(84, 27);
            this.tb_loop_data.TabIndex = 4;
            // 
            // tb_wait_data
            // 
            this.tb_wait_data.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_wait_data.Location = new System.Drawing.Point(85, 470);
            this.tb_wait_data.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tb_wait_data.Name = "tb_wait_data";
            this.tb_wait_data.Size = new System.Drawing.Size(84, 27);
            this.tb_wait_data.TabIndex = 5;
            // 
            // chkbox_one_panel
            // 
            this.chkbox_one_panel.AutoSize = true;
            this.chkbox_one_panel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbox_one_panel.Location = new System.Drawing.Point(40, 409);
            this.chkbox_one_panel.Margin = new System.Windows.Forms.Padding(8);
            this.chkbox_one_panel.Name = "chkbox_one_panel";
            this.chkbox_one_panel.Size = new System.Drawing.Size(98, 23);
            this.chkbox_one_panel.TabIndex = 6;
            this.chkbox_one_panel.Text = "One Panel";
            this.chkbox_one_panel.UseVisualStyleBackColor = true;
            this.chkbox_one_panel.CheckedChanged += new System.EventHandler(this.chkbox_one_panel_CheckedChanged);
            // 
            // InputForm3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 511);
            this.Controls.Add(this.tb_loop_data);
            this.Controls.Add(this.btnStartTest);
            this.Controls.Add(this.chkbox_one_panel);
            this.Controls.Add(this.tb_wait_data);
            this.Controls.Add(this.tb_wait_title);
            this.Controls.Add(this.tb_loop_title);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "InputForm3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Input ISN";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InputForm3_FormClosing);
            this.Load += new System.EventHandler(this.InputForm3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnStartTest;
        private System.Windows.Forms.TextBox tb_loop_title;
        private System.Windows.Forms.TextBox tb_wait_title;
        private System.Windows.Forms.TextBox tb_loop_data;
        private System.Windows.Forms.TextBox tb_wait_data;
        private System.Windows.Forms.CheckBox chkbox_one_panel;
    }
}