﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiTest
{
    public partial class UnitInfoForm : Form
    {
        private Form1 m_main_form = null;
        private int m_no;
        public int IDNo { get { return m_no; } }
        private string m_name;
        public string IDName { get { return m_name; } }
        private bool m_current_focus = false;
        public bool CurrentFocus { set { m_current_focus = value; } get { return m_current_focus; } }

        //public UnitInfoForm()
        //{
        //    InitializeComponent();
        //    this.TopLevel = false;
        //}

        public UnitInfoForm(Form1 main_form, int no, string name)
        {
            InitializeComponent();
            this.TopLevel = false;
            this.m_main_form = main_form;
            this.m_no = no;
            this.m_name = name;
            this.groupBoxName.Text = name;

            this.MouseEnter += new System.EventHandler(this.when_MouseEnter);
            this.groupBoxName.MouseEnter += new System.EventHandler(this.when_MouseEnter);
            this.textBoxStatus.MouseEnter += new System.EventHandler(this.when_MouseEnter);
            this.buttonStart.MouseEnter += new System.EventHandler(this.when_MouseEnter);
            
            TestCount test_count;
            test_count = LastSetting.GetInstance().GetTestCount(name);
            UpdateTestCount(test_count.total, test_count.pass, test_count.fail);
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            ButtonStartClick();
        }

        private void when_MouseEnter(object sender, EventArgs e)
        {
            this.m_main_form.TabPageTop(this.m_no);
            this.m_main_form.ClearFocus();
            this.m_main_form.SetInputFocus();
            m_current_focus = true;
            this.groupBoxName.BackColor = DefaultBackColor;
            this.BackColor = Color.LawnGreen;
        }

        public void SetFormFocus()
        {
            this.m_main_form.TabPageTop(this.m_no);
            this.m_main_form.ClearFocus();
            m_current_focus = true;
            this.groupBoxName.BackColor = DefaultBackColor;
            this.BackColor = Color.LawnGreen;
        }

        public void ButtonStartClick()
        {
            if (m_current_focus && this.buttonStart.Enabled)
            {
                this.buttonStart.Enabled = false;
                this.m_main_form.StartTest(this.m_no, this.m_name);
            }
        }

        public void SetButtonFocus()
        {
            if (m_current_focus && this.buttonStart.Enabled)
                this.buttonStart.Focus();
        }

        public bool IsButtonEnable()
        {
            return this.buttonStart.Enabled;
        }

        public void EnableButton(bool b)
        {
            this.buttonStart.Enabled = b;
        }

        public void UpdateIsn(string data)
        {
            this.textBoxIsn.Text = "SN: " + data;
        }

        public void UpdateTimer(string data)
        {
            this.textBoxTime.Text = "Time: " + data + "s";
        }

        public void UpdateStatus(string data)
        {
            this.textBoxStatus.Text = data;

            if (data.Contains("Ready") || (data.Contains("Running")))
            {
                this.textBoxStatus.BackColor = Color.Yellow;
                //fox progressBar1.CustomColor = Brushes.Blue;
            }
            else if (data.Contains("Pass"))
            {
                TestCount test_count = LastSetting.GetInstance().GetTestCount(this.m_name);
                test_count.total++;
                test_count.pass++;
                UpdateTestCount(test_count.total, test_count.pass, test_count.fail);

                this.textBoxStatus.BackColor = Color.GreenYellow;
            }
            else
            {
                TestCount test_count = LastSetting.GetInstance().GetTestCount(this.m_name);
                test_count.total++;
                test_count.fail++;
                UpdateTestCount(test_count.total, test_count.pass, test_count.fail);

                this.textBoxStatus.BackColor = Color.OrangeRed;
                //fox progressBar1.CustomColor = Brushes.Red;
            }
        }

        public void UpdateTestCount(uint total, uint pass, uint fail)
        {
            this.textBoxCount.Text = String.Format("Count:{0} (P:{1} F:{2})", total, pass, fail);

            TestCount test_count = new TestCount(total, pass, fail);
            LastSetting.GetInstance().SetTestCount(this.m_name, test_count);
        }
        
        public void UpdateProgress(int step)
        {
            if (step == -1)
            {
                this.progressBar1.PerformStep();
            }
            else
            {
                this.progressBar1.Value = step;
            }
        }

        public void SetRangeProgress(int range)
        {
            this.progressBar1.Maximum = range;
        }

        public void SetMaxProgress()
        {
            this.progressBar1.Value = this.progressBar1.Maximum;
        }


        private Font m_font = new Font("Calibri", (float)10.25, FontStyle.Bold);
        
        public void SetTextProgress(string s)
        {
            //fox progressBar1.CustomText = s;
            //SizeF len = progressBar1.CreateGraphics().MeasureString(s, m_font);
            //PointF p = new PointF(progressBar1.Width / 2 - len.Width / 2, progressBar1.Height / 2 - len.Height / 2);
            //progressBar1.CreateGraphics().DrawString(s, m_font, Brushes.Blue, p);
        }
    }



}
