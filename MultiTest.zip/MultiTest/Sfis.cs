﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Net;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace MultiTest
{
    class Sfis
    {
        string program_id = "TSP_ATSHH";
        string program_pwd = "pap_ahga";
        string service_url = string.Empty;

        Assembly assembly = Assembly.GetExecutingAssembly();
        XmlDocument xmldoc = new XmlDocument();

        public Sfis()
        {
            GetSettingFromIni();
        }

        [DllImport("Kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetPrivateProfileStringW(String AppName, String KeyName, String Default, [Out] StringBuilder ret, Int32 size, String FileName);

        private void GetSettingFromIni()
        {
            string name = Path.GetDirectoryName(Application.ExecutablePath) + "\\SFIS.ini";
            StringBuilder sb = new StringBuilder(200);
            GetPrivateProfileStringW("SFIS_SETTING", "SFIS_WEB_SERVICE_URL", "default", sb, sb.Capacity, name);
            this.service_url = sb.ToString();
        }

        private int QueryWebWervice(string serviceFunc, ref string result)
        {
            int ret = -1;

            HttpWebRequest http_request = (HttpWebRequest)WebRequest.Create(this.service_url);
            http_request.Method = "POST";
            http_request.ContentType = "text/xml; charset=utf-8";

            ASCIIEncoding encoding = new ASCIIEncoding();
            byte[] data = encoding.GetBytes(serviceFunc);

            try
            {
                using (Stream stream = http_request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                HttpWebResponse response = (HttpWebResponse)http_request.GetResponse();
                string response_data = new StreamReader(response.GetResponseStream()).ReadToEnd();
                xmldoc.LoadXml(response_data);
                result = xmldoc.InnerText;
                ret = 0;
            }
            catch (WebException we)
            {
                MessageBox.Show("Failed to call SFIS:" + we.Message);
            }

            return ret;
        }

        public int GetVersion(string isn, string device, string type, string chkdata, string chkdata2, ref string result)
        {
            xmldoc.Load(assembly.GetManifestResourceStream("MultiTest.SfisWsdl.WTSP_GETVERSION.xml"));
            xmldoc.GetElementsByTagName("programId")[0].InnerText = program_id;
            xmldoc.GetElementsByTagName("programPassword")[0].InnerText = program_pwd;
            xmldoc.GetElementsByTagName("ISN")[0].InnerText = isn;
            xmldoc.GetElementsByTagName("device")[0].InnerText = device;
            xmldoc.GetElementsByTagName("type")[0].InnerText = type;
            xmldoc.GetElementsByTagName("ChkData")[0].InnerText = chkdata;
            xmldoc.GetElementsByTagName("ChkData2")[0].InnerText = chkdata2;
            int ret = QueryWebWervice(xmldoc.DocumentElement.OuterXml, ref result);
            return ret;
        }

        public int GetIMAC(string isn, string device, string type, string chkdata, string chkdata2, ref string result)
        {
            xmldoc.Load(assembly.GetManifestResourceStream("MultiTest.SfisWsdl.WTSP_GETVERSION.xml"));
            xmldoc.GetElementsByTagName("programId")[0].InnerText = program_id;
            xmldoc.GetElementsByTagName("programPassword")[0].InnerText = program_pwd;
            xmldoc.GetElementsByTagName("ISN")[0].InnerText = isn;
            xmldoc.GetElementsByTagName("device")[0].InnerText = device;
            xmldoc.GetElementsByTagName("tsp")[0].InnerText = type;
            xmldoc.GetElementsByTagName("imac")[0].InnerText = chkdata;
            xmldoc.GetElementsByTagName("type")[0].InnerText = chkdata2;
            int ret = QueryWebWervice(xmldoc.DocumentElement.OuterXml, ref result);
            return ret;
        }
    }
}
