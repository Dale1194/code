﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace MultiTest
{
    class PTest
    {
        public const int WM_USER            = 0x400;
        public const int WM_BUTTON_ENABLE   = WM_USER + 1;
        public const int WM_TIMER_UPDATE    = WM_USER + 2;
        public const int WM_ISN_UPDATE      = WM_USER + 3;
        public const int WM_STATUS_UPDATE   = WM_USER + 4;
        public const int WM_COUNT_UPDATE    = WM_USER + 5;
        public const int WM_PROGRESS_UPDATE = WM_USER + 6;
        public const int WM_PROGRESS_RANGE  = WM_USER + 7;
        public const int WM_PROGRESS_MAX    = WM_USER + 8;
        public const int WM_PROGRESS_TEXT   = WM_USER + 9;
        public const int WM_SET_INFO        = WM_USER + 10;
        public const int WM_CLEAR_INFO      = WM_USER + 11;
        public const int WM_POPUP_INPUT_FORM= WM_USER + 12;
        public const int WM_ZIP_FILE        = WM_USER + 13;
        public const int WM_PIC_MSG_FORM    = WM_USER + 14;
        public const int WM_COMPORT_DBG     = WM_USER + 15;
        public const int WM_PIC_MSG_FORM_CLOSE = WM_USER + 16; //susu add 20241004


        public enum TestMode { OnLine, OffLine, QTR};

        
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_Init", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_Init(IntPtr hUIWnd, string script_file, string config_file, string criteria_file);
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_StartTest", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_StartTest(int id_no, string id_name, int test_mode, string input_data);
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_SFISInit", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_SFISInit(string op_id);
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_SFISLogin", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_SFISLogin(string op_id);
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_SFISLogout", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_SFISLogout();
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_FreeMem", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_FreeMem(IntPtr pointer);
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_SetEvent", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_SetEvent(IntPtr pointer);
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_BackFormData", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_BackFormData(string data1, string data2, string data3);
        [DllImport(@"pegalib.dll", EntryPoint = "Lib_UseComPort", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int Lib_UseComPort(IntPtr hUIWnd, string com_name, int act_id, string cmd);
        [DllImport(@"pegalib.dll", EntryPoint = "just_test", CharSet = CharSet.None, CallingConvention = CallingConvention.StdCall)]
        public extern static int just_test(IntPtr hUIWnd);
    }
}
