﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace MultiTest
{
    public partial class InputForm2 : Form
    {
        string m_title1, m_title2, m_title3;
        string m_reg1, m_reg2, m_reg3;
        string m_data1, m_data2, m_data3;
        private Regex re;
        public string GetData1 { get { return m_data1; } }
        public string GetData2 { get { return m_data2; } }
        public string GetData3 { get { return m_data3; } }

        public InputForm2()
        {
            InitializeComponent();
        }

        public InputForm2(string title1, string reg1, string title2, string reg2, string title3, string reg3)
        {
            InitializeComponent();

            this.textBoxWarning.Visible = false;

            m_title1 = title1;
            m_title2 = title2;
            m_title3 = title3;
            m_reg1 = reg1;
            m_reg2 = reg2;
            m_reg3 = reg3;
            this.textBoxData1.Tag = "1st";
            this.textBoxData2.Tag = "2nd";
            this.textBoxData3.Tag = "3rd";

            m_data1 = "";
            m_data2 = "";
            m_data3 = "";
        }

        private void InputForm2_Load(object sender, EventArgs e)
        {
            if (m_title1 != "N/A")
            {
                this.textBoxTitle1.Text = m_title1;
                this.textBoxData1.Text = "";
                this.textBoxData1.Focus();
            }
            else
            {
                this.textBoxTitle1.Visible = false;
                this.textBoxData1.Visible = false;
            }

            if (m_title2 != "N/A")
            {
                this.textBoxTitle2.Text = m_title2;
                this.textBoxData2.Text = "";
                this.textBoxData2.Focus();
            }
            else
            {
                this.textBoxTitle2.Visible = false;
                this.textBoxData2.Visible = false;
            }

            if (m_title3 != "N/A")
            {
                this.textBoxTitle3.Text = m_title3;
                this.textBoxData3.Text = "";
                this.textBoxData3.Focus();
            }
            else
            {
                this.textBoxTitle3.Visible = false;
                this.textBoxData3.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.m_data1 = this.textBoxData1.Text;
            this.m_data2 = this.textBoxData2.Text;
            this.m_data3 = this.textBoxData3.Text;
            this.Close();
        }

        private void textBoxData1_KeyDown(object sender, KeyEventArgs e)
        {
            TextBox tb = sender as TextBox;
            string s = tb.Tag.ToString();
            if ((String.Compare(s, "1st", true) == 0) && (e.KeyCode == Keys.Return))
            {
                if (m_reg1 != "N/A")
                {
                    re = new Regex(m_reg1, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    if (!re.IsMatch(tb.Text))
                    {
                        this.textBoxWarning.Visible = true;
                        tb.SelectAll();
                        return;
                    }
                }
                this.textBoxWarning.Visible = false;
                if (this.textBoxData2.Visible)
                    this.textBoxData2.Focus();
                else if (this.textBoxData3.Visible)
                    this.textBoxData3.Focus();
                else
                    button1_Click(sender, e);
            }

            if ((String.Compare(s, "2nd", true) == 0) && (e.KeyCode == Keys.Return))
            {
                if (m_reg2 != "N/A")
                {
                    re = new Regex(m_reg2, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    if (!re.IsMatch(tb.Text))
                    {
                        this.textBoxWarning.Visible = true;
                        tb.SelectAll();
                        return;
                    }
                }
                this.textBoxWarning.Visible = false;
                if (this.textBoxData3.Visible)
                    this.textBoxData3.Focus();
                else
                    button1_Click(sender, e);
            }

            if ((String.Compare(s, "3rd", true) == 0) && (e.KeyCode == Keys.Return))
            {
                if (m_reg3 != "N/A")
                {
                    re = new Regex(m_reg3, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                    if (!re.IsMatch(tb.Text))
                    {
                        this.textBoxWarning.Visible = true;
                        tb.SelectAll();
                        return;
                    }
                }
                this.textBoxWarning.Visible = false;
                button1_Click(sender, e);
            }
        }
    }
}
