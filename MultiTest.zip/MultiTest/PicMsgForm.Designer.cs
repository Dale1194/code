﻿namespace MultiTest
{
    partial class PicMsgForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnYes = new System.Windows.Forms.Button();
            this.btnNo = new System.Windows.Forms.Button();
            this.btnRetry = new System.Windows.Forms.Button();
            this.hintPic = new System.Windows.Forms.PictureBox();
            this.hintText = new System.Windows.Forms.TextBox();
            this.tlpALL = new System.Windows.Forms.TableLayoutPanel();
            this.tlpBtn = new System.Windows.Forms.TableLayoutPanel();
            this.btnHoldFocus = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.hintPic)).BeginInit();
            this.tlpALL.SuspendLayout();
            this.tlpBtn.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnYes
            // 
            this.btnYes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnYes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnYes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnYes.Font = new System.Drawing.Font("PMingLiU", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnYes.Location = new System.Drawing.Point(3, 3);
            this.btnYes.Name = "btnYes";
            this.btnYes.Size = new System.Drawing.Size(253, 68);
            this.btnYes.TabIndex = 1;
            this.btnYes.Text = "Yes";
            this.btnYes.UseVisualStyleBackColor = false;
            this.btnYes.Click += new System.EventHandler(this.btnYes_Click);
            // 
            // btnNo
            // 
            this.btnNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnNo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnNo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNo.Font = new System.Drawing.Font("PMingLiU", 36F);
            this.btnNo.Location = new System.Drawing.Point(262, 3);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(253, 68);
            this.btnNo.TabIndex = 2;
            this.btnNo.Text = "No";
            this.btnNo.UseVisualStyleBackColor = false;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // btnRetry
            // 
            this.btnRetry.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRetry.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnRetry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRetry.Font = new System.Drawing.Font("PMingLiU", 36F);
            this.btnRetry.Location = new System.Drawing.Point(521, 3);
            this.btnRetry.Name = "btnRetry";
            this.btnRetry.Size = new System.Drawing.Size(254, 68);
            this.btnRetry.TabIndex = 3;
            this.btnRetry.Text = "Retry";
            this.btnRetry.UseVisualStyleBackColor = false;
            this.btnRetry.Click += new System.EventHandler(this.btnRetry_Click);
            // 
            // hintPic
            // 
            this.hintPic.BackColor = System.Drawing.Color.Gray;
            this.hintPic.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hintPic.Location = new System.Drawing.Point(3, 3);
            this.hintPic.Name = "hintPic";
            this.hintPic.Size = new System.Drawing.Size(778, 375);
            this.hintPic.TabIndex = 3;
            this.hintPic.TabStop = false;
            // 
            // hintText
            // 
            this.hintText.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.hintText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.hintText.Font = new System.Drawing.Font("PMingLiU", 30F);
            this.hintText.Location = new System.Drawing.Point(3, 384);
            this.hintText.Multiline = true;
            this.hintText.Name = "hintText";
            this.hintText.ReadOnly = true;
            this.hintText.Size = new System.Drawing.Size(778, 94);
            this.hintText.TabIndex = 4;
            this.hintText.Text = "一二三四五六七八九十一二三四五六七八九十一二三四五六七八九十共三十六個字";
            // 
            // tlpALL
            // 
            this.tlpALL.BackColor = System.Drawing.Color.Gray;
            this.tlpALL.ColumnCount = 1;
            this.tlpALL.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpALL.Controls.Add(this.tlpBtn, 0, 2);
            this.tlpALL.Controls.Add(this.hintText, 0, 1);
            this.tlpALL.Controls.Add(this.hintPic, 0, 0);
            this.tlpALL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpALL.Location = new System.Drawing.Point(0, 0);
            this.tlpALL.Name = "tlpALL";
            this.tlpALL.RowCount = 3;
            this.tlpALL.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpALL.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tlpALL.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tlpALL.Size = new System.Drawing.Size(784, 561);
            this.tlpALL.TabIndex = 5;
            // 
            // tlpBtn
            // 
            this.tlpBtn.ColumnCount = 3;
            this.tlpBtn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tlpBtn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tlpBtn.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tlpBtn.Controls.Add(this.btnYes, 0, 0);
            this.tlpBtn.Controls.Add(this.btnRetry, 2, 0);
            this.tlpBtn.Controls.Add(this.btnNo, 1, 0);
            this.tlpBtn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlpBtn.Location = new System.Drawing.Point(3, 484);
            this.tlpBtn.Name = "tlpBtn";
            this.tlpBtn.RowCount = 1;
            this.tlpBtn.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tlpBtn.Size = new System.Drawing.Size(778, 74);
            this.tlpBtn.TabIndex = 0;
            // 
            // btnHoldFocus
            // 
            this.btnHoldFocus.Location = new System.Drawing.Point(740, 532);
            this.btnHoldFocus.Name = "btnHoldFocus";
            this.btnHoldFocus.Size = new System.Drawing.Size(32, 23);
            this.btnHoldFocus.TabIndex = 0;
            this.btnHoldFocus.Text = "button1";
            this.btnHoldFocus.UseVisualStyleBackColor = true;
            // 
            // PicMsgForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.tlpALL);
            this.Controls.Add(this.btnHoldFocus);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "PicMsgForm";
            this.Text = "PicMsgForm";
            ((System.ComponentModel.ISupportInitialize)(this.hintPic)).EndInit();
            this.tlpALL.ResumeLayout(false);
            this.tlpALL.PerformLayout();
            this.tlpBtn.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnYes;
        private System.Windows.Forms.Button btnNo;
        private System.Windows.Forms.Button btnRetry;
        private System.Windows.Forms.PictureBox hintPic;
        private System.Windows.Forms.TextBox hintText;
        private System.Windows.Forms.TableLayoutPanel tlpALL;
        private System.Windows.Forms.TableLayoutPanel tlpBtn;
        private System.Windows.Forms.Button btnHoldFocus;
    }
}