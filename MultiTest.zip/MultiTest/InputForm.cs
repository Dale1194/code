﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace MultiTest
{
    public partial class InputForm : Form
    {
        private Form1 m_main_form = null;
        private string m_name;
        public string InputName { get { return m_name; } }
        private string m_pattern;
        private Regex re;

        //public InputForm()
        //{
        //    InitializeComponent();
        //    this.TopLevel = false;
        //}

        public InputForm(Form1 main_form, string name, string pattern)
        {
            InitializeComponent();
            this.TopLevel = false;
            this.m_main_form = main_form;
            this.m_name = name;
            this.m_pattern = pattern;
            
            re = new Regex(pattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
        }

        public void SetText(string s)
        {
            this.textBoxTitle.Text = s;
        }

        public void AddKeyDownEvent(KeyEventHandler TabHandle)
        {
            this.textBoxData.KeyDown += TabHandle;
        }

        public void SetFocus()
        {
            this.textBoxData.Focus();
        }

        public void SetData(string dat)
        {
            this.textBoxData.Text = dat;
        }

        public string GetData()
        {
            return this.textBoxData.Text;
        }

        public void ClearData()
        {
            this.textBoxData.Text = "";
        }

        public bool IsValid()
        {
            return re.IsMatch(this.textBoxData.Text);
        }

        public void SelectAll()
        {
            this.textBoxData.Focus();
            this.textBoxData.SelectAll();
        }

        public void SetTabIndex(int idx)
        {
            this.textBoxData.TabIndex = idx;
        }

        private void InputForm_Load(object sender, EventArgs e)
        {

        }

    }
}
