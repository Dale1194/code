﻿namespace MultiTest
{
    partial class InputForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxTitle1 = new System.Windows.Forms.TextBox();
            this.textBoxData1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxTitle2 = new System.Windows.Forms.TextBox();
            this.textBoxTitle3 = new System.Windows.Forms.TextBox();
            this.textBoxData2 = new System.Windows.Forms.TextBox();
            this.textBoxData3 = new System.Windows.Forms.TextBox();
            this.textBoxWarning = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBoxTitle1
            // 
            this.textBoxTitle1.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxTitle1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTitle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTitle1.Location = new System.Drawing.Point(36, 12);
            this.textBoxTitle1.Name = "textBoxTitle1";
            this.textBoxTitle1.Size = new System.Drawing.Size(100, 24);
            this.textBoxTitle1.TabIndex = 0;
            this.textBoxTitle1.TabStop = false;
            this.textBoxTitle1.Text = "Title1";
            // 
            // textBoxData1
            // 
            this.textBoxData1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxData1.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBoxData1.AcceptsReturn = true;
            this.textBoxData1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxData1.Location = new System.Drawing.Point(142, 12);
            this.textBoxData1.Name = "textBoxData1";
            this.textBoxData1.Size = new System.Drawing.Size(360, 31);
            this.textBoxData1.TabIndex = 1;
            this.textBoxData1.Text = "Data1";
            this.textBoxData1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxData1_KeyDown);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(255, 221);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 29);
            this.button1.TabIndex = 4;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxTitle2
            // 
            this.textBoxTitle2.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxTitle2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTitle2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTitle2.Location = new System.Drawing.Point(36, 66);
            this.textBoxTitle2.Name = "textBoxTitle2";
            this.textBoxTitle2.Size = new System.Drawing.Size(100, 24);
            this.textBoxTitle2.TabIndex = 5;
            this.textBoxTitle2.TabStop = false;
            this.textBoxTitle2.Text = "Title2";
            // 
            // textBoxTitle3
            // 
            this.textBoxTitle3.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxTitle3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTitle3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTitle3.Location = new System.Drawing.Point(36, 120);
            this.textBoxTitle3.Name = "textBoxTitle3";
            this.textBoxTitle3.Size = new System.Drawing.Size(100, 24);
            this.textBoxTitle3.TabIndex = 6;
            this.textBoxTitle3.TabStop = false;
            this.textBoxTitle3.Text = "Title3";
            // 
            // textBoxData2
            // 
            this.textBoxData2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxData2.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBoxData2.AcceptsReturn = true;
            this.textBoxData2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxData2.Location = new System.Drawing.Point(142, 64);
            this.textBoxData2.Name = "textBoxData2";
            this.textBoxData2.Size = new System.Drawing.Size(360, 31);
            this.textBoxData2.TabIndex = 2;
            this.textBoxData2.Text = "Data2";
            this.textBoxData2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxData1_KeyDown);
            // 
            // textBoxData3
            // 
            this.textBoxData3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBoxData3.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.textBoxData3.AcceptsReturn = true;
            this.textBoxData3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxData3.Location = new System.Drawing.Point(142, 116);
            this.textBoxData3.Name = "textBoxData3";
            this.textBoxData3.Size = new System.Drawing.Size(360, 31);
            this.textBoxData3.TabIndex = 3;
            this.textBoxData3.Text = "Data3";
            this.textBoxData3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxData1_KeyDown);
            // 
            // textBoxWarning
            // 
            this.textBoxWarning.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxWarning.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxWarning.ForeColor = System.Drawing.Color.Red;
            this.textBoxWarning.Location = new System.Drawing.Point(142, 168);
            this.textBoxWarning.Name = "textBoxWarning";
            this.textBoxWarning.Size = new System.Drawing.Size(137, 15);
            this.textBoxWarning.TabIndex = 7;
            this.textBoxWarning.Text = "*The input data is invalid!";
            // 
            // InputForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(615, 262);
            this.Controls.Add(this.textBoxWarning);
            this.Controls.Add(this.textBoxData3);
            this.Controls.Add(this.textBoxData2);
            this.Controls.Add(this.textBoxTitle3);
            this.Controls.Add(this.textBoxTitle2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxData1);
            this.Controls.Add(this.textBoxTitle1);
            this.Name = "InputForm2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InputForm2";
            this.Load += new System.EventHandler(this.InputForm2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxTitle1;
        private System.Windows.Forms.TextBox textBoxData1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxTitle2;
        private System.Windows.Forms.TextBox textBoxTitle3;
        private System.Windows.Forms.TextBox textBoxData2;
        private System.Windows.Forms.TextBox textBoxData3;
        private System.Windows.Forms.TextBox textBoxWarning;
    }
}