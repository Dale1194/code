﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MultiTest
{
    public partial class InputForm3 : Form
    {
        private Form1 m_main_form = null;
        private List<InputForm> m_input_forms = new List<InputForm>();
        private JArray m_units_config;
        private string m_reg_rule;
        private Sfis m_sfis = new Sfis();

        public InputForm3(Form1 main_form, JArray units, string reg_rule)
        {
            InitializeComponent();

            this.m_main_form = main_form;
            this.m_units_config = units;
            this.m_reg_rule = reg_rule;
        }

        private void InputForm3_Load(object sender, EventArgs e)
        {
            InputForm input_ui = null;
            int idx = 0;
            bool enable = false;

            foreach (JObject unit in this.m_units_config)
            {
                enable = (bool)unit["Enable"];

                if (enable == true)
                {
                    string name = unit["Name"].ToString();
                    bool input_multiui = (bool)unit["Input_MultiUi"];

                    input_ui = new InputForm(this.m_main_form, name, this.m_reg_rule);
                    input_ui.SetText(name);
                    input_ui.AddKeyDownEvent(InputEdit_KeyDown);
                    input_ui.Show();
                    input_ui.Tag = idx;
                    idx++;
                    input_ui.Enabled = input_multiui;

                    m_input_forms.Add(input_ui);
                    flowLayoutPanel1.Controls.Add(input_ui);
                }
            }

            this.tb_loop_data.Text = "1";
            this.tb_wait_data.Text = "500";

            if (this.m_main_form.Is_Online)
            {
                this.tb_loop_title.Visible = false;
                this.tb_loop_data.Visible = false;
                this.tb_wait_title.Visible = false;
                this.tb_wait_data.Visible = false;
            }
            
            this.ResumeLayout(false);
        }

        private void InputForm3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!m_main_form.AreAllButtonEnable())
            {
                if (MessageBox.Show(this, "The tool is testing. Are you sure you want to exit?", "Multi Testing", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    e.Cancel = true;
            }
            m_main_form.Close();
        }

        public void InputEdit_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Control next_ctrl = flowLayoutPanel1.GetNextControl((sender as Control).Parent, true);
                if ((sender as Control) is TextBox)
                {
                    if (((sender as Control).Parent as InputForm).IsValid() == false)
                    {
                        MessageBox.Show("The input data(format) is wrong!");
                        (sender as TextBox).SelectAll();
                        return;
                    }
                }

                if (if_isn_repeat())
                {
                    MessageBox.Show("ISN are repeat!");
                    return;
                }

                while ((next_ctrl != null) && next_ctrl.Enabled == false)
                    next_ctrl = flowLayoutPanel1.GetNextControl(next_ctrl, true);
                
                if ((next_ctrl != null) && (next_ctrl.Enabled))
                    next_ctrl.SelectNextControl(next_ctrl, true, true, false, true);
                else
                    this.btnStartTest.Focus();
            }
        }

        public void StartTest()
        {
            bool are_enable = false;
            int loop_count = Convert.ToInt32(this.tb_loop_data.Text);
            int wait_time = Convert.ToInt32(this.tb_wait_data.Text);

            if (this.chkbox_one_panel.Checked)
            {
                List<string> isnlist = new List<string>();
                int ret = get_panel_isn(m_input_forms[0].GetData(), ref isnlist);

                if ((ret == 0) && (isnlist.Count == m_input_forms.Count))
                { }
                else if ((ret == 0) && (isnlist.Count / 2 == m_input_forms.Count))
                {
                    if (isnlist.IndexOf(m_input_forms[0].GetData()) >= m_input_forms.Count)
                        isnlist.RemoveRange(0, m_input_forms.Count);
                }
                else
                    return;
                
                foreach (InputForm infrm in m_input_forms)
                    infrm.SetData(isnlist[m_input_forms.IndexOf(infrm)]);
            }

            if (if_isn_repeat())
            {
                MessageBox.Show("ISN are repeat!");
                return;
            }

            for (int count = 0; count < loop_count; count++)
            {
                this.tb_loop_data.Text = string.Format("{0}/{1}", count, loop_count);

                this.btnStartTest.Enabled = false;

                foreach (InputForm infrm in m_input_forms)
                {
                    if (infrm.IsValid())
                    {
                        m_main_form.MultiStartTest((int)infrm.Tag, infrm.InputName, infrm.GetData());
                        System.Threading.Thread.Sleep(150);
                    }
                }

                this.Visible = false;

                System.Threading.Thread.Sleep(100);
                Application.DoEvents();

                do
                {
                    are_enable = m_main_form.AreAllButtonEnable();
                    if (!are_enable)
                    {
                        System.Threading.Thread.Sleep(10);
                        Application.DoEvents();
                    }
                } while (!are_enable);

                this.Visible = true;
                this.btnStartTest.Enabled = true;

                System.Threading.Thread.Sleep(wait_time);
                Application.DoEvents();
            }

            this.tb_loop_data.Text = loop_count.ToString();

            foreach (InputForm infrm in m_input_forms)
            {
                infrm.ClearData();
            }

            foreach (InputForm infrm in m_input_forms)
            {
                if (infrm.Enabled)
                {
                    infrm.SetFocus();
                    break;
                }
            }
            //m_input_forms[0].SetFocus();
        }

        private int get_panel_isn(string isn, ref List<string> isn_list)
        {
            char[] sep = { Convert.ToChar(0x7f) };
            string result = string.Empty;
            int ret = m_sfis.GetVersion(isn, m_main_form.DeviceID, "GET_ISN_BY_AOIISN", "", "ISN", ref result);
            System.Diagnostics.Debug.Write(result);
            if (ret == 0)
            {
                string[] res = result.Split(sep, StringSplitOptions.None);
                if (res[0] == "1")
                    isn_list = res[2].Split(Convert.ToChar(';')).ToList();
                else
                    MessageBox.Show(result);
            }
            return ret;
        }

        private bool if_isn_repeat()
        {
            int count_enable = 0;
            Dictionary<string, string> isn = new Dictionary<string, string>();

            foreach (InputForm infrm in m_input_forms)
            {
                if (infrm.Enabled)
                {
                    string sn = infrm.GetData();
                    if (sn != "")
                    {
                        count_enable++;
                        isn[sn] = sn;
                    }
                }
            }
            return count_enable != isn.Count;
        }

        private void btnStartTest_Click(object sender, EventArgs e)
        {
            StartTest();
        }

        private void btnStartTest_EnabledChanged(object sender, EventArgs e)
        {
            if (this.btnStartTest.Enabled)
                this.Focus();
        }

        private void chkbox_one_panel_CheckedChanged(object sender, EventArgs e)
        {
            bool is_first = true;
            
            foreach (JObject unit in this.m_units_config)
            {
                if ((bool)unit["Enable"] == true)
                {
                    if ((bool)unit["Input_MultiUi"])
                    {
                        if (is_first)
                        {
                            is_first = false;
                            m_input_forms[m_units_config.IndexOf(unit)].Enabled = true;
                            m_input_forms[m_units_config.IndexOf(unit)].SetFocus();
                        }
                        else
                            m_input_forms[m_units_config.IndexOf(unit)].Enabled = !this.chkbox_one_panel.Checked;
                    }
                }
            }
        }
    }
}
