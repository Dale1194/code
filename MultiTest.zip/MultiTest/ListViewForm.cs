﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiTest
{
    public partial class ListViewForm : Form
    {
        private Form1 m_main_form = null;
        private int m_no;
        public int IDNo { get { return m_no; } }
        private string m_name;
        public string IDName { get { return m_name; } }
        private int idx = 0;
        private int idx_of_fist_fail = -1;

        //public ListViewForm()
        //{
        //    InitializeComponent();
        //    this.TopLevel = false;
        //}

        public ListViewForm(Form1 main_form, int no, string name)
        {
            InitializeComponent();
            this.TopLevel = false;
            this.m_main_form = main_form;
            this.m_no = no;
            this.m_name = name;

            this.listView1.FullRowSelect = true;
            this.listView1.Scrollable = true;
        }

        public void SetInfo(string s)
        {
            this.idx++;

            string[] fields = s.Split(",".ToCharArray());

            ListViewItem lvi = new ListViewItem(idx.ToString());
            lvi.SubItems.Add(fields[0]);
            lvi.SubItems.Add(fields[3]);
            lvi.SubItems.Add(fields[2]);
            lvi.SubItems.Add(fields[4]);

            if (fields[1] != "0")
            {
                lvi.BackColor = Color.Red;
                if (idx_of_fist_fail == -1)
                    idx_of_fist_fail = idx;
            }

            this.listView1.Items.Add(lvi);

            //listView1.EnsureVisible(idx-1);
            listView1.TopItem = lvi;
        }

        public void ClearInfo()
        {
            this.idx = 0;
            idx_of_fist_fail = -1;
            this.listView1.Items.Clear();
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                if (idx_of_fist_fail > 0 && idx_of_fist_fail < this.listView1.Items.Count)
                    listView1.EnsureVisible(idx_of_fist_fail - 1);
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ListViewForm_Load(object sender, EventArgs e)
        {

        }
    }
}
