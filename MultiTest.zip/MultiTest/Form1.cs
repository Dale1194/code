﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Compression;
using Newtonsoft.Json;
//using Newtonsoft.Json.Serialization;
using Newtonsoft.Json.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace MultiTest
{
    public partial class Form1 : Form
    {
        List<InputForm> m_input_forms = new List<InputForm>();
        List<UnitInfoForm> m_unit_forms = new List<UnitInfoForm>();
        List<ListViewForm> m_detail_forms = new List<ListViewForm>();
        InputForm3 m_multi_input_form;
        bool m_show_detail = false;
        bool m_show_multi_input_form = false;
        PTest.TestMode m_test_mode = PTest.TestMode.OffLine;
        public bool Is_Online { get { return (this.m_test_mode == PTest.TestMode.OnLine); } }
        string m_device_id;
        public string DeviceID { get { return this.m_device_id; } }

        const bool DeviceID_from_PcDescription = false;
        private PicMsgForm pic_msg_box = new PicMsgForm();
        public Form1()
        {
            InitializeComponent();

            this.Icon = new Icon(Properties.Resources.Monitor, Properties.Resources.Monitor.Size);
            Environment.SetEnvironmentVariable("PATH", Environment.GetEnvironmentVariable("PATH") + ";" + @".\iPLAS");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (DeviceID_from_PcDescription)
                GetAndShowPcDescription();
            else
                ShowDeviceId();

            ScenarioForm scenario = new ScenarioForm(this);
            scenario.ShowDialog();

            if (scenario.DialogResult == DialogResult.OK)
            {
                //PTest.Lib_Init(this.Handle, scenario.File_Selected(), LastSetting.GetInstance().ConfigFile, LastSetting.GetInstance().CriteriaFile);

                this.SuspendLayout();

                InitUI();

                //ShowDeviceId();

                show_dll_version();

                AddMenuAndItems();

                show_scenario_file(scenario.File_Selected());
                
                show_criteria_file(scenario.Criteria_File_Selected());

                show_config_file(scenario.Config_File_Selected());
				
                this.ResumeLayout(false);
            }
            else
            {
                this.Close();
            }
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            SetInputFocus();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.m_test_mode == PTest.TestMode.OnLine)
                PTest.Lib_SFISLogout();
        }

        private void InitUI()
        {
            string jsonText = ReadFile(LastSetting.GetInstance().ConfigFile);
            JObject jo = (JObject)JsonConvert.DeserializeObject(jsonText);
            JObject init_setting = (JObject)jo["Initial_Setting"];
            JObject sfis_setting = (JObject)jo["SFIS_SETTING"];
            JArray input_text = (JArray)jo["Input"];
            JArray units = (JArray)jo["Units"];

            this.Text = init_setting["STATION_ID"].ToString() + " testing tool  " + Application.ProductVersion;
            m_show_detail = (bool)init_setting["SHOW_DETAIL"];

            if (m_show_detail == false)
            {
                tabControlDetail.Visible = false;
                groupBox1.Width = this.Width - 40;
            }
            flowLayoutPanel1.Width = groupBox1.Width - SystemInformation.VerticalScrollBarWidth + 5;
            flowLayoutPanel2.Width = groupBox1.Width - SystemInformation.VerticalScrollBarWidth + 5;

            //int idx = 0;
            int unit_count = 0;
            bool enable = false;
            InputForm input_ui = null;
            UnitInfoForm unit_info_ui = null;
            Panel panel = null;
            TabPage tab_page = null;
            ListViewForm unit_detail_ui = null;

            flowLayoutPanel1.Visible = false;
            
            foreach (JObject input in input_text)
            {
                enable = (bool)input["Enable"];
                
                if (enable == true)
                {
                    string caption = input["Caption"].ToString();
                    string pttern = input["RegRule"].ToString();

                    input_ui = new InputForm(this, caption, pttern);
                    input_ui.SetText(input["Caption"].ToString());
                    input_ui.Show();
                    input_ui.AddKeyDownEvent(InputEdit_KeyDown);

                    m_input_forms.Add(input_ui);

                    panel = new Panel();
                    panel.Tag = 0;
                    panel.AutoSize = true;
                    panel.BorderStyle = BorderStyle.FixedSingle;
                    panel.Controls.Add(input_ui);

                    //tableLayoutPanelInfo.RowCount++;
                    //tableLayoutPanelInfo.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                    //tableLayoutPanelInfo.Controls.Add(panel);
                    //tableLayoutPanelInfo.SetRow(panel, idx++);

                    flowLayoutPanel1.Controls.Add(panel);
                    flowLayoutPanel1.Visible = true;
                }
            }
            
            foreach (JObject unit in units)
            {   
                enable = (bool)unit["Enable"];

                if (enable == true)
                {
                    string name = unit["Name"].ToString();

                    unit_info_ui = new UnitInfoForm(this, unit_count, name);
                    unit_info_ui.Show();

                    m_unit_forms.Add(unit_info_ui);
                    //m_unit_forms.Add(name, unit_info_ui);

                    panel = new Panel();
                    panel.Tag = 0;
                    panel.AutoSize = true;
                    panel.BorderStyle = BorderStyle.FixedSingle;
                    panel.Controls.Add(unit_info_ui);

                    //tableLayoutPanelInfo.RowCount++;
                    //tableLayoutPanelInfo.RowStyles.Add(new RowStyle(SizeType.AutoSize));
                    //tableLayoutPanelInfo.Controls.Add(panel);
                    //tableLayoutPanelInfo.SetRow(panel, idx++);

                    flowLayoutPanel2.Controls.Add(panel);


                    if (m_show_detail == true)
                    {
                        tab_page = new TabPage(name);
                        tab_page.Padding = tabPage1.Padding;
                        tab_page.Size = tabPage1.Size;
                        tab_page.UseVisualStyleBackColor = true;
                        tab_page.Tag = tab_page.Text;
                        
                        tabControlDetail.Controls.Add(tab_page);

                        unit_detail_ui = new ListViewForm(this, unit_count, name);
                        unit_detail_ui.Show();
                        tab_page.Controls.Add(unit_detail_ui);

                        m_detail_forms.Add(unit_detail_ui);

                        this.tabControlDetail.SelectedIndexChanged += new System.EventHandler(this.tabControlDetail_SelectedIndexChanged);
                        tabControlDetail.Controls.Remove(tabPage1);
                    }
                    unit_count++;
                }
            }
            m_unit_forms[0].CurrentFocus = true;
            
            int vertScrollWidth = SystemInformation.VerticalScrollBarWidth;
            //tableLayoutPanelInfo.Padding = new Padding(0, 0, vertScrollWidth, 0);
            flowLayoutPanel1.Padding = new Padding(0, 0, vertScrollWidth, 0);
            flowLayoutPanel2.Padding = new Padding(0, 0, vertScrollWidth, 0);

            if (flowLayoutPanel1.Visible == false)
            {
                Size size;
                flowLayoutPanel2.Location = flowLayoutPanel1.Location;
                size = flowLayoutPanel2.Size;
                size.Height = groupBox1.Size.Height - (flowLayoutPanel1.Location.Y);
                flowLayoutPanel2.Size = size;
            }

            m_show_multi_input_form = (bool)init_setting["Multi_Input"];
            if (m_show_multi_input_form)
            {
                ShowMultiInputForm(units, init_setting["Multi_Input_RegRule"].ToString());

                this.Activated += (s, a) =>
                {
                    m_multi_input_form.TopMost = true;
                    m_multi_input_form.TopMost = false;
                };
            }
        }

        public string ReadFile(string paht, bool add_end_line = false)
        {
            string text = null;
            try
            {
                text = System.IO.File.ReadAllText(paht);
                if (add_end_line == true)
                {
                    text += "\r\n";
                }
            }
            catch (System.ArgumentNullException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            catch (System.IO.FileNotFoundException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            catch (System.IO.PathTooLongException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            return text;
        }

        public void ShowMultiInputForm(JArray units, string reg_rule)
        {
            m_multi_input_form = new InputForm3(this, units, reg_rule);
            m_multi_input_form.Show();
        }

        private void AddMenuAndItems()
        {
            MainMenu main_menu = new MainMenu();
            this.Menu = main_menu;

            MenuItem mi_test_mode = new MenuItem("&Test Mode");
            main_menu.MenuItems.Add(mi_test_mode);

            MenuItem mi_sfis_online = new MenuItem("ON-LINE");
            MenuItem mi_sfis_offline = new MenuItem("OFF-LINE");
            //MenuItem mi_qtr = new MenuItem("QTR");

            mi_sfis_online.Tag = PTest.TestMode.OnLine;
            mi_sfis_offline.Tag = PTest.TestMode.OffLine;
            //mi_qtr.Tag = PTest.TestMode.QTR;

            mi_test_mode.MenuItems.Add(mi_sfis_online);
            mi_test_mode.MenuItems.Add(mi_sfis_offline);
            //mi_test_mode.MenuItems.Add(mi_qtr);
            mi_test_mode.Popup += new EventHandler(this.menuItem_test_mode_Popup);
            
            mi_sfis_online.Click += new EventHandler(this.menuItem_online_mode_Click);
            //mi_sfis_online.Click += new EventHandler(this.menuItem_test_mode_Click);
            mi_sfis_offline.Click += new EventHandler(this.menuItem_test_mode_Click);
            //mi_qtr.Click += new EventHandler(this.menuItem_test_mode_Click);


            MenuItem last_item = null;
            foreach (MenuItem mi in mi_test_mode.MenuItems)
            {
                if (mi.Text == LastSetting.GetInstance().TestMode)
                {
                    last_item = mi;
                    mi.Checked = true;
                    this.toolStripStatusLabel2.Text = "Mode: " + mi.Text;
                    this.m_test_mode = (PTest.TestMode)mi.Tag;
                    this.groupBox1.BackColor = (this.m_test_mode == PTest.TestMode.OnLine) ? Control.DefaultBackColor : Color.Violet;
                }
            }
            this.groupBox1.Text = "";

            if (last_item == null)
            {
                menuItem_test_mode_Click(mi_sfis_offline, null);
            }

            //if (mi_sfis_online.Checked == true)
            //{
            //    show_login_form(mi_sfis_online, mi_sfis_offline);
            //}


            MenuItem mi_count = new MenuItem("&Count");
            main_menu.MenuItems.Add(mi_count);

            MenuItem mi_reset_count = new MenuItem("Reset Count");
            mi_count.MenuItems.Add(mi_reset_count);

            mi_reset_count.Click += new EventHandler(this.menuItem_count_Click);
        }

        private void menuItem_test_mode_Click(object sender, System.EventArgs e)
        {
            MenuItem mi_current = (MenuItem)sender;
            Menu menu = mi_current.Parent;
            foreach (MenuItem mi in menu.MenuItems)
            {
                mi.Checked = (mi.Text == mi_current.Text ? true : false);
            }
            this.toolStripStatusLabel2.Text = "Mode: " + mi_current.Text;
            this.m_test_mode = (PTest.TestMode)mi_current.Tag;
            this.groupBox1.BackColor = Color.Violet;

            LastSetting.GetInstance().TestMode = mi_current.Text;

            PTest.Lib_SFISLogout();
        }

        private void menuItem_online_mode_Click(object sender, System.EventArgs e)
        {
            MenuItem mi_current = (MenuItem)sender;
            MenuItem last_item = null;

            foreach (MenuItem mi in mi_current.Parent.MenuItems)
            {
                if (mi.Text == LastSetting.GetInstance().TestMode)
                {
                    last_item = mi;
                    if (mi_current == mi) return;
                }
            }

            show_login_form(mi_current, last_item);
        }

        private void show_login_form(MenuItem mi_ok, MenuItem mi_not_ok)
        {
            SfisLoginForm login = new SfisLoginForm();
            login.ShowDialog();
            if (login.DialogResult == DialogResult.OK)
            {
                mi_ok.Checked = true;
                mi_not_ok.Checked = false;
                this.toolStripStatusLabel2.Text = "Mode: " + mi_ok.Text;
                this.m_test_mode = (PTest.TestMode)mi_ok.Tag;
                this.groupBox1.BackColor = Control.DefaultBackColor;
                LastSetting.GetInstance().TestMode = mi_ok.Text;
            }
            else
            {
                mi_not_ok.Checked = true;
                mi_ok.Checked = false;
                this.toolStripStatusLabel2.Text = "Mode: " + mi_not_ok.Text;
                this.m_test_mode = (PTest.TestMode)mi_not_ok.Tag;
                this.groupBox1.BackColor = Color.Violet;
                LastSetting.GetInstance().TestMode = mi_not_ok.Text;
            }
        }
                
        private void menuItem_test_mode_Popup(object sender, System.EventArgs e)
        {
            bool are_all_btn_enable = true;

            are_all_btn_enable = AreAllButtonEnable();

            foreach (MenuItem mi in ((MenuItem)sender).MenuItems)
            {
                mi.Enabled = are_all_btn_enable;
            }
        }

        private void menuItem_count_Click(object sender, System.EventArgs e)
        {
            TestCount test_count;

            foreach (UnitInfoForm uif in m_unit_forms)
            {
                test_count = LastSetting.GetInstance().GetTestCount(uif.IDName);
                test_count.total = 0;
                test_count.pass = 0;
                test_count.fail = 0;
                uif.UpdateTestCount(test_count.total, test_count.pass, test_count.fail);
            }
        }

        protected override void WndProc(ref Message m)
        {
            switch (m.Msg)
            {
                case PTest.WM_BUTTON_ENABLE:
                    bool b = ((int)m.LParam == 1) ? true : false;
                    m_unit_forms[(int)m.WParam].EnableButton(b);
                    break;

                case PTest.WM_ISN_UPDATE:
                    string s = Marshal.PtrToStringAnsi(m.LParam);
                    m_unit_forms[(int)m.WParam].UpdateIsn(s);
                    PTest.Lib_FreeMem(m.LParam);
                    break;

                case PTest.WM_TIMER_UPDATE:
                    s = Marshal.PtrToStringAnsi(m.LParam);
                    m_unit_forms[(int)m.WParam].UpdateTimer(s);
                    PTest.Lib_FreeMem(m.LParam);
                    break;

                case PTest.WM_STATUS_UPDATE:
                    s = Marshal.PtrToStringAnsi(m.LParam);
                    m_unit_forms[(int)m.WParam].UpdateStatus(s);
                    PTest.Lib_FreeMem(m.LParam);
                    break;

                case PTest.WM_PROGRESS_UPDATE:
                    m_unit_forms[(int)m.WParam].UpdateProgress((int)m.LParam);
                    break;

                case PTest.WM_PROGRESS_RANGE:
                    m_unit_forms[(int)m.WParam].SetRangeProgress((int)m.LParam);
                    break;

                case PTest.WM_PROGRESS_MAX:
                    m_unit_forms[(int)m.WParam].SetMaxProgress();
                    break;

                case PTest.WM_PROGRESS_TEXT:
                    s = Marshal.PtrToStringAnsi(m.LParam);
                    m_unit_forms[(int)m.WParam].SetTextProgress(s);
                    PTest.Lib_FreeMem(m.LParam);
                    break;

                case PTest.WM_SET_INFO:
                    if (m_show_detail)
                    {
                        s = Marshal.PtrToStringAnsi(m.LParam);
                        m_detail_forms[(int)m.WParam].SetInfo(s);
                    }
                    PTest.Lib_FreeMem(m.LParam);
                    break;

                case PTest.WM_CLEAR_INFO:
                    if (m_show_detail)
                    {
                        m_detail_forms[(int)m.WParam].ClearInfo();
                    }
                    break;

                case PTest.WM_POPUP_INPUT_FORM:
                    char[] sep = { Convert.ToChar(0x7f) };
                    s = Marshal.PtrToStringAnsi(m.LParam);
                    string[] ret = s.Split(sep, StringSplitOptions.None);
                    m_unit_forms[Convert.ToInt32(ret[0])].SetFormFocus();
                    InputForm2 inputfrm = new InputForm2(ret[1], ret[2], ret[3], ret[4], ret[5], ret[6]);
                    inputfrm.ShowDialog();
                    PTest.Lib_BackFormData(inputfrm.GetData1, inputfrm.GetData2, inputfrm.GetData3);
                    PTest.Lib_SetEvent(m.WParam);
                    PTest.Lib_FreeMem(m.LParam);
                    break;

                case PTest.WM_ZIP_FILE:
                    char[] sep2 = { Convert.ToChar(0x7f) };
                    s = Marshal.PtrToStringAnsi(m.LParam);
                    ret = s.Split(sep2, StringSplitOptions.None);
                    zip_file(ret[1], ret[2]);
                    PTest.Lib_SetEvent(m.WParam);
                    PTest.Lib_FreeMem(m.LParam);
                    break;

                case PTest.WM_PIC_MSG_FORM:
                    char[] pic_msg_sep = { Convert.ToChar(0x7f) };
                    s = Marshal.PtrToStringAnsi(m.LParam);
                    string[] pic_msg_args = s.Split(pic_msg_sep, StringSplitOptions.None);
                    m_unit_forms[Convert.ToInt32(pic_msg_args[0])].SetFormFocus();
                    string hintText = String.Format("[{0}]{1}", pic_msg_args[1], pic_msg_args[3]);
                    int btn_num = Convert.ToInt32(pic_msg_args[4]);

                    pic_msg_box = new PicMsgForm(pic_msg_args[2], hintText, btn_num);
                    pic_msg_box.StartPosition = FormStartPosition.CenterScreen;
                    //if btn_num = -1 => only show image
                    if (btn_num >= 0)
                    {
                        DialogResult res = pic_msg_box.ShowDialog();
                        PTest.Lib_BackFormData(pic_msg_box.GetFormReturn, "", "");
                        PTest.Lib_SetEvent(m.WParam);
                        PTest.Lib_FreeMem(m.LParam);
                    }
                    else
                    {
                        //susu add 20241004
                        pic_msg_box.Show();
                    }
                    break;
                //susu add 20241004
                case PTest.WM_PIC_MSG_FORM_CLOSE:
                    pic_msg_box.Close();
                    pic_msg_box.Dispose();
                    break;
            }
            base.WndProc(ref m);
        }

        public void InputEdit_KeyDown(object sender, KeyEventArgs e)
        {
            if (/*(e.KeyCode == Keys.Tab) ||*/ (e.KeyCode == Keys.Return))
            {
                Control next_ctrl = flowLayoutPanel1.GetNextControl((sender as Control).Parent, true);
                Control Unit_next_ctrl = flowLayoutPanel2.GetNextControl((sender as Control).Parent, true);
                if ((sender as Control) is TextBox)
                {
                    if (((sender as Control).Parent as InputForm).IsValid() == false)
                    {
                        MessageBox.Show("The input data(format) is wrong!");
                        (sender as TextBox).SelectAll();
                        return;
                    }
                }

                if (next_ctrl == null)
                {
                    Unit_next_ctrl.SelectNextControl(next_ctrl, true, true, false, true);

                    foreach (Control Unit_co in Unit_next_ctrl.Controls)
                    {
                        if (Unit_co is UnitInfoForm)
                        {
                            foreach (UnitInfoForm uif in m_unit_forms)
                            {
                                //uif.ButtonStartClick();
                                uif.SetButtonFocus();
                            }
                        }
                    }
                }
                else
                {
                    next_ctrl.SelectNextControl(next_ctrl, true, true, false, true);

                    foreach (Control co in next_ctrl.Controls)
                    {
                        if (co is UnitInfoForm)
                        {
                            foreach (UnitInfoForm uif in m_unit_forms)
                            {
                                //uif.ButtonStartClick();
                                uif.SetButtonFocus();
                            }
                        }
                    }
                }
            }
        }

        public void StartTest(int id_no, string id_name)
        {
            byte[] sep = new byte[] { 0x7f };
            string input_data = "";

            foreach (InputForm infrm in m_input_forms)
            {
                if (infrm.IsValid() == false)
                {
                    MessageBox.Show("The input data(format) is wrong!");
                    m_unit_forms[id_no].EnableButton(true);
                    infrm.SelectAll();
                    return;
                }

                if (input_data.Length == 0)
                    input_data = infrm.GetData();
                else
                    input_data = input_data + System.Text.Encoding.ASCII.GetString(sep) + infrm.GetData();
            }

            PTest.Lib_StartTest(id_no, id_name, (int)m_test_mode, input_data);

            foreach (InputForm infrm in m_input_forms)
                infrm.ClearData();

            // move to next focus
            foreach (UnitInfoForm uif in m_unit_forms)
            {
                if (m_unit_forms.IndexOf(uif) > id_no && uif.IsButtonEnable())
                {
                    uif.SetFormFocus();
                    break;
                }
                if (m_unit_forms.IndexOf(uif) == id_no)
                    m_unit_forms[0].SetFormFocus();
            }
            SetInputFocus();
        }

        public void MultiStartTest(int id_no, string id_name, string input_data)
        {
            PTest.Lib_StartTest(id_no, id_name, (int)m_test_mode, input_data);
        }

        public void TabPageTop(int no)
        {
            if (m_show_detail == true)
                this.tabControlDetail.SelectedIndex = no;
        }

        public void ClearFocus()
        {
            foreach (UnitInfoForm uif in m_unit_forms)
            {
                uif.BackColor = Control.DefaultBackColor;
                uif.CurrentFocus = false;
            }
        }

        public void SetInputFocus()
        {
            if (m_input_forms.Count != 0)
                m_input_forms[0].SetFocus();
        }

        public bool AreAllButtonEnable()
        {
            bool is_btn_enable = true;

            foreach (UnitInfoForm uif in m_unit_forms)
            {
                if (uif.IsButtonEnable() != true)
                {
                    is_btn_enable = false;
                    break;
                }
            }

            return is_btn_enable;
        }

        private void tabControlDetail_SelectedIndexChanged(object sender, EventArgs e)
        {
            TabControl.TabPageCollection tpc = this.tabControlDetail.TabPages;
            foreach (TabPage tp in tpc)
            {
                tp.Text = (string)tp.Tag;
            }

            this.tabControlDetail.SelectedTab.Text = "*" + this.tabControlDetail.SelectedTab.Text;
        }

        private void show_dll_version()
        {
            System.Diagnostics.FileVersionInfo myFileVersionInfo = System.Diagnostics.FileVersionInfo.GetVersionInfo(Path.GetDirectoryName(Application.ExecutablePath) + "\\pegalib.dll");
            this.toolStripStatusLabel3.Text = "pegalib.dll:" + myFileVersionInfo.FileVersion;
        }

        private void show_scenario_file(string file)
        {
            this.toolStripStatusLabel4.Text = Path.GetFileNameWithoutExtension(file);
        }

        private void show_criteria_file(string file)
        {
            this.toolStripStatusLabel5.Text = Path.GetFileNameWithoutExtension(file);
        }

        private void show_config_file(string file)
        {
            this.toolStripStatusLabel6.Text = Path.GetFileNameWithoutExtension(file);
        }
		
        private void zip_file(string src_name, string dest_name)
        {
            try
            {
                ZipFile.CreateFromDirectory(src_name, dest_name);
            }
            catch (System.ArgumentException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            catch (System.IO.PathTooLongException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            catch (System.IO.DirectoryNotFoundException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            catch (System.IO.IOException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            catch (System.UnauthorizedAccessException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
            catch (System.NotSupportedException e)
            {
                MessageBox.Show("Exception caught:" + e);
            }
        }

        [DllImport("Kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern int GetPrivateProfileStringW(String AppName, String KeyName, String Default, [Out] StringBuilder ret, Int32 size, String FileName);

        [DllImport("Kernel32.dll", CharSet = CharSet.Unicode)]
        private static extern bool WritePrivateProfileStringW(String AppName, String KeyName, String Value, String FileName);
        
        private void GetAndShowPcDescription()
        {
            string device_id = "";
            string computerDescription = (string)Registry.GetValue(@"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\lanmanserver\parameters", "srvcomment", null);
            if (computerDescription != null)
            {
                if (computerDescription.Split('-').Length == 2)
                {
                    if (computerDescription.Split('-')[1].Length == 6)
                    {
                        if (Regex.IsMatch(computerDescription.Split('-')[1], @"^[0-9]{6}"))
                        {
                            device_id = computerDescription.Split('-')[1];

                            string name = Path.GetDirectoryName(Application.ExecutablePath) + "\\SFIS.ini";
                            WritePrivateProfileStringW("SFIS_SETTING", "SFIS_DEVICE_ID", computerDescription.Split('-')[1], name);
                            this.toolStripStatusLabel1.Text = "Device ID: " + device_id;
                            m_device_id = device_id.ToString();
                        }
                    }
                }

                if (device_id.Length == 0)
                {
                    MessageBox.Show("PC Description: Device ID format error\n[Format]: XXX-123456\nDevice ID must be 6 digital", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("PC Description data not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }



        private void ShowDeviceId()
        {
            string name = Path.GetDirectoryName(Application.ExecutablePath) + "\\SFIS.ini";
            StringBuilder sb = new StringBuilder(200);
            GetPrivateProfileStringW("SFIS_SETTING", "SFIS_DEVICE_ID", "default", sb, sb.Capacity, name);
            this.toolStripStatusLabel1.Text = "Device ID: " + sb.ToString();
            m_device_id = sb.ToString();
        }

    }
}
