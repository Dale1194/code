﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;

namespace MultiTest
{
    class LastSetting
    {
        String m_path = string.Format("{0}\\private.data", Path.GetDirectoryName(Application.ExecutablePath));
        private SettingItems m_settings;

        private static volatile LastSetting obj_;
        private static object syncRoot_ = new Object();

        private LastSetting()
        {
            ReadObjFromFile();
        }

        public static LastSetting GetInstance()
        {
            if (obj_ == null)
            {
                lock (syncRoot_)
                {
                    if (obj_ == null)
                        obj_ = new LastSetting();
                }
            }

            return obj_;
        }

        private void SaveObjToFile()
        {
            Stream stream_file = File.Create(m_path);
            BinaryFormatter serializer = new BinaryFormatter();
            serializer.Serialize(stream_file, m_settings);
            stream_file.Close();
        }

        private void ReadObjFromFile()
        {
            if (File.Exists(m_path))
            {
                Stream stream_file = File.OpenRead(m_path);
                BinaryFormatter serializer = new BinaryFormatter();
                m_settings = (SettingItems)serializer.Deserialize(stream_file);
                stream_file.Close();
            }
            else
            {
                m_settings = new SettingItems();
            }
        }

        public string TestMode
        {
            get { return m_settings.m_test_mode; }
            set
            {
                m_settings.m_test_mode = value;
                SaveObjToFile();
            }
        }

        public string LoginId
        {
            get { return m_settings.m_login_id; }
            set
            {
                m_settings.m_login_id = value;
                SaveObjToFile();
            }
        }

        public string ScenarioFile
        {
            get { return m_settings.m_scenario_file; }
            set
            {
                m_settings.m_scenario_file = value;
                SaveObjToFile();
            }
        }

        public string ConfigFile
        {
            get { return m_settings.m_config_file; }
            set
            {
                m_settings.m_config_file = value;
                SaveObjToFile();
            }
        }

        public string CriteriaFile
        {
            get { return m_settings.m_criteria_file; }
            set
            {
                m_settings.m_criteria_file = value;
                SaveObjToFile();
            }
        }

        public TestCount GetTestCount(string name)
        {
            TestCount tc;
            if (m_settings.m_test_count.TryGetValue(name, out tc) == false)
            {
                tc = new TestCount();
                m_settings.m_test_count[name] = tc;
                SaveObjToFile();
            }

            return tc;
        }

        public void SetTestCount(string name, TestCount tc)
        {
            m_settings.m_test_count[name] = tc;
            SaveObjToFile();
        }
    }

    [Serializable]
    class SettingItems
    {
        public string m_scenario_file = "";
        public string m_config_file = "";
        public string m_criteria_file = "";
        public string m_test_mode = "SFIS &online";
        public string m_login_id = "W10931390";
        public Dictionary<string, TestCount> m_test_count = new Dictionary<string, TestCount>();
    }


    [Serializable]
    class TestCount
    {
        public uint total = 0;
        public uint pass = 0;
        public uint fail = 0;

        public TestCount() { }

        public TestCount(uint t, uint p, uint f)
        {
            total = t;
            pass = p;
            fail = f;
        }
    }
}
