﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiTest
{
    public partial class SfisLoginForm : Form
    {
        public SfisLoginForm()
        {
            InitializeComponent();
        }

        private void SfisLogin_Load(object sender, EventArgs e)
        {
            this.textBoxId.Text = LastSetting.GetInstance().LoginId;

            this.AcceptButton = this.btnLogin;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            LastSetting.GetInstance().LoginId = this.textBoxId.Text;
            
            if (PTest.Lib_SFISLogin(this.textBoxId.Text) == 0)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            LastSetting.GetInstance().LoginId = this.textBoxId.Text;

            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
