﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MultiTest
{
    public partial class ScenarioForm : Form
    {
        private Form1 m_main_form = null;
        string[] scenario_files;
        string[] config_files;
        string[] criteria_files;
        string m_selected_project = null;
        string m_selected_station = null;

        public ScenarioForm(Form1 main_form)
        {
            InitializeComponent();
            this.m_main_form = main_form;
        }

        private void ScenarioForm_Load(object sender, EventArgs e)
        {
            config_file_list();

            this.AcceptButton = this.btnOK;

            //this.textBoxId.Text = LastSetting.GetInstance().LoginId;
        }

        private void ScenarioForm_Shown(object sender, EventArgs e)
        {
            this.textBoxId.Focus();
        }

        private void config_file_list()
        {
            int selected_idx = 0;
            string path = Path.GetDirectoryName(Application.ExecutablePath) + "\\";
            config_files = System.IO.Directory.GetFiles(path, "Config*.ini");

            foreach (string f in config_files)
            {
                FileInfo fi = new FileInfo(f);
                this.comboBoxConfig.Items.Add(fi.Name);

                if (LastSetting.GetInstance().ConfigFile == f)
                {
                    this.comboBoxConfig.SelectedIndex = selected_idx;
                }
                selected_idx++;
            }

        }

        private void scenario_file_list()
        {
            int selected_idx = 0;
            string path = Path.GetDirectoryName(Application.ExecutablePath) + "\\";
            string file = "Scenario_" + m_selected_project + "_" + m_selected_station + "*.ini";
            scenario_files = System.IO.Directory.GetFiles(path, file);

            comboBoxScenario.Items.Clear();
            comboBoxScenario.ResetText();

            if (scenario_files.Length == 0)
            {
                MessageBox.Show("Can not find any scenario file.\n" + file);
                return;
            }

            foreach (string f in scenario_files)
            {
                FileInfo fi = new FileInfo(f);
                this.comboBoxScenario.Items.Add(fi.Name);

                if (LastSetting.GetInstance().ScenarioFile == f)
                {
                    this.comboBoxScenario.SelectedIndex = selected_idx;
                }
                selected_idx++;
            }

        }
        
        private void criteria_file_list()
        {
            int selected_idx = 0;
            string path = Path.GetDirectoryName(Application.ExecutablePath) + "\\";
            string file = "Criteria_" + m_selected_project + "_" + m_selected_station + "*.csv";
            criteria_files = System.IO.Directory.GetFiles(path, file);

            comboBoxCriteria.Items.Clear();
            comboBoxCriteria.ResetText();

            if (criteria_files.Length == 0)
            {
                MessageBox.Show("Can not find any criteria file.\n" + file);
                return;
            }

            foreach (string f in criteria_files)
            {
                FileInfo fi = new FileInfo(f);
                this.comboBoxCriteria.Items.Add(fi.Name);

                if (LastSetting.GetInstance().CriteriaFile == f)
                {
                    this.comboBoxCriteria.SelectedIndex = selected_idx;
                }
                selected_idx++;
            }

        }

        
        private void btnOK_Click(object sender, EventArgs e)
        {
            bool have_selected = false;

            have_selected = this.comboBoxConfig.SelectedIndex == -1 ? false : true;
            have_selected = have_selected && (this.comboBoxScenario.SelectedIndex == -1 ? false : true);
            have_selected = have_selected && (this.comboBoxCriteria.SelectedIndex == -1 ? false : true);
            
            if (have_selected == true)
            {
                LastSetting.GetInstance().LoginId = this.textBoxId.Text;
                LastSetting.GetInstance().ConfigFile = config_files[this.comboBoxConfig.SelectedIndex];
                LastSetting.GetInstance().ScenarioFile = scenario_files[this.comboBoxScenario.SelectedIndex];
                LastSetting.GetInstance().CriteriaFile = criteria_files[this.comboBoxCriteria.SelectedIndex];

                PTest.Lib_Init(this.m_main_form.Handle, LastSetting.GetInstance().ScenarioFile, LastSetting.GetInstance().ConfigFile, LastSetting.GetInstance().CriteriaFile);
                PTest.Lib_SFISInit(this.textBoxId.Text);

                if (PTest.Lib_SFISLogin(this.textBoxId.Text) == 0)
                {
                    LastSetting.GetInstance().TestMode = "ON-LINE";
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
        }

        private void btnOffline_Click(object sender, EventArgs e)
        {
            bool have_selected = false;

            have_selected = this.comboBoxConfig.SelectedIndex == -1 ? false : true;
            have_selected = have_selected && (this.comboBoxScenario.SelectedIndex == -1 ? false : true);
            have_selected = have_selected && (this.comboBoxCriteria.SelectedIndex == -1 ? false : true);

            if (have_selected == true)
            {
                LastSetting.GetInstance().LoginId = this.textBoxId.Text;
                LastSetting.GetInstance().ConfigFile = config_files[this.comboBoxConfig.SelectedIndex];
                LastSetting.GetInstance().ScenarioFile = scenario_files[this.comboBoxScenario.SelectedIndex];
                LastSetting.GetInstance().CriteriaFile = criteria_files[this.comboBoxCriteria.SelectedIndex];
                LastSetting.GetInstance().TestMode = "OFF-LINE";

                PTest.Lib_Init(this.m_main_form.Handle, LastSetting.GetInstance().ScenarioFile, LastSetting.GetInstance().ConfigFile, LastSetting.GetInstance().CriteriaFile);
                PTest.Lib_SFISInit(this.textBoxId.Text);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        public string File_Selected()
        {
            return scenario_files[this.comboBoxScenario.SelectedIndex];
        }

        public string Criteria_File_Selected()
        {
            return criteria_files[this.comboBoxCriteria.SelectedIndex];
        }

        public string Config_File_Selected()
        {
            return config_files[this.comboBoxConfig.SelectedIndex];
        }

        private void comboBoxConfig_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.comboBoxConfig.SelectedIndex == -1)
                return;

            string jsonText="";
            try
            {
                jsonText = System.IO.File.ReadAllText(config_files[this.comboBoxConfig.SelectedIndex]);
            }
            catch (System.ArgumentNullException ex)
            {
                MessageBox.Show("Exception caught:" + ex);
            }
            catch (System.IO.FileNotFoundException ex)
            {
                MessageBox.Show("Exception caught:" + ex);
            }
            catch (System.IO.PathTooLongException ex)
            {
                MessageBox.Show("Exception caught:" + ex);
            }

            if (jsonText == "")
                return;

            JObject jo = (JObject)JsonConvert.DeserializeObject(jsonText);
            JObject init_setting = (JObject)jo["Initial_Setting"];
            m_selected_project = init_setting["PROJECT_NAME"].ToString();
            m_selected_station = init_setting["STATION_ID"].ToString();

            scenario_file_list();
            criteria_file_list();
        }

        private void textBoxId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
