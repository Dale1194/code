﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MultiTest
{
    public partial class PicMsgForm : Form
    {
        string m_form_ret;
        public string GetFormReturn { 
            get {
                switch (this.DialogResult)
                {
                    case DialogResult.None:
                        this.m_form_ret = "None";
                        break;
                    case DialogResult.OK:
                        this.m_form_ret = "OK";
                        break;
                    case DialogResult.Cancel:
                        this.m_form_ret = "Cancel";
                        break;
                    case DialogResult.Abort:
                        this.m_form_ret = "Abort";
                        break;
                    case DialogResult.Retry:
                        this.m_form_ret = "Retry";
                        break;
                    case DialogResult.Ignore:
                        this.m_form_ret = "Ignore";
                        break;
                    case DialogResult.Yes:
                        this.m_form_ret = "Yes";
                        break;
                    case DialogResult.No:
                        this.m_form_ret = "No";
                        break;
                    default:
                        this.m_form_ret = "default";
                        break;
                } 
                return this.m_form_ret;
            }
        }
        public PicMsgForm()
        {
            InitializeComponent();
        }
        public PicMsgForm(string hintPic, string hintText, int btn_num)
        {
            InitializeComponent();

            string pic_src = Path.Combine(Directory.GetCurrentDirectory(), "pics", hintPic);
            //MessageBox.Show(pic_src);
            if (File.Exists(pic_src))
            {
                //MessageBox.Show("path ok");
                this.hintPic.ImageLocation = pic_src;
                this.hintPic.SizeMode = PictureBoxSizeMode.Zoom;

                this.btnYes.Text = "是(Y)";
                this.btnNo.Text = "否(N)";
                this.btnRetry.Text = "重試(R)";
                //this.btnRetry.Enabled = false;

                switch (btn_num)
                {
                    case -1:
                        this.btnRetry.Enabled = false;
                        this.btnRetry.Text = "";
                        this.btnNo.Enabled = false;
                        this.btnNo.Text = "";
                        this.btnYes.Enabled = false;
                        this.btnYes.Text = "";
                        break;
                    case 1:
                        this.btnRetry.Enabled = false;
                        this.btnRetry.Text = "";
                        this.btnNo.Enabled = false;
                        this.btnNo.Text = "";
                        break;
                    case 2:
                        this.btnRetry.Enabled = false;
                        this.btnRetry.Text = "";
                        break;
                    case 3:
                        break;
                }
            }
            else
            {
                MessageBox.Show("path fail");
            }
            this.hintText.Text = hintText;

            this.btnHoldFocus.Focus();
            //
            this.MinimumSize = this.Size;
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Yes;
            //this.m_form_ret = DialogResult.Yes.ToString();
            this.Close();
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.No;
            this.Close();
        }

        private void btnRetry_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Retry;
            this.Close();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            KeyEventArgs e = new KeyEventArgs(keyData);
            switch (e.KeyCode)
            {
                case Keys.Y:
                    if (this.btnYes.Enabled)
                    {
                        this.btnYes_Click(null, e);
                    }
                    break;
                case Keys.N:
                    if (this.btnNo.Enabled)
                    {
                        this.btnNo_Click(null, e);
                    }
                    break;
                case Keys.R:
                    if (this.btnRetry.Enabled)
                    {
                        this.btnRetry_Click(null, e);
                    }
                    break;
            }
            
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
